# SPDX-License-Identifier: AGPL-3.0-or-later
# shellcheck shell=bash
# shellcheck disable=SC2034  # variables are consumed by the sourcing scripts
# Shared setup for the guest Linux image scripts. Source from
# consonance/harmony-linux/linux/ with CWD = consonance/harmony-linux/linux/. Every entry point selects
# its native build host explicitly: the established x86 image uses Linux/x86_64;
# the AA-5(c) image uses the validated native Linux/aarch64 host (msr1).

# shellcheck source=../scripts/lib.sh disable=SC1091
. ../scripts/lib.sh
# shellcheck source=versions.lock disable=SC1091
. ./versions.lock

# Fail fast (never skip silently) when not on Linux/x86_64.
require_linux_amd64() {
    if [ "$(uname -s)" != "Linux" ] || [ "$(uname -m)" != "x86_64" ]; then
        echo "FAIL: the guest Linux image builds and tests only on Linux/x86_64." >&2
        echo "      On macOS run it in a linux/amd64 container — see CONTRIBUTING.md." >&2
        exit 1
    fi
}

# Fail fast (never cross-build silently) when the AA-5(c) artifacts are not
# being built on the pinned Linux/aarch64 execution host. Native builds keep
# the compiler and absolute build paths inside the recorded box contract.
require_linux_aarch64() {
    if [ "$(uname -s)" != "Linux" ] || [ "$(uname -m)" != "aarch64" ]; then
        echo "FAIL: the AA-5(c) guest image builds only on Linux/aarch64." >&2
        echo "      Run it natively on the validated Linux/aarch64 host (msr1)." >&2
        exit 1
    fi
}

# require_tools <tool...>: fail fast with the install hint if any is missing.
require_tools() {
    missing=""
    for t in "$@"; do
        command -v "$t" >/dev/null 2>&1 || missing="$missing $t"
    done
    if [ -n "$missing" ]; then
        echo "FAIL: missing host tools:$missing" >&2
        echo "      install the required Debian build packages before retrying" >&2
        exit 1
    fi
}

GUEST_DIR=$(cd .. && pwd)
LINUX_DIR=$GUEST_DIR/linux
DL_DIR=${HARMONY_DOWNLOAD_DIR:-$GUEST_DIR/dl}
# Final artifacts live on the repo side so they survive the container session.
ART_DIR=${HARMONY_ARTIFACT_DIR:-$GUEST_DIR/build}
# Architecture-qualified production artifacts never overwrite one another.
X86_64_ART_DIR=$ART_DIR/x86_64
AARCH64_ART_DIR=$ART_DIR/aarch64
ARM64_ART_DIR=$AARCH64_ART_DIR

# Build trees live at a fixed absolute path on a native filesystem:
# - fixed, so absolute paths are identical between the two reproducibility
#   builds (the kernel embeds none, but O= must not differ);
# - native (not the bind-mounted repo), because the repo may sit on a
#   case-insensitive macOS filesystem, and a kernel tree cannot be extracted
#   onto one (case-colliding header names).
BUILD_ROOT=${GUEST_BUILD_ROOT:-/tmp/harmony-linux-build}

KSRC=$BUILD_ROOT/linux-$KERNEL_VERSION
KOBJ=$BUILD_ROOT/kernel-build
BBSRC=$BUILD_ROOT/busybox-$BUSYBOX_VERSION
BBOBJ=$BUILD_ROOT/busybox-build
ARM64_KOBJ=$BUILD_ROOT/kernel-build-arm64
MUSLSRC=$BUILD_ROOT/musl-$MUSL_VERSION
X86_MUSL_SRC=$BUILD_ROOT/musl-x86-src
X86_MUSL_PREFIX=$BUILD_ROOT/musl-x86-prefix
ARM64_MUSL_SRC=$BUILD_ROOT/musl-arm64-src
ARM64_MUSL_PREFIX=$BUILD_ROOT/musl-arm64-prefix

# Reproducibility levers (task spec): fixed timestamp/user/host/version, fixed
# SOURCE_DATE_EPOCH, no kconfig header timestamps. LOCALVERSION is fixed in
# the config fragment (empty, LOCALVERSION_AUTO=n).
export KBUILD_BUILD_TIMESTAMP='Thu Jan  1 00:00:00 UTC 1970'
export KBUILD_BUILD_USER=harmony
export KBUILD_BUILD_HOST=harmony
export KBUILD_BUILD_VERSION=1
export SOURCE_DATE_EPOCH=0
export KCONFIG_NOTIMESTAMP=1

# Build the clean-room compatibility library at a fixed native path. Image
# builders use the same bytes and install them at the SDK ABI path.
build_libvoidstar() {
    make -C "$GUEST_DIR/libvoidstar" BUILD_DIR="$BUILD_ROOT/libvoidstar-build" all
}

# install_libvoidstar <rootfs>
install_libvoidstar() {
    rootfs=${1:?install_libvoidstar requires a rootfs}
    build_libvoidstar
    mkdir -p "$rootfs/usr/lib"
    install -m 0755 "$BUILD_ROOT/libvoidstar-build/libvoidstar.so" \
        "$rootfs/usr/lib/libvoidstar.so"
}

# verify_and_extract <tarball> <sha256> <target-dir>: hash-check the download
# (always — "verify the hash before building") and extract it under
# BUILD_ROOT if the source tree is not already there.
verify_and_extract() {
    tarball=$1
    sha=$2
    dir=$3
    if [ ! -f "$tarball" ]; then
        echo "FAIL: $tarball missing — run 'make -C consonance/harmony-linux fetch' first (needs network once)" >&2
        exit 1
    fi
    got=$(sha256_of "$tarball")
    if [ "$got" != "$sha" ]; then
        echo "FAIL: $tarball sha256 mismatch (want $sha, got $got)" >&2
        exit 1
    fi
    if [ ! -d "$dir" ]; then
        mkdir -p "$BUILD_ROOT"
        tar -xf "$tarball" -C "$BUILD_ROOT"
    fi
}

extract_kernel() {
    verify_and_extract "$DL_DIR/$(basename "$KERNEL_URL")" "$KERNEL_SHA256" "$KSRC"
}

extract_busybox() {
    verify_and_extract "$DL_DIR/$(basename "$BUSYBOX_URL")" "$BUSYBOX_SHA256" "$BBSRC"
}

extract_runc_source() {
    local destination=$BUILD_ROOT/runc-$RUNC_VERSION
    rm -rf "$destination"
    verify_and_extract "$DL_DIR/$(basename "$RUNC_SOURCE_URL")" "$RUNC_SOURCE_SHA256" "$destination"
    local runc_patch
    for runc_patch in "$LINUX_DIR"/patches/runc/*.patch; do
        patch -d "$destination" --batch --forward -p1 <"$runc_patch" >/dev/null
    done
}

verify_static_runc() {
    local binary=$1
    local arch=$2
    local machine
    [ -f "$binary" ] || {
        echo "FAIL: pinned runc asset is not a regular file: $binary" >&2
        exit 1
    }
    machine=$(readelf -h "$binary" | sed -n 's/^  Machine: *//p')
    case "$arch:$machine" in
        x86_64:*'Advanced Micro Devices X86-64'*) ;;
        aarch64:*'AArch64'*) ;;
        *)
            echo "FAIL: pinned runc architecture mismatch: $binary ($machine)" >&2
            exit 1
            ;;
    esac
    if readelf -l "$binary" | grep -q ' INTERP '; then
        echo "FAIL: pinned runc is dynamically linked: $binary" >&2
        exit 1
    fi
}

# BusyBox invokes `/bin/pwd` while computing its source/output roots. Pure Nix
# builders deliberately have no ambient /bin, so make the hash-verified source
# use the pinned `pwd` from PATH. The operation is idempotent because several
# guest profiles can share one fresh extraction.
prepare_busybox_build_source() {
    local anchor_count
    anchor_count=$(grep -c '/bin/pwd' "$BBSRC/Makefile" || true)
    case "$anchor_count" in
        1)
            sed 's#/bin/pwd#pwd#' "$BBSRC/Makefile" >"$BBSRC/Makefile.tmp"
            mv "$BBSRC/Makefile.tmp" "$BBSRC/Makefile"
            ;;
        0)
            grep -Fqx "KBUILD_OUTPUT := \$(shell cd \$(KBUILD_OUTPUT) && pwd)" \
                "$BBSRC/Makefile" || {
                echo "FAIL: BusyBox pwd anchor changed" >&2
                exit 1
            }
            ;;
        *)
            echo "FAIL: BusyBox has $anchor_count /bin/pwd anchors" >&2
            exit 1
            ;;
    esac
}

extract_musl() {
    verify_and_extract "$DL_DIR/$(basename "$MUSL_URL")" "$MUSL_SHA256" "$MUSLSRC"
}

# build_musl <source-dir> <prefix> <cflags> [patch...]: build the static
# userspace C runtime from pristine pinned source on every run. Platform
# executables link this musl instead of the host libc, so a host libc update
# cannot change the shipped bytes.
build_musl() {
    local source_dir=$1 prefix=$2 cflags=$3 musl_patch
    shift 3
    extract_musl
    rm -rf "$source_dir" "$prefix"
    cp -a "$MUSLSRC" "$source_dir"
    for musl_patch in "$@"; do
        patch -d "$source_dir" --batch -p1 <"$musl_patch"
    done
    (
        cd "$source_dir" || exit
        CC=cc CFLAGS=$cflags ./configure --prefix="$prefix" --disable-shared >/dev/null
        make -j"$(nproc)" >/dev/null
        make install >/dev/null
    )
    [ -x "$prefix/bin/musl-gcc" ] || {
        echo "FAIL: musl compiler wrapper was not installed in $prefix" >&2
        exit 1
    }
    [ -f "$prefix/lib/libc.a" ] || {
        echo "FAIL: static musl runtime was not installed in $prefix" >&2
        exit 1
    }
}

build_x86_musl() {
    build_musl "$X86_MUSL_SRC" "$X86_MUSL_PREFIX" '-O2 -march=x86-64'
}

# The upstream aarch64 atomics use LL/SC directly, so the Harmony-only patch
# replaces their public CAS primitives with acquire-release LSE CAS.
build_arm64_musl() {
    build_musl "$ARM64_MUSL_SRC" "$ARM64_MUSL_PREFIX" \
        '-O2 -march=armv8.1-a+lse -mno-outline-atomics' \
        "$LINUX_DIR/patches/musl/0001-aarch64-harmony-lse-only-atomics.patch"
}

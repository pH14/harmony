#!/usr/bin/env bash
# SPDX-License-Identifier: AGPL-3.0-or-later
# Build the pinned guest kernel: a vendored **Kata Containers guest-kernel config**
# (kata/, the container-host base) + the **determinism overlay** (config-fragment),
# merged on top so it wins, out-of-tree at a fixed O= path, with all reproducibility
# levers set (see lib-build.sh). The base was rebased from `tinyconfig` to Kata's
# config; the overlay is unchanged in intent. See consonance/harmony-linux/linux/README.md.
set -euo pipefail

cd "$(dirname "$0")"

# shellcheck source=lib-build.sh disable=SC1091
. ./lib-build.sh

require_linux_amd64
require_tools cc make flex bison bc xz gzip

# Each profile variable names one published artifact and one reviewed
# counter-opcode baseline, so a build that claimed both would publish a kernel
# under a label that does not describe it.
profiles=0
for profile in "${N6_TRAPS_OFF:-}" "${TASK_PARK_PROFILE:-}" "${NESTED_HOST_PROFILE:-}"; do
    if [ -n "$profile" ]; then profiles=$((profiles + 1)); fi
done
if [ "$profiles" -gt 1 ]; then
    echo "FAIL: N6_TRAPS_OFF, TASK_PARK_PROFILE and NESTED_HOST_PROFILE select different kernels; set one" >&2
    exit 1
fi

extract_kernel

# Apply the architecture-independent transport first, then the x86 overlay.
# Each directory is ordered lexically by apply-patch-series.sh and the stamp
# records both directory and file names, so a changed common or arch patch
# cannot be mistaken for an already prepared source tree.
bash "$LINUX_DIR/apply-patch-series.sh" "$KSRC" \
    "$LINUX_DIR/patches/common" "$LINUX_DIR/patches/x86"

mkdir -p "$KOBJ" "$ART_DIR"

# Base = Kata guest-kernel config. Kata builds from `allnoconfig` + its fragments
# (its build-kernel.sh passes merge_config.sh -n), so seed with allnoconfig — NOT
# tinyconfig (whose tiny.config size-optimization deltas are not part of Kata's
# config). Then merge, in one pass, the Kata fragments (the container-host base)
# followed by config-fragment (the determinism overlay) LAST so it overrides every
# conflict (SMP/NUMA/KASLR/HZ/HW_RANDOM/... -> off). olddefconfig resolves deps.
echo "== kernel: Kata guest-kernel config (kata/, pinned $(sed -n 's/^- *Release: *//p' kata/PROVENANCE | head -1)) + determinism overlay (linux-$KERNEL_VERSION)"
make -C "$KSRC" O="$KOBJ" ARCH=x86_64 allnoconfig
(cd "$KSRC" && ./scripts/kconfig/merge_config.sh -m -O "$KOBJ" \
    "$KOBJ/.config" \
    "$LINUX_DIR"/kata/common/*.conf \
    "$LINUX_DIR"/kata/x86_64/*.conf \
    "$LINUX_DIR/config-fragment" \
    ${N6_TRAPS_OFF:+"$LINUX_DIR/x86-n6-traps-off-config-fragment"} \
    ${TASK_PARK_PROFILE:+"$LINUX_DIR/x86-task-park-config-fragment"} \
    ${NESTED_HOST_PROFILE:+"$LINUX_DIR/x86-nested-host-config-fragment"})
make -C "$KSRC" O="$KOBJ" ARCH=x86_64 olddefconfig

# merge_config only warns when a fragment symbol cannot take effect; assert the ones
# the image cannot work without (or that determinism cannot lose). Crucially, every
# determinism symbol in the overlay must SURVIVE the merge against the *richer* Kata
# base, which sets several of them the other way (SMP=y, NO_HZ_FULL=y, CPU_FREQ=y,
# RANDOMIZE_BASE=y, X86_PM_TIMER=y, HW_RANDOM=y, ...). Assert each, loudly.
assert_y() {
    for sym in "$@"; do
        if ! grep -qxF "CONFIG_$sym=y" "$KOBJ/.config"; then
            echo "FAIL: CONFIG_$sym=y did not survive merge_config/olddefconfig" >&2
            exit 1
        fi
    done
}
assert_off() {
    for sym in "$@"; do
        if grep -q "^CONFIG_$sym=" "$KOBJ/.config"; then
            echo "FAIL: CONFIG_$sym is enabled but must be off" >&2
            exit 1
        fi
    done
}
# Functional must-haves for the boot-to-/init image (provided by Kata and/or overlay).
# The shipped guest requires the Harmony clock interface at every boot.
assert_y 64BIT PRINTK TTY SERIAL_8250 SERIAL_8250_CONSOLE BINFMT_ELF \
    BINFMT_SCRIPT BLK_DEV_INITRD RD_GZIP PROC_FS PROC_CHILDREN SYSFS DEVTMPFS ACPI PCI \
    HZ_PERIODIC HZ_100 FUTEX POSIX_TIMERS KERNEL_GZIP X86_IOPL_IOPERM DEVMEM \
    HARMONY_PVCLOCK HARMONY_DEVICE NAMESPACES UTS_NS IPC_NS PID_NS \
    NET_NS NET UNIX INET SYSCTL NETDEVICES VETH NET_SCHED NET_SCH_NETEM \
    CGROUPS CGROUP_SCHED CGROUP_PIDS CGROUP_DEVICE CGROUP_BPF BPF_SYSCALL TMPFS UNIX98_PTYS SECCOMP \
    SECCOMP_FILTER
assert_off BPF_JIT FHANDLE
if [ -n "${N6_TRAPS_OFF:-}" ]; then
    assert_off HARMONY_USER_COUNTER_TRAPS
else
    assert_y HARMONY_USER_COUNTER_TRAPS
fi
if [ -n "${TASK_PARK_PROFILE:-}" ]; then
    assert_y SMP
fi
if [ -n "${NESTED_HOST_PROFILE:-}" ]; then
    assert_y KVM KVM_INTEL KVM_AMD
    assert_off KVM_AMD_SEV
fi
# (HPET_TIMER is not in this list: it is def_bool y on x86-64 with no prompt;
# the HPET is excluded at runtime instead — see config-fragment.)
# Determinism overlay: every symbol below is set ON by the Kata base and must be
# flipped OFF by config-fragment (or is absent because the overlay won the timer
# choice). EXT4_FS is deliberately NOT here any more — the container workloads
# need it, and Kata provides it; see the capability audit.
# Dynticks: assert the *meaningful* tickless symbols off — NO_HZ_COMMON (selects
# the dynticks machinery + TICK_ONESHOT) and the choice members NO_HZ_FULL/
# NO_HZ_IDLE. NOT plain CONFIG_NO_HZ: that is the deprecated "Old Idle dynticks
# config" bool which only sets the *default* of the "Timer tick handling" choice
# ("default NO_HZ_IDLE if NO_HZ"); Kata sets it =y, but once HZ_PERIODIC wins the
# choice it is inert (it selects nothing), so it harmlessly stays =y.
assert_off NUMA CPU_FREQ MODULES TRANSPARENT_HUGEPAGE KSM SUSPEND \
    HIBERNATION KEXEC KEXEC_FILE KEXEC_HANDOVER KEXEC_CORE \
    X86_PM_TIMER HIGH_RES_TIMERS RANDOMIZE_BASE \
    LOCALVERSION_AUTO HW_RANDOM NO_HZ_COMMON NO_HZ_FULL NO_HZ_IDLE TICK_ONESHOT
assert_off RWSEM_SPIN_ON_OWNER
# Empty version suffix: git/build state must not leak into the bytes.
if ! grep -qxF 'CONFIG_LOCALVERSION=""' "$KOBJ/.config"; then
    echo "FAIL: CONFIG_LOCALVERSION must be empty (reproducibility)" >&2
    exit 1
fi

echo "== kernel: building bzImage"
make -C "$KSRC" O="$KOBJ" ARCH=x86_64 LOCALVERSION= -j"${HARMONY_BUILD_JOBS:-$(nproc)}" bzImage

# The scan rejects any rdtsc, rdtscp, rdrand or rdseed in the image. It runs
# before the image is published to `$ART_DIR`, so with `set -e` a rejected
# kernel never reaches the path the guest runner reads. `test-publish-check.sh`
# proves that ordering with a planted rejection.
echo "== kernel: counter-opcode scan (rdtsc/rdtscp + rdrand/rdseed)"
bash "$LINUX_DIR/scan-counter-opcodes.sh" "$KOBJ/vmlinux"

# Publish ONLY after the scan passed.
kernel_output=bzImage
if [ -n "${N6_TRAPS_OFF:-}" ]; then
    kernel_output=bzImage-n6-traps-off
elif [ -n "${TASK_PARK_PROFILE:-}" ]; then
    kernel_output=bzImage-task-park
elif [ -n "${NESTED_HOST_PROFILE:-}" ]; then
    kernel_output=bzImage-nested-host
fi
mkdir -p "$ART_DIR/x86_64"
install -m 0644 "$KOBJ/arch/x86/boot/bzImage" "$ART_DIR/$kernel_output"
install -m 0644 "$KOBJ/arch/x86/boot/bzImage" "$ART_DIR/x86_64/$kernel_output"
install -m 0644 "$KOBJ/vmlinux" "$ART_DIR/x86_64/$kernel_output.vmlinux"
echo "ok: $ART_DIR/$kernel_output"

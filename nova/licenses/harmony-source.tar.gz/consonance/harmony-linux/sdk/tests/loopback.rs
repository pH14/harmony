// SPDX-License-Identifier: AGPL-3.0-or-later

use std::cell::RefCell;
use std::rc::Rc;

use harmony_sdk::wire;
use harmony_sdk::{Point, Sdk, SdkError};
use hypercall_proto::{
    Client, CoverageService, Dispatcher, ProtoError, Service, ServiceId, Status, Transport,
};

struct DispatcherLoopback(Dispatcher);

impl Transport for DispatcherLoopback {
    type Error = ();
    fn exchange(&mut self, req: &[u8], resp: &mut [u8]) -> Result<usize, Self::Error> {
        Ok(self.0.dispatch(req, resp))
    }
}

type EventLog = Rc<RefCell<Vec<(u32, Vec<u8>)>>>;

#[derive(Clone, Default)]
struct SharedEvent(EventLog);

impl Service for SharedEvent {
    fn handle(&mut self, opcode: u16, payload: &[u8], _resp: &mut [u8]) -> (Status, usize) {
        if opcode != 1 {
            return (Status::UnknownOpcode, 0);
        }
        if payload.len() < 4 {
            return (Status::BadRequest, 0);
        }
        let id = u32::from_le_bytes([payload[0], payload[1], payload[2], payload[3]]);
        self.0.borrow_mut().push((id, payload[4..].to_vec()));
        (Status::Ok, 0)
    }
    fn save_state(&self) -> Vec<u8> {
        Vec::new()
    }
    fn restore_state(&mut self, _state: &[u8]) -> Result<(), ProtoError> {
        Ok(())
    }
}

fn catalog() -> Vec<Point> {
    vec![
        Point::sometimes(1, "commit_seen"),
        Point::sometimes(2, "rollback_seen"),
        Point::always(20, "balance_nonneg"),
        Point::unreachable(30, "dead_branch"),
        Point::state(40, "max_lsn"),
        Point::buggify(50, "slow_disk"),
    ]
}

fn harness() -> (Sdk<DispatcherLoopback>, EventLog) {
    let events: EventLog = Rc::new(RefCell::new(Vec::new()));
    let mut d = Dispatcher::new();
    d.register(ServiceId::Event, Box::new(SharedEvent(events.clone())));
    let sdk = Sdk::init(DispatcherLoopback(d), &catalog()).expect("init");
    (sdk, events)
}

#[test]
fn init_declares_the_catalog_first() {
    let (_sdk, events) = harness();
    let ev = events.borrow();
    assert_eq!(ev.len(), 1, "init emits exactly one event (the catalog)");
    let (id, data) = &ev[0];
    assert_eq!(*id, wire::CATALOG_EVENT_ID);
    assert_eq!(
        u32::from_le_bytes([data[0], data[1], data[2], data[3]]),
        wire::CATALOG_MAGIC
    );
    assert_eq!(data[4], wire::SDK_WIRE_VERSION);
    let count = u32::from_le_bytes([data[5], data[6], data[7], data[8]]);
    assert_eq!(count, 6, "six declared points");
}

#[test]
fn init_rejects_duplicate_coordinates() {
    let fresh = || {
        let mut d = Dispatcher::new();
        d.register(
            ServiceId::Event,
            Box::new(SharedEvent(Rc::new(RefCell::new(Vec::new())))),
        );
        DispatcherLoopback(d)
    };
    let dup = [Point::always(7, "a"), Point::sometimes(7, "b")];
    assert!(
        matches!(Sdk::init(fresh(), &dup), Err(SdkError::DuplicateCoordinate)),
        "same (NS_ASSERT, id) across assert kinds is rejected"
    );
    let ok = [
        Point::always(7, "a"),
        Point::state(7, "s"),
        Point::buggify(7, "b"),
    ];
    assert!(
        Sdk::init(fresh(), &ok).is_ok(),
        "same id in distinct namespaces is not a collision"
    );
}

#[test]
fn init_rejects_duplicate_names() {
    let mut d = Dispatcher::new();
    d.register(
        ServiceId::Event,
        Box::new(SharedEvent(Rc::new(RefCell::new(Vec::new())))),
    );
    let dup = [Point::always(1, "dup"), Point::state(2, "dup")];
    assert!(
        matches!(
            Sdk::init(DispatcherLoopback(d), &dup),
            Err(SdkError::DuplicateName)
        ),
        "a duplicate name is rejected even across namespaces and ids"
    );
}

#[test]
fn assertion_verbs_emit_expected_dispositions() {
    let (mut sdk, events) = harness();
    let base = events.borrow().len();

    sdk.assert_always(true, 20).unwrap();
    sdk.assert_always(false, 20).unwrap();
    sdk.assert_sometimes(false, 1).unwrap();
    sdk.assert_sometimes(true, 1).unwrap();
    sdk.assert_reachable(30).unwrap();
    sdk.assert_unreachable(30).unwrap();

    let ev = events.borrow();
    let got: Vec<(u32, Vec<u8>)> = ev[base..].to_vec();
    assert_eq!(
        got,
        vec![
            (
                wire::event_id(wire::NS_ASSERT, 20),
                vec![wire::DISP_VIOLATION, 0, 0]
            ),
            (
                wire::event_id(wire::NS_ASSERT, 1),
                vec![wire::DISP_HIT, 0, 0]
            ),
            (
                wire::event_id(wire::NS_ASSERT, 30),
                vec![wire::DISP_HIT, 0, 0]
            ),
            (
                wire::event_id(wire::NS_ASSERT, 30),
                vec![wire::DISP_VIOLATION, 0, 0]
            ),
        ]
    );
}

#[test]
fn state_verbs_emit_op_and_value() {
    let (mut sdk, events) = harness();
    let base = events.borrow().len();

    sdk.state_set(40, 0x0102_0304_0506_0708).unwrap();
    sdk.state_max(40, 42).unwrap();

    let ev = events.borrow();
    let got: Vec<(u32, Vec<u8>)> = ev[base..].to_vec();
    let mut set_payload = vec![wire::STATE_SET];
    set_payload.extend_from_slice(&0x0102_0304_0506_0708_u64.to_le_bytes());
    let mut max_payload = vec![wire::STATE_MAX];
    max_payload.extend_from_slice(&42_u64.to_le_bytes());
    assert_eq!(
        got,
        vec![
            (wire::event_id(wire::NS_STATE, 40), set_payload),
            (wire::event_id(wire::NS_STATE, 40), max_payload),
        ]
    );
}

#[test]
fn coverage_yield_round_trips_through_the_sdk() {
    let events: EventLog = Rc::new(RefCell::new(Vec::new()));
    let mut dispatcher = Dispatcher::new();
    dispatcher.register(ServiceId::Event, Box::new(SharedEvent(events)));
    dispatcher.register(ServiceId::Sdk, Box::new(CoverageService::new()));
    let mut sdk = Sdk::init(DispatcherLoopback(dispatcher), &[]).unwrap();

    assert_eq!(sdk.coverage_yield(7, 1, 3).unwrap(), (2, 0));
    assert_eq!(sdk.coverage_yield(7, 2, 3).unwrap(), (3, 2));
    assert!(sdk.coverage_yield(7, 4, 3).is_err());
}

#[test]
fn setup_complete_emits_the_lifecycle_event() {
    let (mut sdk, events) = harness();
    let base = events.borrow().len();
    sdk.setup_complete().unwrap();
    let ev = events.borrow();
    assert_eq!(ev[base..], [(wire::SETUP_COMPLETE_EVENT_ID, vec![])]);
}

#[test]
fn frame_complete_emits_the_frame_clock_lifecycle_event() {
    let (mut sdk, events) = harness();
    let base = events.borrow().len();
    sdk.frame_complete(0x0102_0304_0506_0708).unwrap();
    let ev = events.borrow();
    assert_eq!(
        ev[base..],
        [(
            wire::FRAME_COMPLETE_EVENT_ID,
            0x0102_0304_0506_0708_u64.to_le_bytes().to_vec()
        )]
    );
}

#[test]
fn same_calls_yield_identical_event_streams() {
    fn run() -> Vec<(u32, Vec<u8>)> {
        let (mut sdk, events) = harness();
        sdk.assert_sometimes(true, 1).unwrap();
        sdk.state_max(40, 7).unwrap();
        sdk.assert_always(false, 20).unwrap();
        sdk.setup_complete().unwrap();
        events.borrow().clone()
    }
    assert_eq!(run(), run());
}

#[test]
fn oversize_ids_are_rejected() {
    let (mut sdk, _events) = harness();
    assert_eq!(
        sdk.assert_always(false, wire::LOCAL_MAX + 1),
        Err(SdkError::PointIdTooLarge)
    );
    assert_eq!(sdk.state_set(u32::MAX, 0), Err(SdkError::PointIdTooLarge));
}

#[test]
fn oversize_catalog_is_rejected() {
    let events: EventLog = Rc::new(RefCell::new(Vec::new()));
    let mut d = Dispatcher::new();
    d.register(ServiceId::Event, Box::new(SharedEvent(events.clone())));
    let big: Vec<Point> = (0..500)
        .map(|i| {
            let name: &'static str =
                Box::leak(format!("signal-{i:05}-that-eats-frame-budget").into_boxed_str());
            Point::sometimes(i, name)
        })
        .collect();
    assert_eq!(
        Sdk::init(DispatcherLoopback(d), &big).err(),
        Some(SdkError::CatalogTooLarge)
    );
    assert!(events.borrow().is_empty(), "nothing emitted on overflow");
}

#[allow(dead_code)]
fn _sdk_composes_over_hypercall_doorbell(
    t: hypercall_doorbell::VmcallTransport,
) -> Result<Sdk<hypercall_doorbell::VmcallTransport>, SdkError<hypercall_doorbell::TransportError>>
{
    Sdk::init(t, &[])
}

#[allow(dead_code)]
fn _sdk_client_escape_hatch_is_a_real_client(sdk: &mut Sdk<DispatcherLoopback>) {
    let _c: &mut Client<DispatcherLoopback> = sdk.client_mut();
}

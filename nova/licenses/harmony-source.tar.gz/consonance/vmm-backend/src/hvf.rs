// SPDX-License-Identifier: AGPL-3.0-or-later

use core::ffi::c_void;
use std::ptr::{self, NonNull};

use crate::arch::arm64::{
    Arm64, Arm64AsidBits, Arm64Caps, Arm64Exit, Arm64Injection, Arm64Policy, Arm64VcpuState,
    GicIntId, canonicalize_core_regs, has_noncanonical_core_regs,
};
use crate::backend::Backend;
use crate::error::{BackendError, Result};
use crate::exit::{Capabilities, CommonExit, Exit, ExitCounts, HypercallFrame};
use crate::types::{Gpa, MpState};

const HV_PAGE_SIZE: usize = 16 * 1024;
const HV_MEMORY_READ: u64 = 1;
const HV_MEMORY_WRITE: u64 = 2;
const HV_MEMORY_EXEC: u64 = 4;

const HV_EXIT_REASON_CANCELED: u32 = 0;
const HV_EXIT_REASON_EXCEPTION: u32 = 1;
const HV_EXIT_REASON_VTIMER_ACTIVATED: u32 = 2;

const HV_INTERRUPT_TYPE_IRQ: u32 = 0;
const HV_INTERRUPT_TYPE_FIQ: u32 = 1;

const HV_REG_PC: u32 = 31;
const HV_REG_FPCR: u32 = 32;
const HV_REG_FPSR: u32 = 33;
const HV_REG_CPSR: u32 = 34;

const HV_SYS_REG_SCTLR_EL1: u16 = 0xc080;
const HV_SYS_REG_DBGBVR0_EL1: u16 = 0x8004;
const HV_SYS_REG_DBGBCR0_EL1: u16 = 0x8005;
const HV_SYS_REG_DBGWVR0_EL1: u16 = 0x8006;
const HV_SYS_REG_DBGWCR0_EL1: u16 = 0x8007;
const HV_SYS_REG_MDSCR_EL1: u16 = 0x8012;
const HV_SYS_REG_CPACR_EL1: u16 = 0xc082;
const HV_SYS_REG_TTBR0_EL1: u16 = 0xc100;
const HV_SYS_REG_TTBR1_EL1: u16 = 0xc101;
const HV_SYS_REG_TCR_EL1: u16 = 0xc102;
const HV_SYS_REG_SPSR_EL1: u16 = 0xc200;
const HV_SYS_REG_ELR_EL1: u16 = 0xc201;
const HV_SYS_REG_SP_EL0: u16 = 0xc208;
const HV_SYS_REG_ESR_EL1: u16 = 0xc290;
const HV_SYS_REG_FAR_EL1: u16 = 0xc300;
const HV_SYS_REG_MAIR_EL1: u16 = 0xc510;
const HV_SYS_REG_VBAR_EL1: u16 = 0xc600;
const HV_SYS_REG_TPIDR_EL1: u16 = 0xc684;
const HV_SYS_REG_CNTKCTL_EL1: u16 = 0xc708;
const HV_SYS_REG_TPIDR_EL0: u16 = 0xde82;
const HV_SYS_REG_TPIDRRO_EL0: u16 = 0xde83;
const HV_SYS_REG_CNTV_CTL_EL0: u16 = 0xdf19;
const HV_SYS_REG_CNTV_CVAL_EL0: u16 = 0xdf1a;
const HV_SYS_REG_SP_EL1: u16 = 0xe208;

const TLB_FLUSH_STUB: [u32; 5] = [
    0xd508_831f,
    0xd508_711f,
    0xd503_3b9f,
    0xd503_3fdf,
    0xd400_0002,
];

const SCTLR_M: u64 = 1;

const ESR_EC_WFX: u64 = 0x01;
const ESR_EC_HVC64: u64 = 0x16;
const ESR_EC_SYSREG: u64 = 0x18;
const ESR_EC_INSTRUCTION_ABORT_LOWER: u64 = 0x20;
const ESR_EC_DATA_ABORT_LOWER: u64 = 0x24;
const GUEST_PAGE: u64 = 4096;
const ESR_EC_DATA_ABORT_SAME: u64 = 0x25;

const PSTATE_MODE_MASK: u64 = 0x1f;
const PSTATE_MODE_EL0T: u64 = 0;
const PSTATE_MODE_EL1T: u64 = 4;
const PSTATE_MODE_EL1H: u64 = 5;
const PSTATE_DAIF: u64 = 0x3c0;
const PSTATE_SSBS: u64 = 1 << 12;
const PSTATE_PAN: u64 = 1 << 22;
const PSTATE_DIT: u64 = 1 << 24;
const PSTATE_NZCV: u64 = 0xf << 28;
const SCTLR_SPAN: u64 = 1 << 23;
const SCTLR_DSSBS: u64 = 1 << 44;
const ESR_IL: u64 = 1 << 25;

const ICC_IAR1_EL1_CANONICAL: u32 = 0x0030_3018;

const PSCI_VERSION: u64 = 0x8400_0000;
const PSCI_CPU_SUSPEND32: u64 = 0x8400_0001;
const PSCI_CPU_SUSPEND64: u64 = 0xc400_0001;
const PSCI_CPU_OFF: u64 = 0x8400_0002;
const PSCI_CPU_ON32: u64 = 0x8400_0003;
const PSCI_CPU_ON64: u64 = 0xc400_0003;
const PSCI_AFFINITY_INFO32: u64 = 0x8400_0004;
const PSCI_AFFINITY_INFO64: u64 = 0xc400_0004;
const PSCI_MIGRATE_INFO_TYPE: u64 = 0x8400_0006;
const PSCI_SYSTEM_OFF: u64 = 0x8400_0008;
const PSCI_SYSTEM_RESET: u64 = 0x8400_0009;
const PSCI_FEATURES: u64 = 0x8400_000a;
const PSCI_VERSION_1_0: u64 = 0x0001_0000;
const SMCCC_VERSION: u64 = 0x8000_0000;
const SMCCC_VERSION_1_1: u64 = 0x0001_0001;
const SMCCC_ARCH_FEATURES: u64 = 0x8000_0001;
const SMCCC_ARCH_WORKAROUND_1: u64 = 0x8000_8000;
const SMCCC_ARCH_WORKAROUND_2: u64 = 0x8000_7fff;
const SMCCC_ARCH_WORKAROUND_3: u64 = 0x8000_3fff;
const SMCCC_TRNG_VERSION: u64 = 0x8400_0050;
const SMCCC_VENDOR_HYP_CALL_UID: u64 = 0x8600_ff01;
const PSCI_NOT_SUPPORTED: u64 = (-1i64) as u64;
const PSCI_ALREADY_ON: u64 = (-4i64) as u64;
const PSCI_NOT_PRESENT: u64 = (-7i64) as u64;

const fn hvf_implicit_identity_value(encoding: u32) -> Option<u64> {
    match encoding {
        0xc022 | 0xc027 | 0xc02a | 0xc032 | 0xc033 | 0xc03b | 0xc03c => Some(0),
        0xd801 => Some(0x0000_0000_8444_c004),
        _ => None,
    }
}

const ID_FEATURE_REGISTERS: core::ops::RangeInclusive<u32> = 0xc020..=0xc03f;

const SIGNED_ID_FIELDS: [(u32, u32); 5] = [
    (0xc020, 16),
    (0xc020, 20),
    (0xc028, 36),
    (0xc038, 24),
    (0xc038, 28),
];

const UNCHECKED_ID_FIELDS: [(u32, u32); 8] = [
    (0xc020, 24),
    (0xc038, 32),
    (0xc038, 36),
    (0xc038, 40),
    (0xc039, 4),
    (0xc039, 8),
    (0xc03a, 40),
    (0xc03a, 56),
];

fn id_field_level(encoding: u32, shift: u32, value: u64) -> i8 {
    let field = ((value >> shift) & 0xf) as i8;
    if field >= 8 && SIGNED_ID_FIELDS.contains(&(encoding, shift)) {
        field - 16
    } else {
        field
    }
}

fn id_register_within_host(encoding: u32, requested: u64, host: u64) -> bool {
    !ID_FEATURE_REGISTERS.contains(&encoding)
        || (0..64).step_by(4).all(|shift| {
            UNCHECKED_ID_FIELDS.contains(&(encoding, shift))
                || id_field_level(encoding, shift, requested)
                    <= id_field_level(encoding, shift, host)
        })
}

#[repr(C)]
#[derive(Clone, Copy, Default)]
struct HvExitException {
    syndrome: u64,
    virtual_address: u64,
    physical_address: u64,
}

#[repr(C)]
#[derive(Clone, Copy, Default)]
struct HvVcpuExit {
    reason: u32,
    _padding: u32,
    exception: HvExitException,
}

core::arch::global_asm!(
    ".globl _harmony_backend_hv_vcpu_set_simd_fp_reg",
    "_harmony_backend_hv_vcpu_set_simd_fp_reg:",
    "ldr q0, [x2]",
    "b _hv_vcpu_set_simd_fp_reg",
);

unsafe extern "C" {
    fn sys_icache_invalidate(start: *mut c_void, len: usize);
}

#[link(name = "Hypervisor", kind = "framework")]
unsafe extern "C" {
    fn hv_vm_create(config: *mut c_void) -> i32;
    fn hv_vm_destroy() -> i32;
    fn hv_vm_map(addr: *mut c_void, ipa: u64, size: usize, flags: u64) -> i32;
    fn hv_vm_unmap(ipa: u64, size: usize) -> i32;
    fn hv_vm_protect(ipa: u64, size: usize, flags: u64) -> i32;

    fn hv_vcpu_create(vcpu: *mut u64, exit: *mut *const HvVcpuExit, config: *mut c_void) -> i32;
    fn hv_vcpu_destroy(vcpu: u64) -> i32;
    fn hv_vcpu_run(vcpu: u64) -> i32;
    fn hv_vcpus_exit(vcpus: *const u64, vcpu_count: u32) -> i32;
    fn hv_vcpu_get_reg(vcpu: u64, reg: u32, value: *mut u64) -> i32;
    fn hv_vcpu_set_reg(vcpu: u64, reg: u32, value: u64) -> i32;
    fn hv_vcpu_get_simd_fp_reg(vcpu: u64, reg: u32, value: *mut [u8; 16]) -> i32;
    fn harmony_backend_hv_vcpu_set_simd_fp_reg(vcpu: u64, reg: u32, value: *const u8) -> i32;
    fn hv_vcpu_get_sys_reg(vcpu: u64, reg: u16, value: *mut u64) -> i32;
    fn hv_vcpu_set_sys_reg(vcpu: u64, reg: u16, value: u64) -> i32;
    fn hv_vcpu_get_pending_interrupt(vcpu: u64, kind: u32, pending: *mut bool) -> i32;
    fn hv_vcpu_set_pending_interrupt(vcpu: u64, kind: u32, pending: bool) -> i32;
    fn hv_vcpu_get_trap_debug_exceptions(vcpu: u64, value: *mut bool) -> i32;
    fn hv_vcpu_set_trap_debug_exceptions(vcpu: u64, value: bool) -> i32;
    fn hv_vcpu_get_trap_debug_reg_accesses(vcpu: u64, value: *mut bool) -> i32;
    fn hv_vcpu_set_trap_debug_reg_accesses(vcpu: u64, value: bool) -> i32;
    fn hv_vcpu_get_vtimer_mask(vcpu: u64, value: *mut bool) -> i32;
    fn hv_vcpu_set_vtimer_mask(vcpu: u64, value: bool) -> i32;
    fn hv_vcpu_get_vtimer_offset(vcpu: u64, value: *mut u64) -> i32;
    fn hv_vcpu_set_vtimer_offset(vcpu: u64, value: u64) -> i32;
}

fn hv(operation: &'static str, status: i32) -> Result<()> {
    if status == 0 {
        Ok(())
    } else {
        Err(BackendError::Io(std::io::Error::other(format!(
            "{operation}: Hypervisor.framework error {:#010x}",
            status as u32
        ))))
    }
}

fn exit_ec(syndrome: u64) -> u64 {
    syndrome >> 26
}

fn tracked_write_fault(exit: &HvExitException, regions: &[(u64, usize)]) -> Option<u64> {
    let ec = exit_ec(exit.syndrome);
    let ipa = exit.physical_address;
    ((ec == ESR_EC_DATA_ABORT_LOWER || ec == ESR_EC_INSTRUCTION_ABORT_LOWER)
        && regions
            .iter()
            .any(|&(gpa, len)| ipa >= gpa && ipa - gpa < len as u64))
    .then_some(ipa & !(HV_PAGE_SIZE as u64 - 1))
}

fn contiguous_runs<'a>(pages: impl IntoIterator<Item = &'a u64>) -> Vec<(u64, usize)> {
    let mut runs: Vec<(u64, usize)> = Vec::new();
    for &page in pages {
        match runs.last_mut() {
            Some((start, len)) if *start + *len as u64 == page => *len += HV_PAGE_SIZE,
            _ => runs.push((page, HV_PAGE_SIZE)),
        }
    }
    runs
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
enum Pending {
    None,
    MmioLoad {
        reg: u32,
        size: u8,
        sign_extend: bool,
        sf: bool,
    },
    SysregRead {
        reg: u32,
    },
    SysregWrite,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
struct UndefinedException {
    pc: u64,
    pstate: u64,
    elr_el1: u64,
    spsr_el1: u64,
    esr_el1: u64,
}

fn undefined_exception(
    next_pc: u64,
    old_pstate: u64,
    sctlr_el1: u64,
    vbar_el1: u64,
) -> Result<UndefinedException> {
    let fault_pc = next_pc.checked_sub(4).ok_or(BackendError::InvalidState)?;
    let vector_offset = match old_pstate & PSTATE_MODE_MASK {
        PSTATE_MODE_EL0T => 0x400,
        PSTATE_MODE_EL1T => 0,
        PSTATE_MODE_EL1H => 0x200,
        _ => return Err(BackendError::InvalidState),
    };
    let pc = vbar_el1
        .checked_add(vector_offset)
        .ok_or(BackendError::InvalidState)?;

    let mut pstate = old_pstate & (PSTATE_NZCV | PSTATE_DIT | PSTATE_PAN);
    if sctlr_el1 & SCTLR_SPAN == 0 {
        pstate |= PSTATE_PAN;
    }
    if sctlr_el1 & SCTLR_DSSBS != 0 {
        pstate |= PSTATE_SSBS;
    }
    pstate |= PSTATE_DAIF | PSTATE_MODE_EL1H;

    Ok(UndefinedException {
        pc,
        pstate,
        elr_el1: fault_pc,
        spsr_el1: old_pstate,
        esr_el1: ESR_IL,
    })
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
struct DataAbort {
    gpa: Gpa,
    size: u8,
    write: bool,
    reg: u32,
    sign_extend: bool,
    sf: bool,
}

fn decode_data_abort(exit: HvVcpuExit) -> Result<DataAbort> {
    let iss = exit.exception.syndrome & 0x01ff_ffff;
    if iss & (1 << 24) == 0 {
        return Err(BackendError::Internal(
            "HVF data abort without a valid instruction syndrome",
        ));
    }
    let sas = ((iss >> 22) & 0x3) as u8;
    let size = 1u8 << sas;
    let reg = ((iss >> 16) & 0x1f) as u32;
    let sign_extend = iss & (1 << 21) != 0;
    let sf = iss & (1 << 15) != 0;
    let write = iss & (1 << 6) != 0;
    Ok(DataAbort {
        gpa: Gpa(exit.exception.physical_address),
        size,
        write,
        reg,
        sign_extend,
        sf,
    })
}

fn mapped_host_spans(
    ranges: &[(usize, usize)],
    host_addr: usize,
    len: usize,
) -> impl Iterator<Item = (usize, usize)> + '_ {
    let end = host_addr.saturating_add(len);
    ranges.iter().filter_map(move |&(start, size)| {
        let lo = host_addr.max(start);
        let hi = end.min(start.saturating_add(size));
        (lo < hi).then(|| (lo, hi - lo))
    })
}

fn flush_stub_gpa(regions: &[(u64, usize)]) -> u64 {
    regions
        .iter()
        .map(|&(gpa, len)| gpa + len as u64)
        .max()
        .unwrap_or(0)
        .next_multiple_of(HV_PAGE_SIZE as u64)
}

fn canonical_sysreg(iss: u64) -> u32 {
    ((iss & 0x003f_ffff) & !(0x1f << 5) & !1) as u32
}

fn sysreg_rt(iss: u64) -> u32 {
    ((iss >> 5) & 0x1f) as u32
}

fn accepted_irq_for_sysreg(
    pending_irq: Option<GicIntId>,
    sysreg: u32,
    read: bool,
) -> Option<GicIntId> {
    (read && sysreg == ICC_IAR1_EL1_CANONICAL)
        .then_some(pending_irq)
        .flatten()
}

fn host_counter() -> u64 {
    let value: u64;
    // SAFETY: CNTPCT_EL0 is a read-only counter register that macOS leaves
    // readable from EL0, and the read has no side effects.
    unsafe {
        core::arch::asm!("isb", "mrs {0}, cntpct_el0", out(reg) value, options(nomem, nostack));
    }
    value
}

fn validate_restore_vcpu_state(state: &Arm64VcpuState) -> Result<()> {
    if has_noncanonical_core_regs(&state.core)
        || state.mp_state != MpState::Runnable
        || !state.vtimer.masked
        || state.vtimer.cntv_ctl_el0 & !0b11 != 0
    {
        return Err(BackendError::InvalidState);
    }
    Ok(())
}

#[derive(Clone, Copy, Debug)]
pub struct HvfExitHandle {
    vcpu: u64,
}

impl HvfExitHandle {
    pub fn request_exit(self) -> Result<()> {
        let vcpus = [self.vcpu];
        // SAFETY: the array is live for the call. HVF treats vCPU identifiers
        // as values and returns an error for an identifier no longer present.
        hv("hv_vcpus_exit", unsafe {
            hv_vcpus_exit(vcpus.as_ptr(), vcpus.len() as u32)
        })
    }
}

pub struct HvfBackend {
    vcpu: u64,
    exit: NonNull<HvVcpuExit>,
    configured: bool,
    pending: Pending,
    pending_irq: Option<GicIntId>,
    accepted_irq: Option<GicIntId>,
    counts: ExitCounts,
    regions: Vec<(u64, usize)>,
    writable: std::collections::BTreeSet<u64>,
    host_ranges: Vec<(usize, usize)>,
    cancel_run: std::sync::Arc<std::sync::atomic::AtomicBool>,
    flush_stub: Option<FlushStub>,
    host_id_regs: std::collections::BTreeMap<u16, u64>,
}

struct FlushStub {
    gpa: u64,
    page: *mut u8,
    layout: std::alloc::Layout,
}

impl HvfBackend {
    pub fn new() -> Result<Self> {
        // SAFETY: null selects the documented default VM configuration.
        hv("hv_vm_create", unsafe { hv_vm_create(ptr::null_mut()) })?;
        let mut vcpu = 0;
        let mut exit = ptr::null();
        // SAFETY: output pointers are live and null selects the default config.
        if let Err(error) = hv("hv_vcpu_create", unsafe {
            hv_vcpu_create(&mut vcpu, &mut exit, ptr::null_mut())
        }) {
            // SAFETY: this constructor created the VM and no vCPU exists.
            let _ = unsafe { hv_vm_destroy() };
            return Err(error);
        }
        let Some(exit) = NonNull::new(exit.cast_mut()) else {
            // SAFETY: creation returned a live vCPU and this is its owner.
            let _ = unsafe { hv_vcpu_destroy(vcpu) };
            // SAFETY: the only vCPU is gone.
            let _ = unsafe { hv_vm_destroy() };
            return Err(BackendError::Internal(
                "hv_vcpu_create returned a null exit page",
            ));
        };
        // SAFETY: `vcpu` is live and owned by this thread.
        if let Err(error) = hv("hv_vcpu_set_vtimer_mask", unsafe {
            hv_vcpu_set_vtimer_mask(vcpu, true)
        }) {
            // SAFETY: constructor cleanup on the owning thread.
            let _ = unsafe { hv_vcpu_destroy(vcpu) };
            // SAFETY: the only vCPU is gone.
            let _ = unsafe { hv_vm_destroy() };
            return Err(error);
        }
        // SAFETY: `vcpu` is live and owned by this thread.
        if let Err(error) = hv("hv_vcpu_set_vtimer_offset", unsafe {
            hv_vcpu_set_vtimer_offset(vcpu, 0)
        }) {
            // SAFETY: constructor cleanup on the owning thread.
            let _ = unsafe { hv_vcpu_destroy(vcpu) };
            // SAFETY: the only vCPU is gone.
            let _ = unsafe { hv_vm_destroy() };
            return Err(error);
        }
        Ok(Self {
            vcpu,
            exit,
            configured: false,
            pending: Pending::None,
            pending_irq: None,
            accepted_irq: None,
            counts: ExitCounts::default(),
            regions: Vec::new(),
            writable: std::collections::BTreeSet::new(),
            host_ranges: Vec::new(),
            cancel_run: std::sync::Arc::default(),
            flush_stub: None,
            host_id_regs: std::collections::BTreeMap::new(),
        })
    }

    fn ensure_flush_stub(&mut self) -> Result<u64> {
        if let Some(stub) = &self.flush_stub {
            return Ok(stub.gpa);
        }
        let gpa = flush_stub_gpa(&self.regions);
        let layout = std::alloc::Layout::from_size_align(HV_PAGE_SIZE, HV_PAGE_SIZE)
            .map_err(|_| BackendError::Internal("HVF flush stub layout"))?;
        // SAFETY: the layout has a non-zero size, so this is a valid allocation
        // request; the pointer is checked for null before any use.
        let page = unsafe { std::alloc::alloc_zeroed(layout) };
        if page.is_null() {
            return Err(BackendError::Memory("HVF flush stub allocation failed"));
        }
        for (slot, word) in TLB_FLUSH_STUB.iter().enumerate() {
            // SAFETY: the allocation is HV_PAGE_SIZE bytes and the stub is five
            // words, so every write lands inside it.
            unsafe { page.add(slot * 4).cast::<u32>().write(*word) };
        }
        // SAFETY: the allocation is live for as long as this backend, nothing
        // else refers to it, and its layout gives it the alignment and length
        // the framework requires.
        let mapped = hv("hv_vm_map", unsafe {
            hv_vm_map(
                page.cast(),
                gpa,
                HV_PAGE_SIZE,
                HV_MEMORY_READ | HV_MEMORY_EXEC,
            )
        });
        if let Err(error) = mapped {
            // SAFETY: the allocation came from this layout and nothing mapped it.
            unsafe { std::alloc::dealloc(page, layout) };
            return Err(error);
        }
        // SAFETY: `page` is a live HV_PAGE_SIZE allocation owned by this
        // backend, and the call only performs cache maintenance on it.
        unsafe { sys_icache_invalidate(page.cast(), HV_PAGE_SIZE) };
        self.flush_stub = Some(FlushStub { gpa, page, layout });
        Ok(gpa)
    }

    fn flush_guest_translations(&mut self) -> Result<()> {
        let gpa = self.ensure_flush_stub()?;
        let sctlr = self.sysreg(HV_SYS_REG_SCTLR_EL1)?;
        self.set_sysreg(HV_SYS_REG_SCTLR_EL1, sctlr & !SCTLR_M)?;
        self.set_reg(HV_REG_CPSR, PSTATE_DAIF | PSTATE_MODE_EL1H)?;
        self.set_reg(HV_REG_PC, gpa)?;
        // SAFETY: this is the owning thread and the vCPU is live.
        hv("hv_vcpu_set_pending_interrupt", unsafe {
            hv_vcpu_set_pending_interrupt(self.vcpu, HV_INTERRUPT_TYPE_IRQ, false)
        })?;
        for _ in 0..2 {
            // SAFETY: the vCPU is live and this call runs on its owning thread.
            hv("hv_vcpu_run", unsafe { hv_vcpu_run(self.vcpu) })?;
            // SAFETY: HVF owns this exit page for the vCPU lifetime and run has
            // completed its write before returning.
            let raw = unsafe { *self.exit.as_ptr() };
            if raw.reason == HV_EXIT_REASON_CANCELED {
                continue;
            }
            if raw.reason == HV_EXIT_REASON_EXCEPTION
                && exit_ec(raw.exception.syndrome) == ESR_EC_HVC64
            {
                return Ok(());
            }
            break;
        }
        Err(BackendError::Internal(
            "HVF translation flush stub did not reach its hypercall",
        ))
    }

    pub fn exit_handle(&self) -> HvfExitHandle {
        HvfExitHandle { vcpu: self.vcpu }
    }

    fn reg(&self, reg: u32) -> Result<u64> {
        let mut value = 0;
        // SAFETY: output points to a live u64 and this is the vCPU owner.
        hv("hv_vcpu_get_reg", unsafe {
            hv_vcpu_get_reg(self.vcpu, reg, &mut value)
        })?;
        Ok(value)
    }

    fn set_reg(&self, reg: u32, value: u64) -> Result<()> {
        // SAFETY: the vCPU is live and this is its owning thread.
        hv("hv_vcpu_set_reg", unsafe {
            hv_vcpu_set_reg(self.vcpu, reg, value)
        })
    }

    fn sysreg(&self, reg: u16) -> Result<u64> {
        let mut value = 0;
        // SAFETY: output points to a live u64 and this is the vCPU owner.
        hv("hv_vcpu_get_sys_reg", unsafe {
            hv_vcpu_get_sys_reg(self.vcpu, reg, &mut value)
        })?;
        Ok(value)
    }

    fn set_sysreg(&self, reg: u16, value: u64) -> Result<()> {
        // SAFETY: the vCPU is live and this is its owning thread.
        hv("hv_vcpu_set_sys_reg", unsafe {
            hv_vcpu_set_sys_reg(self.vcpu, reg, value)
        })
    }

    fn advance_pc(&self) -> Result<()> {
        let next = self
            .reg(HV_REG_PC)?
            .checked_add(4)
            .ok_or(BackendError::InvalidState)?;
        self.set_reg(HV_REG_PC, next)
    }

    fn ensure_runnable(&self) -> Result<()> {
        if !self.configured {
            return Err(BackendError::NotConfigured);
        }
        if self.pending != Pending::None {
            return Err(BackendError::PendingCompletion);
        }
        Ok(())
    }

    fn apply_pending_irq(&mut self) -> Result<()> {
        let inject = self.pending_irq.is_some();
        // SAFETY: this is the owning thread. Keep the level asserted across
        // unrelated exits and while PSTATE.I is masked. HVF holds the level
        // until the guest unmasks IRQs, matching an in-kernel vGIC; acceptance
        // is observable only when the guest reads ICC_IAR1_EL1.
        hv("hv_vcpu_set_pending_interrupt", unsafe {
            hv_vcpu_set_pending_interrupt(self.vcpu, HV_INTERRUPT_TYPE_IRQ, inject)
        })
    }

    fn handle_psci(&self, function: u64) -> Result<Option<Exit<Arm64>>> {
        let result = match function {
            PSCI_VERSION => PSCI_VERSION_1_0,
            SMCCC_VERSION => SMCCC_VERSION_1_1,
            SMCCC_ARCH_FEATURES => match self.reg(1)? {
                SMCCC_ARCH_WORKAROUND_1 => 1,
                SMCCC_ARCH_WORKAROUND_2 => (-2i64) as u64,
                SMCCC_ARCH_WORKAROUND_3 => 0,
                _ => PSCI_NOT_SUPPORTED,
            },
            SMCCC_TRNG_VERSION => PSCI_NOT_SUPPORTED,
            SMCCC_VENDOR_HYP_CALL_UID => PSCI_NOT_SUPPORTED,
            PSCI_MIGRATE_INFO_TYPE => 2,
            PSCI_FEATURES => {
                let queried = self.reg(1)?;
                if matches!(
                    queried,
                    SMCCC_VERSION
                        | PSCI_VERSION
                        | PSCI_SYSTEM_OFF
                        | PSCI_SYSTEM_RESET
                        | PSCI_FEATURES
                ) {
                    0
                } else {
                    PSCI_NOT_SUPPORTED
                }
            }
            PSCI_CPU_ON32 | PSCI_CPU_ON64 => PSCI_ALREADY_ON,
            PSCI_AFFINITY_INFO32 | PSCI_AFFINITY_INFO64 => PSCI_NOT_PRESENT,
            PSCI_CPU_SUSPEND32 | PSCI_CPU_SUSPEND64 | PSCI_CPU_OFF => PSCI_NOT_SUPPORTED,
            PSCI_SYSTEM_OFF | PSCI_SYSTEM_RESET => return Ok(Some(CommonExit::Shutdown.into())),
            _ => return Ok(None),
        };
        self.set_reg(0, result)?;
        Ok(None)
    }

    fn enter_guest(&mut self) -> Result<Exit<Arm64>> {
        loop {
            self.apply_pending_irq()?;
            // SAFETY: the vCPU is live and this call runs on its owning thread.
            hv("hv_vcpu_run", unsafe { hv_vcpu_run(self.vcpu) })?;
            // SAFETY: HVF owns this exit page for the vCPU lifetime and run has
            // completed its write before returning.
            let raw = unsafe { *self.exit.as_ptr() };
            if raw.reason == HV_EXIT_REASON_EXCEPTION
                && let Some(page) = tracked_write_fault(&raw.exception, &self.regions)
            {
                if !self.writable.insert(page) {
                    return Err(BackendError::Internal(
                        "HVF reported a write fault on a page it already made writable",
                    ));
                }
                // SAFETY: the page lies inside a region this backend mapped with
                // `hv_vm_map`, so the call only changes the guest's permissions on
                // memory the backend already exposes.
                hv("hv_vm_protect", unsafe {
                    hv_vm_protect(
                        page,
                        HV_PAGE_SIZE,
                        HV_MEMORY_READ | HV_MEMORY_WRITE | HV_MEMORY_EXEC,
                    )
                })?;
                continue;
            }
            match raw.reason {
                HV_EXIT_REASON_CANCELED => {
                    return Err(BackendError::Internal("HVF vCPU run canceled"));
                }
                HV_EXIT_REASON_VTIMER_ACTIVATED => {
                    return Err(BackendError::Internal(
                        "host-time HVF virtual timer activated despite permanent mask",
                    ));
                }
                HV_EXIT_REASON_EXCEPTION => {}
                _ => return Err(BackendError::Internal("unhandled HVF exit reason")),
            }
            let exit = match exit_ec(raw.exception.syndrome) {
                ESR_EC_WFX => {
                    self.advance_pc()?;
                    CommonExit::Idle.into()
                }
                ESR_EC_HVC64 => {
                    let function = self.reg(0)?;
                    if let Some(exit) = self.handle_psci(function)? {
                        exit
                    } else if matches!(
                        function,
                        SMCCC_VERSION
                            | SMCCC_ARCH_FEATURES
                            | SMCCC_TRNG_VERSION
                            | SMCCC_VENDOR_HYP_CALL_UID
                            | PSCI_VERSION
                            | PSCI_CPU_SUSPEND32
                            | PSCI_CPU_SUSPEND64
                            | PSCI_CPU_OFF
                            | PSCI_CPU_ON32
                            | PSCI_CPU_ON64
                            | PSCI_AFFINITY_INFO32
                            | PSCI_AFFINITY_INFO64
                            | PSCI_MIGRATE_INFO_TYPE
                            | PSCI_FEATURES
                    ) {
                        continue;
                    } else {
                        CommonExit::Hypercall(HypercallFrame {
                            args: [function, self.reg(1)?, self.reg(2)?, self.reg(3)?],
                        })
                        .into()
                    }
                }
                ESR_EC_SYSREG => {
                    let iss = raw.exception.syndrome & 0x01ff_ffff;
                    let reg = sysreg_rt(iss);
                    let read = iss & 1 != 0;
                    let sysreg = canonical_sysreg(iss);
                    if let Some(accepted) = accepted_irq_for_sysreg(self.pending_irq, sysreg, read)
                    {
                        self.accepted_irq = Some(accepted);
                    }
                    let write = if read {
                        None
                    } else if reg == 31 {
                        Some(0)
                    } else {
                        Some(self.reg(reg)?)
                    };
                    self.advance_pc()?;
                    self.pending = if read {
                        Pending::SysregRead { reg }
                    } else {
                        Pending::SysregWrite
                    };
                    Exit::Arch(Arm64Exit::Sysreg { sysreg, write })
                }
                ESR_EC_DATA_ABORT_LOWER | ESR_EC_DATA_ABORT_SAME => {
                    let abort = decode_data_abort(raw)?;
                    self.advance_pc()?;
                    if abort.write {
                        let value = if abort.reg == 31 {
                            0
                        } else {
                            self.reg(abort.reg)?
                        };
                        let mask = if abort.size == 8 {
                            u64::MAX
                        } else {
                            (1u64 << (u32::from(abort.size) * 8)) - 1
                        };
                        CommonExit::Mmio {
                            gpa: abort.gpa,
                            size: abort.size,
                            write: Some(value & mask),
                        }
                        .into()
                    } else {
                        self.pending = Pending::MmioLoad {
                            reg: abort.reg,
                            size: abort.size,
                            sign_extend: abort.sign_extend,
                            sf: abort.sf,
                        };
                        CommonExit::Mmio {
                            gpa: abort.gpa,
                            size: abort.size,
                            write: None,
                        }
                        .into()
                    }
                }
                _ => return Err(BackendError::Internal("unhandled HVF exception class")),
            };
            self.counts.bump(exit.reason());
            return Ok(exit);
        }
    }
}

impl Drop for HvfBackend {
    fn drop(&mut self) {
        if let Some(stub) = self.flush_stub.take() {
            // SAFETY: this backend mapped the stub page at that address and is
            // the sole owner of the allocation behind it.
            unsafe {
                let _ = hv_vm_unmap(stub.gpa, HV_PAGE_SIZE);
                std::alloc::dealloc(stub.page, stub.layout);
            }
        }
        for &(gpa, len) in self.regions.iter().rev() {
            // SAFETY: every entry records a successful map owned by this VM.
            let _ = unsafe { hv_vm_unmap(gpa, len) };
        }
        // SAFETY: this backend owns the vCPU and drops on its owning thread.
        let _ = unsafe { hv_vcpu_destroy(self.vcpu) };
        // SAFETY: the sole vCPU has been destroyed.
        let _ = unsafe { hv_vm_destroy() };
    }
}

impl Backend for HvfBackend {
    type A = Arm64;

    fn set_policy(&mut self, policy: &Arm64Policy) -> Result<()> {
        for (&encoding, &value) in &policy.id_regs.regs {
            if let Some(measured) = hvf_implicit_identity_value(encoding) {
                if value != measured {
                    return Err(BackendError::InvalidState);
                }
                continue;
            }
            let reg = u16::try_from(encoding).map_err(|_| BackendError::InvalidState)?;
            let host = match self.host_id_regs.get(&reg) {
                Some(&host) => host,
                None => {
                    let host = self.sysreg(reg)?;
                    self.host_id_regs.insert(reg, host);
                    host
                }
            };
            if !id_register_within_host(encoding, value, host) {
                return Err(BackendError::IdRegisterAboveHost {
                    encoding,
                    requested: value,
                    host,
                });
            }
            self.set_sysreg(reg, value)?;
        }
        let _ = &policy.sysreg_traps;
        self.configured = true;
        Ok(())
    }

    unsafe fn map_memory(&mut self, gpa: Gpa, host: &mut [u8]) -> Result<()> {
        if host.is_empty() {
            return Err(BackendError::Memory("zero-length memory region"));
        }
        if !gpa.0.is_multiple_of(HV_PAGE_SIZE as u64) {
            return Err(BackendError::Memory("gpa is not 16 KiB-aligned for HVF"));
        }
        if !host.len().is_multiple_of(HV_PAGE_SIZE) {
            return Err(BackendError::Memory(
                "region length is not 16 KiB-aligned for HVF",
            ));
        }
        if !(host.as_ptr() as usize).is_multiple_of(HV_PAGE_SIZE) {
            return Err(BackendError::Memory(
                "host address is not 16 KiB-aligned for HVF",
            ));
        }
        let end = gpa
            .0
            .checked_add(host.len() as u64)
            .ok_or(BackendError::Memory("region wraps address space"))?;
        let stub = self.flush_stub.as_ref().map(|stub| stub.gpa);
        for (mapped_gpa, mapped_len) in self
            .regions
            .iter()
            .copied()
            .chain(stub.map(|gpa| (gpa, HV_PAGE_SIZE)))
        {
            let mapped_end = mapped_gpa + mapped_len as u64;
            if gpa.0 < mapped_end && mapped_gpa < end {
                return Err(BackendError::Memory("region overlaps an existing map"));
            }
        }
        // SAFETY: the caller guarantees pinned, unaliased backing; this method
        // additionally verified the framework's 16 KiB alignment and length.
        hv("hv_vm_map", unsafe {
            hv_vm_map(
                host.as_mut_ptr().cast(),
                gpa.0,
                host.len(),
                HV_MEMORY_READ | HV_MEMORY_EXEC,
            )
        })?;
        self.regions.push((gpa.0, host.len()));
        self.host_ranges
            .push((host.as_mut_ptr() as usize, host.len()));
        Ok(())
    }

    fn drain_dirty_pages(&mut self) -> Result<Vec<u64>> {
        for (start, len) in contiguous_runs(&self.writable) {
            // SAFETY: every recorded page lies inside a region this backend
            // mapped with `hv_vm_map`, and the call only removes the guest's
            // write permission there.
            hv("hv_vm_protect", unsafe {
                hv_vm_protect(start, len, HV_MEMORY_READ | HV_MEMORY_EXEC)
            })?;
        }
        let per_page = HV_PAGE_SIZE as u64 / GUEST_PAGE;
        let gfns = std::mem::take(&mut self.writable)
            .into_iter()
            .flat_map(|page| (page / GUEST_PAGE..).take(per_page as usize))
            .collect();
        Ok(gfns)
    }

    fn run(&mut self) -> Result<Exit<Arm64>> {
        if self.cancel_run.load(std::sync::atomic::Ordering::Acquire) {
            return Err(BackendError::Internal("HVF run canceled by host"));
        }
        self.ensure_runnable()?;
        self.enter_guest()
    }

    fn cancellation_flag(&self) -> Option<std::sync::Arc<std::sync::atomic::AtomicBool>> {
        Some(std::sync::Arc::clone(&self.cancel_run))
    }

    fn invalidate_instruction_cache(&mut self, host_addr: usize, len: usize) {
        for (start, size) in mapped_host_spans(&self.host_ranges, host_addr, len) {
            // SAFETY: the span lies inside a host range this backend passed to
            // `hv_vm_map`, whose caller keeps it pinned while mapped, and the
            // call only performs cache maintenance on those bytes.
            unsafe { sys_icache_invalidate(start as *mut c_void, size) };
        }
    }

    fn inject(&mut self, event: Arm64Injection) -> Result<()> {
        match event {
            Arm64Injection::Interrupt { intid } => self.set_pending_irq(Some(intid)),
        }
    }

    fn set_pending_irq(&mut self, id: Option<GicIntId>) -> Result<()> {
        self.pending_irq = id;
        Ok(())
    }

    fn take_accepted_interrupt(&mut self) -> Option<GicIntId> {
        self.accepted_irq.take()
    }

    fn complete_read(&mut self, value: u64) -> Result<()> {
        match self.pending {
            Pending::MmioLoad {
                reg,
                size,
                sign_extend,
                sf,
            } => {
                let bits = u32::from(size) * 8;
                let masked = if bits == 64 {
                    value
                } else {
                    value & ((1u64 << bits) - 1)
                };
                let completed = if sign_extend && bits < 64 {
                    let shift = 64 - bits;
                    ((masked << shift) as i64 >> shift) as u64
                } else if sf {
                    masked
                } else {
                    masked as u32 as u64
                };
                if reg != 31 {
                    self.set_reg(reg, completed)?;
                }
                self.pending = Pending::None;
                Ok(())
            }
            Pending::SysregRead { reg } => {
                if reg != 31 {
                    self.set_reg(reg, value)?;
                }
                self.pending = Pending::None;
                Ok(())
            }
            _ => Err(BackendError::NoPendingRead),
        }
    }

    fn complete_fault(&mut self) -> Result<()> {
        match self.pending {
            Pending::SysregRead { .. } | Pending::SysregWrite => {
                let exception = undefined_exception(
                    self.reg(HV_REG_PC)?,
                    self.reg(HV_REG_CPSR)?,
                    self.sysreg(HV_SYS_REG_SCTLR_EL1)?,
                    self.sysreg(HV_SYS_REG_VBAR_EL1)?,
                )?;
                self.set_sysreg(HV_SYS_REG_ELR_EL1, exception.elr_el1)?;
                self.set_sysreg(HV_SYS_REG_SPSR_EL1, exception.spsr_el1)?;
                self.set_sysreg(HV_SYS_REG_ESR_EL1, exception.esr_el1)?;
                self.set_reg(HV_REG_CPSR, exception.pstate)?;
                self.set_reg(HV_REG_PC, exception.pc)?;
                self.pending = Pending::None;
                Ok(())
            }
            _ => Err(BackendError::BadCompletion),
        }
    }

    fn complete_ok(&mut self) -> Result<()> {
        if self.pending == Pending::SysregWrite {
            self.pending = Pending::None;
            Ok(())
        } else {
            Err(BackendError::BadCompletion)
        }
    }

    fn complete_hypercall(&mut self, _ret: u64) -> Result<()> {
        Err(BackendError::NoPendingRead)
    }

    fn complete_arch(&mut self, completion: crate::arch::arm64::Arm64Completion) -> Result<()> {
        match completion {}
    }

    fn retire_pending_completion(&mut self) -> Result<()> {
        Ok(())
    }

    fn read_irq_mask(&mut self) -> Result<Option<bool>> {
        if self.pending != Pending::None {
            return Err(BackendError::PendingCompletion);
        }
        Ok(Some(self.reg(HV_REG_CPSR)? & (1 << 7) != 0))
    }

    fn save(&mut self) -> Result<Arm64VcpuState> {
        if self.pending != Pending::None {
            return Err(BackendError::PendingCompletion);
        }
        let mut state = Arm64VcpuState::default();
        for (reg, slot) in state.core.x.iter_mut().enumerate() {
            *slot = self.reg(reg as u32)?;
        }
        state.core.pc = self.reg(HV_REG_PC)?;
        state.core.pstate = self.reg(HV_REG_CPSR)?;
        state.core.sp = self.sysreg(HV_SYS_REG_SP_EL0)?;
        state.core.sp_el1 = self.sysreg(HV_SYS_REG_SP_EL1)?;
        state.core.elr_el1 = self.sysreg(HV_SYS_REG_ELR_EL1)?;
        state.core.spsr_el1 = self.sysreg(HV_SYS_REG_SPSR_EL1)?;
        canonicalize_core_regs(&mut state.core);
        state.simd_fp.fpcr = self.reg(HV_REG_FPCR)?;
        state.simd_fp.fpsr = self.reg(HV_REG_FPSR)?;
        for (reg, q) in state.simd_fp.q.iter_mut().enumerate() {
            // SAFETY: `q` points to 16 writable bytes and the register index is
            // in the measured Q0..Q31 public range.
            hv("hv_vcpu_get_simd_fp_reg", unsafe {
                hv_vcpu_get_simd_fp_reg(self.vcpu, reg as u32, q)
            })?;
        }
        state.sysregs.sctlr_el1 = self.sysreg(HV_SYS_REG_SCTLR_EL1)?;
        state.sysregs.ttbr0_el1 = self.sysreg(HV_SYS_REG_TTBR0_EL1)?;
        state.sysregs.ttbr1_el1 = self.sysreg(HV_SYS_REG_TTBR1_EL1)?;
        state.sysregs.tcr_el1 = self.sysreg(HV_SYS_REG_TCR_EL1)?;
        state.sysregs.mair_el1 = self.sysreg(HV_SYS_REG_MAIR_EL1)?;
        state.sysregs.vbar_el1 = self.sysreg(HV_SYS_REG_VBAR_EL1)?;
        state.sysregs.cpacr_el1 = self.sysreg(HV_SYS_REG_CPACR_EL1)?;
        state.sysregs.esr_el1 = self.sysreg(HV_SYS_REG_ESR_EL1)?;
        state.sysregs.far_el1 = self.sysreg(HV_SYS_REG_FAR_EL1)?;
        state.sysregs.tpidr_el0 = self.sysreg(HV_SYS_REG_TPIDR_EL0)?;
        state.sysregs.tpidr_el1 = self.sysreg(HV_SYS_REG_TPIDR_EL1)?;
        state.sysregs.tpidrro_el0 = self.sysreg(HV_SYS_REG_TPIDRRO_EL0)?;
        state.sysregs.cntkctl_el1 = self.sysreg(HV_SYS_REG_CNTKCTL_EL1)?;
        for index in 0..16u16 {
            state.debug.breakpoint_value[index as usize] =
                self.sysreg(HV_SYS_REG_DBGBVR0_EL1 + index * 8)?;
            state.debug.breakpoint_control[index as usize] =
                self.sysreg(HV_SYS_REG_DBGBCR0_EL1 + index * 8)?;
            state.debug.watchpoint_value[index as usize] =
                self.sysreg(HV_SYS_REG_DBGWVR0_EL1 + index * 8)?;
            state.debug.watchpoint_control[index as usize] =
                self.sysreg(HV_SYS_REG_DBGWCR0_EL1 + index * 8)?;
        }
        state.debug.mdscr_el1 = self.sysreg(HV_SYS_REG_MDSCR_EL1)?;
        // SAFETY: outputs are live bools and this is the owning thread.
        hv("hv_vcpu_get_trap_debug_exceptions", unsafe {
            hv_vcpu_get_trap_debug_exceptions(self.vcpu, &mut state.debug.trap_debug_exceptions)
        })?;
        // SAFETY: outputs are live bools and this is the owning thread.
        hv("hv_vcpu_get_trap_debug_reg_accesses", unsafe {
            hv_vcpu_get_trap_debug_reg_accesses(self.vcpu, &mut state.debug.trap_debug_reg_accesses)
        })?;
        state.vtimer.cntv_ctl_el0 = self.sysreg(HV_SYS_REG_CNTV_CTL_EL0)? & 0b11;
        state.vtimer.cntv_cval_el0 = self.sysreg(HV_SYS_REG_CNTV_CVAL_EL0)?;
        // SAFETY: outputs are live and this is the owning thread.
        hv("hv_vcpu_get_vtimer_mask", unsafe {
            hv_vcpu_get_vtimer_mask(self.vcpu, &mut state.vtimer.masked)
        })?;
        let mut vtimer_offset = 0u64;
        // SAFETY: outputs are live and this is the owning thread.
        hv("hv_vcpu_get_vtimer_offset", unsafe {
            hv_vcpu_get_vtimer_offset(self.vcpu, &mut vtimer_offset)
        })?;
        state.vtimer.counter = host_counter().wrapping_sub(vtimer_offset);
        if !state.vtimer.masked {
            return Err(BackendError::InvalidState);
        }
        // SAFETY: outputs are live and this is the owning thread.
        hv("hv_vcpu_get_pending_interrupt(IRQ)", unsafe {
            hv_vcpu_get_pending_interrupt(
                self.vcpu,
                HV_INTERRUPT_TYPE_IRQ,
                &mut state.interrupts.irq,
            )
        })?;
        // SAFETY: outputs are live and this is the owning thread.
        hv("hv_vcpu_get_pending_interrupt(FIQ)", unsafe {
            hv_vcpu_get_pending_interrupt(
                self.vcpu,
                HV_INTERRUPT_TYPE_FIQ,
                &mut state.interrupts.fiq,
            )
        })?;
        state.mp_state = MpState::Runnable;
        Ok(state)
    }

    fn validate_restore_state(&self, state: &Arm64VcpuState) -> Result<()> {
        validate_restore_vcpu_state(state)
    }

    fn restore(&mut self, state: &Arm64VcpuState) -> Result<()> {
        if self.pending != Pending::None {
            return Err(BackendError::PendingCompletion);
        }
        validate_restore_vcpu_state(state)?;
        self.flush_guest_translations()?;
        for (reg, value) in state.core.x.iter().copied().enumerate() {
            self.set_reg(reg as u32, value)?;
        }
        self.set_reg(HV_REG_PC, state.core.pc)?;
        self.set_reg(HV_REG_CPSR, state.core.pstate)?;
        self.set_sysreg(HV_SYS_REG_SP_EL0, state.core.sp)?;
        self.set_sysreg(HV_SYS_REG_SP_EL1, state.core.sp_el1)?;
        self.set_sysreg(HV_SYS_REG_ELR_EL1, state.core.elr_el1)?;
        self.set_sysreg(HV_SYS_REG_SPSR_EL1, state.core.spsr_el1)?;
        self.set_reg(HV_REG_FPCR, state.simd_fp.fpcr)?;
        self.set_reg(HV_REG_FPSR, state.simd_fp.fpsr)?;
        for (reg, q) in state.simd_fp.q.iter().enumerate() {
            // SAFETY: `q` has 16 readable bytes and the thunk passes it in Q0
            // according to AAPCS64.
            hv("hv_vcpu_set_simd_fp_reg", unsafe {
                harmony_backend_hv_vcpu_set_simd_fp_reg(self.vcpu, reg as u32, q.as_ptr())
            })?;
        }
        self.set_sysreg(HV_SYS_REG_SCTLR_EL1, state.sysregs.sctlr_el1)?;
        self.set_sysreg(HV_SYS_REG_TTBR0_EL1, state.sysregs.ttbr0_el1)?;
        self.set_sysreg(HV_SYS_REG_TTBR1_EL1, state.sysregs.ttbr1_el1)?;
        self.set_sysreg(HV_SYS_REG_TCR_EL1, state.sysregs.tcr_el1)?;
        self.set_sysreg(HV_SYS_REG_MAIR_EL1, state.sysregs.mair_el1)?;
        self.set_sysreg(HV_SYS_REG_VBAR_EL1, state.sysregs.vbar_el1)?;
        self.set_sysreg(HV_SYS_REG_CPACR_EL1, state.sysregs.cpacr_el1)?;
        self.set_sysreg(HV_SYS_REG_ESR_EL1, state.sysregs.esr_el1)?;
        self.set_sysreg(HV_SYS_REG_FAR_EL1, state.sysregs.far_el1)?;
        self.set_sysreg(HV_SYS_REG_TPIDR_EL0, state.sysregs.tpidr_el0)?;
        self.set_sysreg(HV_SYS_REG_TPIDR_EL1, state.sysregs.tpidr_el1)?;
        self.set_sysreg(HV_SYS_REG_TPIDRRO_EL0, state.sysregs.tpidrro_el0)?;
        self.set_sysreg(HV_SYS_REG_CNTKCTL_EL1, state.sysregs.cntkctl_el1)?;
        for index in 0..16u16 {
            self.set_sysreg(
                HV_SYS_REG_DBGBVR0_EL1 + index * 8,
                state.debug.breakpoint_value[index as usize],
            )?;
            self.set_sysreg(
                HV_SYS_REG_DBGBCR0_EL1 + index * 8,
                state.debug.breakpoint_control[index as usize],
            )?;
            self.set_sysreg(
                HV_SYS_REG_DBGWVR0_EL1 + index * 8,
                state.debug.watchpoint_value[index as usize],
            )?;
            self.set_sysreg(
                HV_SYS_REG_DBGWCR0_EL1 + index * 8,
                state.debug.watchpoint_control[index as usize],
            )?;
        }
        self.set_sysreg(HV_SYS_REG_MDSCR_EL1, state.debug.mdscr_el1)?;
        // SAFETY: the vCPU is live and this is the owning thread.
        hv("hv_vcpu_set_trap_debug_exceptions", unsafe {
            hv_vcpu_set_trap_debug_exceptions(self.vcpu, state.debug.trap_debug_exceptions)
        })?;
        // SAFETY: the vCPU is live and this is the owning thread.
        hv("hv_vcpu_set_trap_debug_reg_accesses", unsafe {
            hv_vcpu_set_trap_debug_reg_accesses(self.vcpu, state.debug.trap_debug_reg_accesses)
        })?;
        self.set_sysreg(HV_SYS_REG_CNTV_CVAL_EL0, state.vtimer.cntv_cval_el0)?;
        self.set_sysreg(HV_SYS_REG_CNTV_CTL_EL0, state.vtimer.cntv_ctl_el0)?;
        // SAFETY: the vCPU is live and this is the owning thread.
        hv("hv_vcpu_set_vtimer_mask", unsafe {
            hv_vcpu_set_vtimer_mask(self.vcpu, true)
        })?;
        // SAFETY: the vCPU is live and this is the owning thread.
        hv("hv_vcpu_set_vtimer_offset", unsafe {
            hv_vcpu_set_vtimer_offset(self.vcpu, host_counter().wrapping_sub(state.vtimer.counter))
        })?;
        // SAFETY: the vCPU is live and this is the owning thread.
        hv("hv_vcpu_set_pending_interrupt(IRQ)", unsafe {
            hv_vcpu_set_pending_interrupt(self.vcpu, HV_INTERRUPT_TYPE_IRQ, state.interrupts.irq)
        })?;
        // SAFETY: the vCPU is live and this is the owning thread.
        hv("hv_vcpu_set_pending_interrupt(FIQ)", unsafe {
            hv_vcpu_set_pending_interrupt(self.vcpu, HV_INTERRUPT_TYPE_FIQ, state.interrupts.fiq)
        })?;
        self.pending_irq = None;
        self.accepted_irq = None;
        Ok(())
    }

    fn exit_counts(&self) -> ExitCounts {
        self.counts
    }

    fn reset_exit_counts(&mut self) {
        self.counts = ExitCounts::default();
    }

    fn capabilities(&self) -> Capabilities<Arm64Caps> {
        Capabilities {
            name: "hvf-arm64-virtual_time",
            arch: Arm64Caps {
                in_kernel_gic: false,
                asid_bits: Arm64AsidBits::Eight,
            },
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn raw_exit(syndrome: u64, ipa: u64) -> HvVcpuExit {
        HvVcpuExit {
            reason: HV_EXIT_REASON_EXCEPTION,
            _padding: 0,
            exception: HvExitException {
                syndrome,
                virtual_address: ipa,
                physical_address: ipa,
            },
        }
    }

    #[test]
    fn lower_el_aborts_inside_mapped_ram_are_tracked_writes() {
        let regions = [(0x4000_0000, 0x10_0000)];
        let fault = |ec: u64, ipa: u64| {
            tracked_write_fault(&raw_exit((ec << 26) | 0x1c1_8047, ipa).exception, &regions)
        };
        assert_eq!(fault(0x24, 0x4002_4ff8), Some(0x4002_4000));
        assert_eq!(fault(0x20, 0x400f_fff8), Some(0x400f_c000));
        assert_eq!(fault(0x24, 0x0900_0000), None, "outside RAM");
        assert_eq!(fault(0x24, 0x4010_0000), None, "one past RAM");
        assert_eq!(fault(0x25, 0x4002_4ff8), None);
    }

    #[test]
    fn written_pages_coalesce_into_contiguous_protect_runs() {
        let page = HV_PAGE_SIZE as u64;
        assert_eq!(
            contiguous_runs(&[0, page, 2 * page, 5 * page, 6 * page, 9 * page]),
            [
                (0, 3 * HV_PAGE_SIZE),
                (5 * page, 2 * HV_PAGE_SIZE),
                (9 * page, HV_PAGE_SIZE)
            ]
        );
        assert!(contiguous_runs(&[]).is_empty());
    }

    #[test]
    fn flush_stub_invalidates_translations_and_instruction_cache_then_exits() {
        let sys = |op0: u32, op1: u32, crn: u32, crm: u32, op2: u32, rt: u32| {
            0xd500_0000 | (op0 << 19) | (op1 << 16) | (crn << 12) | (crm << 8) | (op2 << 5) | rt
        };
        let barrier = |crm: u32, op2: u32| 0xd503_301f | (crm << 8) | (op2 << 5);
        assert_eq!(TLB_FLUSH_STUB[0], sys(1, 0, 8, 3, 0, 31));
        assert_eq!(TLB_FLUSH_STUB[1], sys(1, 0, 7, 1, 0, 31));
        assert_eq!(TLB_FLUSH_STUB[2], barrier(0b1011, 4));
        assert_eq!(TLB_FLUSH_STUB[3], barrier(0b1111, 6));
        assert_eq!(TLB_FLUSH_STUB[4], 0xd400_0002);
    }

    #[test]
    fn instruction_cache_spans_stay_inside_mapped_host_ranges() {
        let ranges = [(0x10_000, 0x4000), (0x40_000, 0x8000)];
        let spans = |addr, len| mapped_host_spans(&ranges, addr, len).collect::<Vec<_>>();
        assert_eq!(spans(1, 64), []);
        assert_eq!(spans(0x10_000, 0), []);
        assert_eq!(spans(0x10_100, 0x100), [(0x10_100, 0x100)]);
        assert_eq!(spans(0xf_000, 0x2000), [(0x10_000, 0x1000)]);
        assert_eq!(
            spans(0x12_000, 0x40_000),
            [(0x12_000, 0x2000), (0x40_000, 0x8000)]
        );
        assert_eq!(spans(usize::MAX - 4, 64), []);
    }

    #[test]
    fn flush_stub_sits_above_every_mapped_region() {
        assert_eq!(flush_stub_gpa(&[]), 0);
        assert_eq!(flush_stub_gpa(&[(0x4000_0000, 0x8000_0000)]), 0xc000_0000);
        assert_eq!(
            flush_stub_gpa(&[(0x4000_0000, 0x4000), (0x1000_0000, 0x1000_0000)]),
            0x4000_4000
        );
    }

    #[test]
    fn implicit_identity_allowlist_is_exact_and_value_sensitive() {
        for encoding in [0xc022, 0xc027, 0xc02a, 0xc032, 0xc033, 0xc03b, 0xc03c] {
            assert_eq!(hvf_implicit_identity_value(encoding), Some(0));
        }
        assert_eq!(
            hvf_implicit_identity_value(0xd801),
            Some(0x0000_0000_8444_c004)
        );
        assert_eq!(hvf_implicit_identity_value(0xc020), None);
        assert_ne!(hvf_implicit_identity_value(0xc032), Some(2));
    }

    #[test]
    fn id_register_fields_must_not_exceed_the_host() {
        let host_mmfr0 = 0x0000_1000_0f10_0002;
        assert!(id_register_within_host(0xc038, host_mmfr0, host_mmfr0));
        assert!(!id_register_within_host(
            0xc038,
            host_mmfr0 | (2 << 4),
            host_mmfr0
        ));
        assert!(!id_register_within_host(0xc031, 1 << 8, 0));
        assert!(id_register_within_host(0xc031, 0, 1 << 8));
    }

    #[test]
    fn signed_id_fields_treat_all_ones_as_absent() {
        assert!(id_register_within_host(0xc028, 0xf << 36, 0));
        assert!(!id_register_within_host(0xc028, 0, 0xf << 36));
        assert!(!id_register_within_host(0xc031, 0xf << 36, 0));
    }

    #[test]
    fn hypervisor_and_emulated_id_fields_are_not_compared() {
        assert!(id_register_within_host(0xc020, 1 << 24, 0));
        assert!(id_register_within_host(0xc038, 0x111 << 32, 0));
        assert!(id_register_within_host(0xc039, 0x21 << 4, 0));
        assert!(id_register_within_host(0xc03a, (2 << 56) | (1 << 40), 0));
        assert!(id_register_within_host(0xc000, u64::MAX, 0));
    }

    #[test]
    fn psci_version_matches_the_portable_firmware_contract() {
        assert_eq!(PSCI_VERSION_1_0, 0x0001_0000);
        assert_ne!(PSCI_VERSION_1_0, 0x0001_0001);
    }

    #[test]
    fn probe_data_abort_decodes_exact_mmio_shape() {
        let decoded = decode_data_abort(raw_exit(0x93c4_8007, 0x20000)).unwrap();
        assert_eq!(
            decoded,
            DataAbort {
                gpa: Gpa(0x20000),
                size: 8,
                write: false,
                reg: 4,
                sign_extend: false,
                sf: true,
            }
        );
    }

    #[test]
    fn measured_gic_sysreg_syndromes_canonicalize_independent_of_rt_and_direction() {
        let iar = 0x6230_3019u64 & 0x01ff_ffff;
        let eoir = 0x6232_3038u64 & 0x01ff_ffff;
        let pmr_write = 0x6230_104cu64 & 0x01ff_ffff;
        let pmr_read = 0x6230_106du64 & 0x01ff_ffff;
        assert_eq!(canonical_sysreg(iar), 0x0030_3018);
        assert_eq!(canonical_sysreg(eoir), 0x0032_3018);
        assert_eq!(canonical_sysreg(pmr_write), 0x0030_100c);
        assert_eq!(canonical_sysreg(pmr_read), canonical_sysreg(pmr_write));
        assert_eq!(sysreg_rt(eoir), 1);
        let bpr1_xzr = 0x0036_3018u64 | (31 << 5);
        assert_eq!(sysreg_rt(bpr1_xzr), 31);
        assert_eq!(canonical_sysreg(bpr1_xzr), 0x0036_3018);
    }

    #[test]
    fn pending_irq_is_accepted_only_at_the_guest_iar_read() {
        let pending = Some(GicIntId(20));
        assert_eq!(
            accepted_irq_for_sysreg(pending, ICC_IAR1_EL1_CANONICAL, true),
            pending
        );
        assert_eq!(
            accepted_irq_for_sysreg(pending, ICC_IAR1_EL1_CANONICAL, false),
            None,
            "a write-shaped trap cannot accept an IRQ"
        );
        assert_eq!(
            accepted_irq_for_sysreg(pending, 0x0030_100c, true),
            None,
            "an unrelated trapped read cannot accept an IRQ"
        );
        assert_eq!(
            accepted_irq_for_sysreg(None, ICC_IAR1_EL1_CANONICAL, true),
            None,
            "an IAR read cannot fabricate an IRQ"
        );
    }

    #[test]
    fn untrusted_data_abort_without_isv_fails_closed() {
        assert!(decode_data_abort(raw_exit(0x9000_0007, 0)).is_err());
    }

    #[test]
    fn undef_from_el0_enters_the_lower_aarch64_sync_vector() {
        let old = PSTATE_NZCV | PSTATE_DIT | PSTATE_SSBS | PSTATE_MODE_EL0T;
        let exception = undefined_exception(0x1004, old, SCTLR_DSSBS, 0x8000).unwrap();
        assert_eq!(
            exception,
            UndefinedException {
                pc: 0x8400,
                pstate: PSTATE_NZCV
                    | PSTATE_DIT
                    | PSTATE_PAN
                    | PSTATE_SSBS
                    | PSTATE_DAIF
                    | PSTATE_MODE_EL1H,
                elr_el1: 0x1000,
                spsr_el1: old,
                esr_el1: ESR_IL,
            }
        );
    }

    #[test]
    fn undef_vector_and_pstate_are_mode_and_sctlr_sensitive() {
        let el1t = undefined_exception(0x2004, PSTATE_MODE_EL1T, SCTLR_SPAN, 0x8000).unwrap();
        assert_eq!(el1t.pc, 0x8000);
        assert_eq!(el1t.pstate & PSTATE_PAN, 0);

        let el1h = undefined_exception(0x2004, PSTATE_MODE_EL1H, 0, 0x8000).unwrap();
        assert_eq!(el1h.pc, 0x8200);
        assert_ne!(el1h.pstate & PSTATE_PAN, 0);
        assert_eq!(el1h.pstate & PSTATE_SSBS, 0);

        assert!(undefined_exception(3, PSTATE_MODE_EL0T, 0, 0).is_err());
        assert!(undefined_exception(4, 0x10, 0, 0).is_err());
        assert!(undefined_exception(4, PSTATE_MODE_EL0T, 0, u64::MAX).is_err());
    }
}

// SPDX-License-Identifier: AGPL-3.0-or-later

use std::sync::{Arc, atomic::AtomicBool};

use crate::arch::Arch;
use crate::error::Result;
use crate::exit::{Capabilities, Exit, ExitCounts, StoreCompletions};
use crate::types::Gpa;

pub trait Backend {
    type A: Arch;

    fn set_policy(&mut self, policy: &<Self::A as Arch>::Policy) -> Result<()>;

    /// # Safety
    /// The caller MUST guarantee that `host`'s backing (a) stays live at a fixed
    /// address — pinned, never reallocated or moved — until the backend is
    /// dropped or the region is replaced; (b) is not aliased by any other live
    /// `&`/`&mut` while a `run` is in flight; and (c) starts at a
    /// **4 KiB-aligned host address** (`host.as_ptr() as usize % 4096 == 0`).
    /// `KVM_SET_USER_MEMORY_REGION` requires the *userspace address itself* to be
    /// page-aligned, which a plain `Vec<u8>`/slice does NOT guarantee (KVM
    /// rejects it with `EINVAL`) — back the region with an `mmap`/page-aligned
    /// allocation. Violating (a)/(b) is a use-after-free or data race; that
    /// unenforceable invariant is why this is `unsafe`. The backend records the
    /// region and retains `host`'s pointer past this call — the `&mut [u8]`
    /// borrow ends at return, but the guest writes through that pointer during
    /// every later `run`.
    unsafe fn map_memory(&mut self, gpa: Gpa, host: &mut [u8]) -> Result<()>;

    fn drain_dirty_pages(&mut self) -> Result<Vec<u64>> {
        Err(crate::error::BackendError::Unsupported {
            what: "drain_dirty_pages",
        })
    }

    fn invalidate_instruction_cache(&mut self, _host_addr: usize, _len: usize) {}

    #[cfg(feature = "xsave-diagnostics")]
    fn diagnostic_breakpoint(&mut self, _rip: u64) -> Result<()> {
        Err(crate::error::BackendError::Unsupported {
            what: "diagnostic_breakpoint",
        })
    }

    #[cfg(feature = "xsave-diagnostics")]
    fn diagnostic_debug_hits(&self) -> Vec<u64> {
        Vec::new()
    }

    fn run(&mut self) -> Result<Exit<Self::A>>;

    fn inject(&mut self, event: <Self::A as Arch>::Injection) -> Result<()>;

    fn set_pending_irq(&mut self, id: Option<<Self::A as Arch>::IntId>) -> Result<()>;

    fn take_accepted_interrupt(&mut self) -> Option<<Self::A as Arch>::IntId>;

    fn read_irq_mask(&mut self) -> Result<Option<bool>> {
        Ok(None)
    }

    fn complete_read(&mut self, value: u64) -> Result<()>;

    fn complete_fault(&mut self) -> Result<()>;

    fn complete_ok(&mut self) -> Result<()>;

    fn complete_hypercall(&mut self, ret: u64) -> Result<()>;

    fn complete_arch(&mut self, completion: <Self::A as Arch>::Completion) -> Result<()>;

    fn retire_pending_completion(&mut self) -> Result<()> {
        Err(crate::error::BackendError::Unsupported {
            what: "retire_pending_completion",
        })
    }

    fn finish_exit(&mut self) -> Result<Option<Exit<Self::A>>> {
        Ok(None)
    }

    fn prepare_snapshot(&mut self) -> Result<()> {
        Ok(())
    }

    fn save(&mut self) -> Result<<Self::A as Arch>::VcpuState>;

    fn validate_restore_state(&self, _state: &<Self::A as Arch>::VcpuState) -> Result<()> {
        Ok(())
    }

    fn restore(&mut self, state: &<Self::A as Arch>::VcpuState) -> Result<()>;

    fn exit_counts(&self) -> ExitCounts;

    fn reset_exit_counts(&mut self);

    fn store_completions(&self) -> StoreCompletions {
        StoreCompletions::default()
    }

    fn capabilities(&self) -> Capabilities<<Self::A as Arch>::Caps>;

    fn cancellation_flag(&self) -> Option<Arc<AtomicBool>> {
        None
    }
}

impl<B: Backend + ?Sized> Backend for Box<B> {
    type A = B::A;

    fn set_policy(&mut self, policy: &<Self::A as Arch>::Policy) -> Result<()> {
        (**self).set_policy(policy)
    }

    unsafe fn map_memory(&mut self, gpa: Gpa, host: &mut [u8]) -> Result<()> {
        // SAFETY: the caller upholds `map_memory`'s contract; we only forward the
        // call to the boxed backend, adding no new obligation.
        unsafe { (**self).map_memory(gpa, host) }
    }

    fn drain_dirty_pages(&mut self) -> Result<Vec<u64>> {
        (**self).drain_dirty_pages()
    }

    fn invalidate_instruction_cache(&mut self, host_addr: usize, len: usize) {
        (**self).invalidate_instruction_cache(host_addr, len);
    }

    #[cfg(feature = "xsave-diagnostics")]
    fn diagnostic_breakpoint(&mut self, rip: u64) -> Result<()> {
        (**self).diagnostic_breakpoint(rip)
    }

    #[cfg(feature = "xsave-diagnostics")]
    fn diagnostic_debug_hits(&self) -> Vec<u64> {
        (**self).diagnostic_debug_hits()
    }

    fn run(&mut self) -> Result<Exit<Self::A>> {
        (**self).run()
    }

    fn inject(&mut self, event: <Self::A as Arch>::Injection) -> Result<()> {
        (**self).inject(event)
    }

    fn set_pending_irq(&mut self, id: Option<<Self::A as Arch>::IntId>) -> Result<()> {
        (**self).set_pending_irq(id)
    }

    fn take_accepted_interrupt(&mut self) -> Option<<Self::A as Arch>::IntId> {
        (**self).take_accepted_interrupt()
    }

    fn read_irq_mask(&mut self) -> Result<Option<bool>> {
        (**self).read_irq_mask()
    }

    fn complete_read(&mut self, value: u64) -> Result<()> {
        (**self).complete_read(value)
    }

    fn complete_fault(&mut self) -> Result<()> {
        (**self).complete_fault()
    }

    fn complete_ok(&mut self) -> Result<()> {
        (**self).complete_ok()
    }

    fn complete_hypercall(&mut self, ret: u64) -> Result<()> {
        (**self).complete_hypercall(ret)
    }

    fn complete_arch(&mut self, completion: <Self::A as Arch>::Completion) -> Result<()> {
        (**self).complete_arch(completion)
    }

    fn retire_pending_completion(&mut self) -> Result<()> {
        (**self).retire_pending_completion()
    }

    fn finish_exit(&mut self) -> Result<Option<Exit<Self::A>>> {
        (**self).finish_exit()
    }

    fn prepare_snapshot(&mut self) -> Result<()> {
        (**self).prepare_snapshot()
    }

    fn save(&mut self) -> Result<<Self::A as Arch>::VcpuState> {
        (**self).save()
    }

    fn validate_restore_state(&self, state: &<Self::A as Arch>::VcpuState) -> Result<()> {
        (**self).validate_restore_state(state)
    }

    fn restore(&mut self, state: &<Self::A as Arch>::VcpuState) -> Result<()> {
        (**self).restore(state)
    }

    fn exit_counts(&self) -> ExitCounts {
        (**self).exit_counts()
    }

    fn reset_exit_counts(&mut self) {
        (**self).reset_exit_counts()
    }

    fn store_completions(&self) -> StoreCompletions {
        (**self).store_completions()
    }

    fn capabilities(&self) -> Capabilities<<Self::A as Arch>::Caps> {
        (**self).capabilities()
    }

    fn cancellation_flag(&self) -> Option<Arc<AtomicBool>> {
        (**self).cancellation_flag()
    }
}

#[cfg(test)]
mod tests {
    use super::Backend;
    use crate::arch::x86::{Injection, VcpuState, X86, X86Caps, X86Completion, X86Policy};
    use crate::error::{BackendError, Result};
    use crate::exit::{Capabilities, CommonExit, Exit, ExitCounts};
    use crate::types::Gpa;
    use std::sync::Arc;
    #[cfg(feature = "mock")]
    use std::sync::atomic::AtomicBool;
    use std::sync::atomic::{AtomicUsize, Ordering};

    #[derive(Default)]
    struct DefaultRetireBackend {
        finish_calls: Arc<AtomicUsize>,
        finish_response: Option<Exit<X86>>,
        finish_error: bool,
        validation_calls: Arc<AtomicUsize>,
        preparation_calls: usize,
        preparation_error: bool,
        irq_mask: Option<bool>,
        irq_mask_error: bool,
        #[cfg(feature = "xsave-diagnostics")]
        breakpoint_requests: Vec<u64>,
        #[cfg(feature = "xsave-diagnostics")]
        debug_hits: Vec<u64>,
    }

    impl Backend for DefaultRetireBackend {
        type A = X86;

        fn set_policy(&mut self, _policy: &X86Policy) -> Result<()> {
            Ok(())
        }

        unsafe fn map_memory(&mut self, _gpa: Gpa, _host: &mut [u8]) -> Result<()> {
            Err(BackendError::Unsupported {
                what: "default-retire-test map_memory",
            })
        }

        fn run(&mut self) -> Result<Exit<X86>> {
            Err(BackendError::Unsupported {
                what: "default-retire-test run",
            })
        }

        fn inject(&mut self, _event: Injection) -> Result<()> {
            Ok(())
        }

        fn set_pending_irq(&mut self, _id: Option<u8>) -> Result<()> {
            Ok(())
        }

        fn take_accepted_interrupt(&mut self) -> Option<u8> {
            None
        }

        fn complete_read(&mut self, _value: u64) -> Result<()> {
            Err(BackendError::BadCompletion)
        }

        fn complete_fault(&mut self) -> Result<()> {
            Err(BackendError::BadCompletion)
        }

        fn complete_ok(&mut self) -> Result<()> {
            Err(BackendError::BadCompletion)
        }

        fn complete_hypercall(&mut self, _ret: u64) -> Result<()> {
            Err(BackendError::BadCompletion)
        }

        fn complete_arch(&mut self, _completion: X86Completion) -> Result<()> {
            Err(BackendError::BadCompletion)
        }

        fn finish_exit(&mut self) -> Result<Option<Exit<X86>>> {
            self.finish_calls.fetch_add(1, Ordering::SeqCst);
            if self.finish_error {
                return Err(BackendError::Unsupported {
                    what: "finish_exit-test",
                });
            }
            Ok(self.finish_response.take())
        }

        fn prepare_snapshot(&mut self) -> Result<()> {
            self.preparation_calls += 1;
            if self.preparation_error {
                Err(BackendError::PendingCompletion)
            } else {
                Ok(())
            }
        }

        #[cfg(feature = "xsave-diagnostics")]
        fn diagnostic_breakpoint(&mut self, rip: u64) -> Result<()> {
            self.breakpoint_requests.push(rip);
            if rip == 0 {
                Err(BackendError::InvalidState)
            } else {
                Ok(())
            }
        }

        #[cfg(feature = "xsave-diagnostics")]
        fn diagnostic_debug_hits(&self) -> Vec<u64> {
            self.debug_hits.clone()
        }

        fn read_irq_mask(&mut self) -> Result<Option<bool>> {
            if self.irq_mask_error {
                Err(BackendError::PendingCompletion)
            } else {
                Ok(self.irq_mask)
            }
        }

        fn save(&mut self) -> Result<VcpuState> {
            Ok(VcpuState::default())
        }

        fn validate_restore_state(&self, state: &VcpuState) -> Result<()> {
            self.validation_calls.fetch_add(1, Ordering::SeqCst);
            if state.xsave.len() == 1 {
                Err(BackendError::InvalidState)
            } else {
                Ok(())
            }
        }

        fn restore(&mut self, _state: &VcpuState) -> Result<()> {
            Ok(())
        }

        fn exit_counts(&self) -> ExitCounts {
            ExitCounts::default()
        }

        fn reset_exit_counts(&mut self) {}

        fn capabilities(&self) -> Capabilities<X86Caps> {
            Capabilities {
                name: "default-retire-test",
                arch: X86Caps,
            }
        }
    }

    #[test]
    fn boxed_snapshot_preparation_preserves_failure_and_recovery() {
        let mut backend = Box::new(DefaultRetireBackend {
            preparation_error: true,
            ..Default::default()
        });
        assert!(matches!(
            backend.prepare_snapshot(),
            Err(BackendError::PendingCompletion)
        ));
        assert_eq!(backend.preparation_calls, 1);
        backend.preparation_error = false;
        backend.prepare_snapshot().expect("completion is now ready");
        assert_eq!(backend.preparation_calls, 2);
    }

    #[test]
    #[cfg(feature = "xsave-diagnostics")]
    fn boxed_diagnostics_preserve_addresses_errors_and_hit_order() {
        let mut backend = Box::new(DefaultRetireBackend {
            debug_hits: vec![0x1234, 0xabcd, 0x1234],
            ..Default::default()
        });
        backend
            .diagnostic_breakpoint(0x1234)
            .expect("valid breakpoint");
        assert!(matches!(
            backend.diagnostic_breakpoint(0),
            Err(BackendError::InvalidState)
        ));
        assert_eq!(backend.breakpoint_requests, [0x1234, 0]);
        let mut hits = backend.diagnostic_debug_hits();
        assert_eq!(hits, [0x1234, 0xabcd, 0x1234]);
        hits.clear();
        assert_eq!(backend.diagnostic_debug_hits(), [0x1234, 0xabcd, 0x1234]);
    }

    #[test]
    #[cfg(all(feature = "mock", feature = "xsave-diagnostics"))]
    fn unsupported_diagnostics_fail_without_fabricating_hits() {
        let mut backend = crate::MockBackend::new();
        assert!(matches!(
            backend.diagnostic_breakpoint(0x1234),
            Err(BackendError::Unsupported {
                what: "diagnostic_breakpoint"
            })
        ));
        assert!(backend.diagnostic_debug_hits().is_empty());
    }

    #[test]
    fn default_retirement_is_fail_closed_and_box_forwards_it() {
        let mut plain = DefaultRetireBackend::default();
        assert!(matches!(
            plain.retire_pending_completion(),
            Err(BackendError::Unsupported {
                what: "retire_pending_completion"
            })
        ));

        let mut boxed: Box<dyn Backend<A = X86>> = Box::new(DefaultRetireBackend::default());
        assert!(matches!(
            boxed.retire_pending_completion(),
            Err(BackendError::Unsupported {
                what: "retire_pending_completion"
            })
        ));
    }

    #[test]
    fn box_forwards_finish_exit_response_calls_and_errors() {
        let calls = Arc::new(AtomicUsize::new(0));
        let continuation = Exit::Common(CommonExit::Mmio {
            gpa: Gpa(0xfee0_0000),
            size: 4,
            write: None,
        });
        let mut boxed: Box<dyn Backend<A = X86>> = Box::new(DefaultRetireBackend {
            finish_calls: Arc::clone(&calls),
            finish_response: Some(continuation.clone()),
            finish_error: false,
            ..Default::default()
        });
        assert_eq!(
            boxed.finish_exit().expect("forwarded continuation"),
            Some(continuation)
        );
        assert_eq!(calls.load(Ordering::SeqCst), 1);
        assert_eq!(boxed.finish_exit().expect("forwarded empty response"), None);
        assert_eq!(calls.load(Ordering::SeqCst), 2);

        let error_calls = Arc::new(AtomicUsize::new(0));
        let mut failing: Box<dyn Backend<A = X86>> = Box::new(DefaultRetireBackend {
            finish_calls: Arc::clone(&error_calls),
            finish_response: None,
            finish_error: true,
            ..Default::default()
        });
        assert!(matches!(
            failing.finish_exit(),
            Err(BackendError::Unsupported {
                what: "finish_exit-test"
            })
        ));
        assert_eq!(error_calls.load(Ordering::SeqCst), 1);
    }

    #[test]
    fn box_forwards_restore_shape_validation_without_changing_the_state() {
        let invalid = VcpuState {
            xsave: vec![0],
            ..Default::default()
        };
        let before = invalid.clone();
        let calls = Arc::new(AtomicUsize::new(0));
        let plain = DefaultRetireBackend {
            validation_calls: Arc::clone(&calls),
            ..Default::default()
        };
        assert!(matches!(
            plain.validate_restore_state(&invalid),
            Err(BackendError::InvalidState)
        ));
        assert_eq!(calls.load(Ordering::SeqCst), 1);
        assert_eq!(invalid, before);

        let boxed: Box<dyn Backend<A = X86>> = Box::new(DefaultRetireBackend {
            validation_calls: Arc::clone(&calls),
            ..Default::default()
        });
        assert!(matches!(
            boxed.validate_restore_state(&invalid),
            Err(BackendError::InvalidState)
        ));
        assert_eq!(calls.load(Ordering::SeqCst), 2);
        assert_eq!(invalid, before);
    }

    #[test]
    fn a_backend_without_a_latch_reports_none_through_a_box_too() {
        assert!(
            DefaultRetireBackend::default()
                .cancellation_flag()
                .is_none()
        );
        let without: Box<dyn Backend<A = X86>> = Box::new(DefaultRetireBackend::default());
        assert!(without.cancellation_flag().is_none());
    }

    #[cfg(feature = "mock")]
    #[test]
    fn box_forwards_the_backend_latch_unchanged() {
        let latch = Arc::new(AtomicBool::new(false));
        let boxed: Box<dyn Backend<A = X86>> =
            Box::new(crate::MockBackend::new().with_cancellation_flag(Arc::clone(&latch)));
        let forwarded = boxed.cancellation_flag().expect("latch forwarded");
        assert!(Arc::ptr_eq(&forwarded, &latch));
    }

    #[test]
    fn boxed_irq_mask_forwards_supported_unsupported_and_error_results() {
        for mask in [None, Some(false), Some(true)] {
            let mut backend: Box<dyn Backend<A = X86>> = Box::new(DefaultRetireBackend {
                irq_mask: mask,
                ..Default::default()
            });
            assert_eq!(backend.read_irq_mask().unwrap(), mask);
        }
        let mut backend: Box<dyn Backend<A = X86>> = Box::new(DefaultRetireBackend {
            irq_mask_error: true,
            ..Default::default()
        });
        assert!(matches!(
            backend.read_irq_mask(),
            Err(BackendError::PendingCompletion)
        ));
    }
}

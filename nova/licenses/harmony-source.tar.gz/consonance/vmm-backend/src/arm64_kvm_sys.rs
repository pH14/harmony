// SPDX-License-Identifier: AGPL-3.0-or-later

use std::os::fd::AsRawFd;

use kvm_bindings::{
    kvm_clear_dirty_log, kvm_clear_dirty_log__bindgen_ty_1, kvm_create_device, kvm_device_attr,
    kvm_enable_cap, kvm_run, kvm_userspace_memory_region, kvm_vcpu_init,
};
use kvm_ioctls::{Cap, DeviceFd, Kvm, VcpuFd, VmFd};

use crate::arch::arm64::Arm64AsidBits;
use crate::arm64_kvm::{Arm64Kvm, KvmRunView, RunOffsets, RunPage};
use crate::error::{BackendError, Result};
use crate::types::MpState;

const RUN_OFFSETS: RunOffsets = RunOffsets {
    exit_reason: core::mem::offset_of!(kvm_run, exit_reason),
    mmio_phys_addr: core::mem::offset_of!(kvm_run, __bindgen_anon_1.mmio.phys_addr),
    mmio_data: core::mem::offset_of!(kvm_run, __bindgen_anon_1.mmio.data),
    mmio_len: core::mem::offset_of!(kvm_run, __bindgen_anon_1.mmio.len),
    mmio_is_write: core::mem::offset_of!(kvm_run, __bindgen_anon_1.mmio.is_write),
    system_event_type: core::mem::offset_of!(kvm_run, __bindgen_anon_1.system_event.type_),
};

const _UAPI_PIN: () = {
    assert!(crate::arm64_kvm::KVM_EXIT_MMIO == kvm_bindings::KVM_EXIT_MMIO);
    assert!(crate::arm64_kvm::KVM_EXIT_SYSTEM_EVENT == kvm_bindings::KVM_EXIT_SYSTEM_EVENT);
    assert!(crate::arm64_kvm::KVM_EXIT_INTR == kvm_bindings::KVM_EXIT_INTR);
    assert!(crate::arm64_kvm::KVM_EXIT_FAIL_ENTRY == kvm_bindings::KVM_EXIT_FAIL_ENTRY);
    assert!(crate::arm64_kvm::KVM_EXIT_INTERNAL_ERROR == kvm_bindings::KVM_EXIT_INTERNAL_ERROR);
    assert!(crate::arm64_kvm::KVM_EXIT_HYPERCALL == kvm_bindings::KVM_EXIT_HYPERCALL);
    assert!(crate::arm64_kvm::KVM_REG_ARM64 == kvm_bindings::KVM_REG_ARM64);
    assert!(crate::arm64_kvm::KVM_REG_SIZE_U64 == kvm_bindings::KVM_REG_SIZE_U64);
    assert!(crate::arm64_kvm::KVM_REG_ARM_CORE == kvm_bindings::KVM_REG_ARM_CORE as u64);
    assert!(crate::arm64_kvm::KVM_REG_ARM64_SYSREG == kvm_bindings::KVM_REG_ARM64_SYSREG as u64);
    assert!(crate::arm64_kvm::KVM_REG_ARM_FW == kvm_bindings::KVM_REG_ARM_FW as u64);
    assert!(0x0016 << 16 == kvm_bindings::KVM_REG_ARM_FW_FEAT_BMAP);
    assert!(crate::arm64_kvm::KVM_ARM_VCPU_PSCI_0_2 == kvm_bindings::KVM_ARM_VCPU_PSCI_0_2);
    assert!(crate::arm64_kvm::KVM_MEM_LOG_DIRTY_PAGES == kvm_bindings::KVM_MEM_LOG_DIRTY_PAGES);
    assert!(kvm_bindings::KVM_CAP_MANUAL_DIRTY_LOG_PROTECT2 == 168);
    assert!(kvm_bindings::KVM_DIRTY_LOG_MANUAL_PROTECT_ENABLE == 1);
    assert!(
        crate::arm64_kvm::KVM_DEV_ARM_VGIC_GRP_DIST_REGS
            == kvm_bindings::KVM_DEV_ARM_VGIC_GRP_DIST_REGS
    );
    assert!(
        crate::arm64_kvm::KVM_DEV_ARM_VGIC_GRP_REDIST_REGS
            == kvm_bindings::KVM_DEV_ARM_VGIC_GRP_REDIST_REGS
    );
    assert!(
        crate::arm64_kvm::KVM_DEV_ARM_VGIC_GRP_CPU_SYSREGS
            == kvm_bindings::KVM_DEV_ARM_VGIC_GRP_CPU_SYSREGS
    );
    assert!(7 == kvm_bindings::KVM_DEV_ARM_VGIC_GRP_LEVEL_INFO);
};

const GICD_BASE: u64 = 0x0800_0000;
const GICR_BASE: u64 = 0x080a_0000;
const QUARANTINED_VTIMER_PPI: u32 = 20;

const fn ioc(dir: u64, typ: u64, nr: u64, size: u64) -> u64 {
    (dir << 30) | (size << 16) | (typ << 8) | nr
}

const KVM_ENABLE_CAP_IOCTL: libc::c_ulong = 0x4068_aea3;

const KVM_CLEAR_DIRTY_LOG_IOCTL: libc::c_ulong =
    ioc(3, 0xAE, 0xC0, size_of::<kvm_clear_dirty_log>() as u64) as libc::c_ulong;

const _: () = {
    assert!(kvm_bindings::KVM_CAP_ARM_WRITABLE_IMP_ID_REGS == 239);
    assert!(size_of::<kvm_enable_cap>() == 104);
    assert!(size_of::<kvm_clear_dirty_log>() == 24);
    assert!(KVM_CLEAR_DIRTY_LOG_IOCTL == 0xc018_aec0);
};

fn kvm_err(e: kvm_ioctls::Error) -> BackendError {
    BackendError::Io(std::io::Error::from_raw_os_error(e.errno()))
}

pub struct LiveKvm {
    vcpu: VcpuFd,
    asid_bits: Arm64AsidBits,
    vgic: Option<DeviceFd>,
    _vm: VmFd,
    _kvm: Kvm,
    run: *mut kvm_run,
    mmap_size: usize,
    cancel_run: std::sync::Arc<std::sync::atomic::AtomicBool>,
}

impl LiveKvm {
    pub fn new() -> Result<Self> {
        // SAFETY: `sysconf` has no pointer arguments or memory-safety contract.
        let host_page_size = unsafe { libc::sysconf(libc::_SC_PAGESIZE) };
        crate::arm64_kvm::require_4k_host_page_size(host_page_size as i64)?;
        let kvm = Kvm::new().map_err(kvm_err)?;
        if !kvm.check_extension(Cap::ImmediateExit) {
            return Err(BackendError::Capability {
                cap: "KVM_CAP_IMMEDIATE_EXIT",
            });
        }
        let vm = kvm.create_vm().map_err(kvm_err)?;
        Self::enable_manual_dirty_log(&vm)?;
        Self::enable_writable_imp_id_regs(&vm)?;
        let vcpu = vm.create_vcpu(0).map_err(kvm_err)?;

        let mmap_size = kvm.get_vcpu_mmap_size().map_err(kvm_err)?;
        if mmap_size < size_of::<kvm_run>() {
            return Err(BackendError::Internal("kvm_run mmap size too small"));
        }
        // SAFETY: map the per-vCPU shared `kvm_run` page; `vcpu`'s fd is valid
        // for `mmap`, offset 0 is the `kvm_run`, and the mapping is unmapped in
        // `Drop`. A `MAP_FAILED` return is converted to an error, never used.
        let run = unsafe {
            let p = libc::mmap(
                std::ptr::null_mut(),
                mmap_size,
                libc::PROT_READ | libc::PROT_WRITE,
                libc::MAP_SHARED,
                vcpu.as_raw_fd(),
                0,
            );
            if p == libc::MAP_FAILED {
                return Err(BackendError::Io(std::io::Error::last_os_error()));
            }
            p.cast::<kvm_run>()
        };

        let mut this = Self {
            vcpu,
            asid_bits: Arm64AsidBits::Eight,
            vgic: None,
            _vm: vm,
            _kvm: kvm,
            run,
            mmap_size,
            cancel_run: std::sync::Arc::default(),
        };
        this.vcpu_init()?;
        let mmfr0 = this.get_one_reg(
            crate::arm64_kvm::KVM_REG_ARM64
                | crate::arm64_kvm::KVM_REG_SIZE_U64
                | crate::arm64_kvm::KVM_REG_ARM64_SYSREG
                | u64::from(Arm64AsidBits::ID_AA64MMFR0_EL1),
        )?;
        this.asid_bits =
            Arm64AsidBits::from_id_register(mmfr0).ok_or(BackendError::Capability {
                cap: "ID_AA64MMFR0_EL1.ASIDBits of 8 or 16",
            })?;
        this.create_vgic()?;
        Ok(this)
    }

    fn enable_manual_dirty_log(vm: &VmFd) -> Result<()> {
        let capability = kvm_bindings::KVM_CAP_MANUAL_DIRTY_LOG_PROTECT2;
        if vm.check_extension_raw(libc::c_ulong::from(capability)) <= 0 {
            return Err(BackendError::Capability {
                cap: "KVM_CAP_MANUAL_DIRTY_LOG_PROTECT2",
            });
        }
        let cap = kvm_enable_cap {
            cap: capability,
            flags: 0,
            args: [
                u64::from(kvm_bindings::KVM_DIRTY_LOG_MANUAL_PROTECT_ENABLE),
                0,
                0,
                0,
            ],
            pad: [0; 64],
        };
        // SAFETY: `vm` is a live KVM VM fd and `cap` is the pinned 104-byte
        // input structure required by KVM_ENABLE_CAP. The kernel only reads it
        // for this ioctl; the reference remains live for the entire call.
        let result = unsafe { libc::ioctl(vm.as_raw_fd(), KVM_ENABLE_CAP_IOCTL, &cap) };
        if result == 0 {
            Ok(())
        } else {
            Err(BackendError::Io(std::io::Error::last_os_error()))
        }
    }

    fn enable_writable_imp_id_regs(vm: &VmFd) -> Result<()> {
        let capability = kvm_bindings::KVM_CAP_ARM_WRITABLE_IMP_ID_REGS;
        if vm.check_extension_raw(libc::c_ulong::from(capability)) <= 0 {
            return Err(BackendError::Capability {
                cap: "KVM_CAP_ARM_WRITABLE_IMP_ID_REGS",
            });
        }
        let cap = kvm_enable_cap {
            cap: capability,
            flags: 0,
            args: [0; 4],
            pad: [0; 64],
        };
        // SAFETY: `vm` is a live KVM VM fd and `cap` is the pinned 104-byte
        // input structure required by KVM_ENABLE_CAP. The kernel only reads it
        // for this ioctl; the reference remains live for the entire call.
        let result = unsafe { libc::ioctl(vm.as_raw_fd(), KVM_ENABLE_CAP_IOCTL, &cap) };
        if result == 0 {
            Ok(())
        } else {
            Err(BackendError::Io(std::io::Error::last_os_error()))
        }
    }

    fn quarantine_host_vtimer(&self) -> Result<()> {
        let irq = QUARANTINED_VTIMER_PPI;
        self.vcpu
            .set_device_attr(&kvm_device_attr {
                flags: 0,
                group: kvm_bindings::KVM_ARM_VCPU_TIMER_CTRL,
                attr: u64::from(kvm_bindings::KVM_ARM_VCPU_TIMER_IRQ_VTIMER),
                addr: std::ptr::from_ref(&irq) as u64,
            })
            .map_err(kvm_err)
    }

    fn create_vgic(&mut self) -> Result<()> {
        let mut device = kvm_create_device {
            type_: kvm_bindings::kvm_device_type_KVM_DEV_TYPE_ARM_VGIC_V3,
            fd: 0,
            flags: 0,
        };
        let vgic = self._vm.create_device(&mut device).map_err(kvm_err)?;

        fn set_addr(vgic: &DeviceFd, attr: u64, value: &u64) -> Result<()> {
            vgic.set_device_attr(&kvm_device_attr {
                flags: 0,
                group: kvm_bindings::KVM_DEV_ARM_VGIC_GRP_ADDR,
                attr,
                addr: std::ptr::from_ref(value) as u64,
            })
            .map_err(kvm_err)
        }

        set_addr(
            &vgic,
            u64::from(kvm_bindings::KVM_VGIC_V3_ADDR_TYPE_DIST),
            &GICD_BASE,
        )?;
        set_addr(
            &vgic,
            u64::from(kvm_bindings::KVM_VGIC_V3_ADDR_TYPE_REDIST),
            &GICR_BASE,
        )?;
        let nr_irqs = crate::arm64_kvm::HARMONY_GIC_NR_IRQS;
        vgic.set_device_attr(&kvm_device_attr {
            flags: 0,
            group: kvm_bindings::KVM_DEV_ARM_VGIC_GRP_NR_IRQS,
            attr: 0,
            addr: std::ptr::from_ref(&nr_irqs) as u64,
        })
        .map_err(kvm_err)?;
        let mut iidr = 0u32;
        let mut iidr_attr = kvm_device_attr {
            flags: 0,
            group: kvm_bindings::KVM_DEV_ARM_VGIC_GRP_DIST_REGS,
            attr: 0x0008,
            addr: std::ptr::from_mut(&mut iidr) as u64,
        };
        // SAFETY: `addr` points to a live writable `u32` for the duration of
        // this 32-bit distributor-register ioctl.
        unsafe { vgic.get_device_attr(&mut iidr_attr) }.map_err(kvm_err)?;
        vgic.set_device_attr(&kvm_device_attr {
            addr: std::ptr::from_ref(&iidr) as u64,
            ..iidr_attr
        })
        .map_err(kvm_err)?;
        self.quarantine_host_vtimer()?;
        vgic.set_device_attr(&kvm_device_attr {
            flags: 0,
            group: kvm_bindings::KVM_DEV_ARM_VGIC_GRP_CTRL,
            attr: u64::from(kvm_bindings::KVM_DEV_ARM_VGIC_CTRL_INIT),
            addr: 0,
        })
        .map_err(kvm_err)?;
        self.vgic = Some(vgic);
        Ok(())
    }

    fn vgic(&self) -> Result<&DeviceFd> {
        self.vgic
            .as_ref()
            .ok_or(BackendError::Internal("vGICv3 is not initialised"))
    }

    fn read_run_view(&self) -> Result<KvmRunView> {
        // SAFETY: `self.run` came from a successful `mmap` of `mmap_size` bytes
        // (≥ `size_of::<kvm_run>()`), live until `Drop`, and `RUN_OFFSETS` names
        // real `kvm_run` fields; every read inside is bounds-checked.
        unsafe { RunPage::new(self.run.cast::<u8>(), self.mmap_size).view(&RUN_OFFSETS) }
    }
}

impl Arm64Kvm for LiveKvm {
    fn vcpu_init(&mut self) -> Result<()> {
        let mut kvi = kvm_vcpu_init::default();
        self._vm.get_preferred_target(&mut kvi).map_err(kvm_err)?;
        kvi.features = crate::arm64_kvm::vcpu_init_features();
        debug_assert!(
            kvi.features[0] & (1 << crate::arm64_kvm::KVM_ARM_VCPU_PSCI_0_2) != 0,
            "vcpu_init must request PSCI 0.2"
        );
        self.vcpu.vcpu_init(&kvi).map_err(kvm_err)?;
        Ok(())
    }

    fn asid_bits(&self) -> Arm64AsidBits {
        self.asid_bits
    }

    unsafe fn set_user_memory_region(
        &mut self,
        slot: u32,
        gpa: u64,
        host: *mut u8,
        len: u64,
    ) -> Result<()> {
        // SAFETY: this compatibility entry point uses the same pinned backing
        // contract as the flagged registration path and requests logging by
        // default, matching the backend's normal ARM behavior.
        unsafe {
            self.set_user_memory_region_with_flags(
                slot,
                gpa,
                host,
                len,
                kvm_bindings::KVM_MEM_LOG_DIRTY_PAGES,
            )
        }
    }

    unsafe fn set_user_memory_region_with_flags(
        &mut self,
        slot: u32,
        gpa: u64,
        host: *mut u8,
        len: u64,
        flags: u32,
    ) -> Result<()> {
        let region = kvm_userspace_memory_region {
            slot,
            flags,
            guest_phys_addr: gpa,
            memory_size: len,
            userspace_addr: host as u64,
        };
        // SAFETY: the caller upholds `map_memory`'s contract (the backing is
        // pinned, page-aligned, and unaliased for the backend's lifetime), so
        // registering it as a memslot is sound.
        unsafe { self._vm.set_user_memory_region(region) }.map_err(kvm_err)
    }

    fn get_dirty_log(&mut self, slot: u32, size: u64) -> Result<Vec<u64>> {
        let expected = crate::arm64_kvm::dirty_bitmap_words(size)?;
        let size = usize::try_from(size).map_err(|_| BackendError::InvalidState)?;
        let bitmap = self._vm.get_dirty_log(slot, size).map_err(kvm_err)?;
        if bitmap.len() != expected {
            return Err(BackendError::Internal(
                "KVM dirty bitmap has an unexpected size",
            ));
        }
        Ok(bitmap)
    }

    fn clear_dirty_log(
        &mut self,
        slot: u32,
        size: u64,
        first_page: u64,
        num_pages: u32,
        bitmap: &[u64],
    ) -> Result<()> {
        crate::arm64_kvm::validate_clear_dirty_log(size, first_page, num_pages, bitmap)?;
        let clear = kvm_clear_dirty_log {
            slot,
            num_pages,
            first_page,
            __bindgen_anon_1: kvm_clear_dirty_log__bindgen_ty_1 {
                dirty_bitmap: bitmap.as_ptr().cast_mut().cast(),
            },
        };
        // SAFETY: the VM fd is live; `bitmap` is a validated, live slice whose
        // exact word count covers `num_pages`; and KVM reads it only for this
        // synchronous ioctl while the vCPU is stopped at the drain boundary.
        let result = unsafe {
            libc::ioctl(
                self._vm.as_raw_fd(),
                KVM_CLEAR_DIRTY_LOG_IOCTL,
                std::ptr::from_ref(&clear),
            )
        };
        if result == 0 {
            Ok(())
        } else {
            Err(BackendError::Io(std::io::Error::last_os_error()))
        }
    }

    fn get_one_reg(&self, id: u64) -> Result<u64> {
        let mut data = [0u8; 8];
        self.vcpu.get_one_reg(id, &mut data).map_err(kvm_err)?;
        Ok(u64::from_le_bytes(data))
    }

    fn set_one_reg(&mut self, id: u64, value: u64) -> Result<()> {
        self.vcpu
            .set_one_reg(id, &value.to_le_bytes())
            .map_err(kvm_err)?;
        Ok(())
    }

    fn get_one_reg32(&self, id: u64) -> Result<u32> {
        let mut data = [0u8; 4];
        self.vcpu.get_one_reg(id, &mut data).map_err(kvm_err)?;
        Ok(u32::from_le_bytes(data))
    }

    fn set_one_reg32(&mut self, id: u64, value: u32) -> Result<()> {
        self.vcpu
            .set_one_reg(id, &value.to_le_bytes())
            .map_err(kvm_err)?;
        Ok(())
    }

    fn get_one_reg128(&self, id: u64) -> Result<[u8; 16]> {
        let mut data = [0u8; 16];
        self.vcpu.get_one_reg(id, &mut data).map_err(kvm_err)?;
        Ok(data)
    }

    fn set_one_reg128(&mut self, id: u64, value: [u8; 16]) -> Result<()> {
        self.vcpu.set_one_reg(id, &value).map_err(kvm_err)?;
        Ok(())
    }

    fn get_mp_state(&self) -> Result<MpState> {
        let mp = self.vcpu.get_mp_state().map_err(kvm_err)?;
        Ok(if mp.mp_state == kvm_bindings::KVM_MP_STATE_STOPPED {
            MpState::Halted
        } else {
            MpState::Runnable
        })
    }

    fn set_mp_state(&mut self, mp: MpState) -> Result<()> {
        let mp_state = match mp {
            MpState::Runnable => kvm_bindings::KVM_MP_STATE_RUNNABLE,
            MpState::Halted => kvm_bindings::KVM_MP_STATE_STOPPED,
        };
        self.vcpu
            .set_mp_state(kvm_bindings::kvm_mp_state { mp_state })
            .map_err(kvm_err)?;
        Ok(())
    }

    fn set_irq_line(&mut self, id: crate::arch::arm64::GicIntId, level: bool) -> Result<()> {
        let (kind, number) = if id.is_ppi() {
            (kvm_bindings::KVM_ARM_IRQ_TYPE_PPI, id.0)
        } else if id.is_spi() {
            (kvm_bindings::KVM_ARM_IRQ_TYPE_SPI, id.0)
        } else {
            return Err(BackendError::InvalidState);
        };
        let irq = (kind << kvm_bindings::KVM_ARM_IRQ_TYPE_SHIFT)
            | (0 << kvm_bindings::KVM_ARM_IRQ_VCPU_SHIFT)
            | (number << kvm_bindings::KVM_ARM_IRQ_NUM_SHIFT);
        self._vm.set_irq_line(irq, level).map_err(kvm_err)
    }

    fn get_vgic_attr(&self, group: u32, attr: u64, width64: bool) -> Result<u64> {
        let vgic = self.vgic()?;
        if width64 {
            let mut value = 0u64;
            let mut device_attr = kvm_device_attr {
                flags: 0,
                group,
                attr,
                addr: std::ptr::from_mut(&mut value) as u64,
            };
            // SAFETY: `addr` points to the live, writable `u64` value for the
            // duration of the ioctl and the selected group uses a 64-bit ABI.
            unsafe { vgic.get_device_attr(&mut device_attr) }.map_err(kvm_err)?;
            Ok(value)
        } else {
            let mut value = 0u32;
            let mut device_attr = kvm_device_attr {
                flags: 0,
                group,
                attr,
                addr: std::ptr::from_mut(&mut value) as u64,
            };
            // SAFETY: `addr` points to the live, writable `u32` value for the
            // duration of the ioctl and the selected group uses a 32-bit ABI.
            unsafe { vgic.get_device_attr(&mut device_attr) }.map_err(kvm_err)?;
            Ok(u64::from(value))
        }
    }

    fn set_vgic_attr(&mut self, group: u32, attr: u64, width64: bool, value: u64) -> Result<()> {
        let vgic = self.vgic()?;
        if width64 {
            vgic.set_device_attr(&kvm_device_attr {
                flags: 0,
                group,
                attr,
                addr: std::ptr::from_ref(&value) as u64,
            })
            .map_err(kvm_err)
        } else {
            let value = u32::try_from(value).map_err(|_| BackendError::InvalidState)?;
            vgic.set_device_attr(&kvm_device_attr {
                flags: 0,
                group,
                attr,
                addr: std::ptr::from_ref(&value) as u64,
            })
            .map_err(kvm_err)
        }
    }

    fn write_mmio_data(&mut self, data: [u8; 8]) -> Result<()> {
        // SAFETY: `self.run` is a live mmap of the `kvm_run`; the pending exit is
        // an MMIO load, so writing its `data` staging buffer (through the
        // bounds-checked `RunPage` seam) is the kernel's documented completion
        // path, read back on the next `KVM_RUN`.
        unsafe {
            RunPage::new(self.run.cast::<u8>(), self.mmap_size).write_mmio_data(&RUN_OFFSETS, data)
        }
    }

    fn complete_mmio_exit(&mut self) -> Result<()> {
        // SAFETY: `self.run` is this vCPU's live shared `kvm_run` mapping and
        // the vCPU is not concurrently running.
        unsafe { (*self.run).immediate_exit = 1 };
        let result = self.vcpu.run();
        // SAFETY: same exclusive mapping access as above; always clear the
        // one-shot flag before interpreting the ioctl result.
        unsafe { (*self.run).immediate_exit = 0 };
        match result {
            Err(error) if error.errno() == libc::EINTR => Ok(()),
            Err(error) => Err(kvm_err(error)),
            Ok(_) => Err(BackendError::Internal(
                "KVM immediate-exit MMIO completion executed guest code",
            )),
        }
    }

    fn run(&mut self) -> Result<KvmRunView> {
        if self.cancel_run.load(std::sync::atomic::Ordering::Acquire) {
            return Err(BackendError::Internal("KVM run canceled by host"));
        }
        self.vcpu.run().map_err(kvm_err)?;
        self.read_run_view()
    }

    fn cancellation_flag(&self) -> Option<std::sync::Arc<std::sync::atomic::AtomicBool>> {
        Some(std::sync::Arc::clone(&self.cancel_run))
    }
}

impl Drop for LiveKvm {
    fn drop(&mut self) {
        // SAFETY: `self.run` came from `mmap(.., self.mmap_size, ..)` and is
        // unmapped exactly once here.
        unsafe {
            libc::munmap(self.run.cast(), self.mmap_size);
        }
    }
}

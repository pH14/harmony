// SPDX-License-Identifier: AGPL-3.0-or-later

use std::collections::BTreeMap;

use crate::error::{BackendError, Result};
use crate::types::MpState;

#[derive(Clone, PartialEq, Eq, Debug, Default)]
pub struct VcpuState {
    pub regs: VcpuRegs,
    pub sregs: VcpuSregs,
    pub xcr0: u64,
    pub debugregs: DebugRegs,
    pub events: VcpuEvents,
    pub mp_state: MpState,
    pub msrs: BTreeMap<u32, u64>,
    pub xsave: Vec<u8>,
    pub xsave_restore_bv: Option<u64>,
    pub nested_state: Option<Vec<u8>>,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub struct VcpuRegs {
    pub rax: u64,
    pub rbx: u64,
    pub rcx: u64,
    pub rdx: u64,
    pub rsi: u64,
    pub rdi: u64,
    pub rsp: u64,
    pub rbp: u64,
    pub r8: u64,
    pub r9: u64,
    pub r10: u64,
    pub r11: u64,
    pub r12: u64,
    pub r13: u64,
    pub r14: u64,
    pub r15: u64,
    pub rip: u64,
    pub rflags: u64,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub struct Segment {
    pub base: u64,
    pub limit: u32,
    pub selector: u16,
    pub type_: u8,
    pub present: u8,
    pub dpl: u8,
    pub db: u8,
    pub s: u8,
    pub l: u8,
    pub g: u8,
    pub avl: u8,
    pub unusable: u8,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub struct DescriptorTable {
    pub base: u64,
    pub limit: u16,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub struct VcpuSregs {
    pub cs: Segment,
    pub ds: Segment,
    pub es: Segment,
    pub fs: Segment,
    pub gs: Segment,
    pub ss: Segment,
    pub tr: Segment,
    pub ldt: Segment,
    pub gdt: DescriptorTable,
    pub idt: DescriptorTable,
    pub cr0: u64,
    pub cr2: u64,
    pub cr3: u64,
    pub cr4: u64,
    pub cr8: u64,
    pub efer: u64,
    pub apic_base: u64,
    pub flags: u64,
    pub pdptrs: [u64; 4],
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub struct DebugRegs {
    pub db: [u64; 4],
    pub dr6: u64,
    pub dr7: u64,
    pub flags: u64,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub struct VcpuEvents {
    pub exception_injected: u8,
    pub exception_nr: u8,
    pub exception_has_error_code: u8,
    pub exception_pending: u8,
    pub exception_error_code: u32,
    pub exception_has_payload: u8,
    pub exception_payload: u64,
    pub interrupt_injected: u8,
    pub interrupt_nr: u8,
    pub interrupt_soft: u8,
    pub interrupt_shadow: u8,
    pub nmi_injected: u8,
    pub nmi_pending: u8,
    pub nmi_masked: u8,
    pub sipi_vector: u32,
    pub flags: u32,
    pub smi_smm: u8,
    pub smi_pending: u8,
    pub smi_inside_nmi: u8,
    pub smi_latched_init: u8,
    pub triple_fault_pending: u8,
}

pub fn canonicalize_regs(_regs: &mut VcpuRegs) {}

pub fn canonicalize_sregs(sregs: &mut VcpuSregs) {
    for seg in [
        &mut sregs.cs,
        &mut sregs.ds,
        &mut sregs.es,
        &mut sregs.fs,
        &mut sregs.gs,
        &mut sregs.ss,
        &mut sregs.tr,
        &mut sregs.ldt,
    ] {
        if seg.unusable != 0 {
            *seg = Segment {
                base: seg.base,
                selector: seg.selector,
                unusable: 1,
                ..Segment::default()
            };
        }
    }
}

const XSTATE_BV: usize = 512;
const XCOMP_BV: usize = 520;
const XSAVE_HEADER_END: usize = XCOMP_BV + 8;
const X87_CONTROL: std::ops::Range<usize> = 0..24;
const X87_ST: std::ops::Range<usize> = 32..160;
const SSE_MXCSR: std::ops::Range<usize> = 24..28;
const MXCSR_MASK: std::ops::Range<usize> = 28..32;
const MXCSR_MASK_PINNED: [u8; 4] = 0x0000FFFFu32.to_le_bytes();
const SSE_XMM: std::ops::Range<usize> = 160..416;
const X87_INIT_FCW: [u8; 2] = 0x037Fu16.to_le_bytes();
const SSE_INIT_MXCSR: [u8; 4] = 0x1F80u32.to_le_bytes();
const LEGACY_TAIL: std::ops::Range<usize> = 416..512;

pub fn canonicalize_xsave(image: &mut [u8]) {
    if image.len() < XSAVE_HEADER_END || image[XCOMP_BV..XSAVE_HEADER_END] != [0u8; 8] {
        return;
    }

    image[MXCSR_MASK].copy_from_slice(&MXCSR_MASK_PINNED);
    image[LEGACY_TAIL].fill(0);

    let is_zero = |r: std::ops::Range<usize>, image: &[u8]| image[r].iter().all(|&b| b == 0);
    let x87_init = |image: &[u8]| {
        image[X87_CONTROL.start..X87_CONTROL.start + 2] == X87_INIT_FCW
            && is_zero(X87_CONTROL.start + 2..X87_CONTROL.end, image)
            && is_zero(X87_ST, image)
    };
    let sse_init = |image: &[u8]| image[SSE_MXCSR] == SSE_INIT_MXCSR && is_zero(SSE_XMM, image);

    let mut bv = u64::from_le_bytes(image[XSTATE_BV..XSTATE_BV + 8].try_into().expect("8 bytes"));
    if bv & 1 == 0 {
        image[X87_CONTROL.start..X87_CONTROL.start + 2].copy_from_slice(&X87_INIT_FCW);
        image[X87_CONTROL.start + 2..X87_CONTROL.end].fill(0);
        image[X87_ST].fill(0);
    } else if x87_init(image) {
        bv &= !1;
    }
    if bv & 2 == 0 {
        if bv & 4 == 0 {
            image[SSE_MXCSR].copy_from_slice(&SSE_INIT_MXCSR);
        }
        image[SSE_XMM].fill(0);
    } else if sse_init(image) {
        bv &= !2;
    }
    image[XSTATE_BV..XSTATE_BV + 8].copy_from_slice(&bv.to_le_bytes());
}

fn standard_xsave_header(image: &[u8]) -> Option<(u64, u64)> {
    if image.len() < XSAVE_HEADER_END {
        return None;
    }
    let xstate_bv = u64::from_le_bytes(image[XSTATE_BV..XSTATE_BV + 8].try_into().ok()?);
    let xcomp_bv = u64::from_le_bytes(image[XCOMP_BV..XSAVE_HEADER_END].try_into().ok()?);
    Some((xstate_bv, xcomp_bv))
}

pub fn canonicalize_xsave_with_restore_bv(image: &mut [u8]) -> Option<u64> {
    let original = standard_xsave_header(image)
        .filter(|&(_, xcomp_bv)| xcomp_bv == 0)
        .map(|(xstate_bv, _)| xstate_bv);
    canonicalize_xsave(image);
    original
}

pub fn restore_xsave_image(image: &[u8], restore_bv: Option<u64>) -> Result<Vec<u8>> {
    let Some(restore_bv) = restore_bv else {
        return Ok(image.to_vec());
    };
    let Some((_, xcomp_bv)) = standard_xsave_header(image) else {
        return Err(BackendError::InvalidState);
    };
    if xcomp_bv != 0 {
        return Err(BackendError::InvalidState);
    }

    let mut restored = image.to_vec();
    restored[XSTATE_BV..XSTATE_BV + 8].copy_from_slice(&restore_bv.to_le_bytes());
    let mut canonical = restored.clone();
    canonicalize_xsave(&mut canonical);
    if canonical != image {
        return Err(BackendError::InvalidState);
    }
    Ok(restored)
}

pub fn logical_xsave_restore_bv(image: &[u8], restore_bv: Option<u64>) -> Result<Option<u64>> {
    if image.len() < 576 {
        return Err(BackendError::InvalidState);
    }
    let Some((canonical_bv, 0)) = standard_xsave_header(image) else {
        return Err(BackendError::InvalidState);
    };
    restore_xsave_image(image, Some(restore_bv.unwrap_or(canonical_bv)))?;
    Ok(restore_bv.map(|raw| raw & !(3 & !canonical_bv)))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn init_image(xstate_bv: u64) -> Vec<u8> {
        let mut image = vec![0u8; 4096];
        image[0..2].copy_from_slice(&X87_INIT_FCW);
        image[SSE_MXCSR].copy_from_slice(&SSE_INIT_MXCSR);
        image[28..32].copy_from_slice(&0xFFFFu32.to_le_bytes());
        image[XSTATE_BV..XSTATE_BV + 8].copy_from_slice(&xstate_bv.to_le_bytes());
        image
    }

    #[test]
    fn logical_presence_collapses_only_init_x87_and_sse() {
        let canonical = init_image(0);
        let before = canonical.clone();
        for raw in [0, 1, 2, 3] {
            assert_eq!(
                logical_xsave_restore_bv(&canonical, Some(raw)).unwrap(),
                Some(0)
            );
        }
        assert_eq!(logical_xsave_restore_bv(&canonical, None).unwrap(), None);
        assert_eq!(canonical, before);
        for bit in [1, 2, 4, 8, 1 << 63] {
            let mut active = init_image(bit);
            if bit == 1 {
                active[X87_ST.start] = 0x55;
            }
            if bit == 2 {
                active[SSE_XMM.start] = 0x55;
            }
            if bit == 4 {
                active[576] = 0x55;
            }
            let before = active.clone();
            for raw in [bit, bit | 3] {
                assert_eq!(
                    logical_xsave_restore_bv(&active, Some(raw)).unwrap(),
                    Some(bit)
                );
            }
            assert_eq!(active, before);
            assert_ne!(
                logical_xsave_restore_bv(&active, Some(bit)).unwrap(),
                Some(0)
            );
        }
    }

    #[test]
    fn logical_presence_preserves_mxcsr_with_sse_or_avx() {
        for bit in [2, 4, 6] {
            let mut active = init_image(bit);
            active[SSE_MXCSR].copy_from_slice(&0x3f80_u32.to_le_bytes());
            let before = active.clone();
            assert_eq!(
                logical_xsave_restore_bv(&active, Some(bit)).unwrap(),
                Some(bit)
            );
            assert_eq!(active, before);
            assert_eq!(&active[SSE_MXCSR], &0x3f80_u32.to_le_bytes());
        }
    }

    #[test]
    fn logical_presence_rejects_invalid_provenance() {
        let canonical = init_image(0);
        for length in [0, 512, 527, 528, 575] {
            for raw in [None, Some(0)] {
                assert!(logical_xsave_restore_bv(&canonical[..length], raw).is_err());
            }
        }
        let mut compacted = canonical.clone();
        compacted[XCOMP_BV..XSAVE_HEADER_END].copy_from_slice(&(1_u64 << 63).to_le_bytes());
        for raw in [None, Some(0)] {
            assert!(logical_xsave_restore_bv(&compacted, raw).is_err());
        }
        for bit in [1, 2, 4] {
            let mut active = init_image(bit);
            if bit == 1 {
                active[X87_ST.start] = 1;
            }
            if bit == 2 {
                active[SSE_XMM.start] = 1;
            }
            if bit == 4 {
                active[576] = 1;
            }
            assert!(logical_xsave_restore_bv(&active, Some(0)).is_err());
        }
        let mut noncanonical = canonical;
        noncanonical[SSE_XMM.start] = 1;
        assert!(logical_xsave_restore_bv(&noncanonical, None).is_err());
        assert!(logical_xsave_restore_bv(&noncanonical, Some(0)).is_err());
    }

    #[test]
    fn init_state_encodings_collapse_to_one_image() {
        let mut a = init_image(0x3);
        let mut b = init_image(0x2);
        canonicalize_xsave(&mut a);
        canonicalize_xsave(&mut b);
        assert_eq!(a, b);
        assert_eq!(a[XSTATE_BV..XSTATE_BV + 8], 0u64.to_le_bytes());
    }

    #[test]
    fn capture_and_restore_preserve_x87_and_sse_init_presence() {
        for (raw_bv, canonical_bv) in [(0x0, 0), (0x3, 0), (0x2, 0), (0x7, 0x4)] {
            let mut canonical = init_image(raw_bv);
            assert_eq!(
                canonicalize_xsave_with_restore_bv(&mut canonical),
                Some(raw_bv)
            );
            assert_eq!(
                u64::from_le_bytes(canonical[XSTATE_BV..XSTATE_BV + 8].try_into().unwrap()),
                canonical_bv
            );
            let restored = restore_xsave_image(&canonical, Some(raw_bv)).unwrap();
            assert_eq!(
                u64::from_le_bytes(restored[XSTATE_BV..XSTATE_BV + 8].try_into().unwrap()),
                raw_bv
            );
            let mut recanonicalized = restored.clone();
            canonicalize_xsave(&mut recanonicalized);
            assert_eq!(recanonicalized, canonical);
        }
    }

    #[test]
    fn restore_provenance_cannot_drop_a_canonical_component() {
        let mut canonical = init_image(1);
        canonical[X87_ST.start] = 0x55;
        assert_eq!(canonicalize_xsave_with_restore_bv(&mut canonical), Some(1));
        assert_eq!(
            u64::from_le_bytes(canonical[XSTATE_BV..XSTATE_BV + 8].try_into().unwrap()),
            1
        );
        assert!(matches!(
            restore_xsave_image(&canonical, Some(2)),
            Err(BackendError::InvalidState)
        ));
    }

    #[test]
    fn live_state_is_untouched_and_retains_raw_bv() {
        let mut image = init_image(0x3);
        image[0..2].copy_from_slice(&0x027Fu16.to_le_bytes());
        image[SSE_XMM.start] = 0x5A;
        let before = image.clone();
        assert_eq!(canonicalize_xsave_with_restore_bv(&mut image), Some(0x3));
        assert_eq!(image, before);
        assert_eq!(restore_xsave_image(&image, Some(0x3)).unwrap(), before);
    }

    #[test]
    fn absent_sse_and_avx_materialize_init_mxcsr_but_active_sse_preserves_it() {
        for bv in [0, 1, 8] {
            let mut image = init_image(bv);
            image[SSE_MXCSR].copy_from_slice(&0x3f80u32.to_le_bytes());
            image[SSE_XMM].fill(0xa5);
            canonicalize_xsave(&mut image);
            assert_eq!(image[SSE_MXCSR], SSE_INIT_MXCSR);
            assert!(image[SSE_XMM].iter().all(|byte| *byte == 0));
        }
        for bv in [2, 6] {
            let mut image = init_image(bv);
            image[SSE_MXCSR].copy_from_slice(&0x3f80u32.to_le_bytes());
            canonicalize_xsave(&mut image);
            assert_eq!(image[SSE_MXCSR], 0x3f80u32.to_le_bytes());
            assert_eq!(
                u64::from_le_bytes(image[XSTATE_BV..XSTATE_BV + 8].try_into().unwrap()),
                bv
            );
        }
    }

    #[test]
    fn ymm_presence_preserves_mxcsr_without_sse_presence() {
        let mut image = init_image(4);
        image[SSE_MXCSR].copy_from_slice(&0x3f80u32.to_le_bytes());
        image[576] = 0x5a;
        let original = image.clone();
        let restore_bv = canonicalize_xsave_with_restore_bv(&mut image);
        assert_eq!(restore_bv, Some(4));
        assert_eq!(image, original);
        assert_eq!(restore_xsave_image(&image, restore_bv).unwrap(), original);
        canonicalize_xsave(&mut image);
        assert_eq!(image, original);
        assert!(matches!(
            restore_xsave_image(&image, Some(0)),
            Err(BackendError::InvalidState)
        ));
    }

    #[test]
    fn malformed_restore_provenance_is_rejected_without_mutating_the_source() {
        let canonical = init_image(0);

        let mut malformed = canonical.clone();
        malformed[X87_ST.start] = 0xEE;
        let before = malformed.clone();
        assert!(matches!(
            restore_xsave_image(&malformed, Some(1)),
            Err(BackendError::InvalidState)
        ));
        assert_eq!(malformed, before);

        let mut compacted = canonical;
        compacted[XCOMP_BV..XSAVE_HEADER_END].copy_from_slice(&1_u64.to_le_bytes());
        assert!(matches!(
            restore_xsave_image(&compacted, Some(1)),
            Err(BackendError::InvalidState)
        ));
        assert_eq!(restore_xsave_image(&compacted, None).unwrap(), compacted);
        let short = [0xA5; XSAVE_HEADER_END - 1];
        assert_eq!(restore_xsave_image(&short, None).unwrap(), short);
        assert!(matches!(
            restore_xsave_image(&short, Some(1)),
            Err(BackendError::InvalidState)
        ));
    }

    #[test]
    fn restore_provenance_rejects_non_init_state_bits() {
        let canonical = init_image(0);
        assert!(matches!(
            restore_xsave_image(&canonical, Some(0x4)),
            Err(BackendError::InvalidState)
        ));
    }

    #[test]
    fn restore_provenance_accepts_canonical_equal_header_but_rejects_malformed_image() {
        let canonical = init_image(0);
        assert_eq!(restore_xsave_image(&canonical, Some(0)).unwrap(), canonical);

        let mut malformed = canonical.clone();
        malformed[X87_ST.start] = 0xEE;
        assert!(matches!(
            restore_xsave_image(&malformed, Some(0)),
            Err(BackendError::InvalidState)
        ));
    }

    #[test]
    fn ignored_area_bytes_become_the_init_values() {
        let mut image = init_image(0x0);
        image[X87_ST.start] = 0xEE;
        image[SSE_XMM.start + 7] = 0xEE;
        canonicalize_xsave(&mut image);
        assert_eq!(image, init_image(0x0));
    }

    #[test]
    fn mxcsr_mask_is_pinned_to_the_contract_value() {
        let mut image = init_image(0x2);
        image[MXCSR_MASK].copy_from_slice(&0x0002FFFFu32.to_le_bytes());
        canonicalize_xsave(&mut image);
        assert_eq!(image[MXCSR_MASK], MXCSR_MASK_PINNED);
    }

    #[test]
    fn legacy_tail_host_template_is_zeroed() {
        let mut a = init_image(0x2);
        let mut b = init_image(0x2);
        a[464..472].copy_from_slice(&0x7u64.to_le_bytes());
        b[464..472].copy_from_slice(&0x600e7u64.to_le_bytes());
        canonicalize_xsave(&mut a);
        canonicalize_xsave(&mut b);
        assert_eq!(a, b);
        assert!(a[LEGACY_TAIL].iter().all(|&x| x == 0));
    }

    #[test]
    fn resume_flag_distinguishes_debug_restart_states() {
        let mut resume = VcpuRegs {
            rflags: 0x10282,
            ..VcpuRegs::default()
        };
        let mut ordinary = VcpuRegs {
            rflags: 0x282,
            ..VcpuRegs::default()
        };
        canonicalize_regs(&mut resume);
        canonicalize_regs(&mut ordinary);
        assert_ne!(resume, ordinary);
        assert_eq!(resume.rflags, 0x10282);
        assert_eq!(ordinary.rflags, 0x282);
    }

    #[test]
    fn general_registers_are_untouched() {
        let mut regs = VcpuRegs {
            rax: 0x1234,
            rsp: 0xffff_ffff_8260_3e98,
            rip: 0xffff_ffff_8125_6a62,
            rflags: 0x10ac6,
            ..VcpuRegs::default()
        };
        canonicalize_regs(&mut regs);
        assert_eq!(regs.rax, 0x1234);
        assert_eq!(regs.rsp, 0xffff_ffff_8260_3e98);
        assert_eq!(regs.rip, 0xffff_ffff_8125_6a62);
        assert_eq!(regs.rflags, 0x10ac6);
    }

    #[test]
    fn unusable_segment_residue_collapses_to_the_zeroed_form() {
        let intel = Segment {
            base: 726582208,
            selector: 0x23,
            limit: 0xFFFF_FFFF,
            type_: 1,
            db: 1,
            g: 1,
            unusable: 1,
            ..Segment::default()
        };
        let amd = Segment {
            base: 726582208,
            selector: 0x23,
            unusable: 1,
            ..Segment::default()
        };
        let mut a = VcpuSregs {
            fs: intel,
            ..VcpuSregs::default()
        };
        let mut b = VcpuSregs {
            fs: amd,
            ..VcpuSregs::default()
        };
        canonicalize_sregs(&mut a);
        canonicalize_sregs(&mut b);
        assert_eq!(a, b);
        assert_eq!(a.fs.base, 726582208);
        assert_eq!(a.fs.selector, 0x23);
        assert_eq!(a.fs.unusable, 1);
    }

    #[test]
    fn usable_segments_are_untouched() {
        let cs = Segment {
            limit: 0xFFFF_FFFF,
            selector: 0x10,
            type_: 11,
            present: 1,
            s: 1,
            l: 1,
            g: 1,
            ..Segment::default()
        };
        let mut sregs = VcpuSregs {
            cs,
            ..VcpuSregs::default()
        };
        let before = sregs;
        canonicalize_sregs(&mut sregs);
        assert_eq!(sregs, before);
    }

    #[test]
    fn compacted_images_are_untouched() {
        let mut image = init_image(0x3);
        image[XCOMP_BV..XCOMP_BV + 8].copy_from_slice(&(1u64 << 63 | 0x3).to_le_bytes());
        let before = image.clone();
        assert_eq!(canonicalize_xsave_with_restore_bv(&mut image), None);
        assert_eq!(image, before);
    }

    #[test]
    fn xsave_header_length_boundary_is_fail_closed_and_inclusive() {
        let mut short = vec![0xa5; XCOMP_BV + 7];
        let before = short.clone();
        assert_eq!(canonicalize_xsave_with_restore_bv(&mut short), None);
        assert_eq!(short, before);

        let mut exact = init_image(0x2);
        exact.truncate(XCOMP_BV + 8);
        exact[MXCSR_MASK].copy_from_slice(&0x0002_FFFFu32.to_le_bytes());
        exact[LEGACY_TAIL].fill(0xa5);
        let restore_bv = canonicalize_xsave_with_restore_bv(&mut exact);
        assert_eq!(restore_bv, Some(0x2));
        assert_eq!(exact[MXCSR_MASK], MXCSR_MASK_PINNED);
        assert!(exact[LEGACY_TAIL].iter().all(|&byte| byte == 0));

        let restored = restore_xsave_image(&exact, restore_bv).unwrap();
        assert_eq!(restored[XSTATE_BV..XSTATE_BV + 8], 0x2u64.to_le_bytes());
        let mut recanonicalized = restored;
        canonicalize_xsave(&mut recanonicalized);
        assert_eq!(recanonicalized, exact);
    }
}

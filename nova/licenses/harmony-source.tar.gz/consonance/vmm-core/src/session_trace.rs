// SPDX-License-Identifier: AGPL-3.0-or-later

use std::io::{self, Write};

use sha2::{Digest, Sha256};

use crate::virtual_time::{
    LiveVirtualTimeTrace, LogDivergence, NormalizedLog, PlacementViolation, ScheduledInterrupt,
    check_delivery_placement, compare_normalized_logs,
};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SessionTraceStart {
    InitialBoot,
    RecoveryBoot,
    Branch { snapshot: u64 },
    Replay { snapshot: u64 },
}

impl SessionTraceStart {
    fn encode(self, out: &mut impl Write) -> io::Result<()> {
        match self {
            Self::InitialBoot => write!(out, "initial"),
            Self::RecoveryBoot => write!(out, "recovery"),
            Self::Branch { snapshot } => write!(out, "branch:{snapshot}"),
            Self::Replay { snapshot } => write!(out, "replay:{snapshot}"),
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SessionTraceSegment {
    start: SessionTraceStart,
    normalized: NormalizedLog,
    schedule: Vec<ScheduledInterrupt>,
}

impl SessionTraceSegment {
    pub(crate) fn capture(start: SessionTraceStart, trace: &LiveVirtualTimeTrace) -> Self {
        Self {
            start,
            normalized: trace.normalized_log().clone(),
            schedule: trace.schedule().to_vec(),
        }
    }

    pub fn start(&self) -> SessionTraceStart {
        self.start
    }

    pub fn normalized_log(&self) -> &NormalizedLog {
        &self.normalized
    }

    pub fn schedule(&self) -> &[ScheduledInterrupt] {
        &self.schedule
    }
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct SessionVirtualTimeTrace {
    segments: Vec<SessionTraceSegment>,
}

impl SessionVirtualTimeTrace {
    pub(crate) fn from_segments(segments: Vec<SessionTraceSegment>) -> Self {
        Self { segments }
    }

    pub fn segments(&self) -> &[SessionTraceSegment] {
        &self.segments
    }

    pub fn event_count(&self) -> usize {
        self.segments
            .iter()
            .map(|segment| segment.normalized.events.len())
            .sum()
    }

    pub fn schedule_count(&self) -> usize {
        self.segments
            .iter()
            .map(|segment| segment.schedule.len())
            .sum()
    }

    pub fn checkpoint_count(&self) -> usize {
        self.segments
            .iter()
            .flat_map(|segment| &segment.normalized.events)
            .filter(|event| event.state_hash.is_some())
            .count()
    }

    pub fn digest(&self) -> [u8; 32] {
        let mut body = Vec::new();
        self.write_body(&mut body)
            .expect("writing session trace to Vec cannot fail");
        let mut hasher = Sha256::new();
        hasher.update(b"consonance.session-prescriptive-log.v1\0");
        hasher.update(body);
        hasher.finalize().into()
    }

    pub fn write_text(&self, mut out: impl Write) -> io::Result<()> {
        writeln!(out, "format consonance.session-prescriptive-log.v1")?;
        writeln!(out, "digest {}", hex(&self.digest()))?;
        self.write_body(&mut out)
    }

    fn write_body(&self, mut out: impl Write) -> io::Result<()> {
        writeln!(out, "segments {}", self.segments.len())?;
        for (segment_index, segment) in self.segments.iter().enumerate() {
            write!(out, "segment {segment_index} start=")?;
            segment.start.encode(&mut out)?;
            writeln!(
                out,
                " events={} schedules={}",
                segment.normalized.events.len(),
                segment.schedule.len()
            )?;
            for event in &segment.normalized.events {
                writeln!(
                    out,
                    "event {segment_index}:{} class={:?} payload={} vns={} interrupts={:?} state_hash={}",
                    event.event_index,
                    event.class,
                    hex(&event.payload_digest),
                    event.vns_after,
                    event.interrupts,
                    event
                        .state_hash
                        .as_ref()
                        .map_or_else(|| "-".to_string(), |hash| hex(hash)),
                )?;
            }
            for scheduled in &segment.schedule {
                writeln!(
                    out,
                    "schedule {segment_index}:{} deadline_vns={} armed_for_event={} canceled_at_event={:?} interrupt_id={}",
                    scheduled.schedule_index,
                    scheduled.deadline_vns,
                    scheduled.armed_for_event,
                    scheduled.canceled_at_event,
                    scheduled.interrupt_id,
                )?;
            }
        }
        Ok(())
    }
}

fn hex(bytes: &[u8]) -> String {
    bytes.iter().map(|byte| format!("{byte:02x}")).collect()
}

#[derive(Clone, Debug, PartialEq, Eq, thiserror::Error)]
pub enum SessionTraceDivergence {
    #[error("session trace segment count differs: left {left}, right {right}")]
    SegmentCount { left: usize, right: usize },
    #[error("session trace segment {segment_index} start differs")]
    Start { segment_index: usize },
    #[error("session trace segment {segment_index}: {divergence}")]
    Log {
        segment_index: usize,
        divergence: LogDivergence,
    },
    #[error("session trace segment {segment_index} schedule differs")]
    Schedule { segment_index: usize },
}

pub fn compare_session_traces(
    left: &SessionVirtualTimeTrace,
    right: &SessionVirtualTimeTrace,
) -> Result<(), SessionTraceDivergence> {
    for (segment_index, (a, b)) in left.segments.iter().zip(&right.segments).enumerate() {
        if a.start != b.start {
            return Err(SessionTraceDivergence::Start { segment_index });
        }
        compare_normalized_logs(&a.normalized, &b.normalized).map_err(|divergence| {
            SessionTraceDivergence::Log {
                segment_index,
                divergence,
            }
        })?;
        if a.schedule != b.schedule {
            return Err(SessionTraceDivergence::Schedule { segment_index });
        }
    }
    if left.segments.len() != right.segments.len() {
        return Err(SessionTraceDivergence::SegmentCount {
            left: left.segments.len(),
            right: right.segments.len(),
        });
    }
    Ok(())
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ContinuationScheduleField {
    DeadlineVns,
    ScheduleIndex,
    ArmedForEvent,
    CanceledAtEvent,
    InterruptId,
}

#[derive(Clone, Debug, PartialEq, Eq, thiserror::Error)]
pub enum ContinuationDivergence {
    #[error(
        "portable continuation cut is out of range: events {event_cut}/{source_events}, schedules {schedule_cut}/{source_schedules}"
    )]
    CutOutOfRange {
        event_cut: usize,
        source_events: usize,
        schedule_cut: usize,
        source_schedules: usize,
    },
    #[error("portable continuation {divergence}")]
    Log { divergence: LogDivergence },
    #[error(
        "portable continuation schedule count differs: source {source_count}, restored {restored_count}"
    )]
    ScheduleCount {
        source_count: usize,
        restored_count: usize,
    },
    #[error("portable continuation schedule {schedule_index} differs in {field:?}")]
    Schedule {
        schedule_index: u64,
        field: ContinuationScheduleField,
    },
    #[error(
        "portable continuation boundary-hash count differs: source {source_count}, restored {restored_count}"
    )]
    BoundaryHashCount {
        source_count: usize,
        restored_count: usize,
    },
    #[error("portable continuation state hash differs at boundary {boundary_index}")]
    BoundaryStateHash { boundary_index: usize },
}

pub fn compare_portable_continuation(
    source: &SessionTraceSegment,
    source_event_cut: usize,
    source_schedule_cut: usize,
    source_boundary_hashes: &[[u8; 32]],
    restored: &SessionTraceSegment,
    restored_boundary_hashes: &[[u8; 32]],
) -> Result<(), ContinuationDivergence> {
    if source_event_cut > source.normalized.events.len()
        || source_schedule_cut > source.schedule.len()
    {
        return Err(ContinuationDivergence::CutOutOfRange {
            event_cut: source_event_cut,
            source_events: source.normalized.events.len(),
            schedule_cut: source_schedule_cut,
            source_schedules: source.schedule.len(),
        });
    }

    let event_base = u64::try_from(source_event_cut).unwrap_or(u64::MAX);
    let schedule_base = u64::try_from(source_schedule_cut).unwrap_or(u64::MAX);
    let source_events = &source.normalized.events[source_event_cut..];
    for (offset, (a, b)) in source_events
        .iter()
        .zip(&restored.normalized.events)
        .enumerate()
    {
        let relative = u64::try_from(offset).unwrap_or(u64::MAX);
        let field = if a.event_index.checked_sub(event_base) != Some(relative)
            || b.event_index != relative
        {
            Some(crate::virtual_time::LogField::EventIndex)
        } else if a.class != b.class {
            Some(crate::virtual_time::LogField::Class)
        } else if a.payload_digest != b.payload_digest {
            Some(crate::virtual_time::LogField::PayloadDigest)
        } else if a.vns_after != b.vns_after {
            Some(crate::virtual_time::LogField::VnsAfter)
        } else if !interrupts_equal_rebased(&a.interrupts, &b.interrupts, schedule_base) {
            Some(crate::virtual_time::LogField::Interrupts)
        } else if a.state_hash != b.state_hash {
            Some(crate::virtual_time::LogField::StateHash)
        } else {
            None
        };
        if let Some(field) = field {
            return Err(ContinuationDivergence::Log {
                divergence: LogDivergence {
                    event_index: relative,
                    field,
                },
            });
        }
    }
    if source_events.len() != restored.normalized.events.len() {
        return Err(ContinuationDivergence::Log {
            divergence: LogDivergence {
                event_index: u64::try_from(
                    source_events.len().min(restored.normalized.events.len()),
                )
                .unwrap_or(u64::MAX),
                field: crate::virtual_time::LogField::Length,
            },
        });
    }

    let source_schedules = &source.schedule[source_schedule_cut..];
    for (offset, (a, b)) in source_schedules.iter().zip(&restored.schedule).enumerate() {
        let relative = u64::try_from(offset).unwrap_or(u64::MAX);
        let field = if a.deadline_vns != b.deadline_vns {
            Some(ContinuationScheduleField::DeadlineVns)
        } else if a.schedule_index.checked_sub(schedule_base) != Some(relative)
            || b.schedule_index != relative
        {
            Some(ContinuationScheduleField::ScheduleIndex)
        } else if a.armed_for_event.checked_sub(event_base) != Some(b.armed_for_event) {
            Some(ContinuationScheduleField::ArmedForEvent)
        } else if rebase_optional(a.canceled_at_event, event_base) != Some(b.canceled_at_event) {
            Some(ContinuationScheduleField::CanceledAtEvent)
        } else if a.interrupt_id != b.interrupt_id {
            Some(ContinuationScheduleField::InterruptId)
        } else {
            None
        };
        if let Some(field) = field {
            return Err(ContinuationDivergence::Schedule {
                schedule_index: relative,
                field,
            });
        }
    }
    if source_schedules.len() != restored.schedule.len() {
        return Err(ContinuationDivergence::ScheduleCount {
            source_count: source_schedules.len(),
            restored_count: restored.schedule.len(),
        });
    }

    for (boundary_index, (source, restored)) in source_boundary_hashes
        .iter()
        .zip(restored_boundary_hashes)
        .enumerate()
    {
        if source != restored {
            return Err(ContinuationDivergence::BoundaryStateHash { boundary_index });
        }
    }
    if source_boundary_hashes.len() != restored_boundary_hashes.len() {
        return Err(ContinuationDivergence::BoundaryHashCount {
            source_count: source_boundary_hashes.len(),
            restored_count: restored_boundary_hashes.len(),
        });
    }
    Ok(())
}

fn interrupts_equal_rebased(
    source: &[crate::virtual_time::InterruptDelivery],
    restored: &[crate::virtual_time::InterruptDelivery],
    schedule_base: u64,
) -> bool {
    source.len() == restored.len()
        && source.iter().zip(restored).all(|(a, b)| {
            a.deadline_vns == b.deadline_vns
                && a.schedule_index.checked_sub(schedule_base) == Some(b.schedule_index)
                && a.interrupt_id == b.interrupt_id
        })
}

fn rebase_optional(value: Option<u64>, base: u64) -> Option<Option<u64>> {
    match value {
        Some(value) => value.checked_sub(base).map(Some),
        None => Some(None),
    }
}

#[derive(Clone, Debug, PartialEq, Eq, thiserror::Error)]
#[error("session trace segment {segment_index}: {violation}")]
pub struct SessionPlacementViolation {
    pub segment_index: usize,
    pub violation: PlacementViolation,
}

pub fn check_session_delivery_placement(
    trace: &SessionVirtualTimeTrace,
) -> Result<(), SessionPlacementViolation> {
    for (segment_index, segment) in trace.segments.iter().enumerate() {
        check_delivery_placement(&segment.schedule, &segment.normalized).map_err(|violation| {
            SessionPlacementViolation {
                segment_index,
                violation,
            }
        })?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::virtual_time::{InterruptDelivery, LogField, NormalizedEvent, NormalizedEventClass};

    fn segment(start: SessionTraceStart, vns: u64) -> SessionTraceSegment {
        SessionTraceSegment {
            start,
            normalized: NormalizedLog {
                events: vec![NormalizedEvent {
                    event_index: 0,
                    class: NormalizedEventClass::TimeRead,
                    payload_digest: [3; 32],
                    vns_after: vns,
                    interrupts: Vec::new(),
                    state_hash: Some([5; 32]),
                }],
            },
            schedule: Vec::new(),
        }
    }

    #[test]
    fn comparator_accepts_an_identical_restore_aware_sequence() {
        let trace = SessionVirtualTimeTrace::from_segments(vec![
            segment(SessionTraceStart::InitialBoot, 10),
            segment(SessionTraceStart::Replay { snapshot: 1 }, 4),
            segment(SessionTraceStart::Branch { snapshot: 2 }, 7),
        ]);
        assert_eq!(compare_session_traces(&trace, &trace.clone()), Ok(()));
        assert_eq!(check_session_delivery_placement(&trace), Ok(()));
        assert_eq!(trace.event_count(), 3);
        assert_eq!(trace.schedule_count(), 0);
        assert_eq!(trace.checkpoint_count(), 3);
        assert_eq!(trace.segments()[0].normalized_log().events.len(), 1);
        assert!(trace.segments()[0].schedule().is_empty());

        let mut text = Vec::new();
        trace.write_text(&mut text).unwrap();
        let text = String::from_utf8(text).unwrap();
        assert!(text.contains("segment 0 start=initial events=1 schedules=0"));
        assert!(text.contains("segment 1 start=replay:1 events=1 schedules=0"));
        assert!(text.contains("segment 2 start=branch:2 events=1 schedules=0"));
        assert_eq!(hex(&[0x00, 0xab, 0xff]), "00abff");
    }

    #[test]
    fn schedule_count_text_and_placement_are_not_vacuous() {
        let mut scheduled = segment(SessionTraceStart::InitialBoot, 10);
        scheduled.schedule.push(ScheduledInterrupt {
            deadline_vns: 10,
            schedule_index: 0,
            armed_for_event: 0,
            canceled_at_event: None,
            interrupt_id: 27,
        });
        let trace = SessionVirtualTimeTrace::from_segments(vec![scheduled]);
        assert_eq!(trace.schedule_count(), 1);
        assert_eq!(trace.segments()[0].schedule().len(), 1);
        assert_eq!(trace.segments()[0].schedule()[0].interrupt_id, 27);
        assert!(matches!(
            check_session_delivery_placement(&trace),
            Err(SessionPlacementViolation {
                segment_index: 0,
                ..
            })
        ));
        let mut text = Vec::new();
        trace.write_text(&mut text).unwrap();
        let text = String::from_utf8(text).unwrap();
        assert!(text.starts_with("format consonance.session-prescriptive-log.v1\ndigest "));
        assert!(text.contains("schedule 0:0 deadline_vns=10"));
    }

    #[test]
    fn comparator_rejects_a_planted_middle_segment_increment() {
        let left = SessionVirtualTimeTrace::from_segments(vec![
            segment(SessionTraceStart::InitialBoot, 10),
            segment(SessionTraceStart::Replay { snapshot: 1 }, 4),
            segment(SessionTraceStart::Branch { snapshot: 2 }, 7),
        ]);
        let mut right = left.clone();
        right.segments[1].normalized.events[0].vns_after += 1;
        assert_eq!(
            compare_session_traces(&left, &right),
            Err(SessionTraceDivergence::Log {
                segment_index: 1,
                divergence: LogDivergence {
                    event_index: 0,
                    field: LogField::VnsAfter,
                },
            })
        );
        assert_ne!(left.digest(), right.digest());
    }

    #[test]
    fn segment_boundaries_permit_real_vtime_rewinds() {
        let trace = SessionVirtualTimeTrace::from_segments(vec![
            segment(SessionTraceStart::InitialBoot, 100),
            segment(SessionTraceStart::Replay { snapshot: 1 }, 10),
        ]);
        assert_eq!(check_session_delivery_placement(&trace), Ok(()));
    }

    fn portable_pair() -> (SessionTraceSegment, SessionTraceSegment) {
        let event =
            |event_index: u64, vns_after: u64, schedule_index: Option<u64>| NormalizedEvent {
                event_index,
                class: NormalizedEventClass::TimeRead,
                payload_digest: [event_index as u8; 32],
                vns_after,
                interrupts: schedule_index
                    .map(|schedule_index| {
                        vec![InterruptDelivery {
                            deadline_vns: 30,
                            schedule_index,
                            interrupt_id: 27,
                        }]
                    })
                    .unwrap_or_default(),
                state_hash: Some([event_index as u8; 32]),
            };
        let source = SessionTraceSegment {
            start: SessionTraceStart::Branch { snapshot: 8 },
            normalized: NormalizedLog {
                events: vec![
                    event(0, 10, None),
                    event(1, 20, None),
                    event(2, 30, Some(1)),
                ],
            },
            schedule: vec![
                ScheduledInterrupt {
                    deadline_vns: 9,
                    schedule_index: 0,
                    armed_for_event: 0,
                    canceled_at_event: Some(0),
                    interrupt_id: 27,
                },
                ScheduledInterrupt {
                    deadline_vns: 30,
                    schedule_index: 1,
                    armed_for_event: 1,
                    canceled_at_event: Some(2),
                    interrupt_id: 27,
                },
            ],
        };
        let mut restored_events = source.normalized.events[1..].to_vec();
        for (event_index, event) in restored_events.iter_mut().enumerate() {
            event.event_index = u64::try_from(event_index).unwrap();
            for delivery in &mut event.interrupts {
                delivery.schedule_index -= 1;
            }
        }
        let restored = SessionTraceSegment {
            start: SessionTraceStart::Replay { snapshot: 1 },
            normalized: NormalizedLog {
                events: restored_events,
            },
            schedule: vec![ScheduledInterrupt {
                deadline_vns: 30,
                schedule_index: 0,
                armed_for_event: 0,
                canceled_at_event: Some(1),
                interrupt_id: 27,
            }],
        };
        (source, restored)
    }

    #[test]
    fn portable_continuation_rebases_and_compares_every_retained_field() {
        let (source, restored) = portable_pair();
        let hashes = [[7; 32], [8; 32], [9; 32]];
        assert_eq!(
            compare_portable_continuation(&source, 1, 1, &hashes, &restored, &hashes),
            Ok(())
        );
    }

    #[test]
    fn portable_continuation_accepts_cuts_at_both_exact_ends() {
        let (source, mut restored) = portable_pair();
        restored.normalized.events.clear();
        restored.schedule.clear();
        assert_eq!(
            compare_portable_continuation(
                &source,
                source.normalized.events.len(),
                source.schedule.len(),
                &[],
                &restored,
                &[],
            ),
            Ok(())
        );
    }

    #[test]
    fn portable_continuation_catches_a_planted_increment_at_the_exact_event() {
        let (source, mut restored) = portable_pair();
        restored.normalized.events[1].vns_after += 1;
        let hashes = [[7; 32], [8; 32], [9; 32]];
        assert_eq!(
            compare_portable_continuation(&source, 1, 1, &hashes, &restored, &hashes),
            Err(ContinuationDivergence::Log {
                divergence: LogDivergence {
                    event_index: 1,
                    field: LogField::VnsAfter,
                },
            })
        );
    }

    #[test]
    fn portable_continuation_catches_a_planted_boundary_hash() {
        let (source, restored) = portable_pair();
        let source_hashes = [[7; 32], [8; 32], [9; 32]];
        let mut restored_hashes = source_hashes;
        restored_hashes[1][17] ^= 1;
        assert_eq!(
            compare_portable_continuation(
                &source,
                1,
                1,
                &source_hashes,
                &restored,
                &restored_hashes,
            ),
            Err(ContinuationDivergence::BoundaryStateHash { boundary_index: 1 })
        );
    }

    #[test]
    fn portable_continuation_rejects_each_cut_and_rebased_identity_independently() {
        let (source, restored) = portable_pair();
        let hashes = [[7; 32], [8; 32], [9; 32]];
        for (event_cut, schedule_cut) in [(4, 1), (1, 3)] {
            assert!(matches!(
                compare_portable_continuation(
                    &source,
                    event_cut,
                    schedule_cut,
                    &hashes,
                    &restored,
                    &hashes,
                ),
                Err(ContinuationDivergence::CutOutOfRange { .. })
            ));
        }

        let mut bad_source = source.clone();
        bad_source.normalized.events[1].event_index = 0;
        assert!(matches!(
            compare_portable_continuation(&bad_source, 1, 1, &hashes, &restored, &hashes),
            Err(ContinuationDivergence::Log { .. })
        ));
        let mut bad_restored = restored.clone();
        bad_restored.normalized.events[0].event_index = 1;
        assert!(matches!(
            compare_portable_continuation(&source, 1, 1, &hashes, &bad_restored, &hashes),
            Err(ContinuationDivergence::Log { .. })
        ));
        let mut bad_source = source.clone();
        bad_source.schedule[1].schedule_index = 0;
        assert!(matches!(
            compare_portable_continuation(&bad_source, 1, 1, &hashes, &restored, &hashes),
            Err(ContinuationDivergence::Schedule { .. })
        ));
        let mut bad_restored = restored.clone();
        bad_restored.schedule[0].schedule_index = 1;
        assert!(matches!(
            compare_portable_continuation(&source, 1, 1, &hashes, &bad_restored, &hashes),
            Err(ContinuationDivergence::Schedule { .. })
        ));
    }

    #[test]
    fn interrupt_rebasing_checks_every_field_and_optional_bound() {
        let source = InterruptDelivery {
            deadline_vns: 30,
            schedule_index: 4,
            interrupt_id: 27,
        };
        let restored = InterruptDelivery {
            schedule_index: 1,
            ..source
        };
        assert!(interrupts_equal_rebased(&[source], &[restored], 3));
        assert!(!interrupts_equal_rebased(&[source], &[], 3));
        for changed in [
            InterruptDelivery {
                deadline_vns: 31,
                ..restored
            },
            InterruptDelivery {
                schedule_index: 2,
                ..restored
            },
            InterruptDelivery {
                interrupt_id: 28,
                ..restored
            },
        ] {
            assert!(!interrupts_equal_rebased(&[source], &[changed], 3));
        }
        assert_eq!(rebase_optional(None, 3), Some(None));
        assert_eq!(rebase_optional(Some(2), 3), None);
        assert_eq!(rebase_optional(Some(3), 3), Some(Some(0)));
        assert_eq!(rebase_optional(Some(4), 3), Some(Some(1)));
    }
}

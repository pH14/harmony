// SPDX-License-Identifier: AGPL-3.0-or-later

use zerocopy::little_endian::U64;
use zerocopy::{FromBytes, Immutable, IntoBytes, KnownLayout, Unaligned};

use crate::codec::{
    Reader, decode_contract_hash, decode_mp_state, decode_timers, encode_mp_state,
    encoding_capacity, put_section, put_timers, read_fixed, timer_payload_len,
};
use crate::error::VmStateError;
use crate::records::SnapshotRecords;
use crate::types::{DeviceBlob, MpState, TimerQueueState, VtimeState};
use crate::wire::{HeaderWire, VtimeWire};
use crate::{ARCH_AARCH64, VM_STATE_MAGIC, VM_STATE_VERSION};

const TAG_REGS: u16 = 1;
const TAG_SYSREGS: u16 = 2;
const TAG_MP_STATE: u16 = 3;
const TAG_VTIME: u16 = 4;
const TAG_TIMERS: u16 = 5;
const TAG_HYPERCALL: u16 = 6;
const TAG_DEVICES: u16 = 7;
const TAG_CONTRACT_HASH: u16 = 8;
const TAG_SIMD_FP: u16 = 9;
const TAG_DEBUG: u16 = 10;
const TAG_VTIMER: u16 = 11;
const TAG_INTERRUPTS: u16 = 12;

const SECTION_COUNT: u16 = 12;

const TAG_ENGINE_STATE: u16 = 13;

const HEADER_LEN: usize = 10;

#[derive(Clone, PartialEq, Eq, Debug, Default)]
pub struct Arm64VmState {
    pub regs: Arm64Regs,
    pub sysregs: Arm64Sysregs,
    pub simd_fp: Arm64SimdFp,
    pub debug: Arm64Debug,
    pub vtimer: Arm64Vtimer,
    pub interrupts: Arm64Interrupts,
    pub mp_state: MpState,
    pub vtime: VtimeState,
    pub timers: TimerQueueState,
    pub hypercall: Vec<u8>,
    pub devices: DeviceBlob,
    pub contract_hash: [u8; 32],
    pub engine_state: Vec<u8>,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub struct Arm64Regs {
    pub x: [u64; 31],
    pub sp: u64,
    pub pc: u64,
    pub pstate: u64,
    pub sp_el1: u64,
    pub elr_el1: u64,
    pub spsr_el1: u64,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub struct Arm64Sysregs {
    pub sctlr_el1: u64,
    pub ttbr0_el1: u64,
    pub ttbr1_el1: u64,
    pub tcr_el1: u64,
    pub mair_el1: u64,
    pub vbar_el1: u64,
    pub cpacr_el1: u64,
    pub esr_el1: u64,
    pub far_el1: u64,
    pub tpidr_el0: u64,
    pub tpidr_el1: u64,
    pub tpidrro_el0: u64,
    pub cntkctl_el1: u64,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub struct Arm64SimdFp {
    pub q: [[u8; 16]; 32],
    pub fpcr: u64,
    pub fpsr: u64,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub struct Arm64Debug {
    pub breakpoint_value: [u64; 16],
    pub breakpoint_control: [u64; 16],
    pub watchpoint_value: [u64; 16],
    pub watchpoint_control: [u64; 16],
    pub mdscr_el1: u64,
    pub trap_debug_exceptions: bool,
    pub trap_debug_reg_accesses: bool,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub struct Arm64Vtimer {
    pub cntv_ctl_el0: u64,
    pub cntv_cval_el0: u64,
    pub masked: bool,
    pub counter: u64,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub struct Arm64Interrupts {
    pub irq: bool,
    pub fiq: bool,
}

#[derive(FromBytes, IntoBytes, Immutable, KnownLayout, Unaligned)]
#[repr(C)]
struct Arm64RegsWire {
    x: [U64; 31],
    sp: U64,
    pc: U64,
    pstate: U64,
    sp_el1: U64,
    elr_el1: U64,
    spsr_el1: U64,
}

impl From<&Arm64Regs> for Arm64RegsWire {
    fn from(r: &Arm64Regs) -> Self {
        Self {
            x: r.x.map(U64::from),
            sp: r.sp.into(),
            pc: r.pc.into(),
            pstate: r.pstate.into(),
            sp_el1: r.sp_el1.into(),
            elr_el1: r.elr_el1.into(),
            spsr_el1: r.spsr_el1.into(),
        }
    }
}

impl From<&Arm64RegsWire> for Arm64Regs {
    fn from(w: &Arm64RegsWire) -> Self {
        Self {
            x: w.x.map(|v| v.get()),
            sp: w.sp.get(),
            pc: w.pc.get(),
            pstate: w.pstate.get(),
            sp_el1: w.sp_el1.get(),
            elr_el1: w.elr_el1.get(),
            spsr_el1: w.spsr_el1.get(),
        }
    }
}

#[derive(FromBytes, IntoBytes, Immutable, KnownLayout, Unaligned)]
#[repr(C)]
struct Arm64SysregsWire {
    sctlr_el1: U64,
    ttbr0_el1: U64,
    ttbr1_el1: U64,
    tcr_el1: U64,
    mair_el1: U64,
    vbar_el1: U64,
    cpacr_el1: U64,
    esr_el1: U64,
    far_el1: U64,
    tpidr_el0: U64,
    tpidr_el1: U64,
    tpidrro_el0: U64,
    cntkctl_el1: U64,
}

impl From<&Arm64Sysregs> for Arm64SysregsWire {
    fn from(s: &Arm64Sysregs) -> Self {
        Self {
            sctlr_el1: s.sctlr_el1.into(),
            ttbr0_el1: s.ttbr0_el1.into(),
            ttbr1_el1: s.ttbr1_el1.into(),
            tcr_el1: s.tcr_el1.into(),
            mair_el1: s.mair_el1.into(),
            vbar_el1: s.vbar_el1.into(),
            cpacr_el1: s.cpacr_el1.into(),
            esr_el1: s.esr_el1.into(),
            far_el1: s.far_el1.into(),
            tpidr_el0: s.tpidr_el0.into(),
            tpidr_el1: s.tpidr_el1.into(),
            tpidrro_el0: s.tpidrro_el0.into(),
            cntkctl_el1: s.cntkctl_el1.into(),
        }
    }
}

impl From<&Arm64SysregsWire> for Arm64Sysregs {
    fn from(w: &Arm64SysregsWire) -> Self {
        Self {
            sctlr_el1: w.sctlr_el1.get(),
            ttbr0_el1: w.ttbr0_el1.get(),
            ttbr1_el1: w.ttbr1_el1.get(),
            tcr_el1: w.tcr_el1.get(),
            mair_el1: w.mair_el1.get(),
            vbar_el1: w.vbar_el1.get(),
            cpacr_el1: w.cpacr_el1.get(),
            esr_el1: w.esr_el1.get(),
            far_el1: w.far_el1.get(),
            tpidr_el0: w.tpidr_el0.get(),
            tpidr_el1: w.tpidr_el1.get(),
            tpidrro_el0: w.tpidrro_el0.get(),
            cntkctl_el1: w.cntkctl_el1.get(),
        }
    }
}

#[derive(FromBytes, IntoBytes, Immutable, KnownLayout, Unaligned)]
#[repr(C)]
struct Arm64SimdFpWire {
    q: [[u8; 16]; 32],
    fpcr: U64,
    fpsr: U64,
}

impl From<&Arm64SimdFp> for Arm64SimdFpWire {
    fn from(s: &Arm64SimdFp) -> Self {
        Self {
            q: s.q,
            fpcr: s.fpcr.into(),
            fpsr: s.fpsr.into(),
        }
    }
}

impl From<&Arm64SimdFpWire> for Arm64SimdFp {
    fn from(w: &Arm64SimdFpWire) -> Self {
        Self {
            q: w.q,
            fpcr: w.fpcr.get(),
            fpsr: w.fpsr.get(),
        }
    }
}

#[derive(FromBytes, IntoBytes, Immutable, KnownLayout, Unaligned)]
#[repr(C)]
struct Arm64DebugWire {
    breakpoint_value: [U64; 16],
    breakpoint_control: [U64; 16],
    watchpoint_value: [U64; 16],
    watchpoint_control: [U64; 16],
    mdscr_el1: U64,
    trap_debug_exceptions: u8,
    trap_debug_reg_accesses: u8,
    reserved: [u8; 6],
}

impl From<&Arm64Debug> for Arm64DebugWire {
    fn from(s: &Arm64Debug) -> Self {
        Self {
            breakpoint_value: s.breakpoint_value.map(U64::from),
            breakpoint_control: s.breakpoint_control.map(U64::from),
            watchpoint_value: s.watchpoint_value.map(U64::from),
            watchpoint_control: s.watchpoint_control.map(U64::from),
            mdscr_el1: s.mdscr_el1.into(),
            trap_debug_exceptions: u8::from(s.trap_debug_exceptions),
            trap_debug_reg_accesses: u8::from(s.trap_debug_reg_accesses),
            reserved: [0; 6],
        }
    }
}

fn decode_bool(value: u8) -> Result<bool, VmStateError> {
    match value {
        0 => Ok(false),
        1 => Ok(true),
        _ => Err(VmStateError::InvalidField),
    }
}

fn decode_debug(w: &Arm64DebugWire) -> Result<Arm64Debug, VmStateError> {
    if w.reserved != [0; 6] {
        return Err(VmStateError::InvalidField);
    }
    Ok(Arm64Debug {
        breakpoint_value: w.breakpoint_value.map(|v| v.get()),
        breakpoint_control: w.breakpoint_control.map(|v| v.get()),
        watchpoint_value: w.watchpoint_value.map(|v| v.get()),
        watchpoint_control: w.watchpoint_control.map(|v| v.get()),
        mdscr_el1: w.mdscr_el1.get(),
        trap_debug_exceptions: decode_bool(w.trap_debug_exceptions)?,
        trap_debug_reg_accesses: decode_bool(w.trap_debug_reg_accesses)?,
    })
}

#[derive(FromBytes, IntoBytes, Immutable, KnownLayout, Unaligned)]
#[repr(C)]
struct Arm64VtimerWire {
    cntv_ctl_el0: U64,
    cntv_cval_el0: U64,
    counter: U64,
    masked: u8,
    reserved: [u8; 7],
}

impl From<&Arm64Vtimer> for Arm64VtimerWire {
    fn from(s: &Arm64Vtimer) -> Self {
        Self {
            cntv_ctl_el0: s.cntv_ctl_el0.into(),
            cntv_cval_el0: s.cntv_cval_el0.into(),
            counter: s.counter.into(),
            masked: u8::from(s.masked),
            reserved: [0; 7],
        }
    }
}

fn decode_vtimer(w: &Arm64VtimerWire) -> Result<Arm64Vtimer, VmStateError> {
    if w.reserved != [0; 7] {
        return Err(VmStateError::InvalidField);
    }
    Ok(Arm64Vtimer {
        cntv_ctl_el0: w.cntv_ctl_el0.get(),
        cntv_cval_el0: w.cntv_cval_el0.get(),
        masked: decode_bool(w.masked)?,
        counter: w.counter.get(),
    })
}

#[derive(FromBytes, IntoBytes, Immutable, KnownLayout, Unaligned)]
#[repr(C)]
struct Arm64InterruptsWire {
    irq: u8,
    fiq: u8,
    reserved: [u8; 6],
}

impl From<&Arm64Interrupts> for Arm64InterruptsWire {
    fn from(s: &Arm64Interrupts) -> Self {
        Self {
            irq: u8::from(s.irq),
            fiq: u8::from(s.fiq),
            reserved: [0; 6],
        }
    }
}

fn decode_interrupts(w: &Arm64InterruptsWire) -> Result<Arm64Interrupts, VmStateError> {
    if w.reserved != [0; 6] {
        return Err(VmStateError::InvalidField);
    }
    Ok(Arm64Interrupts {
        irq: decode_bool(w.irq)?,
        fiq: decode_bool(w.fiq)?,
    })
}

impl Arm64VmState {
    pub fn encode(&self) -> Result<Vec<u8>, VmStateError> {
        self.encode_with_counter(self.vtimer.counter)
    }

    fn encode_with_counter(&self, counter: u64) -> Result<Vec<u8>, VmStateError> {
        let mut vtimer = Arm64VtimerWire::from(&self.vtimer);
        vtimer.counter = counter.into();
        let section_count = SECTION_COUNT + u16::from(!self.engine_state.is_empty());
        let mut out = Vec::with_capacity(encoding_capacity(
            [
                size_of::<Arm64RegsWire>(),
                size_of::<Arm64SysregsWire>(),
                1,
                size_of::<VtimeWire>(),
                timer_payload_len(&self.timers)?,
                self.hypercall.len(),
                self.devices.0.len(),
                self.contract_hash.len(),
                size_of::<Arm64SimdFpWire>(),
                size_of::<Arm64DebugWire>(),
                size_of::<Arm64VtimerWire>(),
                size_of::<Arm64InterruptsWire>(),
            ]
            .into_iter()
            .chain((!self.engine_state.is_empty()).then_some(self.engine_state.len())),
        )?);
        out.extend_from_slice(
            HeaderWire {
                magic: VM_STATE_MAGIC.into(),
                version: VM_STATE_VERSION.into(),
                arch: ARCH_AARCH64.into(),
                section_count: section_count.into(),
            }
            .as_bytes(),
        );

        put_section(
            &mut out,
            TAG_REGS,
            Arm64RegsWire::from(&self.regs).as_bytes(),
        )?;
        put_section(
            &mut out,
            TAG_SYSREGS,
            Arm64SysregsWire::from(&self.sysregs).as_bytes(),
        )?;
        put_section(&mut out, TAG_MP_STATE, &[encode_mp_state(self.mp_state)])?;
        put_section(&mut out, TAG_VTIME, VtimeWire::from(&self.vtime).as_bytes())?;
        put_timers(&mut out, TAG_TIMERS, &self.timers)?;
        put_section(&mut out, TAG_HYPERCALL, &self.hypercall)?;
        put_section(&mut out, TAG_DEVICES, &self.devices.0)?;
        put_section(&mut out, TAG_CONTRACT_HASH, &self.contract_hash)?;
        put_section(
            &mut out,
            TAG_SIMD_FP,
            Arm64SimdFpWire::from(&self.simd_fp).as_bytes(),
        )?;
        put_section(
            &mut out,
            TAG_DEBUG,
            Arm64DebugWire::from(&self.debug).as_bytes(),
        )?;
        put_section(&mut out, TAG_VTIMER, vtimer.as_bytes())?;
        put_section(
            &mut out,
            TAG_INTERRUPTS,
            Arm64InterruptsWire::from(&self.interrupts).as_bytes(),
        )?;
        if !self.engine_state.is_empty() {
            put_section(&mut out, TAG_ENGINE_STATE, &self.engine_state)?;
        }

        Ok(out)
    }

    pub fn decode(bytes: &[u8]) -> Result<Arm64VmState, VmStateError> {
        let header = HeaderWire::read_from_prefix(bytes)
            .map_err(|_| VmStateError::Truncated)?
            .0;
        let magic = header.magic.get();
        if magic != VM_STATE_MAGIC {
            return Err(VmStateError::BadMagic(magic));
        }
        let version = header.version.get();
        if version != VM_STATE_VERSION {
            return Err(VmStateError::UnsupportedVersion(version));
        }
        let arch = header.arch.get();
        if arch != ARCH_AARCH64 {
            return Err(VmStateError::UnsupportedArch(arch));
        }
        let section_count = header.section_count.get();

        let mut r = Reader::new(&bytes[HEADER_LEN..]);
        let mut last_tag: Option<u16> = None;

        let mut regs = None;
        let mut sysregs = None;
        let mut mp_state = None;
        let mut vtime = None;
        let mut timers = None;
        let mut hypercall = None;
        let mut devices = None;
        let mut contract_hash = None;
        let mut simd_fp = None;
        let mut debug = None;
        let mut vtimer = None;
        let mut interrupts = None;
        let mut engine_state = None;

        for _ in 0..section_count {
            let tag = r.u16()?;
            let len = r.u32()? as usize;
            let payload = r.take(len)?;

            if let Some(prev) = last_tag
                && tag <= prev
            {
                return Err(if tag == prev {
                    VmStateError::DuplicateTag(tag)
                } else {
                    VmStateError::SectionOrder(tag)
                });
            }
            last_tag = Some(tag);

            match tag {
                TAG_REGS => regs = Some(Arm64Regs::from(&read_fixed::<Arm64RegsWire>(payload)?)),
                TAG_SYSREGS => {
                    sysregs = Some(Arm64Sysregs::from(&read_fixed::<Arm64SysregsWire>(
                        payload,
                    )?));
                }
                TAG_MP_STATE => mp_state = Some(decode_mp_state(payload)?),
                TAG_VTIME => vtime = Some(VtimeState::from(&read_fixed::<VtimeWire>(payload)?)),
                TAG_TIMERS => timers = Some(decode_timers(payload)?),
                TAG_HYPERCALL => hypercall = Some(payload.to_vec()),
                TAG_DEVICES => devices = Some(DeviceBlob(payload.to_vec())),
                TAG_CONTRACT_HASH => contract_hash = Some(decode_contract_hash(payload)?),
                TAG_SIMD_FP => {
                    simd_fp = Some(Arm64SimdFp::from(&read_fixed::<Arm64SimdFpWire>(payload)?));
                }
                TAG_DEBUG => {
                    debug = Some(decode_debug(&read_fixed::<Arm64DebugWire>(payload)?)?);
                }
                TAG_VTIMER => {
                    vtimer = Some(decode_vtimer(&read_fixed::<Arm64VtimerWire>(payload)?)?);
                }
                TAG_INTERRUPTS => {
                    interrupts = Some(decode_interrupts(&read_fixed::<Arm64InterruptsWire>(
                        payload,
                    )?)?);
                }
                TAG_ENGINE_STATE => {
                    if payload.is_empty() {
                        return Err(VmStateError::InvalidField);
                    }
                    engine_state = Some(payload.to_vec());
                }
                other => return Err(VmStateError::UnknownTag(other)),
            }
        }

        if !r.at_end() {
            return Err(VmStateError::TrailingBytes);
        }

        let vtime = vtime.ok_or(VmStateError::MissingSection(TAG_VTIME))?;
        Ok(Arm64VmState {
            regs: regs.ok_or(VmStateError::MissingSection(TAG_REGS))?,
            sysregs: sysregs.ok_or(VmStateError::MissingSection(TAG_SYSREGS))?,
            simd_fp: simd_fp.ok_or(VmStateError::MissingSection(TAG_SIMD_FP))?,
            debug: debug.ok_or(VmStateError::MissingSection(TAG_DEBUG))?,
            vtimer: vtimer.ok_or(VmStateError::MissingSection(TAG_VTIMER))?,
            interrupts: interrupts.ok_or(VmStateError::MissingSection(TAG_INTERRUPTS))?,
            mp_state: mp_state.ok_or(VmStateError::MissingSection(TAG_MP_STATE))?,
            vtime,
            timers: timers.ok_or(VmStateError::MissingSection(TAG_TIMERS))?,
            hypercall: hypercall.ok_or(VmStateError::MissingSection(TAG_HYPERCALL))?,
            devices: devices.ok_or(VmStateError::MissingSection(TAG_DEVICES))?,
            contract_hash: contract_hash.ok_or(VmStateError::MissingSection(TAG_CONTRACT_HASH))?,
            engine_state: engine_state.unwrap_or_default(),
        })
    }
}

impl SnapshotRecords for Arm64VmState {
    const ARCH_TAG: u16 = ARCH_AARCH64;

    fn encode(&self) -> Result<Vec<u8>, VmStateError> {
        Arm64VmState::encode(self)
    }

    fn encode_for_hash(&self) -> Result<Vec<u8>, VmStateError> {
        self.encode_with_counter(0)
    }

    fn decode(bytes: &[u8]) -> Result<Self, VmStateError> {
        Arm64VmState::decode(bytes)
    }

    fn vtime(&self) -> &VtimeState {
        &self.vtime
    }

    fn timers(&self) -> &TimerQueueState {
        &self.timers
    }

    fn engine_state(&self) -> &[u8] {
        &self.engine_state
    }

    fn set_engine_state(&mut self, state: Vec<u8>) {
        self.engine_state = state;
    }

    fn entropy_bytes(&self) -> &[u8] {
        &self.hypercall
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::VmState;

    fn sample() -> Arm64VmState {
        let mut s = Arm64VmState::default();
        s.regs.x[0] = 0x4000_0000;
        s.regs.pc = 0x0020_0000;
        s.regs.pstate = 0x3c5;
        s.sysregs.sctlr_el1 = 0x30d0_0800;
        s.sysregs.cntkctl_el1 = 0;
        s.simd_fp.q[0] = [0x5A; 16];
        s.simd_fp.q[31] = [0xA5; 16];
        s.simd_fp.fpcr = 0x0040_0000;
        s.simd_fp.fpsr = 0x0800_009f;
        s.debug.breakpoint_value[0] = 0x1111_2222_3333_4444;
        s.debug.breakpoint_control[15] = 0x55;
        s.debug.watchpoint_value[7] = 0xAAAA_BBBB_CCCC_DDDD;
        s.debug.watchpoint_control[8] = 0x66;
        s.debug.mdscr_el1 = 0x2000;
        s.debug.trap_debug_exceptions = true;
        s.vtimer.cntv_ctl_el0 = 1;
        s.vtimer.cntv_cval_el0 = 0x1234_5678;
        s.vtimer.masked = true;
        s.vtimer.counter = 0x8765_4321;
        s.interrupts.irq = true;
        s.mp_state = MpState::Runnable;
        s.vtime.snapshot_vns = 7;
        s.hypercall = vec![9, 9, 9];
        s.devices = DeviceBlob(vec![1, 2, 3, 4]);
        s.contract_hash = [0xAB; 32];
        s
    }

    #[test]
    fn the_hashed_encoding_ignores_the_virtual_counter() {
        let early = sample();
        let mut late = early.clone();
        late.vtimer.counter = early.vtimer.counter + 1_000_000;

        assert_ne!(
            SnapshotRecords::encode(&early).unwrap(),
            SnapshotRecords::encode(&late).unwrap()
        );
        assert_eq!(
            SnapshotRecords::encode_for_hash(&early).unwrap(),
            SnapshotRecords::encode_for_hash(&late).unwrap()
        );
        assert_eq!(
            Arm64VmState::decode(&SnapshotRecords::encode(&late).unwrap())
                .unwrap()
                .vtimer
                .counter,
            late.vtimer.counter
        );
    }

    fn section(blob: &[u8], wanted: u16) -> (usize, usize) {
        let mut pos = HEADER_LEN;
        while pos < blob.len() {
            let tag = u16::from_le_bytes(blob[pos..pos + 2].try_into().unwrap());
            let len = u32::from_le_bytes(blob[pos + 2..pos + 6].try_into().unwrap()) as usize;
            let payload = pos + 6;
            if tag == wanted {
                return (payload, len);
            }
            pos = payload + len;
        }
        panic!("section {wanted} not present in valid arm64 blob");
    }

    fn split(blob: &[u8]) -> (u16, Vec<(u16, Vec<u8>)>) {
        let count = u16::from_le_bytes(blob[8..10].try_into().unwrap());
        let mut sections = Vec::new();
        let mut pos = HEADER_LEN;
        while pos < blob.len() {
            let tag = u16::from_le_bytes(blob[pos..pos + 2].try_into().unwrap());
            let len = u32::from_le_bytes(blob[pos + 2..pos + 6].try_into().unwrap()) as usize;
            let payload = pos + 6;
            sections.push((tag, blob[payload..payload + len].to_vec()));
            pos = payload + len;
        }
        (count, sections)
    }

    fn pack(version: u16, count: u16, sections: &[(u16, Vec<u8>)]) -> Vec<u8> {
        let mut out = Vec::new();
        out.extend_from_slice(&crate::VM_STATE_MAGIC.to_le_bytes());
        out.extend_from_slice(&version.to_le_bytes());
        out.extend_from_slice(&crate::ARCH_AARCH64.to_le_bytes());
        out.extend_from_slice(&count.to_le_bytes());
        for (tag, payload) in sections {
            out.extend_from_slice(&tag.to_le_bytes());
            out.extend_from_slice(&(payload.len() as u32).to_le_bytes());
            out.extend_from_slice(payload);
        }
        out
    }

    #[test]
    fn round_trips_byte_deterministically() {
        let s = sample();
        let a = s.encode().unwrap();
        let b = s.encode().unwrap();
        assert_eq!(a, b, "equal values must encode to identical bytes");
        assert_eq!(Arm64VmState::decode(&a).unwrap(), s);
    }

    #[test]
    fn current_engine_state_round_trips_multiple_payloads() {
        for payload in [vec![0x01], vec![0x00, 0xFE, 0xA5], (0u8..=255).collect()] {
            let mut state = sample();
            state.engine_state = payload.clone();
            let blob = state.encode().unwrap();
            assert_eq!(
                u16::from_le_bytes(blob[4..6].try_into().unwrap()),
                VM_STATE_VERSION
            );
            assert_eq!(
                u16::from_le_bytes(blob[8..10].try_into().unwrap()),
                13,
                "current format adds exactly one trailing section"
            );
            let decoded = Arm64VmState::decode(&blob).unwrap();
            assert_eq!(decoded.engine_state, payload);
            assert_eq!(decoded.encode().unwrap(), blob);
        }
    }

    #[test]
    fn current_engine_state_section_is_optional_nonempty_and_last() {
        let good_state = {
            let mut state = sample();
            state.engine_state = vec![1, 2, 3];
            state
        };
        let good = good_state.encode().unwrap();
        let (count, sections) = split(&good);
        assert_eq!(count, 13);
        assert_eq!(sections.last().map(|(tag, _)| *tag), Some(TAG_ENGINE_STATE));

        let mut empty = sections.clone();
        empty.last_mut().unwrap().1.clear();
        assert_eq!(
            Arm64VmState::decode(&pack(VM_STATE_VERSION, count, &empty)),
            Err(VmStateError::InvalidField)
        );

        let mut missing = sections.clone();
        missing.pop();
        let decoded = Arm64VmState::decode(&pack(VM_STATE_VERSION, count - 1, &missing)).unwrap();
        assert!(decoded.engine_state.is_empty());

        let mut duplicate = sections.clone();
        duplicate.push(sections.last().unwrap().clone());
        assert_eq!(
            Arm64VmState::decode(&pack(VM_STATE_VERSION, count + 1, &duplicate)),
            Err(VmStateError::DuplicateTag(TAG_ENGINE_STATE))
        );

        let mut out_of_order = sections;
        let last = out_of_order.len() - 1;
        out_of_order.swap(last - 1, last);
        assert_eq!(
            Arm64VmState::decode(&pack(VM_STATE_VERSION, count, &out_of_order)),
            Err(VmStateError::SectionOrder(TAG_ENGINE_STATE - 1))
        );

        let mut trailing = good;
        trailing.push(0);
        assert_eq!(
            Arm64VmState::decode(&trailing),
            Err(VmStateError::TrailingBytes)
        );
    }

    #[test]
    fn foreign_arch_tags_are_rejected_both_ways() {
        let x86 = VmState::default();
        let x86_bytes = x86.encode().unwrap();
        assert_eq!(
            Arm64VmState::decode(&x86_bytes),
            Err(VmStateError::UnsupportedArch(crate::ARCH_X86_64))
        );
        let arm = sample().encode().unwrap();
        assert_eq!(
            VmState::decode(&arm),
            Err(VmStateError::UnsupportedArch(ARCH_AARCH64))
        );
    }

    #[test]
    fn strict_decode_rejects_malformed_blobs() {
        let good = sample().encode().unwrap();

        assert_eq!(
            Arm64VmState::decode(&good[..4]),
            Err(VmStateError::Truncated)
        );
        assert_eq!(
            Arm64VmState::decode(&good[..good.len() - 1]),
            Err(VmStateError::Truncated)
        );

        let mut trailing = good.clone();
        trailing.push(0);
        assert_eq!(
            Arm64VmState::decode(&trailing),
            Err(VmStateError::TrailingBytes)
        );

        let mut bad_magic = good.clone();
        bad_magic[0] ^= 0xFF;
        assert!(matches!(
            Arm64VmState::decode(&bad_magic),
            Err(VmStateError::BadMagic(_))
        ));

        let mut bad_version = good.clone();
        bad_version[4] = 0xEE;
        assert!(matches!(
            Arm64VmState::decode(&bad_version),
            Err(VmStateError::UnsupportedVersion(_))
        ));
    }

    #[test]
    fn retained_state_sections_reject_noncanonical_boolean_and_reserved_bytes() {
        let good = sample().encode().unwrap();

        let (debug, debug_len) = section(&good, TAG_DEBUG);
        assert_eq!(debug_len, size_of::<Arm64DebugWire>());
        for offset in [debug + 520, debug + 521, debug + 522] {
            let mut malformed = good.clone();
            malformed[offset] = 2;
            assert_eq!(
                Arm64VmState::decode(&malformed),
                Err(VmStateError::InvalidField)
            );
        }

        let (vtimer, vtimer_len) = section(&good, TAG_VTIMER);
        assert_eq!(vtimer_len, size_of::<Arm64VtimerWire>());
        for offset in [vtimer + 24, vtimer + 25] {
            let mut malformed = good.clone();
            malformed[offset] = 2;
            assert_eq!(
                Arm64VmState::decode(&malformed),
                Err(VmStateError::InvalidField)
            );
        }

        let (interrupts, interrupts_len) = section(&good, TAG_INTERRUPTS);
        assert_eq!(interrupts_len, size_of::<Arm64InterruptsWire>());
        for offset in [interrupts, interrupts + 1, interrupts + 2] {
            let mut malformed = good.clone();
            malformed[offset] = 2;
            assert_eq!(
                Arm64VmState::decode(&malformed),
                Err(VmStateError::InvalidField)
            );
        }
    }

    #[test]
    fn decode_never_panics_on_arbitrary_prefixes() {
        let good = sample().encode().unwrap();
        for n in 0..good.len() {
            let _ = Arm64VmState::decode(&good[..n]);
        }
    }

    #[test]
    fn snapshot_records_surface_matches_the_inherent_codec() {
        let s = sample();
        assert_eq!(<Arm64VmState as SnapshotRecords>::ARCH_TAG, ARCH_AARCH64);
        assert_eq!(
            <Arm64VmState as SnapshotRecords>::encode(&s).unwrap(),
            s.encode().unwrap()
        );
        assert_eq!(s.vtime(), &s.vtime);
        assert_eq!(s.timers(), &s.timers);
        assert_eq!(s.entropy_bytes(), &s.hypercall[..]);
    }
}

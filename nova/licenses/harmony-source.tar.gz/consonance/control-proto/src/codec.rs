// SPDX-License-Identifier: AGPL-3.0-or-later

use crate::error::ProtocolError;
use crate::types::{
    Answer, CapFlags, Caps, CoverageGeometry, CrashInfo, CrashKind, DecisionId, EventRef,
    HashScope, HostFault, Moment, RegsView, Reply, Reproducer, Request, Resolution, SnapId,
    StopConditions, StopMask, StopReason,
};
use crate::{MAX_FRAME_LEN, PROTO_VERSION};

const MAGIC: u32 = u32::from_le_bytes(*b"CTL1");
const HEADER_LEN: usize = 14;

const REQ_HELLO: u8 = 1;
const REQ_SNAPSHOT: u8 = 2;
const REQ_DROP: u8 = 3;
const REQ_BRANCH: u8 = 4;
const REQ_REPLAY: u8 = 5;
const REQ_RUN: u8 = 6;
const REQ_HASH: u8 = 7;
const REQ_PERTURB: u8 = 8;
const REQ_SDK_EVENTS: u8 = 9;
const REQ_READ: u8 = 10;
const REQ_REGS: u8 = 11;
const REQ_EXEC: u8 = 12;
const REQ_RECORDED_ENV: u8 = 13;
const REQ_CONSOLE: u8 = 14;

const RESULT_OK: u8 = 0;
const RESULT_ERR: u8 = 1;

const REPLY_HELLO: u8 = 1;
const REPLY_UNIT: u8 = 3;
const REPLY_STOP: u8 = 4;
const REPLY_HASH: u8 = 5;
const REPLY_SDK_EVENTS: u8 = 6;
const REPLY_BYTES: u8 = 7;
const REPLY_REGS: u8 = 8;
const REPLY_EXEC_RESULT: u8 = 9;
const REPLY_SNAPSHOT: u8 = 10;
const REPLY_RECORDED: u8 = 11;
const REPLY_CONSOLE: u8 = 12;

const SR_DEADLINE: u8 = 1;
const SR_QUIESCENT: u8 = 2;
const SR_CRASH: u8 = 3;
const SR_DECISION: u8 = 4;
const SR_SNAPSHOT_POINT: u8 = 5;
const SR_ASSERTION: u8 = 6;

const CK_PANIC: u8 = 0;
const CK_UNRECOVERABLE_FAULT: u8 = 1;
const CK_SHUTDOWN: u8 = 2;

const HS_WHOLE: u8 = 0;
const HS_DISK: u8 = 1;
const HS_REGION: u8 = 2;

const CE_UNKNOWN_SNAPSHOT: u8 = 1;
const CE_RESTORE_FAILED: u8 = 2;
const CE_SNAPSHOT_WHILE_ARMED: u8 = 3;
const CE_NOT_QUIESCENT: u8 = 4;
const CE_BAD_ENV_VERSION: u8 = 5;
const CE_MALFORMED_ENVIRONMENT: u8 = 6;
const CE_RESOLVE_WITHOUT_DECISION: u8 = 7;
const CE_MALFORMED_ANSWER: u8 = 8;
const CE_PROTOCOL: u8 = 9;
const CE_UNSUPPORTED: u8 = 10;
const CE_PERTURB_OUT_OF_RANGE: u8 = 11;
const CE_PERTURB_PAST_MOMENT: u8 = 12;
const CE_PERTURB_MOMENT_TAKEN: u8 = 13;
const CE_SCHEDULE_UNSATISFIABLE: u8 = 14;
const CE_READ_OUT_OF_RANGE: u8 = 17;
const CE_READ_TOO_LARGE: u8 = 18;
const CE_TAINTED: u8 = 19;
const CE_SNAPSHOT_REFUSED: u8 = 20;

const PE_SHORT_FRAME: u8 = 0;
const PE_BAD_MAGIC: u8 = 1;
const PE_BAD_VERSION: u8 = 2;
const PE_BAD_LENGTH: u8 = 3;

const ABSENT: u8 = 0;
const PRESENT: u8 = 1;

pub fn encode_request(seq: u32, req: &Request, buf: &mut Vec<u8>) -> Result<(), ProtocolError> {
    let mut body = Vec::new();
    write_request(&mut body, req);
    finish_frame(seq, &body, buf)
}

pub fn encode_reply(
    seq: u32,
    reply: &Result<Reply, crate::error::ControlError>,
    buf: &mut Vec<u8>,
) -> Result<(), ProtocolError> {
    let mut body = Vec::new();
    write_reply_result(&mut body, reply);
    finish_frame(seq, &body, buf)
}

pub fn decode_request(buf: &[u8]) -> Result<Option<(u32, Request, usize)>, ProtocolError> {
    let Some((seq, body, consumed)) = decode_frame(buf)? else {
        return Ok(None);
    };
    let mut r = Reader::new(body);
    let req = read_request(&mut r)?;
    r.finish()?;
    Ok(Some((seq, req, consumed)))
}

#[allow(clippy::type_complexity)]
pub fn decode_reply(
    buf: &[u8],
) -> Result<Option<(u32, Result<Reply, crate::error::ControlError>, usize)>, ProtocolError> {
    let Some((seq, body, consumed)) = decode_frame(buf)? else {
        return Ok(None);
    };
    let mut r = Reader::new(body);
    let reply = read_reply_result(&mut r)?;
    r.finish()?;
    Ok(Some((seq, reply, consumed)))
}

fn finish_frame(seq: u32, body: &[u8], buf: &mut Vec<u8>) -> Result<(), ProtocolError> {
    if body.len() > MAX_FRAME_LEN {
        return Err(ProtocolError::BadLength);
    }
    buf.extend_from_slice(&MAGIC.to_le_bytes());
    buf.extend_from_slice(&PROTO_VERSION.to_le_bytes());
    buf.extend_from_slice(&seq.to_le_bytes());
    buf.extend_from_slice(&(body.len() as u32).to_le_bytes());
    buf.extend_from_slice(body);
    Ok(())
}

type Framed<'a> = (u32, &'a [u8], usize);

fn decode_frame(buf: &[u8]) -> Result<Option<Framed<'_>>, ProtocolError> {
    if buf.len() < HEADER_LEN {
        return Ok(None);
    }
    if u32::from_le_bytes([buf[0], buf[1], buf[2], buf[3]]) != MAGIC {
        return Err(ProtocolError::BadMagic);
    }
    if u16::from_le_bytes([buf[4], buf[5]]) != PROTO_VERSION {
        return Err(ProtocolError::BadVersion);
    }
    let seq = u32::from_le_bytes([buf[6], buf[7], buf[8], buf[9]]);
    let len = u32::from_le_bytes([buf[10], buf[11], buf[12], buf[13]]) as usize;
    if len > MAX_FRAME_LEN {
        return Err(ProtocolError::BadLength);
    }
    let end = HEADER_LEN + len;
    if buf.len() < end {
        return Ok(None);
    }
    Ok(Some((seq, &buf[HEADER_LEN..end], end)))
}

fn write_request(w: &mut Vec<u8>, req: &Request) {
    match req {
        Request::Hello(caps) => {
            w.push(REQ_HELLO);
            write_caps(w, caps);
        }
        Request::Snapshot => w.push(REQ_SNAPSHOT),
        Request::Drop(SnapId(id)) => {
            w.push(REQ_DROP);
            put_u64(w, *id);
        }
        Request::Branch { snap, env } => {
            w.push(REQ_BRANCH);
            put_u64(w, snap.0);
            write_env(w, env);
        }
        Request::Replay(SnapId(id)) => {
            w.push(REQ_REPLAY);
            put_u64(w, *id);
        }
        Request::Run { until, resolve } => {
            w.push(REQ_RUN);
            write_stop_conditions(w, until);
            write_opt_resolution(w, resolve);
        }
        Request::Hash { scope } => {
            w.push(REQ_HASH);
            write_hash_scope(w, scope);
        }
        Request::Perturb {
            fault: HostFault(bytes),
            at: Moment(at),
        } => {
            w.push(REQ_PERTURB);
            put_bytes(w, bytes);
            put_u64(w, *at);
        }
        Request::SdkEvents { offset } => {
            w.push(REQ_SDK_EVENTS);
            put_u32(w, *offset);
        }
        Request::Console { offset } => {
            w.push(REQ_CONSOLE);
            put_u32(w, *offset);
        }
        Request::Read { gpa, len } => {
            w.push(REQ_READ);
            put_u64(w, *gpa);
            put_u32(w, *len);
        }
        Request::Regs => w.push(REQ_REGS),
        Request::Exec { cmd, deadline } => {
            w.push(REQ_EXEC);
            put_bytes(w, cmd.as_bytes());
            put_u64(w, deadline.0);
        }
        Request::RecordedEnv => w.push(REQ_RECORDED_ENV),
    }
}

fn read_request(r: &mut Reader) -> Result<Request, ProtocolError> {
    Ok(match r.u8()? {
        REQ_HELLO => Request::Hello(read_caps(r)?),
        REQ_SNAPSHOT => Request::Snapshot,
        REQ_DROP => Request::Drop(SnapId(r.u64()?)),
        REQ_BRANCH => Request::Branch {
            snap: SnapId(r.u64()?),
            env: read_env(r)?,
        },
        REQ_REPLAY => Request::Replay(SnapId(r.u64()?)),
        REQ_RUN => Request::Run {
            until: read_stop_conditions(r)?,
            resolve: read_opt_resolution(r)?,
        },
        REQ_HASH => Request::Hash {
            scope: read_hash_scope(r)?,
        },
        REQ_PERTURB => Request::Perturb {
            fault: HostFault(r.bytes()?.to_vec()),
            at: Moment(r.u64()?),
        },
        REQ_SDK_EVENTS => Request::SdkEvents { offset: r.u32()? },
        REQ_CONSOLE => Request::Console { offset: r.u32()? },
        REQ_READ => Request::Read {
            gpa: r.u64()?,
            len: r.u32()?,
        },
        REQ_REGS => Request::Regs,
        REQ_EXEC => Request::Exec {
            cmd: String::from_utf8(r.bytes()?.to_vec()).map_err(|_| ProtocolError::ShortFrame)?,
            deadline: Moment(r.u64()?),
        },
        REQ_RECORDED_ENV => Request::RecordedEnv,
        _ => return Err(ProtocolError::ShortFrame),
    })
}

fn write_reply_result(w: &mut Vec<u8>, reply: &Result<Reply, crate::error::ControlError>) {
    match reply {
        Ok(reply) => {
            w.push(RESULT_OK);
            write_reply(w, reply);
        }
        Err(err) => {
            w.push(RESULT_ERR);
            write_control_error(w, err);
        }
    }
}

fn read_reply_result(
    r: &mut Reader,
) -> Result<Result<Reply, crate::error::ControlError>, ProtocolError> {
    Ok(match r.u8()? {
        RESULT_OK => Ok(read_reply(r)?),
        RESULT_ERR => Err(read_control_error(r)?),
        _ => return Err(ProtocolError::ShortFrame),
    })
}

fn write_reply(w: &mut Vec<u8>, reply: &Reply) {
    match reply {
        Reply::Hello(caps) => {
            w.push(REPLY_HELLO);
            write_caps(w, caps);
        }
        Reply::Unit => w.push(REPLY_UNIT),
        Reply::Stop(reason) => {
            w.push(REPLY_STOP);
            write_stop_reason(w, reason);
        }
        Reply::Hash(digest) => {
            w.push(REPLY_HASH);
            w.extend_from_slice(digest);
        }
        Reply::SdkEvents(events) => {
            w.push(REPLY_SDK_EVENTS);
            put_u32(w, events.len() as u32);
            for (moment, id, bytes) in events {
                put_u64(w, *moment);
                put_u32(w, *id);
                put_bytes(w, bytes);
            }
        }
        Reply::Console { total, chunk } => {
            w.push(REPLY_CONSOLE);
            put_u32(w, *total);
            put_bytes(w, chunk);
        }
        Reply::Bytes(bytes) => {
            w.push(REPLY_BYTES);
            put_bytes(w, bytes);
        }
        Reply::Regs(view) => {
            w.push(REPLY_REGS);
            write_regs_view(w, view);
        }
        Reply::ExecResult { output, ok } => {
            w.push(REPLY_EXEC_RESULT);
            put_bytes(w, output);
            w.push(u8::from(*ok));
        }
        Reply::Snapshot {
            id,
            at,
            sdk_events,
            tainted,
        } => {
            w.push(REPLY_SNAPSHOT);
            put_u64(w, id.0);
            put_u64(w, at.0);
            put_u64(w, *sdk_events);
            w.push(u8::from(*tainted));
        }
        Reply::Recorded(env) => {
            w.push(REPLY_RECORDED);
            write_env(w, env);
        }
    }
}

fn read_reply(r: &mut Reader) -> Result<Reply, ProtocolError> {
    Ok(match r.u8()? {
        REPLY_HELLO => Reply::Hello(read_caps(r)?),
        REPLY_UNIT => Reply::Unit,
        REPLY_STOP => Reply::Stop(read_stop_reason(r)?),
        REPLY_HASH => Reply::Hash(read_array32(r)?),
        REPLY_SDK_EVENTS => {
            let count = r.u32()?;
            let mut events = Vec::new();
            for _ in 0..count {
                let moment = r.u64()?;
                let id = r.u32()?;
                let bytes = r.bytes()?.to_vec();
                events.push((moment, id, bytes));
            }
            Reply::SdkEvents(events)
        }
        REPLY_CONSOLE => Reply::Console {
            total: r.u32()?,
            chunk: r.bytes()?.to_vec(),
        },
        REPLY_BYTES => Reply::Bytes(r.bytes()?.to_vec()),
        REPLY_REGS => Reply::Regs(read_regs_view(r)?),
        REPLY_EXEC_RESULT => Reply::ExecResult {
            output: r.bytes()?.to_vec(),
            ok: r.bool()?,
        },
        REPLY_SNAPSHOT => Reply::Snapshot {
            id: SnapId(r.u64()?),
            at: Moment(r.u64()?),
            sdk_events: r.u64()?,
            tainted: r.bool()?,
        },
        REPLY_RECORDED => Reply::Recorded(read_env(r)?),
        _ => return Err(ProtocolError::ShortFrame),
    })
}

fn write_regs_view(w: &mut Vec<u8>, v: &RegsView) {
    put_u16(w, v.version);
    for g in &v.gpr {
        put_u64(w, *g);
    }
    put_u64(w, v.rip);
    put_u64(w, v.rflags);
    for s in &v.seg {
        put_u16(w, *s);
    }
    put_u64(w, v.cr0);
    put_u64(w, v.cr3);
    put_u64(w, v.cr4);
    put_u64(w, v.moment.0);
    put_u64(w, v.vtime);
}

fn read_regs_view(r: &mut Reader) -> Result<RegsView, ProtocolError> {
    let version = r.u16()?;
    let mut gpr = [0u64; 16];
    for g in &mut gpr {
        *g = r.u64()?;
    }
    let rip = r.u64()?;
    let rflags = r.u64()?;
    let mut seg = [0u16; 6];
    for s in &mut seg {
        *s = r.u16()?;
    }
    Ok(RegsView {
        version,
        gpr,
        rip,
        rflags,
        seg,
        cr0: r.u64()?,
        cr3: r.u64()?,
        cr4: r.u64()?,
        moment: Moment(r.u64()?),
        vtime: r.u64()?,
    })
}

fn write_caps(w: &mut Vec<u8>, c: &Caps) {
    put_u16(w, c.protocol_version);
    put_u16(w, c.env_version_min);
    put_u16(w, c.env_version_max);
    put_u32(w, c.coverage.map_bytes);
    w.push(c.coverage.producer);
    put_u32(w, c.flags.0);
}

fn read_caps(r: &mut Reader) -> Result<Caps, ProtocolError> {
    Ok(Caps {
        protocol_version: r.u16()?,
        env_version_min: r.u16()?,
        env_version_max: r.u16()?,
        coverage: CoverageGeometry {
            map_bytes: r.u32()?,
            producer: r.u8()?,
        },
        flags: CapFlags(r.u32()?),
    })
}

fn write_env(w: &mut Vec<u8>, env: &Reproducer) {
    put_u16(w, env.blob_version);
    put_bytes(w, &env.bytes);
}

fn read_env(r: &mut Reader) -> Result<Reproducer, ProtocolError> {
    Ok(Reproducer {
        blob_version: r.u16()?,
        bytes: r.bytes()?.to_vec(),
    })
}

fn write_stop_conditions(w: &mut Vec<u8>, sc: &StopConditions) {
    write_opt_vtime(w, &sc.deadline);
    put_u32(w, sc.on.0);
}

fn read_stop_conditions(r: &mut Reader) -> Result<StopConditions, ProtocolError> {
    Ok(StopConditions {
        deadline: read_opt_vtime(r)?,
        on: StopMask(r.u32()?),
    })
}

fn write_hash_scope(w: &mut Vec<u8>, scope: &HashScope) {
    match scope {
        HashScope::Whole => w.push(HS_WHOLE),
        HashScope::Disk => w.push(HS_DISK),
        HashScope::Region { base, len } => {
            w.push(HS_REGION);
            put_u64(w, *base);
            put_u64(w, *len);
        }
    }
}

fn read_hash_scope(r: &mut Reader) -> Result<HashScope, ProtocolError> {
    Ok(match r.u8()? {
        HS_WHOLE => HashScope::Whole,
        HS_DISK => HashScope::Disk,
        HS_REGION => HashScope::Region {
            base: r.u64()?,
            len: r.u64()?,
        },
        _ => return Err(ProtocolError::ShortFrame),
    })
}

fn write_stop_reason(w: &mut Vec<u8>, reason: &StopReason) {
    match reason {
        StopReason::Deadline { vtime } => {
            w.push(SR_DEADLINE);
            put_u64(w, vtime.0);
        }
        StopReason::Quiescent { vtime } => {
            w.push(SR_QUIESCENT);
            put_u64(w, vtime.0);
        }
        StopReason::Crash { vtime, info } => {
            w.push(SR_CRASH);
            put_u64(w, vtime.0);
            write_crash_info(w, info);
        }
        StopReason::Decision { vtime, id, ctx } => {
            w.push(SR_DECISION);
            put_u64(w, vtime.0);
            put_u64(w, id.0);
            put_bytes(w, ctx);
        }
        StopReason::SnapshotPoint { vtime } => {
            w.push(SR_SNAPSHOT_POINT);
            put_u64(w, vtime.0);
        }
        StopReason::Assertion { vtime, ev } => {
            w.push(SR_ASSERTION);
            put_u64(w, vtime.0);
            write_event_ref(w, ev);
        }
    }
}

fn read_stop_reason(r: &mut Reader) -> Result<StopReason, ProtocolError> {
    Ok(match r.u8()? {
        SR_DEADLINE => StopReason::Deadline {
            vtime: Moment(r.u64()?),
        },
        SR_QUIESCENT => StopReason::Quiescent {
            vtime: Moment(r.u64()?),
        },
        SR_CRASH => StopReason::Crash {
            vtime: Moment(r.u64()?),
            info: read_crash_info(r)?,
        },
        SR_DECISION => StopReason::Decision {
            vtime: Moment(r.u64()?),
            id: DecisionId(r.u64()?),
            ctx: r.bytes()?.to_vec(),
        },
        SR_SNAPSHOT_POINT => StopReason::SnapshotPoint {
            vtime: Moment(r.u64()?),
        },
        SR_ASSERTION => StopReason::Assertion {
            vtime: Moment(r.u64()?),
            ev: read_event_ref(r)?,
        },
        _ => return Err(ProtocolError::ShortFrame),
    })
}

fn write_crash_info(w: &mut Vec<u8>, info: &CrashInfo) {
    w.push(match info.kind {
        CrashKind::Panic => CK_PANIC,
        CrashKind::UnrecoverableFault => CK_UNRECOVERABLE_FAULT,
        CrashKind::Shutdown => CK_SHUTDOWN,
    });
    put_bytes(w, &info.detail);
}

fn read_crash_info(r: &mut Reader) -> Result<CrashInfo, ProtocolError> {
    let kind = match r.u8()? {
        CK_PANIC => CrashKind::Panic,
        CK_UNRECOVERABLE_FAULT => CrashKind::UnrecoverableFault,
        CK_SHUTDOWN => CrashKind::Shutdown,
        _ => return Err(ProtocolError::ShortFrame),
    };
    Ok(CrashInfo {
        kind,
        detail: r.bytes()?.to_vec(),
    })
}

fn write_event_ref(w: &mut Vec<u8>, ev: &EventRef) {
    put_u32(w, ev.id);
    put_bytes(w, &ev.data);
}

fn read_event_ref(r: &mut Reader) -> Result<EventRef, ProtocolError> {
    Ok(EventRef {
        id: r.u32()?,
        data: r.bytes()?.to_vec(),
    })
}

fn write_control_error(w: &mut Vec<u8>, err: &crate::error::ControlError) {
    use crate::error::ControlError as Ce;
    match err {
        Ce::UnknownSnapshot(SnapId(id)) => {
            w.push(CE_UNKNOWN_SNAPSHOT);
            put_u64(w, *id);
        }
        Ce::RestoreFailed => w.push(CE_RESTORE_FAILED),
        Ce::SnapshotWhileArmed => w.push(CE_SNAPSHOT_WHILE_ARMED),
        Ce::NotQuiescent => w.push(CE_NOT_QUIESCENT),
        Ce::SnapshotRefused { reason } => {
            w.push(CE_SNAPSHOT_REFUSED);
            put_bytes(w, reason.as_bytes());
        }
        Ce::BadEnvVersion(v) => {
            w.push(CE_BAD_ENV_VERSION);
            put_u16(w, *v);
        }
        Ce::MalformedEnvironment => w.push(CE_MALFORMED_ENVIRONMENT),
        Ce::ResolveWithoutDecision => w.push(CE_RESOLVE_WITHOUT_DECISION),
        Ce::MalformedAnswer => w.push(CE_MALFORMED_ANSWER),
        Ce::Unsupported => w.push(CE_UNSUPPORTED),
        Ce::PerturbOutOfRange { gpa, ram_len } => {
            w.push(CE_PERTURB_OUT_OF_RANGE);
            put_u64(w, *gpa);
            put_u64(w, *ram_len);
        }
        Ce::PerturbPastMoment { at, floor } => {
            w.push(CE_PERTURB_PAST_MOMENT);
            put_u64(w, *at);
            put_u64(w, *floor);
        }
        Ce::PerturbMomentTaken { at } => {
            w.push(CE_PERTURB_MOMENT_TAKEN);
            put_u64(w, *at);
        }
        Ce::ScheduleUnsatisfiable { moment, vtime } => {
            w.push(CE_SCHEDULE_UNSATISFIABLE);
            put_u64(w, *moment);
            put_u64(w, *vtime);
        }
        Ce::ReadOutOfRange { gpa, len, ram_len } => {
            w.push(CE_READ_OUT_OF_RANGE);
            put_u64(w, *gpa);
            put_u32(w, *len);
            put_u64(w, *ram_len);
        }
        Ce::ReadTooLarge { len, cap } => {
            w.push(CE_READ_TOO_LARGE);
            put_u32(w, *len);
            put_u32(w, *cap);
        }
        Ce::Tainted => w.push(CE_TAINTED),
        Ce::Protocol(pe) => {
            w.push(CE_PROTOCOL);
            w.push(match pe {
                ProtocolError::ShortFrame => PE_SHORT_FRAME,
                ProtocolError::BadMagic => PE_BAD_MAGIC,
                ProtocolError::BadVersion => PE_BAD_VERSION,
                ProtocolError::BadLength => PE_BAD_LENGTH,
            });
        }
    }
}

fn read_control_error(r: &mut Reader) -> Result<crate::error::ControlError, ProtocolError> {
    use crate::error::ControlError as Ce;
    Ok(match r.u8()? {
        CE_UNKNOWN_SNAPSHOT => Ce::UnknownSnapshot(SnapId(r.u64()?)),
        CE_RESTORE_FAILED => Ce::RestoreFailed,
        CE_SNAPSHOT_WHILE_ARMED => Ce::SnapshotWhileArmed,
        CE_NOT_QUIESCENT => Ce::NotQuiescent,
        CE_SNAPSHOT_REFUSED => Ce::SnapshotRefused {
            reason: std::str::from_utf8(r.bytes()?)
                .map_err(|_| ProtocolError::ShortFrame)?
                .to_owned(),
        },
        CE_BAD_ENV_VERSION => Ce::BadEnvVersion(r.u16()?),
        CE_MALFORMED_ENVIRONMENT => Ce::MalformedEnvironment,
        CE_RESOLVE_WITHOUT_DECISION => Ce::ResolveWithoutDecision,
        CE_MALFORMED_ANSWER => Ce::MalformedAnswer,
        CE_UNSUPPORTED => Ce::Unsupported,
        CE_PERTURB_OUT_OF_RANGE => Ce::PerturbOutOfRange {
            gpa: r.u64()?,
            ram_len: r.u64()?,
        },
        CE_PERTURB_PAST_MOMENT => Ce::PerturbPastMoment {
            at: r.u64()?,
            floor: r.u64()?,
        },
        CE_PERTURB_MOMENT_TAKEN => Ce::PerturbMomentTaken { at: r.u64()? },
        CE_SCHEDULE_UNSATISFIABLE => Ce::ScheduleUnsatisfiable {
            moment: r.u64()?,
            vtime: r.u64()?,
        },
        CE_READ_OUT_OF_RANGE => Ce::ReadOutOfRange {
            gpa: r.u64()?,
            len: r.u32()?,
            ram_len: r.u64()?,
        },
        CE_READ_TOO_LARGE => Ce::ReadTooLarge {
            len: r.u32()?,
            cap: r.u32()?,
        },
        CE_TAINTED => Ce::Tainted,
        CE_PROTOCOL => Ce::Protocol(match r.u8()? {
            PE_SHORT_FRAME => ProtocolError::ShortFrame,
            PE_BAD_MAGIC => ProtocolError::BadMagic,
            PE_BAD_VERSION => ProtocolError::BadVersion,
            PE_BAD_LENGTH => ProtocolError::BadLength,
            _ => return Err(ProtocolError::ShortFrame),
        }),
        _ => return Err(ProtocolError::ShortFrame),
    })
}

fn write_opt_vtime(w: &mut Vec<u8>, v: &Option<Moment>) {
    match v {
        Some(Moment(t)) => {
            w.push(PRESENT);
            put_u64(w, *t);
        }
        None => w.push(ABSENT),
    }
}

fn read_opt_vtime(r: &mut Reader) -> Result<Option<Moment>, ProtocolError> {
    Ok(match r.u8()? {
        ABSENT => None,
        PRESENT => Some(Moment(r.u64()?)),
        _ => return Err(ProtocolError::ShortFrame),
    })
}

fn write_opt_resolution(w: &mut Vec<u8>, resolution: &Option<Resolution>) {
    match resolution {
        Some(Resolution {
            vtime: Moment(vtime),
            service,
            id: DecisionId(id),
            answer: Answer(bytes),
        }) => {
            w.push(PRESENT);
            put_u64(w, *vtime);
            put_u16(w, *service);
            put_u64(w, *id);
            put_bytes(w, bytes);
        }
        None => w.push(ABSENT),
    }
}

fn read_opt_resolution(r: &mut Reader) -> Result<Option<Resolution>, ProtocolError> {
    Ok(match r.u8()? {
        ABSENT => None,
        PRESENT => Some(Resolution {
            vtime: Moment(r.u64()?),
            service: r.u16()?,
            id: DecisionId(r.u64()?),
            answer: Answer(r.bytes()?.to_vec()),
        }),
        _ => return Err(ProtocolError::ShortFrame),
    })
}

fn put_u16(w: &mut Vec<u8>, v: u16) {
    w.extend_from_slice(&v.to_le_bytes());
}

fn put_u32(w: &mut Vec<u8>, v: u32) {
    w.extend_from_slice(&v.to_le_bytes());
}

fn put_u64(w: &mut Vec<u8>, v: u64) {
    w.extend_from_slice(&v.to_le_bytes());
}

fn put_bytes(w: &mut Vec<u8>, b: &[u8]) {
    put_u32(w, u32::try_from(b.len()).unwrap_or(u32::MAX));
    w.extend_from_slice(b);
}

struct Reader<'a> {
    buf: &'a [u8],
    pos: usize,
}

impl<'a> Reader<'a> {
    fn new(buf: &'a [u8]) -> Self {
        Self { buf, pos: 0 }
    }

    fn finish(&self) -> Result<(), ProtocolError> {
        if self.pos == self.buf.len() {
            Ok(())
        } else {
            Err(ProtocolError::ShortFrame)
        }
    }

    fn take(&mut self, n: usize) -> Result<&'a [u8], ProtocolError> {
        let end = self.pos.checked_add(n).ok_or(ProtocolError::ShortFrame)?;
        let slice = self
            .buf
            .get(self.pos..end)
            .ok_or(ProtocolError::ShortFrame)?;
        self.pos = end;
        Ok(slice)
    }

    fn u8(&mut self) -> Result<u8, ProtocolError> {
        Ok(self.take(1)?[0])
    }

    fn u16(&mut self) -> Result<u16, ProtocolError> {
        let b = self.take(2)?;
        Ok(u16::from_le_bytes([b[0], b[1]]))
    }

    fn u32(&mut self) -> Result<u32, ProtocolError> {
        let b = self.take(4)?;
        Ok(u32::from_le_bytes([b[0], b[1], b[2], b[3]]))
    }

    fn u64(&mut self) -> Result<u64, ProtocolError> {
        let b = self.take(8)?;
        Ok(u64::from_le_bytes([
            b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7],
        ]))
    }

    fn bool(&mut self) -> Result<bool, ProtocolError> {
        match self.u8()? {
            0 => Ok(false),
            1 => Ok(true),
            _ => Err(ProtocolError::ShortFrame),
        }
    }

    fn bytes(&mut self) -> Result<&'a [u8], ProtocolError> {
        let len = self.u32()? as usize;
        self.take(len)
    }

    fn array32(&mut self) -> Result<[u8; 32], ProtocolError> {
        let b = self.take(32)?;
        let mut out = [0u8; 32];
        out.copy_from_slice(b);
        Ok(out)
    }
}

fn read_array32(r: &mut Reader) -> Result<[u8; 32], ProtocolError> {
    r.array32()
}

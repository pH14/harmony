<!-- SPDX-License-Identifier: AGPL-3.0-or-later -->

# uml

`uml` runs the User-mode Linux profile built by
`consonance/harmony-linux/uml` as an ordinary host process.

- `Profile::load` reads `profile.json`, checks the schema, the SECCOMP
  userspace mode, the host architecture and the empty host library list, then
  re-hashes the executable, config and rootfs and checks that the executable
  has no ELF interpreter. `VerifiedProfile::identity_sha256` hashes the parsed
  profile.
- `HostIdentity::current` reads the CPU model and feature flags from
  `/proc/cpuinfo`.
- `Launch` builds the UML command line: memory size, initramfs,
  `seccomp=on`, `time-travel=inf-cpu` starting at zero, console 0 on the
  output pipe, every other console and serial line on `null`, and a
  per-launch work directory for
  `TMPDIR` and `uml_dir`. The environment is cleared except for `TMPDIR` and
  `GLIBC_TUNABLES`. With a `Bridge`, it adds `harmony_fd=3` and the boot seed.
  It refuses extra kernel arguments that would replace these settings or
  attach host files, disks, consoles or network devices, because a
  `Recording` cannot carry those host resources.
- `Bridge` serves the guest's `/dev/harmony` requests on a `SOCK_SEQPACKET`
  pair from a thread of its own. It answers entropy from the seed, records
  each event with its virtual time, and fails the run if virtual time goes
  backwards. With a cut, it stops answering at that event, and the guest
  stops with `ExitReason::EventCut`.
- `Session` holds the bridge socket on the caller's thread instead. Its
  services answer the same SDK requests as the KVM backend through
  `environment::sdk`: entropy, events, assertion violations, standing-service
  questions answered by a `ServiceHandler`, payload pulls and coverage.
  `branch` installs a seed, handler and payloads. `run_until` runs to a
  virtual-time deadline, and `run_to_snapshot_point` runs to the guest's
  snapshot request. Each returns a `Stop`: an event count, deadline,
  snapshot point, violation, exhausted input, a closed bridge, or a guest
  exit. A guest whose virtual time
  stops moving for the progress limit fails with `SessionError::Hung`. The
  session pauses the guest before each answer, takes a `Checkpoint` there,
  restores one in place, or starts a fresh process that restores one at boot.
  The host owns the guest's physical memory file and an image file, both
  memfds, and maps them side by side. A `Checkpoint` is a snapshot in the
  session's `Checkpoints` page store plus the services state at the capture.
  A capture stores the image and the physical pages the kernel reports as
  written since the last capture or restore, as a delta on the previous
  checkpoint. A restore writes back only the pages that differ between the
  current state and the target. `Checkpoints::delta` lists a checkpoint's
  pages relative to a base for publishing, `Checkpoint::sidecar` encodes the
  services state, and `Checkpoints::import` rebuilds a checkpoint from both.
  `Checkpoint::digest` hashes a checkpoint's pages and services state.
  `Checkpoints::import` reproduces the published checkpoint only onto a base
  with the publisher's digest, because a base also holds per-process host
  values: the C library's stack canary and pointer guard, host process IDs
  and the work directory name. `state_hash` hashes the services state and the
  pending request. Sessions are Linux only.
- `Recording` names the profile, host, seed, memory, boot arguments, event
  count and event hash of a run. It refuses a run with a replaced initramfs,
  which it cannot replay. `Recording::check` refuses a different profile or
  host, and `Recording::launch` replays to the recorded cut.
- `Guest` starts the process in its own process group with a parent-death
  signal, merges stdout and stderr into one pipe, and keeps a bounded console
  tail. It stops the guest at a wall-clock limit or a console byte limit.
  Cleanup kills the process group, reaps it, kills any process still in the
  group or session, and removes the work directory. `Exit` reports any
  process that survived the sweep.

The parent-death signal follows the thread that spawned the guest, so a guest
must be started from a thread that outlives it.

`harmony-uml-qualify` is the qualification binary described in
`consonance/harmony-linux/uml/README.md`.

The crate's `unsafe` blocks are host system calls: sequenced-packet sockets,
descriptor passing, `memfd_create`, fixed mappings and process-group signals.
Miri cannot run those calls, so the tests that make them are ignored under
Miri and the qualification suites exercise them on Linux; Miri runs the
crate's other library tests.

`Checkpoints::full` exports all nonzero pages relative to the store's zero root.
`import_full` restores that complete state over a fresh launch, removing stale
pages as well as restoring changed ones. Ordinary cache deltas still use their
explicit setup checkpoint. This distinction makes durable investigation roots
portable across launches without treating volatile host-private boot memory as
an interchangeable baseline. Profile and launch identity checks belong to the
client that persists the root.

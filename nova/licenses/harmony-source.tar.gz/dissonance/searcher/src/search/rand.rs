// SPDX-License-Identifier: AGPL-3.0-or-later

use std::num::{NonZeroU64, NonZeroUsize};

pub(crate) fn splitmix64(state: &mut u64) -> u64 {
    *state = state.wrapping_add(0x9e37_79b9_7f4a_7c15);
    let mut z = *state;
    z = (z ^ (z >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
    z = (z ^ (z >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
    z ^ (z >> 31)
}

#[derive(Clone, Copy, Debug, serde::Deserialize, serde::Serialize)]
pub struct RomuDuoJrRand {
    x_state: u64,
    y_state: u64,
}

impl RomuDuoJrRand {
    #[must_use]
    pub fn with_seed(mut seed: u64) -> Self {
        Self {
            x_state: splitmix64(&mut seed),
            y_state: splitmix64(&mut seed),
        }
    }

    #[expect(clippy::unreadable_literal)]
    pub fn next_u64(&mut self) -> u64 {
        let xp = self.x_state;
        self.x_state = 15241094284759029579_u64.wrapping_mul(self.y_state);
        self.y_state = self.y_state.wrapping_sub(xp).rotate_left(27);
        xp
    }

    pub fn below(&mut self, upper_bound_excl: NonZeroUsize) -> usize {
        self.below_u64(NonZeroU64::new(upper_bound_excl.get() as u64).unwrap()) as usize
    }

    pub fn below_u64(&mut self, upper_bound_excl: NonZeroU64) -> u64 {
        let mul = u128::from(self.next_u64()) * u128::from(upper_bound_excl.get());
        (mul >> 64) as u64
    }
}

#[cfg(test)]
mod tests {
    use std::num::NonZeroUsize;

    use super::RomuDuoJrRand;

    #[test]
    fn sequence_matches_the_recorded_generator() {
        let mut rand = RomuDuoJrRand::with_seed(0x5eed_0903);
        let first: Vec<u64> = (0..4).map(|_| rand.next_u64()).collect();
        let mut again = RomuDuoJrRand::with_seed(0x5eed_0903);
        let bound = NonZeroUsize::new(97).expect("nonzero bound");
        let bounded: Vec<usize> = (0..4).map(|_| again.below(bound)).collect();
        assert_eq!(first, REFERENCE_NEXT);
        assert_eq!(bounded, REFERENCE_BELOW_97);
    }

    #[test]
    fn wide_bounds_preserve_the_native_sequence() {
        let bounds = [1, 97, 1_u64 << 48, u64::MAX];
        for bound in bounds {
            let mut rand = RomuDuoJrRand::with_seed(1);
            let mut reference = rand;
            for _ in 0..1000 {
                let expected =
                    ((u128::from(reference.next_u64()) * u128::from(bound)) >> 64) as u64;
                assert_eq!(
                    rand.below_u64(std::num::NonZeroU64::new(bound).unwrap()),
                    expected
                );
                assert!(expected < bound);
            }
        }
    }

    const REFERENCE_NEXT: [u64; 4] = [
        12213431933298621606,
        3036258437508424578,
        10882873578750246974,
        3543664003024287084,
    ];
    const REFERENCE_BELOW_97: [usize; 4] = [64, 15, 57, 18];
}

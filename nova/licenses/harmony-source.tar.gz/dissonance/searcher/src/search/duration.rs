// SPDX-License-Identifier: AGPL-3.0-or-later

use std::{
    collections::{BTreeMap, VecDeque},
    marker::PhantomData,
    num::{NonZeroU64, NonZeroUsize},
};

use serde::{Deserialize, Serialize};

use crate::search::rand::RomuDuoJrRand;

pub const DURATION_POLICY_IDENTIFIER: &str = "recent_useful_work_log_duration_v2";
pub const DURATION_POLICIES_IDENTIFIER: &str = "recent_useful_work_context_log_duration_v2";
pub const MAX_DURATION_CONTEXTS: usize = 256;
const RECENT_OBSERVATIONS: usize = 128;
const CONTEXT_NODE_OVERHEAD: usize = 128;

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
struct Observation {
    duration: NonZeroU64,
    useful: bool,
    execution_cost: NonZeroU64,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct DurationCheckpoint {
    policy: String,
    #[serde(deserialize_with = "deserialize_recent")]
    recent: Vec<Observation>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct DurationRequest<C> {
    pub context: C,
    pub max_duration: NonZeroU64,
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct DurationDraw<C> {
    pub context: C,
    pub max_duration: NonZeroU64,
    pub duration: NonZeroU64,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(bound(serialize = "C: Serialize", deserialize = "C: Deserialize<'de>"))]
pub struct DurationContextCheckpoint<C> {
    pub context: C,
    pub history: DurationCheckpoint,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(bound(serialize = "C: Serialize", deserialize = "C: Deserialize<'de>"))]
pub struct DurationPoliciesCheckpoint<C> {
    pub policy: String,
    #[serde(deserialize_with = "deserialize_contexts")]
    pub contexts: Vec<DurationContextCheckpoint<C>>,
}

fn deserialize_contexts<'de, D, C>(
    deserializer: D,
) -> Result<Vec<DurationContextCheckpoint<C>>, D::Error>
where
    D: serde::Deserializer<'de>,
    C: Deserialize<'de>,
{
    struct ContextVisitor<C>(PhantomData<C>);

    impl<'de, C> serde::de::Visitor<'de> for ContextVisitor<C>
    where
        C: Deserialize<'de>,
    {
        type Value = Vec<DurationContextCheckpoint<C>>;

        fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            write!(
                formatter,
                "at most {MAX_DURATION_CONTEXTS} duration contexts"
            )
        }

        fn visit_seq<S>(self, mut sequence: S) -> Result<Self::Value, S::Error>
        where
            S: serde::de::SeqAccess<'de>,
        {
            if sequence
                .size_hint()
                .is_some_and(|size| size > MAX_DURATION_CONTEXTS)
            {
                return Err(serde::de::Error::custom(
                    "duration context history exceeds its capacity",
                ));
            }
            let mut contexts = Vec::with_capacity(MAX_DURATION_CONTEXTS);
            while let Some(context) = sequence.next_element()? {
                if contexts.len() == MAX_DURATION_CONTEXTS {
                    return Err(serde::de::Error::custom(
                        "duration context history exceeds its capacity",
                    ));
                }
                contexts.push(context);
            }
            Ok(contexts)
        }
    }

    deserializer.deserialize_seq(ContextVisitor(PhantomData))
}

fn deserialize_recent<'de, D>(deserializer: D) -> Result<Vec<Observation>, D::Error>
where
    D: serde::Deserializer<'de>,
{
    struct RecentVisitor;

    impl<'de> serde::de::Visitor<'de> for RecentVisitor {
        type Value = Vec<Observation>;

        fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            write!(
                formatter,
                "at most {RECENT_OBSERVATIONS} duration observations"
            )
        }

        fn visit_seq<S>(self, mut sequence: S) -> Result<Self::Value, S::Error>
        where
            S: serde::de::SeqAccess<'de>,
        {
            if sequence
                .size_hint()
                .is_some_and(|size| size > RECENT_OBSERVATIONS)
            {
                return Err(serde::de::Error::custom(
                    "duration history exceeds its capacity",
                ));
            }
            let mut recent = Vec::with_capacity(RECENT_OBSERVATIONS);
            while let Some(observation) = sequence.next_element()? {
                if recent.len() == RECENT_OBSERVATIONS {
                    return Err(serde::de::Error::custom(
                        "duration history exceeds its capacity",
                    ));
                }
                recent.push(observation);
            }
            Ok(recent)
        }
    }

    deserializer.deserialize_seq(RecentVisitor)
}

#[derive(Debug, Eq, PartialEq)]
pub struct DurationPolicy {
    recent: VecDeque<Observation>,
}

impl Clone for DurationPolicy {
    fn clone(&self) -> Self {
        let mut policy = Self::new();
        policy.recent.extend(self.recent.iter().copied());
        policy
    }
}

impl Default for DurationPolicy {
    fn default() -> Self {
        Self::new()
    }
}

impl DurationPolicy {
    #[must_use]
    pub fn new() -> Self {
        Self {
            recent: VecDeque::with_capacity(RECENT_OBSERVATIONS),
        }
    }

    #[must_use]
    pub fn draw(&self, rand: &mut RomuDuoJrRand, max_duration: NonZeroU64) -> u64 {
        Self::draw_from(&self.recent, rand, max_duration)
    }

    #[must_use]
    pub fn draw_without_history(rand: &mut RomuDuoJrRand, max_duration: NonZeroU64) -> u64 {
        Self::draw_from(&VecDeque::new(), rand, max_duration)
    }

    fn draw_from(
        recent: &VecDeque<Observation>,
        rand: &mut RomuDuoJrRand,
        max_duration: NonZeroU64,
    ) -> u64 {
        let scales = (u64::BITS - max_duration.get().leading_zeros()) as usize;
        let scale_bound = NonZeroUsize::new(scales).expect("positive duration has a scale");
        if rand.next_u64() & 1 == 0 {
            return 1_u64 << rand.below(scale_bound);
        }
        let mut successes = [0_u128; u64::BITS as usize];
        let mut costs = [0_u128; u64::BITS as usize];
        for observation in recent {
            let scale = observation.duration.get().trailing_zeros() as usize;
            successes[scale] += u128::from(observation.useful);
            costs[scale] += u128::from(observation.execution_cost.get());
        }
        let mut best = [0_usize; u64::BITS as usize];
        let mut count = 0;
        for scale in 0..scales {
            if successes[scale] == 0 {
                continue;
            }
            let order = if count == 0 {
                std::cmp::Ordering::Greater
            } else {
                (successes[scale] * costs[best[0]]).cmp(&(successes[best[0]] * costs[scale]))
            };
            if order.is_gt() {
                count = 0;
            }
            if !order.is_lt() {
                best[count] = scale;
                count += 1;
            }
        }
        let scale = match NonZeroUsize::new(count) {
            Some(count) => best[rand.below(count)],
            None => rand.below(scale_bound),
        };
        1_u64 << scale
    }

    pub fn observe(
        &mut self,
        duration: NonZeroU64,
        useful: bool,
        execution_cost: NonZeroU64,
    ) -> Result<(), &'static str> {
        if !duration.get().is_power_of_two() {
            return Err("duration observation is not a logarithmic choice");
        }
        if self.recent.len() == RECENT_OBSERVATIONS {
            self.recent.pop_front();
        }
        self.recent.push_back(Observation {
            duration,
            useful,
            execution_cost,
        });
        Ok(())
    }

    #[must_use]
    pub fn checkpoint(&self) -> DurationCheckpoint {
        DurationCheckpoint {
            policy: DURATION_POLICY_IDENTIFIER.to_owned(),
            recent: self.recent.iter().copied().collect(),
        }
    }

    pub fn from_checkpoint(checkpoint: DurationCheckpoint) -> Result<Self, &'static str> {
        if checkpoint.policy != DURATION_POLICY_IDENTIFIER {
            return Err("unrecognized duration policy");
        }
        if checkpoint.recent.len() > RECENT_OBSERVATIONS {
            return Err("duration history exceeds its capacity");
        }
        if checkpoint
            .recent
            .iter()
            .any(|entry| !entry.duration.get().is_power_of_two())
        {
            return Err("duration history contains a nonlogarithmic choice");
        }
        let mut policy = Self::new();
        policy.recent.extend(checkpoint.recent);
        Ok(policy)
    }

    #[must_use]
    pub fn memory_bytes(&self) -> usize {
        std::mem::size_of::<Self>().saturating_add(
            self.recent
                .capacity()
                .saturating_mul(std::mem::size_of::<Observation>()),
        )
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DurationPolicies<C> {
    policies: BTreeMap<C, DurationPolicy>,
    order: VecDeque<C>,
}

impl<C: Copy + Ord> Default for DurationPolicies<C> {
    fn default() -> Self {
        Self::new()
    }
}

impl<C: Copy + Ord> DurationPolicies<C> {
    #[must_use]
    pub fn new() -> Self {
        Self {
            policies: BTreeMap::new(),
            order: VecDeque::with_capacity(MAX_DURATION_CONTEXTS),
        }
    }

    #[must_use]
    pub fn draw(
        &self,
        context: C,
        rand: &mut RomuDuoJrRand,
        max_duration: NonZeroU64,
    ) -> DurationDraw<C> {
        let duration = match self.policies.get(&context) {
            Some(policy) => policy.draw(rand, max_duration),
            None => DurationPolicy::draw_without_history(rand, max_duration),
        };
        DurationDraw {
            context,
            max_duration,
            duration: NonZeroU64::new(duration).expect("duration policy draws a positive duration"),
        }
    }

    pub fn observe(
        &mut self,
        context: C,
        duration: NonZeroU64,
        useful: bool,
        execution_work: NonZeroU64,
    ) -> Result<(), &'static str> {
        if !duration.get().is_power_of_two() {
            return Err("duration observation is not a logarithmic choice");
        }
        if let Some(policy) = self.policies.get_mut(&context) {
            return policy.observe(duration, useful, execution_work);
        }
        if self.order.len() == MAX_DURATION_CONTEXTS {
            let old = self
                .order
                .pop_front()
                .ok_or("duration context order is inconsistent")?;
            self.policies.remove(&old);
        }
        self.order.push_back(context);
        self.policies
            .entry(context)
            .or_default()
            .observe(duration, useful, execution_work)
    }

    #[must_use]
    pub fn context_checkpoint(&self, context: C) -> Option<DurationCheckpoint> {
        self.policies.get(&context).map(DurationPolicy::checkpoint)
    }

    #[must_use]
    pub(crate) fn eviction_checkpoint(&self, context: C) -> Option<DurationContextCheckpoint<C>> {
        if self.policies.contains_key(&context) || self.order.len() < MAX_DURATION_CONTEXTS {
            return None;
        }
        self.order.front().and_then(|old| {
            self.policies
                .get(old)
                .map(|history| DurationContextCheckpoint {
                    context: *old,
                    history: history.checkpoint(),
                })
        })
    }

    #[must_use]
    pub fn checkpoint(&self) -> DurationPoliciesCheckpoint<C> {
        DurationPoliciesCheckpoint {
            policy: DURATION_POLICIES_IDENTIFIER.to_owned(),
            contexts: self
                .order
                .iter()
                .filter_map(|context| {
                    self.policies
                        .get(context)
                        .map(|policy| DurationContextCheckpoint {
                            context: *context,
                            history: policy.checkpoint(),
                        })
                })
                .collect(),
        }
    }

    pub fn from_checkpoint(
        checkpoint: DurationPoliciesCheckpoint<C>,
    ) -> Result<Self, &'static str> {
        if checkpoint.policy != DURATION_POLICIES_IDENTIFIER {
            return Err("unrecognized duration policies");
        }
        if checkpoint.contexts.len() > MAX_DURATION_CONTEXTS {
            return Err("duration context history exceeds its capacity");
        }
        let mut policies = Self::new();
        for entry in checkpoint.contexts {
            if policies.policies.contains_key(&entry.context) {
                return Err("duration checkpoint repeats a context");
            }
            let policy = DurationPolicy::from_checkpoint(entry.history)?;
            policies.order.push_back(entry.context);
            policies.policies.insert(entry.context, policy);
        }
        Ok(policies)
    }

    #[must_use]
    pub fn memory_bytes(&self) -> usize {
        std::mem::size_of::<Self>()
            .saturating_add(
                self.order
                    .capacity()
                    .saturating_mul(std::mem::size_of::<C>()),
            )
            .saturating_add(
                self.policies
                    .values()
                    .map(|policy| policy.memory_bytes().saturating_add(CONTEXT_NODE_OVERHEAD))
                    .sum::<usize>(),
            )
    }

    #[must_use]
    pub fn memory_reserve_bytes() -> usize {
        std::mem::size_of::<Self>()
            .saturating_add(MAX_DURATION_CONTEXTS.saturating_mul(std::mem::size_of::<C>()))
            .saturating_add(
                MAX_DURATION_CONTEXTS.saturating_mul(
                    std::mem::size_of::<DurationPolicy>()
                        .saturating_add(
                            RECENT_OBSERVATIONS.saturating_mul(std::mem::size_of::<Observation>()),
                        )
                        .saturating_add(CONTEXT_NODE_OVERHEAD),
                ),
            )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn positive(value: u64) -> NonZeroU64 {
        NonZeroU64::new(value).expect("positive")
    }

    #[test]
    fn observing_a_retained_context_searches_the_map_once() {
        use std::{
            cmp::Ordering,
            sync::atomic::{AtomicUsize, Ordering as AtomicOrdering},
        };

        static COMPARISONS: AtomicUsize = AtomicUsize::new(0);

        #[derive(Clone, Copy, Eq, PartialEq)]
        struct Context(u16);

        impl Ord for Context {
            fn cmp(&self, other: &Self) -> Ordering {
                COMPARISONS.fetch_add(1, AtomicOrdering::Relaxed);
                self.0.cmp(&other.0)
            }
        }

        impl PartialOrd for Context {
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                Some(self.cmp(other))
            }
        }

        let mut policies = DurationPolicies::new();
        for context in 0..MAX_DURATION_CONTEXTS as u16 {
            policies
                .observe(Context(context), positive(1), true, positive(1))
                .unwrap();
        }
        for context in [0, 127, 255] {
            COMPARISONS.store(0, AtomicOrdering::Relaxed);
            assert!(policies.policies.get_mut(&Context(context)).is_some());
            let once = COMPARISONS.load(AtomicOrdering::Relaxed);
            assert!(once > 0);
            COMPARISONS.store(0, AtomicOrdering::Relaxed);
            policies
                .observe(Context(context), positive(2), false, positive(3))
                .unwrap();
            assert_eq!(COMPARISONS.load(AtomicOrdering::Relaxed), once);
        }
    }

    #[test]
    fn context_updates_match_the_original_lookup_path() {
        fn original_observe(
            policies: &mut DurationPolicies<u16>,
            context: u16,
            duration: NonZeroU64,
            useful: bool,
            work: NonZeroU64,
        ) -> Result<(), &'static str> {
            if !duration.get().is_power_of_two() {
                return Err("duration observation is not a logarithmic choice");
            }
            if !policies.policies.contains_key(&context) {
                if policies.order.len() == MAX_DURATION_CONTEXTS {
                    let old = policies
                        .order
                        .pop_front()
                        .ok_or("duration context order is inconsistent")?;
                    policies.policies.remove(&old);
                }
                policies.order.push_back(context);
                policies.policies.insert(context, DurationPolicy::new());
            }
            policies
                .policies
                .get_mut(&context)
                .ok_or("duration context was not retained")?
                .observe(duration, useful, work)
        }

        let mut actual = DurationPolicies::<u16>::new();
        let mut expected = DurationPolicies::<u16>::new();
        let mut actual_rand = RomuDuoJrRand::with_seed(51);
        let mut expected_rand = actual_rand;
        for round in 0..1600_u16 {
            let context = if round < 512 {
                round % 256
            } else {
                round.wrapping_mul(37) % 384
            };
            let duration = positive(if round % 113 == 0 {
                3
            } else {
                1_u64 << (round % 64)
            });
            let useful = round % 2 == 0;
            let work = positive(u64::MAX - u64::from(round));
            assert_eq!(
                actual.observe(context, duration, useful, work),
                original_observe(&mut expected, context, duration, useful, work)
            );
            assert_eq!(actual, expected);
            assert_eq!(actual.memory_bytes(), expected.memory_bytes());
            for context in [context, 511] {
                assert_eq!(
                    actual.draw(context, &mut actual_rand, positive(u64::MAX)),
                    expected.draw(context, &mut expected_rand, positive(u64::MAX))
                );
            }
            assert_eq!(actual_rand.next_u64(), expected_rand.next_u64());
            if round % 64 == 0 {
                assert_eq!(
                    postcard::to_allocvec(&actual.checkpoint()).unwrap(),
                    postcard::to_allocvec(&expected.checkpoint()).unwrap()
                );
                actual = DurationPolicies::from_checkpoint(actual.checkpoint()).unwrap();
                expected = DurationPolicies::from_checkpoint(expected.checkpoint()).unwrap();
            }
        }
    }

    #[test]
    fn feasible_draws_include_the_full_integer_range() {
        let policy = DurationPolicy::new();
        let mut rand = RomuDuoJrRand::with_seed(17);
        let mut seen = 0_u64;
        for _ in 0..16_384 {
            let duration = policy.draw(&mut rand, positive(u64::MAX));
            assert!(duration.is_power_of_two());
            seen |= duration;
        }
        assert_eq!(seen, u64::MAX);
        for maximum in [1, 3, 17, u64::MAX] {
            for _ in 0..128 {
                assert!(policy.draw(&mut rand, positive(maximum)) <= maximum);
            }
        }
    }

    #[test]
    fn restored_histories_stay_within_the_memory_reserve() {
        let mut live = DurationPolicies::<u16>::new();
        for context in 0..MAX_DURATION_CONTEXTS as u16 {
            for _ in 0..=RECENT_OBSERVATIONS / 2 {
                live.observe(context, positive(1), true, positive(1))
                    .expect("observe");
            }
        }
        let mut restored =
            DurationPolicies::from_checkpoint(live.checkpoint()).expect("restore checkpoint");
        for context in 0..MAX_DURATION_CONTEXTS as u16 {
            for _ in 0..RECENT_OBSERVATIONS {
                restored
                    .observe(context, positive(2), false, positive(1))
                    .expect("observe");
            }
        }
        assert!(restored.memory_bytes() <= DurationPolicies::<u16>::memory_reserve_bytes());
    }

    #[test]
    fn history_is_bounded_and_extreme_costs_do_not_overflow() {
        let mut policy = DurationPolicy::new();
        for _ in 0..1_024 {
            policy
                .observe(positive(1), true, positive(u64::MAX))
                .expect("observe");
            policy
                .observe(positive(2), true, positive(u64::MAX))
                .expect("observe");
        }
        assert_eq!(policy.checkpoint().recent.len(), RECENT_OBSERVATIONS);
        let mut rand = RomuDuoJrRand::with_seed(9);
        for _ in 0..128 {
            assert!(policy.draw(&mut rand, positive(2)) <= 2);
        }
    }

    #[test]
    fn corrupt_checkpoints_are_rejected() {
        let mut checkpoint = DurationPolicy::new().checkpoint();
        checkpoint.policy = "unknown".to_owned();
        assert!(DurationPolicy::from_checkpoint(checkpoint).is_err());
        let entry = Observation {
            duration: positive(1),
            useful: true,
            execution_cost: positive(1),
        };
        let mut checkpoint = DurationPolicy::new().checkpoint();
        checkpoint.recent = vec![entry; RECENT_OBSERVATIONS + 1];
        assert!(DurationPolicy::from_checkpoint(checkpoint).is_err());
        let mut checkpoint = DurationPolicy::new().checkpoint();
        checkpoint.recent.push(Observation {
            duration: positive(3),
            ..entry
        });
        assert!(DurationPolicy::from_checkpoint(checkpoint).is_err());
    }

    #[test]
    fn invalid_observation_does_not_change_learning_state() {
        let mut policy = DurationPolicy::new();
        policy
            .observe(positive(2), true, positive(7))
            .expect("observe");
        let before = policy.checkpoint();
        assert!(policy.observe(positive(3), true, positive(1)).is_err());
        assert_eq!(policy.checkpoint(), before);
    }

    #[test]
    fn history_limit_is_enforced_during_checkpoint_decoding() {
        let mut checkpoint = DurationPolicy::new().checkpoint();
        checkpoint.recent = vec![
            Observation {
                duration: positive(1),
                useful: false,
                execution_cost: positive(1),
            };
            RECENT_OBSERVATIONS + 1
        ];
        let json = serde_json::to_vec(&checkpoint).expect("encode");
        assert!(serde_json::from_slice::<DurationCheckpoint>(&json).is_err());
        let postcard = postcard::to_stdvec(&checkpoint).expect("encode");
        assert!(postcard::from_bytes::<DurationCheckpoint>(&postcard).is_err());
        checkpoint.recent.pop();
        let postcard = postcard::to_stdvec(&checkpoint).expect("encode");
        assert_eq!(
            postcard::from_bytes::<DurationCheckpoint>(&postcard).expect("decode"),
            checkpoint
        );
    }

    #[test]
    fn preference_uses_execution_cost_instead_of_the_duration_label() {
        let mut policy = DurationPolicy::new();
        for _ in 0..32 {
            policy
                .observe(positive(1), true, positive(100))
                .expect("observe");
            policy
                .observe(positive(2), true, positive(1))
                .expect("observe");
        }
        let mut rand = RomuDuoJrRand::with_seed(91);
        let preferred = (0..1_024)
            .filter(|_| policy.draw(&mut rand, positive(2)) == 2)
            .count();
        assert!(preferred > 640);
        for _ in 0..128 {
            assert_eq!(policy.draw(&mut rand, positive(1)), 1);
        }
    }

    #[test]
    fn a_cloned_history_stays_within_its_memory_reserve_once_refilled() {
        let mut source = DurationPolicy::new();
        for _ in 0..(RECENT_OBSERVATIONS - 1) {
            source
                .observe(positive(1), true, positive(1))
                .expect("observe");
        }
        let mut policy = source.clone();
        for _ in 0..RECENT_OBSERVATIONS {
            policy
                .observe(positive(2), true, positive(1))
                .expect("observe");
        }
        let reserve = std::mem::size_of::<DurationPolicy>()
            + RECENT_OBSERVATIONS * std::mem::size_of::<Observation>();
        assert!(policy.memory_bytes() <= reserve);
    }

    #[test]
    fn a_partially_filled_checkpoint_stays_within_its_memory_reserve_once_refilled() {
        let mut source = DurationPolicy::new();
        for _ in 0..(RECENT_OBSERVATIONS - 1) {
            source
                .observe(positive(1), true, positive(1))
                .expect("observe");
        }
        let contexts = (0..u32::try_from(MAX_DURATION_CONTEXTS).expect("context count"))
            .map(|context| DurationContextCheckpoint {
                context,
                history: source.checkpoint(),
            })
            .collect();
        let mut policies = DurationPolicies::from_checkpoint(DurationPoliciesCheckpoint {
            policy: DURATION_POLICIES_IDENTIFIER.to_owned(),
            contexts,
        })
        .expect("restore");
        for context in 0..u32::try_from(MAX_DURATION_CONTEXTS).expect("context count") {
            for _ in 0..RECENT_OBSERVATIONS {
                policies
                    .observe(context, positive(2), true, positive(1))
                    .expect("observe");
            }
        }
        assert_eq!(policies.policies.len(), MAX_DURATION_CONTEXTS);
        assert!(policies.memory_bytes() <= DurationPolicies::<u32>::memory_reserve_bytes());
    }

    #[test]
    fn a_saturated_context_history_stays_within_its_memory_reserve() {
        let mut policies = DurationPolicies::<u32>::new();
        for context in 0..u32::try_from(MAX_DURATION_CONTEXTS * 2).expect("context count") {
            for _ in 0..(RECENT_OBSERVATIONS * 2) {
                policies
                    .observe(context, positive(1), true, positive(1))
                    .expect("observe");
                policies
                    .observe(context, positive(2), false, positive(1))
                    .expect("observe");
            }
        }
        assert_eq!(policies.policies.len(), MAX_DURATION_CONTEXTS);
        assert!(policies.memory_bytes() <= DurationPolicies::<u32>::memory_reserve_bytes());
    }
}

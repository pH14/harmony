// SPDX-License-Identifier: AGPL-3.0-or-later

use std::{
    collections::{BTreeMap, BTreeSet, VecDeque},
    error::Error,
    fmt::Debug,
    io::Write,
    num::{NonZeroU64, NonZeroUsize},
    path::PathBuf,
    sync::{Arc, Mutex, mpsc},
    time::{Duration, Instant},
};

use serde::{Deserialize, Serialize, de::DeserializeOwned};
use sha2::{Digest, Sha256};

use crate::search::archive::{
    Archive, ArchiveCandidate, ArchiveEntryReport, ArchiveKey, CampaignSpliceTail,
    ContinuationAccounting, Edge, Input, Position, ProgressPoint, RetentionPolicy,
    SELECTOR_IDENTIFIER, SelectorAccounting, SelectorDraw, SelectorPath,
    retention_policy_from_identifier, retention_policy_identifier,
};
use crate::search::checkpoint::{
    CheckpointHeader, CheckpointPlan, CheckpointReader, CheckpointWriter, SEARCH_CHECKPOINT_FORMAT,
};
use crate::search::continuation::CONTINUATION_IDENTIFIER;
use crate::search::draw::{
    DrawMixture, EnergyStrategy, MixtureDraw, MixtureEnergy, SUFFIX_DOUBLING_LIMIT,
    draw_mixture_from_identifier, draw_mixture_identifier, draw_suffix, energy_strategy,
};
use crate::search::draw_tables::{
    DEFAULT_DRAW_TABLE_PARAMETERS, DRAW_TABLE_POLICY_FIELD, DrawTableHeader, DrawTables,
    DrawVersionSchedule, biased_step, draw_table_from_identifier, draw_table_identifier,
};
use crate::search::duration::{
    DurationCheckpoint, DurationContextCheckpoint, DurationDraw, DurationPolicies, DurationPolicy,
    DurationRequest,
};
use crate::search::empirical_steps::{EmpiricalStepCheckpoint, EmpiricalStepParameters};

pub const LONGEST_SPLICE_TAIL: usize = 128;
use crate::search::parallel::with_worker_pool;
use crate::search::rand::RomuDuoJrRand;
use crate::search::telemetry::{
    CampaignTelemetry, HostTimes, IdleClock, IdleReason, TargetCounters, nanos_since, now,
    thread_schedstat,
};

pub type CampaignOutcome<G> = (
    CampaignModeReport<<G as CampaignTypes>::Action, <G as CampaignTypes>::ArchiveReport>,
    SnapshotCheckpoint<<G as CampaignTypes>::Snapshot>,
);

pub type InitialDrawState<G> = (
    DrawTables<<G as CampaignTypes>::Action>,
    Option<DrawTableHeader>,
);

pub const CAMPAIGN_SCHEMA_VERSION: u32 = 10;

pub const CAMPAIGN_SCHEDULE_IDENTITY: &str = "jobs are selected into a deterministic sliding \
     window; each job's planned finish is the planned finish of the admission before its \
     selection plus its planned action cost, and jobs are admitted in planned-finish order; \
     physical workers run queued jobs in that order, but host completion order cannot reach \
     campaign state; the same seed, configuration, origin, and workload bytes produce the same \
     recorded stream";

const CAMPAIGN_PROGRESS_POLICY: &str = "mechanical_watermark_bounded_1024_v2";
const ORIGIN_GENESIS: &str = "genesis";
const ORIGIN_SNAPSHOT_ROOT: &str = "snapshot_root";
const ORIGIN_ARCHIVE: &str = "archive";
const ORIGIN_SEARCH_CHECKPOINT: &str = "search_checkpoint";

#[derive(Clone, Debug, Default)]
pub struct CampaignExecutionOptions {
    pub work_budget: Option<u64>,
    pub checkpoints: Option<CheckpointPlan>,
    pub placement: Option<ThreadPlacement>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum PlacedThread {
    Coordinator,
    Worker(u32),
}

type PlaceThread = dyn Fn(PlacedThread) -> Result<(), String> + Send + Sync;

#[derive(Clone)]
pub struct ThreadPlacement(Arc<PlaceThread>);

impl ThreadPlacement {
    pub fn new(place: impl Fn(PlacedThread) -> Result<(), String> + Send + Sync + 'static) -> Self {
        Self(Arc::new(place))
    }

    fn place(placement: Option<&Self>, thread: PlacedThread) -> Result<(), String> {
        placement.map_or(Ok(()), |placement| (placement.0)(thread))
    }
}

impl Debug for ThreadPlacement {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.write_str("ThreadPlacement")
    }
}

#[must_use]
pub const fn default_window(workers: u32) -> usize {
    workers as usize
}

const SCHEDULE_POLICY_WINDOW_SUFFIX: &str = "_v5";
const SCHEDULE_POLICY_WINDOW_PREFIX: &str = "planned_finish_window_";
const DEFAULT_MIXTURE_WEIGHT: u8 = 128;

fn schedule_policy_identifier(window: usize) -> String {
    format!("{SCHEDULE_POLICY_WINDOW_PREFIX}{window}{SCHEDULE_POLICY_WINDOW_SUFFIX}")
}

fn schedule_policy_window(policy: &str) -> Option<usize> {
    let window = policy.strip_prefix(SCHEDULE_POLICY_WINDOW_PREFIX)?;
    let window = window.strip_suffix(SCHEDULE_POLICY_WINDOW_SUFFIX)?;
    window.parse().ok().filter(|window| *window >= 1)
}

fn schedule_policy_is_supported(policy: &str) -> bool {
    schedule_policy_window(policy).is_some()
}

const CONSECUTIVE_SKIP_LIMIT: u64 = 1_024;

const CURVE_INTERVAL: u64 = 100;

const PROGRESS_CHECKPOINT_INTERVAL: u64 = 100;

const MAX_PROGRESS_CURVE_POINTS: usize = 1_024;

fn compact_progress_curve<M, P>(
    curve: &mut Vec<ProgressPoint<M, P>>,
    current_interval: u64,
) -> u64 {
    if curve.len() < MAX_PROGRESS_CURVE_POINTS {
        return current_interval;
    }
    let next_interval = current_interval.saturating_mul(2);
    if next_interval == current_interval {
        return current_interval;
    }
    curve.retain(|point| point.executions.is_multiple_of(next_interval));
    next_interval
}

fn progress_line_interval(executions: u64) -> u64 {
    let span = PROGRESS_CHECKPOINT_INTERVAL.saturating_mul(MAX_PROGRESS_CURVE_POINTS as u64);
    let doublings = (executions / span).checked_ilog2().unwrap_or(0);
    PROGRESS_CHECKPOINT_INTERVAL.saturating_mul(1 << doublings)
}

fn progress_checkpoint_due(executions: u64) -> bool {
    executions > 0
        && (executions == 1 || executions.is_multiple_of(progress_line_interval(executions)))
}

fn full_selector_report_due(executions: u64) -> bool {
    executions > 0
        && executions.is_multiple_of(
            progress_line_interval(executions).saturating_mul(MAX_PROGRESS_CURVE_POINTS as u64),
        )
}

pub const RESUME_IDENTIFIER: &str = "whole_tree";

pub const SNAPSHOT_ROOT_RESUME_IDENTIFIER: &str = "snapshot_root";

pub type WorkloadPolicies = BTreeMap<String, String>;

pub trait CampaignTypes: Sync {
    type Target;
    type Action: Copy + Ord + Debug + Eq + Send + Sync + Serialize + DeserializeOwned;
    type Key: ArchiveKey + Debug + Eq + Send + Sync;
    type Milestones: Copy + Default + Debug + Eq + Send + Sync + Serialize + DeserializeOwned;
    type Progress: Copy + Default + Debug + Eq + Send + Sync + Serialize + DeserializeOwned;
    type Snapshot: Clone + Debug + Eq + Send + Sync + Serialize + DeserializeOwned;
    type Observations: Clone + Debug + Eq + Send + Sync + Serialize;
    type Evidence: Clone + Default;
    type ArchiveReport: Clone;
    type Run: Clone + Sync;
}

pub trait Reporting: CampaignTypes {
    fn diagnostics(_evidence: &Self::Evidence) -> Option<serde_json::Value> {
        None
    }
    fn retained_diagnostics<'a>(
        _snapshots: impl Iterator<Item = (Option<&'a Self::Snapshot>, u64)>,
    ) -> Option<serde_json::Value>
    where
        Self::Snapshot: 'a,
    {
        None
    }
    fn merge_witness_diagnostics(
        _evidence: &mut Self::Evidence,
        _observations: &[Self::Observations],
        _sequence: u64,
    ) {
    }
    fn evidence_checkpoint(_evidence: &Self::Evidence) -> Result<Vec<u8>, Box<dyn Error>> {
        Err("this workload cannot write its evidence into a search checkpoint".into())
    }
    fn evidence_from_checkpoint(_bytes: &[u8]) -> Result<Self::Evidence, Box<dyn Error>> {
        Err("this workload cannot read its evidence from a search checkpoint".into())
    }
    fn checkpoint_marks(_evidence: &Self::Evidence) -> usize {
        0
    }
    fn stream_format(&self) -> &'static str;
    fn checkpoint_format(&self) -> &'static str;
    fn workload_identity_sha256(&self) -> String;
    fn action_cost_unit(&self) -> &'static str;
    fn execution_work_unit(&self) -> &'static str;
    fn result_sha256(&self, result: &CampaignJobResult<Self>) -> Result<String, Box<dyn Error>>;
    fn archive_report(
        &self,
        evidence: &Self::Evidence,
        state: ArchiveReportState<Self>,
    ) -> Self::ArchiveReport;
}

pub trait InputPolicy: CampaignTypes {
    fn policies(&self, run: &Self::Run) -> WorkloadPolicies;
    fn resolve_recorded(&self, policies: &WorkloadPolicies) -> Result<Self::Run, Box<dyn Error>>;
    fn sample_alphabet(
        &self,
        run: &Self::Run,
        previous: Option<&Self::Action>,
        rand: &mut RomuDuoJrRand,
    ) -> Result<Self::Action, Box<dyn Error>>;

    fn draw_table_parameters(&self, run: &Self::Run) -> EmpiricalStepParameters {
        let _ = run;
        DEFAULT_DRAW_TABLE_PARAMETERS
    }
    fn draw_state_memory_reserve_bytes(&self, run: &Self::Run) -> usize {
        let _ = run;
        DrawTables::<Self::Action>::memory_reserve_bytes()
    }
    fn draw_state_memory_bytes(&self, state: &DrawTables<Self::Action>) -> usize {
        state.memory_bytes()
    }
    fn duration_request(
        &self,
        run: &Self::Run,
        parent: Self::Key,
        remaining_work: Option<NonZeroU64>,
    ) -> Option<DurationRequest<Self::Key>> {
        let _ = (run, parent, remaining_work);
        None
    }
    fn expand_suffix_duration(
        &self,
        run: &Self::Run,
        state: &DrawTables<Self::Action>,
        mixture: MixtureDraw,
        mutation_seed: u64,
        previous: Option<&Self::Action>,
        draw: DurationDraw<Self::Key>,
    ) -> Result<Vec<Self::Action>, Box<dyn Error>> {
        self.expand_duration_recorded_or_live(
            run,
            state,
            mixture,
            None,
            mutation_seed,
            previous,
            draw,
            false,
        )
    }
    #[allow(clippy::too_many_arguments)]
    fn expand_suffix_recorded_duration(
        &self,
        run: &Self::Run,
        state: &DrawTables<Self::Action>,
        mixture: MixtureDraw,
        before: Option<&EmpiricalStepCheckpoint>,
        mutation_seed: u64,
        previous: Option<&Self::Action>,
        draw: Option<DurationDraw<Self::Key>>,
    ) -> Result<Vec<Self::Action>, Box<dyn Error>> {
        match draw {
            Some(draw) => self.expand_duration_recorded_or_live(
                run,
                state,
                mixture,
                before,
                mutation_seed,
                previous,
                draw,
                true,
            ),
            None => {
                self.expand_suffix_recorded(run, state, mixture, before, mutation_seed, previous)
            }
        }
    }
    #[allow(clippy::too_many_arguments)]
    fn expand_duration_recorded_or_live(
        &self,
        run: &Self::Run,
        state: &DrawTables<Self::Action>,
        mixture: MixtureDraw,
        before: Option<&EmpiricalStepCheckpoint>,
        mutation_seed: u64,
        previous: Option<&Self::Action>,
        draw: DurationDraw<Self::Key>,
        replay: bool,
    ) -> Result<Vec<Self::Action>, Box<dyn Error>> {
        let _ = draw;
        self.expand_recorded_or_live(run, state, mixture, before, mutation_seed, previous, replay)
    }
    fn duration_of_action(&self, run: &Self::Run, action: &Self::Action) -> Option<NonZeroU64> {
        let _ = (run, action);
        None
    }
    fn draw_checkpoint(
        &self,
        state: &DrawTables<Self::Action>,
    ) -> Result<Option<EmpiricalStepCheckpoint>, Box<dyn Error>> {
        state.checkpoint().map(Some)
    }
    fn draw_checkpoint_version(&self, checkpoint: &EmpiricalStepCheckpoint) -> u64 {
        checkpoint.records
    }
    fn expand_suffix(
        &self,
        run: &Self::Run,
        state: &DrawTables<Self::Action>,
        mixture: MixtureDraw,
        mutation_seed: u64,
        previous: Option<&Self::Action>,
    ) -> Result<Vec<Self::Action>, Box<dyn Error>> {
        self.expand_recorded_or_live(run, state, mixture, None, mutation_seed, previous, false)
    }
    fn expand_suffix_recorded(
        &self,
        run: &Self::Run,
        state: &DrawTables<Self::Action>,
        mixture: MixtureDraw,
        before: Option<&EmpiricalStepCheckpoint>,
        mutation_seed: u64,
        previous: Option<&Self::Action>,
    ) -> Result<Vec<Self::Action>, Box<dyn Error>> {
        self.expand_recorded_or_live(run, state, mixture, before, mutation_seed, previous, true)
    }
    #[allow(clippy::too_many_arguments)]
    fn expand_recorded_or_live(
        &self,
        run: &Self::Run,
        state: &DrawTables<Self::Action>,
        mixture: MixtureDraw,
        before: Option<&EmpiricalStepCheckpoint>,
        mutation_seed: u64,
        previous: Option<&Self::Action>,
        replay: bool,
    ) -> Result<Vec<Self::Action>, Box<dyn Error>> {
        state.draw(before, replay, |view| {
            draw_suffix(
                mixture.mixture,
                mixture.weight,
                mutation_seed,
                previous,
                |rand| biased_step(view, rand),
                |previous, rand| self.sample_alphabet(run, previous, rand),
            )
        })
    }
    fn finish_stream_record(
        &self,
        run: &Self::Run,
        state: &mut DrawTables<Self::Action>,
        retained: &[(usize, &[Self::Action])],
        evidence: &Self::Evidence,
    ) -> Result<Option<EmpiricalStepCheckpoint>, Box<dyn Error>> {
        let _ = (run, evidence);
        state.finish_record(retained)
    }
    fn remember_draw_version(
        &self,
        state: &mut DrawTables<Self::Action>,
        schedule: &DrawVersionSchedule,
    ) -> Result<(), Box<dyn Error>> {
        state.remember_version(schedule)
    }
}

pub trait TargetExecution: CampaignTypes {
    fn new_target(&self) -> Result<Self::Target, String>;
    fn reset(&self, target: &mut Self::Target);
    fn restore(
        &self,
        target: &mut Self::Target,
        snapshot: &Self::Snapshot,
    ) -> Result<(), Box<dyn Error>>;
    fn execution_work(&self, target: &Self::Target) -> u64;
    fn telemetry(&self, _target: &Self::Target) -> TargetCounters {
        TargetCounters::new()
    }
    fn action_cost_fn(&self) -> fn(&Self::Action) -> u64;
    fn snapshot_memory_charge(snapshot: &Self::Snapshot) -> usize;
    fn apply_action(
        &self,
        target: &mut Self::Target,
        action: &Self::Action,
        milestones: &mut Self::Milestones,
    ) -> Result<(), Box<dyn Error>>;
    fn rollout_observations(&self, _target: &Self::Target) -> Vec<Self::Observations> {
        Vec::new()
    }
    fn rollout_probe(
        &self,
        _run: &Self::Run,
        target: &mut Self::Target,
        snapshot: &Self::Snapshot,
    ) -> Result<bool, Box<dyn Error>> {
        self.restore(target, snapshot)?;
        Ok(true)
    }
    fn snapshot(&self, target: &mut Self::Target) -> Result<Self::Snapshot, Box<dyn Error>>;
    #[allow(clippy::too_many_arguments)]
    fn execute_job(
        &self,
        run: &Self::Run,
        target: &mut Self::Target,
        origin_snapshot: &Self::Snapshot,
        replay: &[Self::Action],
        parent_milestones: Self::Milestones,
        suffix: &[Self::Action],
        retention: RetentionPolicy,
        stop_rollout_on_objective: bool,
    ) -> Result<CampaignJobResult<Self>, Box<dyn Error>>
    where
        Self: Workload + Sized,
    {
        crate::search::rollout::execute_job(
            self,
            run,
            target,
            origin_snapshot,
            replay,
            parent_milestones,
            suffix,
            retention,
            stop_rollout_on_objective,
        )
    }
}

pub trait Evaluation: CampaignTypes {
    fn execution_disposition(
        &self,
        target: &Self::Target,
    ) -> crate::search::rollout::ExecutionDisposition;
    fn objective_reached(
        &self,
        run: &Self::Run,
        target: &Self::Target,
    ) -> Result<bool, Box<dyn Error>>;
    fn rollout_outcome(
        &self,
        run: &Self::Run,
        target: &Self::Target,
    ) -> Result<crate::search::rollout::Outcome, Box<dyn Error>> {
        Ok(crate::search::rollout::Outcome {
            objective_reached: self.objective_reached(run, target)?,
            disposition: self.execution_disposition(target),
        })
    }
    fn merge_preparation_failure(
        &self,
        _evidence: &mut Self::Evidence,
        _observations: &[Self::Observations],
    ) {
    }
    fn current_key(&self, target: &Self::Target) -> Result<Self::Key, Box<dyn Error>>;
    fn rollout_key(&self, target: &Self::Target) -> Result<Self::Key, Box<dyn Error>> {
        self.current_key(target)
    }
    fn complete_candidate_key(
        &self,
        key: Self::Key,
        snapshot: &Self::Snapshot,
    ) -> Result<Self::Key, Box<dyn Error>>;
    fn merge_milestones(&self, into: &mut Self::Milestones, from: Self::Milestones);
    fn aggregate_milestones(evidence: &Self::Evidence) -> Self::Milestones;
    fn aggregate_progress(evidence: &Self::Evidence) -> Self::Progress;
    fn merge_origin_evidence(&self, evidence: &mut Self::Evidence, source: &Self::ArchiveReport);
    fn merge_snapshot_root_evidence(
        &self,
        evidence: &mut Self::Evidence,
        target: &Self::Target,
    ) -> Result<(), Box<dyn Error>>;
    fn merge_import_evidence(
        &self,
        evidence: &mut Self::Evidence,
        milestones: Self::Milestones,
        input: &Input<Self::Action>,
    );
    fn merge_action_evidence<F>(
        &self,
        evidence: &mut Self::Evidence,
        action: &CampaignActionResult<Self>,
        sequence: u64,
        input: F,
    ) -> Result<(), Box<dyn Error>>
    where
        F: FnOnce() -> Result<Input<Self::Action>, Box<dyn Error>>;
    fn source_entries<'a>(
        &self,
        source: &'a Self::ArchiveReport,
    ) -> &'a [ArchiveEntryReport<Self::Action, Self::Key, Self::Milestones>];
    fn resume_input(
        &self,
        source: &Self::ArchiveReport,
    ) -> Result<Input<Self::Action>, Box<dyn Error>>;
}

pub trait Workload: CampaignTypes + TargetExecution + InputPolicy + Evaluation + Reporting {}

impl<T> Workload for T where
    T: CampaignTypes + TargetExecution + InputPolicy + Evaluation + Reporting
{
}

pub struct ArchiveReportState<G: CampaignTypes + ?Sized> {
    pub seed: u64,
    pub executions: u64,
    pub entries: Vec<ArchiveEntryReport<G::Action, G::Key, G::Milestones>>,
    pub progress_curve: Vec<ProgressPoint<G::Milestones, G::Progress>>,
    pub retained: u64,
    pub rejected: u64,
    pub terminal_endpoints: u64,
    pub terminal_objectives: u64,
    pub execution_failures: u64,
    pub selector: SelectorAccounting,
}

pub enum CampaignOrigin<G: Workload + ?Sized> {
    Genesis,
    SnapshotRoot {
        checkpoint: CampaignCheckpoint<G::Snapshot>,
    },
    Archive {
        path: String,
        file_sha256: String,
        report: Box<G::ArchiveReport>,
        checkpoint: Option<CampaignCheckpoint<G::Snapshot>>,
    },
    SearchCheckpoint {
        path: PathBuf,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CampaignCheckpoint<S> {
    pub path: String,
    pub file_sha256: String,
    pub snapshots: SnapshotCheckpoint<S>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(bound = "S: Serialize + DeserializeOwned")]
pub struct SnapshotCheckpoint<S> {
    pub format: String,
    pub entries: Vec<SnapshotCheckpointEntry<S>>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(bound = "S: Serialize + DeserializeOwned")]
pub struct SnapshotCheckpointEntry<S> {
    pub id: u64,
    pub snapshot: S,
}

impl<S: Serialize + DeserializeOwned> SnapshotCheckpoint<S> {
    pub fn to_bytes(&self) -> Result<Vec<u8>, Box<dyn Error>> {
        Ok(postcard::to_allocvec(self)?)
    }

    pub fn from_bytes(bytes: &[u8], expected_format: &str) -> Result<Self, Box<dyn Error>> {
        let (format, _) = postcard::take_from_bytes::<&str>(bytes)?;
        if format != expected_format {
            return Err("snapshot checkpoint format is not recognized".into());
        }
        Ok(postcard::from_bytes(bytes)?)
    }
}

pub struct CampaignConfig<G: Workload + ?Sized> {
    pub campaign_seed: u64,
    pub workers: u32,
    pub execution_budget: u64,
    pub host: String,
    pub wall_budget: Option<Duration>,
    pub stop_rollout_on_objective: bool,
    pub stop_campaign_on_objective: bool,
    pub archive_entry_limit: usize,
    pub window: usize,
    pub memory_budget_mib: Option<usize>,
    pub materialize_final_artifacts: bool,
    pub run: G::Run,
    pub mixture: DrawMixture,
    pub retention: RetentionPolicy,
    pub objective_witness_path: Option<PathBuf>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(bound = "T: Serialize + DeserializeOwned")]
pub struct CampaignStreamHeader<T> {
    pub schema_version: u32,
    pub format: String,
    pub campaign_seed: u64,
    pub schedule_policy: String,
    pub progress_policy: String,
    pub host: String,
    pub origin_kind: String,
    pub origin_path: Option<String>,
    pub origin_archive_sha256: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub origin_checkpoint_path: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub origin_checkpoint_sha256: Option<String>,
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub origin_checkpoint_policy_changes: BTreeMap<String, PolicyChange>,
    pub resume_input_sha256: String,
    pub resume_actions: usize,
    pub execution_budget: u64,
    pub stop_rollout_on_objective: bool,
    pub stop_campaign_on_objective: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub work_budget: Option<u64>,
    pub wall_budget_seconds: Option<u64>,
    pub archive_entry_limit: usize,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub memory_budget_mib: Option<usize>,
    pub resume_policy: String,
    pub mixture_policy: String,
    #[serde(flatten)]
    pub workload_policies: WorkloadPolicies,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub draw_header: Option<T>,
    pub retention_policy: String,
    pub parent_scheduler: String,
    pub preference_portfolio: String,
    pub executor_mode: String,
    pub selection_seed_derivation: String,
    pub workload_identity_sha256: String,
    pub action_cost_unit: String,
    pub execution_work_unit: String,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(tag = "outcome", rename_all = "snake_case")]
pub enum CampaignSpliceRecord {
    Unavailable,
    Tail {
        donor_id: u64,
        leaf_id: u64,
        tail_postcard: Vec<u8>,
    },
}

#[derive(Clone, Copy, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(tag = "decision", rename_all = "snake_case")]
pub enum CampaignAdmissionDecision {
    Retained { id: u64 },
    Duplicate { id: u64 },
    Rejected,
    ProbeRefused,
    Objective,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(bound = "C: Serialize + DeserializeOwned, K: Serialize + DeserializeOwned")]
pub struct CampaignJobRecord<C, K = ()> {
    pub sequence: u64,
    pub reservation: u64,
    pub parent_id: u64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub continuation_energy: Option<u16>,
    pub mutation_seed: u64,
    pub execution_work: u64,
    pub result_sha256: String,
    pub decisions: Vec<CampaignAdmissionDecision>,
    pub mixture_weight: u8,
    pub splice_weight: u8,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub splice: Option<CampaignSpliceRecord>,

    pub selector: SelectorDraw,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub draw_checkpoint_before: Option<C>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub draw_checkpoint_after: Option<C>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub duration_draw: Option<DurationDraw<K>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub duration_admission_sequence_at_draw: Option<u64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub duration_remaining_work: Option<NonZeroU64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub duration_checkpoint_at_draw: Option<DurationCheckpoint>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub duration_checkpoint_before: Option<DurationCheckpoint>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub duration_checkpoint_after: Option<DurationCheckpoint>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub suffix_limit: Option<u8>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(bound = "C: Serialize + DeserializeOwned, K: Serialize + DeserializeOwned")]
pub struct CampaignSkipRecord<C, K = ()> {
    pub parent_id: u64,
    pub mutation_seed: u64,
    pub mixture_weight: u8,
    pub splice_weight: u8,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub splice: Option<CampaignSpliceRecord>,

    pub selector: SelectorDraw,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub draw_checkpoint_before: Option<C>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub draw_checkpoint_after: Option<C>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub duration_draw: Option<DurationDraw<K>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub duration_admission_sequence_at_draw: Option<u64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub duration_remaining_work: Option<NonZeroU64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub duration_checkpoint_at_draw: Option<DurationCheckpoint>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub duration_checkpoint_before: Option<DurationCheckpoint>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub duration_checkpoint_after: Option<DurationCheckpoint>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub suffix_limit: Option<u8>,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(bound = "C: Serialize + DeserializeOwned, K: Serialize + DeserializeOwned")]
#[serde(tag = "event", rename_all = "snake_case")]
pub enum CampaignStreamRecord<C, K = ()> {
    Job(CampaignJobRecord<C, K>),
    Skip(CampaignSkipRecord<C, K>),
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct CampaignOriginRecord {
    pub kind: String,
    pub path: Option<String>,
    pub archive_sha256: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub checkpoint_path: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub checkpoint_sha256: Option<String>,
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub checkpoint_policy_changes: BTreeMap<String, PolicyChange>,
    pub resume_input_sha256: String,
    pub resume_actions: usize,
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
pub struct PolicyChange {
    pub checkpoint: String,
    pub run: String,
}

pub const PREFERENCE_POLICY_FIELD: &str = "preference_policy";

const PREFERENCE_PORTFOLIO_FIELD: &str = "preference_portfolio";

const RESUMABLE_POLICY_FIELDS: [&str; 9] = [
    "mixture_policy",
    "retention_policy",
    "parent_scheduler",
    "continuation_policy",
    "stop_rollout_on_objective",
    "stop_campaign_on_objective",
    DRAW_TABLE_POLICY_FIELD,
    PREFERENCE_PORTFOLIO_FIELD,
    PREFERENCE_POLICY_FIELD,
];

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(bound = "A: Serialize + DeserializeOwned + Ord + Clone, R: Serialize + DeserializeOwned")]
pub struct CampaignModeReport<A: Ord, R> {
    pub mode: String,
    pub campaign_seed: u64,
    pub window: usize,
    pub host: String,
    pub schedule_identity: String,
    pub origin: CampaignOriginRecord,
    pub execution_budget: u64,
    pub stop_rollout_on_objective: bool,
    pub stop_campaign_on_objective: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub work_budget: Option<u64>,
    pub executions_completed: u64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub executions_to_first_objective: Option<u64>,
    pub wall_budget_seconds: Option<u64>,
    pub archive_entry_limit: usize,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub memory_budget_mib: Option<usize>,
    pub resume_policy: String,
    pub mixture_policy: String,
    #[serde(flatten)]
    pub workload_policies: WorkloadPolicies,
    pub retention_policy: String,
    pub parent_scheduler: String,
    pub executor_mode: String,
    pub selection_seed_derivation: String,
    pub workload_identity_sha256: String,
    pub action_cost_unit: String,
    pub execution_work_unit: String,
    pub bootstrap_execution_work: u64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub tree_import: Option<TreeImportCounts>,
    pub execution_work: u64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub work_to_first_objective: Option<u64>,
    pub duplicates_skipped: u64,
    pub probe_refused: u64,
    pub terminal_endpoints: u64,
    pub terminal_objectives: u64,
    pub execution_failures: u64,
    pub objectives_reached: u64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub objective_witness: Option<Input<A>>,
    pub replacement_cost_displaced: u64,
    #[serde(default, skip_serializing_if = "is_zero_u64")]
    pub snapshot_evictions: u64,
    #[serde(default, skip_serializing_if = "is_zero_usize")]
    pub resident_snapshot_bytes: usize,
    #[serde(default, skip_serializing_if = "is_zero_usize")]
    pub history_memory_bytes: usize,
    #[serde(default, skip_serializing_if = "is_zero_usize")]
    pub draw_state_memory_bytes: usize,
    #[serde(default, skip_serializing_if = "is_zero_usize")]
    pub resident_memory_bytes: usize,
    #[serde(default, skip_serializing_if = "is_zero_usize")]
    pub live_entries: usize,
    #[serde(default, skip_serializing_if = "is_zero_u64")]
    pub history_compactions: u64,
    #[cfg(test)]
    #[serde(default, skip_serializing_if = "is_zero_u64")]
    pub(crate) liveness_anchor_reactivations: u64,
    #[serde(default, skip_serializing_if = "is_zero_u64")]
    pub historical_entries_dropped: u64,
    #[serde(default, skip_serializing_if = "is_zero_u64")]
    pub input_reconstructions: u64,
    #[serde(default, skip_serializing_if = "is_zero_usize")]
    pub input_index_nodes: usize,
    #[serde(default, skip_serializing_if = "is_zero_usize")]
    pub historical_cells: usize,
    pub stream_sha256: String,
    pub archive: R,
    #[serde(skip)]
    pub telemetry: CampaignTelemetry,
}

#[derive(Clone, Copy, Debug, Default, Deserialize, Eq, PartialEq, Serialize)]
pub struct TreeImportCounts {
    pub imported: u64,
    pub duplicate: u64,
    pub rejected: u64,
    pub terminal: u64,
    pub rerooted: u64,
    #[serde(default, skip_serializing_if = "is_zero_u64")]
    pub checkpointed: u64,
}

fn is_zero_u64(value: &u64) -> bool {
    *value == 0
}

fn is_zero_usize(value: &usize) -> bool {
    *value == 0
}

fn archive_entry_limit_is_valid(limit: usize) -> bool {
    (1..=crate::search::archive::MAX_ARCHIVE_ENTRIES).contains(&limit)
}

fn memory_is_within_reserve(bytes: usize, reserve: usize) -> bool {
    bytes <= reserve
}

fn resident_memory_is_within_budget(bytes: usize, memory_budget_mib: Option<usize>) -> bool {
    memory_budget_mib.is_none_or(|budget_mib| bytes <= budget_mib.saturating_mul(1024 * 1024))
}

struct ContinuationReservation<G: Workload + ?Sized> {
    parent_index: usize,
    parent_id: u64,
    donor: u64,
    leaf: u64,
    source: Position<G::Key>,
    destination: Position<G::Key>,
    wave: u32,
    suffix: Vec<G::Action>,
}

fn take_continuation<G: Workload + ?Sized>(
    core: &mut CoordinatorCore<G>,
    from_highest_preference: bool,
) -> Option<ContinuationReservation<G>> {
    let mut examined = 0_usize;
    let mut gaining_fallback = None;
    while examined < CONTINUATION_EXITS_PER_RESERVATION
        && let Some(continuation) = core.archive.pop_continuation(from_highest_preference)
    {
        examined = examined.saturating_add(1);
        let Some(parent_index) = core.archive.index_of_id(continuation.parent) else {
            continue;
        };
        if !core.archive.active[parent_index] {
            continue;
        }
        let outranks = core.archive.outranks_slot_holders(
            parent_index,
            continuation.destination,
            continuation.preference,
        );
        let gaining = continuation.gains != 0;
        if !outranks && (!gaining || gaining_fallback.is_some()) {
            continue;
        }
        let actions = continuation.actions;
        if core.all_prefixes_archived(parent_index, &actions) {
            continue;
        }
        let reservation = ContinuationReservation {
            parent_index,
            parent_id: continuation.parent,
            donor: continuation.donor,
            leaf: continuation.leaf,
            source: continuation.source,
            destination: continuation.destination,
            wave: continuation.wave,
            suffix: actions,
        };
        if outranks {
            core.archive.record_continuation_dispatch(false);
            return Some(reservation);
        }
        gaining_fallback = Some(reservation);
    }
    if gaining_fallback.is_some() {
        core.archive.record_continuation_dispatch(true);
    }
    gaining_fallback
}

fn continuation_attempt<G: Workload + ?Sized>(
    core: &mut CoordinatorCore<G>,
    campaign_seed: u64,
    reservation: u64,
) -> (Option<u16>, Option<ContinuationReservation<G>>) {
    if core.archive.continuation_pending() == 0 {
        return (None, None);
    }
    let energy = CONTINUATION_ATTEMPT_SHARE;
    let takes = draws_continuation(campaign_seed, reservation);
    core.archive.record_continuation_reservation(energy, takes);
    let taken = takes
        .then(|| {
            let from_highest_preference = draws_highest_preference(campaign_seed, reservation);
            take_continuation(core, from_highest_preference)
        })
        .flatten();
    (Some(energy), taken)
}

fn continuation_reservation_matches<G: Workload + ?Sized>(
    taken: Option<&ContinuationReservation<G>>,
    energy: Option<u16>,
    selector: &SelectorDraw,
    splice: Option<&CampaignSpliceRecord>,
    recorded_energy: Option<u16>,
    sequence: u64,
) -> Result<(), Box<dyn Error>> {
    if recorded_energy != energy {
        return Err(
            format!("record {sequence} disagrees with the rebuilt continuation share").into(),
        );
    }
    let recorded = selector.path == SelectorPath::Continuation;
    match (taken, recorded) {
        (None, false) => Ok(()),
        (None, true) => Err(format!(
            "record {sequence} is a continuation job the replayed queue did not produce"
        )
        .into()),
        (Some(_), false) => Err(format!(
            "the replayed queue produced a continuation at record {sequence}, which is an ordinary job"
        )
        .into()),
        (Some(taken), true) => {
            let Some(CampaignSpliceRecord::Tail {
                donor_id,
                leaf_id,
                tail_postcard,
            }) = splice
            else {
                return Err(
                    format!("continuation record {sequence} lacks its complete tail").into(),
                );
            };
            let tail: Vec<G::Action> = postcard::from_bytes(tail_postcard)?;
            if *donor_id != taken.donor || *leaf_id != taken.leaf || tail != taken.suffix {
                return Err(format!(
                    "continuation record {sequence} disagrees with the replayed queue entry"
                )
                .into());
            }
            Ok(())
        }
    }
}

fn continuation_arrival<G: Workload>(
    archive: &Archive<G::Action, G::Key, G::Milestones, G::Snapshot>,
    edge: Option<Edge<G::Key>>,
    decisions: &[CampaignAdmissionDecision],
) -> (Option<usize>, bool) {
    let Some((source, destination)) = edge else {
        return (None, false);
    };
    decisions
        .iter()
        .fold((None, false), |(landed, replaced), decision| {
            let (id, retained) = match decision {
                CampaignAdmissionDecision::Retained { id } => (*id, true),
                CampaignAdmissionDecision::Duplicate { id } => (*id, false),
                _ => return (landed, replaced),
            };
            let arrived = archive
                .index_of_id(id)
                .filter(|index| archive.lands_on_edge(*index, source, destination));
            (
                landed.or(arrived),
                replaced || (arrived.is_some() && retained),
            )
        })
}

fn retained_archive_indexes<G: Workload>(
    core: &CoordinatorCore<G>,
    decisions: &[CampaignAdmissionDecision],
) -> Vec<usize> {
    decisions
        .iter()
        .filter_map(|decision| match decision {
            CampaignAdmissionDecision::Retained { id } => core.archive.index_of_id(*id),
            _ => None,
        })
        .collect()
}

fn progress_policy_is_supported(policy: &str) -> bool {
    policy == CAMPAIGN_PROGRESS_POLICY
}

fn record_mixture_outcome(
    energy: &mut MixtureEnergy,
    mixture: DrawMixture,
    path: SelectorPath,
    mutation_seed: u64,
    (mixture_weight, splice_weight): (u8, u8),
    new_slot: bool,
    work: u64,
) -> Result<(), Box<dyn Error>> {
    if path == SelectorPath::Continuation {
        return Ok(());
    }
    if matches!(
        mixture,
        DrawMixture::Energy { .. } | DrawMixture::EnergySplice { .. }
    ) {
        energy.record_outcome(
            energy_strategy(mutation_seed, mixture_weight, splice_weight)?,
            new_slot,
            work,
        );
    }
    Ok(())
}

pub(crate) const CONTINUATION_EXITS_PER_RESERVATION: usize = 8;

pub(crate) const CONTINUATION_ATTEMPT_IN: usize = 4;

pub(crate) const CONTINUATION_HIGHEST_TIER_IN: usize = 4;

const CONTINUATION_ATTEMPT_SHARE: u16 = 64;

const CONTINUATION_TIER_SALT: u64 = 0x9e37_79b9_7f4a_7c15;

fn draws_one_in(seed: u64, one_in: usize) -> bool {
    let Some(bound) = NonZeroUsize::new(one_in) else {
        return false;
    };
    RomuDuoJrRand::with_seed(seed).below(bound) == 0
}

#[must_use]
pub(crate) fn draws_continuation(campaign_seed: u64, reservation: u64) -> bool {
    draws_one_in(campaign_seed ^ reservation, CONTINUATION_ATTEMPT_IN)
}

#[must_use]
pub(crate) fn draws_highest_preference(campaign_seed: u64, reservation: u64) -> bool {
    draws_one_in(
        campaign_seed ^ reservation ^ CONTINUATION_TIER_SALT,
        CONTINUATION_HIGHEST_TIER_IN,
    )
}

fn stop_reservations_after_objective(
    stop_campaign_on_objective: bool,
    objective_found: bool,
) -> bool {
    stop_campaign_on_objective && objective_found
}

#[derive(Serialize)]
#[serde(bound = "")]
pub struct CampaignCandidate<G: CampaignTypes + ?Sized> {
    pub key: G::Key,
    pub viable: bool,
    pub snapshot: G::Snapshot,
}

impl<G: CampaignTypes + ?Sized> PartialEq for CampaignCandidate<G> {
    fn eq(&self, other: &Self) -> bool {
        self.key == other.key && self.viable == other.viable && self.snapshot == other.snapshot
    }
}
impl<G: CampaignTypes + ?Sized> Eq for CampaignCandidate<G> {}

impl<G: CampaignTypes + ?Sized> Clone for CampaignCandidate<G> {
    fn clone(&self) -> Self {
        Self {
            key: self.key,
            viable: self.viable,
            snapshot: self.snapshot.clone(),
        }
    }
}

impl<G: CampaignTypes + ?Sized> Debug for CampaignCandidate<G> {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("CampaignCandidate")
            .field("key", &self.key)
            .field("viable", &self.viable)
            .field("snapshot", &self.snapshot)
            .finish()
    }
}

#[derive(Serialize)]
#[serde(bound = "")]
pub struct CampaignActionResult<G: CampaignTypes + ?Sized> {
    pub action: G::Action,
    pub observations: Vec<G::Observations>,
    pub milestones: G::Milestones,
    pub outcome: crate::search::rollout::Outcome,
    pub candidate: Option<CampaignCandidate<G>>,
}

impl<G: CampaignTypes + ?Sized> PartialEq for CampaignActionResult<G> {
    fn eq(&self, other: &Self) -> bool {
        self.action == other.action
            && self.observations == other.observations
            && self.milestones == other.milestones
            && self.outcome == other.outcome
            && self.candidate == other.candidate
    }
}
impl<G: CampaignTypes + ?Sized> Eq for CampaignActionResult<G> {}

impl<G: CampaignTypes + ?Sized> Clone for CampaignActionResult<G> {
    fn clone(&self) -> Self {
        Self {
            action: self.action,
            observations: self.observations.clone(),
            milestones: self.milestones,
            outcome: self.outcome,
            candidate: self.candidate.clone(),
        }
    }
}

impl<G: CampaignTypes + ?Sized> Debug for CampaignActionResult<G> {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("CampaignActionResult")
            .field("action", &self.action)
            .field("observations", &self.observations)
            .field("milestones", &self.milestones)
            .field("outcome", &self.outcome)
            .field("candidate", &self.candidate)
            .finish()
    }
}

#[derive(Serialize)]
#[serde(bound = "")]
pub struct CampaignJobResult<G: CampaignTypes + ?Sized> {
    pub preparation_failure: Option<Vec<G::Observations>>,
    pub actions: Vec<CampaignActionResult<G>>,
}

impl<G: CampaignTypes + ?Sized> PartialEq for CampaignJobResult<G> {
    fn eq(&self, other: &Self) -> bool {
        self.preparation_failure == other.preparation_failure && self.actions == other.actions
    }
}
impl<G: CampaignTypes + ?Sized> Eq for CampaignJobResult<G> {}

impl<G: CampaignTypes + ?Sized> Clone for CampaignJobResult<G> {
    fn clone(&self) -> Self {
        Self {
            preparation_failure: self.preparation_failure.clone(),
            actions: self.actions.clone(),
        }
    }
}

impl<G: CampaignTypes + ?Sized> Debug for CampaignJobResult<G> {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("CampaignJobResult")
            .field("preparation_failure", &self.preparation_failure)
            .field("actions", &self.actions)
            .finish()
    }
}

fn verify_selector_annotation(draw: &SelectorDraw) -> Result<(), Box<dyn Error>> {
    match (draw.path, draw.tier_rank) {
        (SelectorPath::Tiers | SelectorPath::Recent, None) => {
            Err("tier draw is missing its rank".into())
        }
        (SelectorPath::Continuation, Some(_)) => {
            Err("continuation draw carries a tier rank".into())
        }
        _ => Ok(()),
    }
}

#[must_use]
pub fn derive_selection_seed(campaign_seed: u64) -> u64 {
    let digest = Sha256::digest(campaign_seed.to_le_bytes());
    u64::from_le_bytes(
        digest[..8]
            .try_into()
            .expect("a SHA-256 digest has eight bytes"),
    )
}

pub(crate) struct CoordinatorCore<G: Workload + ?Sized> {
    pub(crate) archive: Archive<G::Action, G::Key, G::Milestones, G::Snapshot>,
    pub(crate) evidence: G::Evidence,
    curve: Vec<ProgressPoint<G::Milestones, G::Progress>>,
    curve_interval: u64,
    bounded_progress_curve: bool,
    record_progress: bool,
    terminal_endpoints: u64,
    terminal_objectives: u64,
    execution_failures: u64,
    pub(crate) objectives_reached: u64,
    pub(crate) objective_witness: Option<Input<G::Action>>,
    sequence: u64,
    probe_refused: u64,
    pub(crate) mixture_energy: MixtureEnergy,
    suffix_jobs_in_flight: BTreeMap<(u64, u8), u32>,
}

impl<G: Workload + ?Sized> CoordinatorCore<G> {
    pub(crate) fn new(
        workload: &G,
        run: &G::Run,
        archive_entry_limit: usize,
        memory_budget_mib: Option<usize>,
    ) -> Self {
        let mut archive = Archive::new(workload.action_cost_fn());
        archive.max_entries = archive_entry_limit;
        if let Some(memory_budget_mib) = memory_budget_mib {
            let total = memory_budget_mib.saturating_mul(1024 * 1024);
            let draw_reserve = workload
                .draw_state_memory_reserve_bytes(run)
                .saturating_add(DurationPolicies::<G::Key>::memory_reserve_bytes());
            archive.set_memory_budget(
                total.saturating_sub(draw_reserve),
                G::snapshot_memory_charge,
            );
        }
        Self {
            archive,
            evidence: G::Evidence::default(),
            curve: Vec::new(),
            curve_interval: CURVE_INTERVAL,
            bounded_progress_curve: true,
            record_progress: true,
            terminal_endpoints: 0,
            terminal_objectives: 0,
            execution_failures: 0,
            objectives_reached: 0,
            objective_witness: None,
            sequence: 0,
            probe_refused: 0,
            mixture_energy: MixtureEnergy::default(),
            suffix_jobs_in_flight: BTreeMap::new(),
        }
    }

    fn suffix_limit(&self, parent_id: u64, parent_index: usize) -> u8 {
        let limit = self.archive.suffix_limit(parent_index);
        if self
            .suffix_jobs_in_flight
            .range((parent_id, limit)..=(parent_id, u8::MAX))
            .next()
            .is_some()
        {
            1
        } else {
            limit
        }
    }

    fn start_suffix_job(&mut self, parent_id: u64, limit: Option<u8>) {
        if let Some(limit) = limit {
            *self
                .suffix_jobs_in_flight
                .entry((parent_id, limit))
                .or_insert(0) += 1;
        }
    }

    fn finish_suffix_job(&mut self, parent_id: u64, limit: Option<u8>) {
        if let Some(limit) = limit
            && let Some(count) = self.suffix_jobs_in_flight.get_mut(&(parent_id, limit))
        {
            *count -= 1;
            if *count == 0 {
                self.suffix_jobs_in_flight.remove(&(parent_id, limit));
            }
        }
    }

    fn checkpoint_state(&self) -> CoreCheckpoint<G> {
        CoreCheckpoint {
            curve: self.curve.clone(),
            curve_interval: self.curve_interval,
            bounded_progress_curve: self.bounded_progress_curve,
            record_progress: self.record_progress,
            terminal_endpoints: self.terminal_endpoints,
            terminal_objectives: self.terminal_objectives,
            execution_failures: self.execution_failures,
            objectives_reached: self.objectives_reached,
            objective_witness: self.objective_witness.clone(),
            sequence: self.sequence,
            probe_refused: self.probe_refused,
            mixture_energy: self.mixture_energy,
        }
    }

    fn restore_state(&mut self, state: CoreCheckpoint<G>) -> Result<(), Box<dyn Error>> {
        self.curve = state.curve;
        self.curve_interval = state.curve_interval;
        self.bounded_progress_curve = state.bounded_progress_curve;
        self.record_progress = state.record_progress;
        self.terminal_endpoints = state.terminal_endpoints;
        self.terminal_objectives = state.terminal_objectives;
        self.execution_failures = state.execution_failures;
        self.objectives_reached = state.objectives_reached;
        self.objective_witness = state.objective_witness;
        self.sequence = state.sequence;
        self.probe_refused = state.probe_refused;
        self.mixture_energy = state.mixture_energy;
        Ok(())
    }

    pub(crate) fn bootstrap(
        &mut self,
        workload: &G,
        run: &G::Run,
        target: &mut G::Target,
    ) -> Result<(), Box<dyn Error>> {
        workload.reset(target);
        let outcome = workload.rollout_outcome(run, target)?;
        if outcome.disposition.is_failed() {
            return Err("campaign genesis target failed before execution".into());
        }
        if matches!(
            outcome.disposition,
            crate::search::rollout::ExecutionDisposition::Terminal
        ) {
            self.terminal_endpoints = self.terminal_endpoints.saturating_add(1);
            if outcome.objective_reached {
                self.terminal_objectives = self.terminal_objectives.saturating_add(1);
            }
        }
        if outcome.objective_reached {
            self.objectives_reached = self.objectives_reached.saturating_add(1);
            self.objective_witness = Some(Input::default());
        }
        let genesis_key = workload.current_key(target)?;
        let genesis_snapshot = workload.snapshot(target)?;
        self.archive
            .insert(
                None,
                0,
                ArchiveCandidate {
                    suffix: Vec::new(),
                    key: genesis_key,
                    milestones: G::Milestones::default(),
                },
                genesis_snapshot,
            )?
            .ok_or("failed to retain campaign genesis")?;
        Ok(())
    }

    pub(crate) fn bootstrap_snapshot_root(
        &mut self,
        workload: &G,
        run: &G::Run,
        target: &mut G::Target,
        checkpoint: &CampaignCheckpoint<G::Snapshot>,
    ) -> Result<(), Box<dyn Error>> {
        let snapshot = validate_snapshot_root_checkpoint(workload, checkpoint)?;
        workload.restore(target, snapshot)?;
        let outcome = workload.rollout_outcome(run, target)?;
        if outcome.disposition.is_failed() {
            return Err("snapshot-root checkpoint restores a failed target".into());
        }
        if matches!(
            outcome.disposition,
            crate::search::rollout::ExecutionDisposition::Terminal
        ) {
            self.terminal_endpoints = self.terminal_endpoints.saturating_add(1);
            if outcome.objective_reached {
                self.terminal_objectives = self.terminal_objectives.saturating_add(1);
            }
        }
        if outcome.disposition.is_terminal() && !outcome.objective_reached {
            return Err("snapshot-root checkpoint restores a terminal target".into());
        }
        if outcome.objective_reached {
            self.objectives_reached = self.objectives_reached.saturating_add(1);
            self.objective_witness = Some(Input::default());
        }
        workload.merge_snapshot_root_evidence(&mut self.evidence, target)?;
        let key = workload.current_key(target)?;
        let retained = self.archive.insert(
            None,
            0,
            ArchiveCandidate {
                suffix: Vec::new(),
                key,
                milestones: G::Milestones::default(),
            },
            snapshot.clone(),
        )?;
        if retained != Some(0) || self.archive.entries.len() != 1 {
            return Err("failed to retain snapshot-root checkpoint as archive id zero".into());
        }
        Ok(())
    }

    pub(crate) fn import_tree(
        &mut self,
        workload: &G,
        run: &G::Run,
        target: &mut G::Target,
        source: &G::ArchiveReport,
        checkpoint: Option<&SnapshotCheckpoint<G::Snapshot>>,
    ) -> Result<TreeImportCounts, Box<dyn Error>> {
        let checkpointed: BTreeMap<u64, &G::Snapshot> = checkpoint
            .map(|checkpoint| {
                checkpoint
                    .entries
                    .iter()
                    .map(|entry| (entry.id, &entry.snapshot))
                    .collect()
            })
            .unwrap_or_default();
        workload.merge_origin_evidence(&mut self.evidence, source);
        let preserve_inactive_snapshots = self.archive.preserves_inactive_snapshots();
        self.archive.preserve_inactive_snapshots(true)?;
        self.bootstrap(workload, run, target)?;
        let genesis_id = 0;
        let mut counts = TreeImportCounts::default();
        let mut index_of: BTreeMap<u64, usize> = BTreeMap::new();
        let source_entries = workload.source_entries(source);
        let mut imported: Vec<Option<usize>> = Vec::with_capacity(source_entries.len());
        for (index, entry) in source_entries.iter().enumerate() {
            index_of.insert(entry.id, index);
            if entry.input.actions.is_empty() {
                imported.push(Some(genesis_id));
                continue;
            }
            let mut ancestor = entry.parent_id;
            let mut parent = None;
            while let Some(id) = ancestor {
                let Some(ancestor_index) = index_of.get(&id).copied().filter(|i| *i < index) else {
                    break;
                };
                if let Some(new_id) = imported[ancestor_index] {
                    parent = Some((ancestor_index, new_id));
                    break;
                }
                ancestor = source_entries[ancestor_index].parent_id;
            }
            let (parent_input_len, parent_id) = match parent {
                Some((ancestor_index, new_id)) => {
                    let parent_input = &source_entries[ancestor_index].input.actions;
                    if entry.input.actions.get(..parent_input.len())
                        != Some(parent_input.as_slice())
                    {
                        return Err("source archive entry does not extend its parent".into());
                    }
                    if ancestor_index != index_of[&entry.parent_id.unwrap_or(u64::MAX)] {
                        counts.rerooted = counts.rerooted.saturating_add(1);
                    }
                    (parent_input.len(), new_id)
                }
                None => {
                    counts.rerooted = counts.rerooted.saturating_add(1);
                    (0, genesis_id)
                }
            };
            let parent_entry = &self.archive.entries[parent_id];
            let mut milestones = parent_entry.milestones;
            let prefix = entry.input.clone();
            let snapshot = if let Some(snapshot) = checkpointed.get(&entry.id) {
                workload.restore(target, snapshot)?;
                milestones = merge_max(workload, milestones, entry.milestones);
                counts.checkpointed = counts.checkpointed.saturating_add(1);
                if workload
                    .rollout_outcome(run, target)?
                    .disposition
                    .is_terminal()
                {
                    None
                } else {
                    Some((*snapshot).clone())
                }
            } else {
                workload.restore(
                    target,
                    parent_entry
                        .snapshot
                        .as_deref()
                        .ok_or("whole-tree import parent snapshot was released early")?,
                )?;
                let mut terminal = false;
                for action in &entry.input.actions[parent_input_len..] {
                    workload.apply_action(target, action, &mut milestones)?;
                    if workload
                        .rollout_outcome(run, target)?
                        .disposition
                        .is_terminal()
                    {
                        terminal = true;
                        break;
                    }
                }
                if terminal {
                    None
                } else {
                    Some(workload.snapshot(target)?)
                }
            };
            let Some(snapshot) = snapshot else {
                counts.terminal = counts.terminal.saturating_add(1);
                imported.push(None);
                continue;
            };
            workload.merge_import_evidence(&mut self.evidence, milestones, &prefix);
            let key = workload.current_key(target)?;
            let suffix = prefix
                .actions
                .get(parent_input_len..)
                .ok_or("source archive input is shorter than its imported parent")?
                .to_vec();
            let inserted_before = self.archive.entries.len();
            match self.archive.insert(
                Some(parent_id),
                0,
                ArchiveCandidate {
                    suffix,
                    key,
                    milestones,
                },
                snapshot,
            )? {
                Some(id) if id == inserted_before => {
                    counts.imported = counts.imported.saturating_add(1);
                    imported.push(Some(id));
                }
                Some(id) => {
                    counts.duplicate = counts.duplicate.saturating_add(1);
                    imported.push(Some(id));
                }
                None => {
                    counts.rejected = counts.rejected.saturating_add(1);
                    imported.push(None);
                }
            }
        }
        if self.archive.entries.len() == 1 {
            return Err("whole-tree import retained no entry past genesis".into());
        }
        self.archive
            .preserve_inactive_snapshots(preserve_inactive_snapshots)?;
        Ok(counts)
    }

    #[cfg(test)]
    pub(crate) fn admit_job(
        &mut self,
        workload: &G,
        parent_id: u64,
        result: CampaignJobResult<G>,
    ) -> Result<(u64, Vec<CampaignAdmissionDecision>), Box<dyn Error>> {
        let (sequence, decisions, _) =
            self.admit_job_tracking(workload, parent_id, result, false, |_| false)?;
        Ok((sequence, decisions))
    }

    fn admit_job_tracking(
        &mut self,
        workload: &G,
        parent_id: u64,
        result: CampaignJobResult<G>,
        limited: bool,
        mut tracked_action: impl FnMut(&G::Action) -> bool,
    ) -> Result<(u64, Vec<CampaignAdmissionDecision>, DurationAdmission), Box<dyn Error>> {
        let CampaignJobResult {
            preparation_failure,
            actions,
        } = result;
        if preparation_failure.is_some() && !actions.is_empty() {
            return Err("preparation failure result also carries actions".into());
        }
        self.sequence = self.sequence.saturating_add(1);
        let sequence = self.sequence;
        let parent_index = self
            .archive
            .index_of_id(parent_id)
            .ok_or("campaign job parent is no longer resident")?;
        if let Some(observations) = preparation_failure {
            self.execution_failures = self.execution_failures.saturating_add(1);
            workload.merge_preparation_failure(&mut self.evidence, &observations);
            return Ok((sequence, Vec::new(), DurationAdmission::default()));
        }
        let mut current_parent = parent_index;
        let mut pending_suffix = Vec::new();
        let mut previous_key = None;
        let mut decisions = Vec::new();
        let mut duration = DurationAdmission::default();
        let actions_run = actions.len();
        let terminal = actions
            .last()
            .is_some_and(|action| action.outcome.disposition.is_terminal());
        let parent_place = self.archive.entries[parent_index].key.place();
        let retained_at_start = self.archive.retained;
        let mut left_place = false;
        for action in actions {
            let tracked = tracked_action(&action.action) && !action.outcome.disposition.is_failed();
            duration.applied |= tracked;
            pending_suffix.push(action.action);
            workload.merge_action_evidence(&mut self.evidence, &action, sequence, || {
                let mut input = self
                    .archive
                    .materialize_input(current_parent)
                    .map_err(|error| -> Box<dyn Error> { error.into() })?;
                input.actions.extend_from_slice(&pending_suffix);
                Ok(input)
            })?;
            match action.outcome.disposition {
                crate::search::rollout::ExecutionDisposition::Terminal => {
                    self.terminal_endpoints = self.terminal_endpoints.saturating_add(1);
                    if action.outcome.objective_reached {
                        self.terminal_objectives = self.terminal_objectives.saturating_add(1);
                    }
                }
                crate::search::rollout::ExecutionDisposition::Failed => {
                    self.execution_failures = self.execution_failures.saturating_add(1);
                }
                crate::search::rollout::ExecutionDisposition::Runnable => {}
            }
            if action.outcome.objective_reached {
                duration.useful |= tracked;
                self.objectives_reached = self.objectives_reached.saturating_add(1);
                if self.objective_witness.is_none() {
                    let mut input = self
                        .archive
                        .materialize_input(current_parent)
                        .map_err(|error| -> Box<dyn Error> { error.into() })?;
                    input.actions.extend_from_slice(&pending_suffix);
                    self.objective_witness = Some(input);
                }
                decisions.push(CampaignAdmissionDecision::Objective);
            }
            if let Some(candidate) = action.candidate {
                let completed =
                    workload.complete_candidate_key(candidate.key, &candidate.snapshot)?;
                if !candidate.viable {
                    let key = self.archive.complete_after(
                        Some(current_parent),
                        previous_key,
                        completed,
                    )?;
                    left_place |= key.place() != parent_place;
                    self.probe_refused = self.probe_refused.saturating_add(1);
                    decisions.push(CampaignAdmissionDecision::ProbeRefused);
                    continue;
                }
                let retained_before = self.archive.retained;
                let (admitted, key) = self.archive.insert_after(
                    Some(current_parent),
                    previous_key,
                    sequence,
                    ArchiveCandidate {
                        suffix: pending_suffix.as_slice(),
                        key: completed,
                        milestones: action.milestones,
                    },
                    candidate.snapshot,
                )?;
                left_place |= key.place() != parent_place;
                match admitted {
                    Some(id) if self.archive.retained > retained_before => {
                        duration.useful |= tracked;
                        decisions.push(CampaignAdmissionDecision::Retained {
                            id: self
                                .archive
                                .stable_id(id)
                                .ok_or("retained archive slot is missing")?,
                        });
                        current_parent = id;
                        pending_suffix.clear();
                        previous_key = None;
                    }
                    Some(id) => {
                        decisions.push(CampaignAdmissionDecision::Duplicate {
                            id: self
                                .archive
                                .stable_id(id)
                                .ok_or("duplicate archive slot is missing")?,
                        });
                        current_parent = id;
                        pending_suffix.clear();
                        previous_key = None;
                    }
                    None => {
                        decisions.push(CampaignAdmissionDecision::Rejected);
                        previous_key = Some(key);
                    }
                }
            }
        }
        if limited {
            self.archive.record_suffix_outcome(
                parent_index,
                actions_run,
                self.archive.retained > retained_at_start,
                left_place,
                terminal,
            );
        }
        if sequence.is_multiple_of(self.curve_interval) {
            self.push_curve_point();
            self.compact_progress_curve_if_needed();
        }
        Ok((sequence, decisions, duration))
    }

    fn push_curve_point(&mut self) {
        self.curve.push(ProgressPoint {
            executions: self.sequence,
            milestones: self.aggregate_milestones(),
            progress: self
                .record_progress
                .then(|| G::aggregate_progress(&self.evidence)),
            active_entries: self.archive.active_count(),
            occupied_cells: self.archive.occupied_cell_count(),
            terminal_endpoints: self.terminal_endpoints,
            execution_failures: self.execution_failures,
        });
    }

    fn compact_progress_curve_if_needed(&mut self) {
        if !self.bounded_progress_curve {
            return;
        }
        self.curve_interval = compact_progress_curve(&mut self.curve, self.curve_interval);
    }

    fn aggregate_milestones(&self) -> G::Milestones {
        G::aggregate_milestones(&self.evidence)
    }

    fn finish_curve(&mut self) {
        if self.sequence > 0
            && self.curve.last().map(|point| point.executions) != Some(self.sequence)
        {
            self.push_curve_point();
        }
    }

    fn all_prefixes_archived(&self, parent_index: usize, suffix: &[G::Action]) -> bool {
        !suffix.is_empty() && self.archive.all_extensions_retained(parent_index, suffix)
    }

    pub(crate) fn into_archive_report_and_snapshots(
        mut self,
        workload: &G,
        campaign_seed: u64,
        materialize_final_artifacts: bool,
    ) -> (G::ArchiveReport, Vec<(u64, G::Snapshot)>) {
        let selector = self.archive.selector_report();
        let (entries, snapshots) = if materialize_final_artifacts {
            self.archive.take_entry_reports_and_snapshots()
        } else {
            (Vec::new(), Vec::new())
        };
        let report = workload.archive_report(
            &self.evidence,
            ArchiveReportState {
                seed: campaign_seed,
                executions: self.sequence,
                entries,
                progress_curve: self.curve,
                retained: self.archive.retained,
                rejected: self.archive.rejected,
                terminal_endpoints: self.terminal_endpoints,
                terminal_objectives: self.terminal_objectives,
                execution_failures: self.execution_failures,
                selector,
            },
        );
        (report, snapshots)
    }
}

fn merge_max<G: Workload + ?Sized>(
    workload: &G,
    mut base: G::Milestones,
    other: G::Milestones,
) -> G::Milestones {
    workload.merge_milestones(&mut base, other);
    base
}

fn resolve_origin<G: Workload>(
    workload: &G,
    config: &CampaignConfig<G>,
    origin: &CampaignOrigin<G>,
    search_checkpoint: Option<&CheckpointReader>,
) -> Result<CampaignOriginRecord, Box<dyn Error>> {
    if let CampaignOrigin::SearchCheckpoint { path } = origin {
        let reader = search_checkpoint.ok_or("a search checkpoint origin was not opened")?;
        let checkpoint_policy_changes = search_checkpoint_policy_changes(
            &reader.header,
            &search_checkpoint_header(workload, config, &reader.header.reason, 0, 0, 0, 0),
        )?;
        let path = path.display().to_string();
        let resume_input_sha256 = format!(
            "{:x}",
            Sha256::digest(serde_json::to_vec(&Input::<G::Action>::default())?)
        );
        return Ok(CampaignOriginRecord {
            kind: ORIGIN_SEARCH_CHECKPOINT.to_owned(),
            path: None,
            archive_sha256: None,
            checkpoint_path: Some(path),
            checkpoint_sha256: Some(reader.file_sha256.clone()),
            checkpoint_policy_changes,
            resume_input_sha256,
            resume_actions: 0,
        });
    }
    let (kind, path, archive_sha256, checkpoint, resume_input) = match origin {
        CampaignOrigin::SearchCheckpoint { .. } => {
            return Err("a search checkpoint origin was not opened".into());
        }
        CampaignOrigin::Genesis => (
            ORIGIN_GENESIS.to_owned(),
            None,
            None,
            None,
            Input::default(),
        ),
        CampaignOrigin::SnapshotRoot { checkpoint } => (
            ORIGIN_SNAPSHOT_ROOT.to_owned(),
            None,
            None,
            Some(checkpoint),
            Input::default(),
        ),
        CampaignOrigin::Archive {
            path,
            file_sha256,
            report,
            checkpoint,
        } => (
            ORIGIN_ARCHIVE.to_owned(),
            Some(path.clone()),
            Some(file_sha256.clone()),
            checkpoint.as_ref(),
            workload.resume_input(report)?,
        ),
    };
    let resume_input_sha256 = format!("{:x}", Sha256::digest(serde_json::to_vec(&resume_input)?));
    Ok(CampaignOriginRecord {
        kind,
        path,
        archive_sha256,
        checkpoint_path: checkpoint.map(|checkpoint| checkpoint.path.clone()),
        checkpoint_sha256: checkpoint.map(|checkpoint| checkpoint.file_sha256.clone()),
        checkpoint_policy_changes: BTreeMap::new(),
        resume_input_sha256,
        resume_actions: resume_input.actions.len(),
    })
}

pub const PREFERENCE_PORTFOLIO_PREFIX: &str = "preference_portfolio_v1:";

#[must_use]
pub fn preference_portfolio_identifier<K: ArchiveKey>() -> String {
    format!(
        "{PREFERENCE_PORTFOLIO_PREFIX}{},{}",
        K::preferences(),
        K::capacity().max(1)
    )
}

fn stream_header<G: Workload>(
    workload: &G,
    config: &CampaignConfig<G>,
    origin: &CampaignOriginRecord,
    draw_header: Option<DrawTableHeader>,
) -> CampaignStreamHeader<DrawTableHeader> {
    CampaignStreamHeader {
        schema_version: CAMPAIGN_SCHEMA_VERSION,
        format: workload.stream_format().to_owned(),
        campaign_seed: config.campaign_seed,
        schedule_policy: schedule_policy_identifier(config.window),
        progress_policy: CAMPAIGN_PROGRESS_POLICY.to_owned(),
        host: config.host.clone(),
        origin_kind: origin.kind.clone(),
        origin_path: origin.path.clone(),
        origin_archive_sha256: origin.archive_sha256.clone(),
        origin_checkpoint_path: origin.checkpoint_path.clone(),
        origin_checkpoint_sha256: origin.checkpoint_sha256.clone(),
        origin_checkpoint_policy_changes: origin.checkpoint_policy_changes.clone(),
        resume_input_sha256: origin.resume_input_sha256.clone(),
        resume_actions: origin.resume_actions,
        execution_budget: config.execution_budget,
        stop_rollout_on_objective: config.stop_rollout_on_objective,
        stop_campaign_on_objective: config.stop_campaign_on_objective,
        work_budget: None,
        wall_budget_seconds: config.wall_budget.map(|budget| budget.as_secs()),
        archive_entry_limit: config.archive_entry_limit,
        memory_budget_mib: config.memory_budget_mib,
        resume_policy: if origin.kind == ORIGIN_SNAPSHOT_ROOT {
            SNAPSHOT_ROOT_RESUME_IDENTIFIER.to_owned()
        } else {
            RESUME_IDENTIFIER.to_owned()
        },
        mixture_policy: draw_mixture_identifier(config.mixture),
        workload_policies: recorded_policies(workload, &config.run),
        draw_header,
        retention_policy: retention_policy_identifier(config.retention).to_owned(),
        parent_scheduler: SELECTOR_IDENTIFIER.to_owned(),
        preference_portfolio: preference_portfolio_identifier::<G::Key>(),
        executor_mode: "snapshot_resume_archive".to_owned(),
        selection_seed_derivation: "sha256(campaign_seed_le)[0..8] as u64 le".to_owned(),
        workload_identity_sha256: workload.workload_identity_sha256(),
        action_cost_unit: workload.action_cost_unit().to_owned(),
        execution_work_unit: workload.execution_work_unit().to_owned(),
    }
}

struct StreamWriter<'a> {
    sink: &'a mut dyn Write,
    hasher: Sha256,
}

impl<'a> StreamWriter<'a> {
    fn new(sink: &'a mut dyn Write) -> Self {
        Self {
            sink,
            hasher: Sha256::new(),
        }
    }

    fn write_line<T: Serialize>(&mut self, value: &T) -> Result<(), Box<dyn Error>> {
        let mut line = serde_json::to_vec(value)?;
        line.push(b'\n');
        self.sink.write_all(&line)?;
        self.hasher.update(&line);
        Ok(())
    }

    fn finish(self) -> Result<String, Box<dyn Error>> {
        self.sink.flush()?;
        Ok(format!("{:x}", self.hasher.finalize()))
    }
}

#[derive(Deserialize, Serialize)]
struct CampaignCounters {
    bootstrap_execution_work: u64,
    #[serde(with = "crate::search::checkpoint::json_bytes")]
    tree_import: Option<TreeImportCounts>,
    job_execution_work: u64,
    work_to_first_objective: Option<u64>,
    executions_to_first_objective: Option<u64>,
    duplicates_skipped: u64,
    draw_state_memory_bytes: usize,
}

fn execution_work_delta(before: u64, after: u64, scope: &str) -> Result<u64, Box<dyn Error>> {
    after
        .checked_sub(before)
        .ok_or_else(|| format!("{scope} execution-work counter rewound").into())
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
struct DurationAdmission {
    applied: bool,
    useful: bool,
}

struct DurationAdmissionRecord<C> {
    sequence: u64,
    context: C,
    before: Option<DurationCheckpoint>,
    evicted: Option<DurationContextCheckpoint<C>>,
}

fn duration_checkpoint_at_reservation<C: Copy + Ord>(
    policies: &DurationPolicies<C>,
    admissions: &VecDeque<DurationAdmissionRecord<C>>,
    context: C,
    sequence: u64,
) -> Option<DurationCheckpoint> {
    for admission in admissions
        .iter()
        .filter(|admission| admission.sequence > sequence)
    {
        if admission.context == context {
            return admission.before.clone();
        }
        if admission
            .evicted
            .as_ref()
            .is_some_and(|evicted| evicted.context == context)
        {
            return admission
                .evicted
                .as_ref()
                .map(|evicted| evicted.history.clone());
        }
    }
    policies.context_checkpoint(context)
}

#[allow(clippy::too_many_arguments)]
fn validate_duration_reservation<C>(
    draw: Option<&DurationDraw<C>>,
    admission_sequence: Option<u64>,
    recorded_remaining_work: Option<NonZeroU64>,
    current_sequence: u64,
    selection_sequence: u64,
    campaign_work_budget: Option<u64>,
    current_work: u64,
    work_history: &VecDeque<(u64, u64)>,
) -> Result<Option<NonZeroU64>, Box<dyn Error>> {
    let Some(_draw) = draw else {
        if admission_sequence.is_some() {
            return Err("duration reservation sequence is missing its duration choice".into());
        }
        if recorded_remaining_work.is_some() {
            return Err("recorded stream carries remaining duration work without a choice".into());
        }
        return Ok(None);
    };
    let Some(admission_sequence) = admission_sequence else {
        return Err("recorded duration choice is missing its admission sequence".into());
    };
    if admission_sequence > current_sequence {
        return Err("duration choice claims a future admission sequence".into());
    }
    if admission_sequence != selection_sequence {
        return Err("duration choice was not drawn at its selection point".into());
    }
    let work_at_draw = if admission_sequence == current_sequence {
        Some(current_work)
    } else {
        work_history
            .iter()
            .find(|(sequence, _)| *sequence == admission_sequence)
            .map(|(_, work)| *work)
    }
    .ok_or("duration choice has no reconstructed reservation work")?;
    let expected_remaining_work = campaign_work_budget
        .and_then(|budget| NonZeroU64::new(budget.saturating_sub(work_at_draw)));
    if expected_remaining_work != recorded_remaining_work {
        return Err("recorded duration work diverges from its reservation sequence".into());
    }
    Ok(expected_remaining_work)
}

fn verify_duration_draw(
    draw: &DurationDraw<impl Copy>,
    checkpoint: Option<&DurationCheckpoint>,
    mutation_seed: u64,
) -> Result<(), Box<dyn Error>> {
    let policy = match checkpoint {
        Some(checkpoint) => DurationPolicy::from_checkpoint(checkpoint.clone())?,
        None => DurationPolicy::new(),
    };
    let mut rand = RomuDuoJrRand::with_seed(mutation_seed);
    let expected = policy.draw(&mut rand, draw.max_duration);
    if expected != draw.duration.get() {
        return Err("recorded duration choice diverges from its draw-time policy state".into());
    }
    Ok(())
}

fn validate_duration_draw<G: Workload + ?Sized>(
    workload: &G,
    run: &G::Run,
    parent: G::Key,
    campaign_work_budget: Option<u64>,
    remaining_work: Option<NonZeroU64>,
    recorded: Option<DurationDraw<G::Key>>,
) -> Result<Option<DurationDraw<G::Key>>, Box<dyn Error>> {
    if let Some(remaining_work) = remaining_work {
        let Some(campaign_work_budget) = campaign_work_budget else {
            return Err("recorded duration work has no campaign budget".into());
        };
        if remaining_work.get() > campaign_work_budget {
            return Err("recorded duration work exceeds its campaign budget".into());
        }
    }
    let request = workload.duration_request(run, parent, remaining_work);
    match (request, recorded) {
        (None, None) => Ok(None),
        (Some(_), None) => Err("recorded stream is missing its duration choice".into()),
        (None, Some(_)) => Err("recorded stream carries an unexpected duration choice".into()),
        (Some(request), Some(draw)) => {
            if draw.context != request.context {
                return Err("recorded duration context diverges from the workload request".into());
            }
            if draw.max_duration != request.max_duration {
                return Err("recorded duration maximum diverges from the workload request".into());
            }
            if draw.duration > draw.max_duration || !draw.duration.get().is_power_of_two() {
                return Err("recorded duration choice is outside its bounded alphabet".into());
            }
            Ok(Some(draw))
        }
    }
}

#[derive(Default, Deserialize, Serialize)]
struct LiveCoordinatorProfile {
    receive_wait_ns: u128,
    admission_ns: u128,
    bookkeeping_ns: u128,
    history_compaction_ns: u128,
    stream_write_ns: u128,
    selection_ns: u128,
    receives: u64,
    admissions: u64,
    selections: u64,
    replay_jobs: u64,
    replay_actions: u64,
    replay_cost: u64,
    suffix_actions: u64,
    suffix_cost: u64,
    splice_jobs: u64,
    splice_actions: u64,
    splice_cost: u64,
}

impl LiveCoordinatorProfile {
    fn note_dispatch<G: Workload + ?Sized>(
        &mut self,
        spec: &JobSpec<G>,
        spliced: bool,
        cost: fn(&G::Action) -> u64,
    ) {
        let total = |actions: &[G::Action]| actions.iter().map(cost).sum::<u64>();
        if !spec.replay.is_empty() {
            self.replay_jobs = self.replay_jobs.saturating_add(1);
        }
        self.replay_actions = self
            .replay_actions
            .saturating_add(u64::try_from(spec.replay.len()).unwrap_or(u64::MAX));
        self.replay_cost = self.replay_cost.saturating_add(total(&spec.replay));
        self.suffix_actions = self
            .suffix_actions
            .saturating_add(u64::try_from(spec.suffix.len()).unwrap_or(u64::MAX));
        self.suffix_cost = self.suffix_cost.saturating_add(total(&spec.suffix));
        if spliced {
            self.splice_jobs = self.splice_jobs.saturating_add(1);
            self.splice_actions = self
                .splice_actions
                .saturating_add(u64::try_from(spec.suffix.len()).unwrap_or(u64::MAX));
            self.splice_cost = self.splice_cost.saturating_add(total(&spec.suffix));
        }
    }
}

fn record_compaction_elapsed(
    profile: &mut LiveCoordinatorProfile,
    before: u64,
    after: u64,
    elapsed_ns: u128,
) {
    if after > before {
        profile.history_compaction_ns = profile.history_compaction_ns.saturating_add(elapsed_ns);
    }
}

fn profile_now() -> Instant {
    now()
}

fn profile_elapsed(started: Instant) -> u128 {
    started.elapsed().as_nanos()
}

impl CampaignCounters {
    fn note_first_objective(&mut self, sequence: u64) {
        if self.work_to_first_objective.is_none() {
            self.work_to_first_objective = Some(
                self.bootstrap_execution_work
                    .saturating_add(self.job_execution_work),
            );
            self.executions_to_first_objective = Some(sequence);
        }
    }

    fn new() -> Self {
        Self {
            bootstrap_execution_work: 0,
            tree_import: None,
            job_execution_work: 0,
            work_to_first_objective: None,
            executions_to_first_objective: None,
            duplicates_skipped: 0,
            draw_state_memory_bytes: 0,
        }
    }
}

fn build_report<G: Workload>(
    workload: &G,
    header: &CampaignStreamHeader<DrawTableHeader>,
    origin: CampaignOriginRecord,
    core: CoordinatorCore<G>,
    counters: &CampaignCounters,
    stream_sha256: String,
    materialize_final_artifacts: bool,
) -> CampaignOutcome<G> {
    let executions_completed = core.sequence;
    let probe_refused = core.probe_refused;
    let terminal_endpoints = core.terminal_endpoints;
    let terminal_objectives = core.terminal_objectives;
    let execution_failures = core.execution_failures;
    let objectives_reached = core.objectives_reached;
    let objective_witness = core.objective_witness.clone();
    let replacement_cost_displaced = core.archive.replacement_cost_displaced();
    let snapshot_evictions = core.archive.snapshot_evictions();
    let resident_snapshot_bytes = core.archive.resident_snapshot_bytes();
    let history_memory_bytes = core.archive.history_memory_bytes();
    let draw_state_memory_bytes = counters.draw_state_memory_bytes;
    let resident_memory_bytes = core
        .archive
        .resident_memory_bytes()
        .saturating_add(draw_state_memory_bytes);
    let live_entries = core.archive.live_entry_count();
    let history_compactions = core.archive.history_compactions();
    #[cfg(test)]
    let liveness_anchor_reactivations = core.archive.liveness_anchor_reactivations();
    let historical_entries_dropped = core.archive.historical_entries_dropped();
    let input_reconstructions = core.archive.input_reconstructions();
    let input_index_nodes = core.archive.input_index_nodes();
    let historical_cells = core.archive.historical_cell_count();
    let (archive, snapshots) = core.into_archive_report_and_snapshots(
        workload,
        header.campaign_seed,
        materialize_final_artifacts,
    );
    let checkpoint = SnapshotCheckpoint {
        format: workload.checkpoint_format().to_owned(),
        entries: snapshots
            .into_iter()
            .map(|(id, snapshot)| SnapshotCheckpointEntry { id, snapshot })
            .collect(),
    };
    let report = CampaignModeReport {
        mode: "campaign".to_owned(),
        campaign_seed: header.campaign_seed,
        window: schedule_policy_window(&header.schedule_policy).unwrap_or_default(),
        host: header.host.clone(),
        schedule_identity: CAMPAIGN_SCHEDULE_IDENTITY.to_owned(),
        origin,
        execution_budget: header.execution_budget,
        stop_rollout_on_objective: header.stop_rollout_on_objective,
        stop_campaign_on_objective: header.stop_campaign_on_objective,
        work_budget: header.work_budget,
        executions_completed,
        executions_to_first_objective: counters.executions_to_first_objective,
        wall_budget_seconds: header.wall_budget_seconds,
        archive_entry_limit: header.archive_entry_limit,
        memory_budget_mib: header.memory_budget_mib,
        resume_policy: header.resume_policy.clone(),
        mixture_policy: header.mixture_policy.clone(),
        workload_policies: header.workload_policies.clone(),
        retention_policy: header.retention_policy.clone(),
        parent_scheduler: header.parent_scheduler.clone(),
        executor_mode: header.executor_mode.clone(),
        selection_seed_derivation: header.selection_seed_derivation.clone(),
        workload_identity_sha256: header.workload_identity_sha256.clone(),
        action_cost_unit: header.action_cost_unit.clone(),
        execution_work_unit: header.execution_work_unit.clone(),
        bootstrap_execution_work: counters.bootstrap_execution_work,
        tree_import: counters.tree_import,
        execution_work: counters
            .bootstrap_execution_work
            .saturating_add(counters.job_execution_work),
        work_to_first_objective: counters.work_to_first_objective,
        duplicates_skipped: counters.duplicates_skipped,
        probe_refused,
        terminal_endpoints,
        terminal_objectives,
        execution_failures,
        objectives_reached,
        objective_witness,
        replacement_cost_displaced,
        snapshot_evictions,
        resident_snapshot_bytes,
        history_memory_bytes,
        draw_state_memory_bytes,
        resident_memory_bytes,
        live_entries,
        history_compactions,
        #[cfg(test)]
        liveness_anchor_reactivations,
        historical_entries_dropped,
        input_reconstructions,
        input_index_nodes,
        historical_cells,
        stream_sha256,
        archive,
        telemetry: CampaignTelemetry::default(),
    };
    (report, checkpoint)
}

struct PostcardSha256(Sha256);

impl postcard::ser_flavors::Flavor for PostcardSha256 {
    type Output = sha2::digest::Output<Sha256>;

    fn try_extend(&mut self, data: &[u8]) -> postcard::Result<()> {
        self.0.update(data);
        Ok(())
    }

    fn try_push(&mut self, data: u8) -> postcard::Result<()> {
        self.0.update([data]);
        Ok(())
    }

    fn finalize(self) -> postcard::Result<Self::Output> {
        Ok(self.0.finalize())
    }
}

pub fn postcard_result_sha256<G: Workload + ?Sized>(
    result: &CampaignJobResult<G>,
) -> Result<String, Box<dyn Error>> {
    postcard_value_sha256(result)
}

pub fn postcard_value_sha256<T: Serialize + ?Sized>(value: &T) -> Result<String, Box<dyn Error>> {
    let digest = postcard::serialize_with_flavor::<_, PostcardSha256, sha2::digest::Output<Sha256>>(
        value,
        PostcardSha256(Sha256::new()),
    )?;
    Ok(format!("{digest:x}"))
}

struct JobSpec<G: Workload + ?Sized> {
    reservation: usize,
    snapshot: Arc<G::Snapshot>,
    replay: Vec<G::Action>,
    parent_milestones: G::Milestones,
    suffix: Vec<G::Action>,
}

type SelectedJob<G> = (JobSpec<G>, PendingJob<G>);

fn planned_finish<G: Workload + ?Sized>(
    clock: u64,
    spec: &JobSpec<G>,
    cost: fn(&G::Action) -> u64,
) -> u64 {
    spec.replay
        .iter()
        .chain(&spec.suffix)
        .map(cost)
        .fold(clock, u64::saturating_add)
}

#[derive(Deserialize, Serialize)]
#[serde(bound = "")]
struct JobSpecRecord<G: Workload + ?Sized> {
    replay: Vec<G::Action>,
    parent_milestones: G::Milestones,
    suffix: Vec<G::Action>,
}

impl<G: Workload + ?Sized> JobSpecRecord<G> {
    fn of(spec: &JobSpec<G>) -> Self {
        Self {
            replay: spec.replay.clone(),
            parent_milestones: spec.parent_milestones,
            suffix: spec.suffix.clone(),
        }
    }
}

#[derive(Serialize)]
#[serde(bound = "")]
struct InFlightJobRef<'a, G: Workload + ?Sized> {
    reservation: usize,
    spec: &'a JobSpecRecord<G>,
    pending: &'a PendingJob<G>,
}

#[derive(Deserialize)]
#[serde(bound = "")]
struct InFlightJob<G: Workload + ?Sized> {
    reservation: usize,
    spec: JobSpecRecord<G>,
    pending: PendingJob<G>,
}

#[derive(Deserialize, Serialize)]
#[serde(bound = "")]
struct CoreCheckpoint<G: Workload + ?Sized> {
    #[serde(with = "crate::search::checkpoint::json_bytes")]
    curve: Vec<ProgressPoint<G::Milestones, G::Progress>>,
    curve_interval: u64,
    bounded_progress_curve: bool,
    record_progress: bool,
    terminal_endpoints: u64,
    terminal_objectives: u64,
    execution_failures: u64,
    objectives_reached: u64,
    objective_witness: Option<Input<G::Action>>,
    sequence: u64,
    probe_refused: u64,
    mixture_energy: MixtureEnergy,
}

struct SearchResume<G: Workload + ?Sized> {
    rand: RomuDuoJrRand,
    reserved: u64,
    admitted: usize,
    planned_clock: u64,
    profile: LiveCoordinatorProfile,
    in_flight: Vec<InFlightJob<G>>,
}

#[derive(Deserialize, Serialize)]
#[serde(bound = "")]
struct PendingJob<G: Workload + ?Sized> {
    snapshot_id: u64,
    parent_id: u64,
    continuation_energy: Option<u16>,
    continuation_wave: u32,
    continuation_edge: Option<Edge<G::Key>>,
    mutation_seed: u64,
    mixture_weight: u8,
    splice_weight: u8,
    #[serde(with = "crate::search::checkpoint::json_bytes")]
    splice: Option<CampaignSpliceRecord>,
    #[serde(with = "crate::search::checkpoint::json_bytes")]
    selector: SelectorDraw,
    draw_checkpoint_before: Option<EmpiricalStepCheckpoint>,
    duration_draw: Option<DurationDraw<G::Key>>,
    duration_admission_sequence_at_draw: Option<u64>,
    duration_remaining_work: Option<NonZeroU64>,
    duration_checkpoint_at_draw: Option<DurationCheckpoint>,
    suffix_limit: Option<u8>,
    planned_finish: u64,
}

struct CompletedJob<G: Workload + ?Sized> {
    held_since: Option<std::time::Instant>,
    pending: PendingJob<G>,
    result: CampaignJobResult<G>,
    execution_work: u64,
    result_sha256: String,
}

fn replay_suffix_limit(drawn: bool, recorded: Option<u8>) -> Result<Option<u8>, Box<dyn Error>> {
    match (drawn, recorded) {
        (true, Some(limit)) if (1..=SUFFIX_DOUBLING_LIMIT).contains(&limit) => Ok(Some(limit)),
        (false, None) => Ok(None),
        _ => Err("recorded suffix limit does not match the drawn suffix".into()),
    }
}

fn replay_splice<G: CampaignTypes>(
    strategy: EnergyStrategy,
    recorded: Option<CampaignSpliceRecord>,
) -> Result<Option<Vec<G::Action>>, Box<dyn Error>> {
    if strategy != EnergyStrategy::Splice {
        if recorded.is_some() {
            return Err("non-splice draw carries splice resolution evidence".into());
        }
        return Ok(None);
    }
    match recorded {
        Some(CampaignSpliceRecord::Unavailable) => Ok(None),
        Some(CampaignSpliceRecord::Tail { tail_postcard, .. }) => {
            let tail: Vec<G::Action> = postcard::from_bytes(&tail_postcard)?;
            if tail.is_empty() || tail.len() > LONGEST_SPLICE_TAIL {
                return Err("recorded splice tail length is outside the bound".into());
            }
            Ok(Some(tail))
        }
        None => Err("splice draw lacks resolution evidence".into()),
    }
}

#[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
#[serde(bound = "K: Serialize + DeserializeOwned")]
pub struct CampaignProgressRecord<K> {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub workload_diagnostics: Option<serde_json::Value>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub retained_diagnostics: Option<serde_json::Value>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub progress: Option<serde_json::Value>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub milestones: Option<serde_json::Value>,
    #[serde(default)]
    pub objectives_reached: u64,
    #[serde(default)]
    pub terminal_endpoints: u64,
    #[serde(default)]
    pub terminal_objectives: u64,
    #[serde(default)]
    pub execution_failures: u64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub search_elapsed_millis: Option<u64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub coordinator: Option<serde_json::Value>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub host_times: Option<HostTimes>,
    pub unix_time: u64,
    pub executions: u64,
    #[serde(default)]
    pub execution_work: u64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub deepest_key: Option<K>,
    pub cheapest_cost_in_group: u64,
    pub retained: u64,
    #[serde(default)]
    pub active_entries: usize,
    #[serde(default)]
    pub resident_snapshots: usize,
    #[serde(default)]
    pub resident_snapshot_bytes: usize,
    #[serde(default)]
    pub history_memory_bytes: usize,
    #[serde(default)]
    pub draw_state_memory_bytes: usize,
    #[serde(default)]
    pub entry_metadata_memory_bytes: usize,
    #[serde(default)]
    pub input_index_memory_bytes: usize,
    #[serde(default)]
    pub cell_memory_bytes: usize,
    #[serde(default)]
    pub resident_memory_bytes: usize,
    #[serde(default)]
    pub snapshot_evictions: u64,
    #[serde(default)]
    pub entry_drops: u64,
    #[serde(default)]
    pub live_entries: usize,
    #[serde(default)]
    pub history_compactions: u64,
    #[serde(default)]
    pub historical_entries_dropped: u64,
    #[serde(default)]
    pub input_reconstructions: u64,
    #[serde(default)]
    pub input_index_nodes: usize,
    #[serde(default)]
    pub historical_cells: usize,
    #[serde(default)]
    pub selector: SelectorAccounting,
    #[serde(default)]
    pub continuations: ContinuationAccounting,
}

fn write_live_progress<G: Workload>(
    core: &CoordinatorCore<G>,
    counters: &CampaignCounters,
    profile: Option<(&LiveCoordinatorProfile, HostTimes)>,
    draw_state_memory_bytes: usize,
    telemetry_started: Instant,
    final_census: bool,
    sink: &mut dyn Write,
) -> Result<(), Box<dyn Error>> {
    let sequence = core.sequence;
    #[allow(clippy::disallowed_methods)]
    let unix_time = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |since| since.as_secs());
    let (deepest_key, cheapest, retained) = core
        .archive
        .live_progress()
        .map(|(key, cheapest, retained)| (Some(key), cheapest, retained))
        .unwrap_or((None, 0, 0));
    let line = serde_json::to_string(&CampaignProgressRecord {
        workload_diagnostics: G::diagnostics(&core.evidence),
        retained_diagnostics: final_census
            .then(|| G::retained_diagnostics(core.archive.retained_snapshots()))
            .flatten(),
        coordinator: profile
            .map(|(coordinator, _)| serde_json::to_value(coordinator))
            .transpose()?,
        host_times: profile.map(|(_, host_times)| host_times),
        progress: Some(serde_json::to_value(G::aggregate_progress(&core.evidence))?),
        milestones: Some(serde_json::to_value(core.aggregate_milestones())?),
        objectives_reached: core.objectives_reached,
        terminal_endpoints: core.terminal_endpoints,
        terminal_objectives: core.terminal_objectives,
        execution_failures: core.execution_failures,
        search_elapsed_millis: Some(telemetry_started)
            .map(|at| u64::try_from(at.elapsed().as_millis()).unwrap_or(u64::MAX)),
        unix_time,
        executions: sequence,
        execution_work: counters
            .bootstrap_execution_work
            .saturating_add(counters.job_execution_work),
        deepest_key,
        cheapest_cost_in_group: cheapest,
        retained,
        active_entries: core.archive.active_count(),
        resident_snapshots: core.archive.resident_snapshot_count(),
        resident_snapshot_bytes: core.archive.resident_snapshot_bytes(),
        history_memory_bytes: core.archive.history_memory_bytes(),
        draw_state_memory_bytes,
        entry_metadata_memory_bytes: core.archive.entry_metadata_memory_bytes(),
        input_index_memory_bytes: core.archive.input_index_memory_bytes(),
        cell_memory_bytes: core.archive.cell_memory_bytes(),
        resident_memory_bytes: core
            .archive
            .resident_memory_bytes()
            .saturating_add(draw_state_memory_bytes),
        snapshot_evictions: core.archive.snapshot_evictions(),
        entry_drops: core.archive.entry_drops(),
        live_entries: core.archive.live_entry_count(),
        history_compactions: core.archive.history_compactions(),
        historical_entries_dropped: core.archive.historical_entries_dropped(),
        input_reconstructions: core.archive.input_reconstructions(),
        input_index_nodes: core.archive.input_index_nodes(),
        historical_cells: core.archive.historical_cell_count(),
        selector: if final_census || full_selector_report_due(sequence) {
            core.archive.selector_report()
        } else {
            core.archive.selector_counters()
        },
        continuations: core.archive.continuation_report(),
    })?;
    sink.write_all(line.as_bytes())?;
    sink.write_all(b"\n")?;
    sink.flush()?;
    Ok(())
}

fn bootstrap_core<G: Workload>(
    workload: &G,
    run: &G::Run,
    core: &mut CoordinatorCore<G>,
    target: &mut G::Target,
    origin: &CampaignOrigin<G>,
) -> Result<Option<TreeImportCounts>, Box<dyn Error>> {
    match origin {
        CampaignOrigin::Archive {
            report, checkpoint, ..
        } => Ok(Some(core.import_tree(
            workload,
            run,
            target,
            report,
            checkpoint.as_ref().map(|checkpoint| &checkpoint.snapshots),
        )?)),
        CampaignOrigin::Genesis => {
            core.bootstrap(workload, run, target)?;
            Ok(None)
        }
        CampaignOrigin::SnapshotRoot { checkpoint } => {
            core.bootstrap_snapshot_root(workload, run, target, checkpoint)?;
            Ok(None)
        }
        CampaignOrigin::SearchCheckpoint { .. } => {
            Err("a search checkpoint restores its archive instead of bootstrapping one".into())
        }
    }
}

fn validate_snapshot_root_checkpoint<'a, G: Workload + ?Sized>(
    workload: &G,
    checkpoint: &'a CampaignCheckpoint<G::Snapshot>,
) -> Result<&'a G::Snapshot, Box<dyn Error>> {
    if checkpoint.path.is_empty() {
        return Err("snapshot-root checkpoint logical path is empty".into());
    }
    if checkpoint.file_sha256.len() != 64
        || !checkpoint
            .file_sha256
            .bytes()
            .all(|byte| byte.is_ascii_hexdigit())
    {
        return Err("snapshot-root checkpoint SHA-256 is malformed".into());
    }
    if checkpoint.snapshots.format != workload.checkpoint_format() {
        return Err("snapshot-root checkpoint format is not recognized".into());
    }
    let [entry] = checkpoint.snapshots.entries.as_slice() else {
        return Err("snapshot-root checkpoint must contain exactly one entry".into());
    };
    if entry.id != 0 {
        return Err("snapshot-root checkpoint entry id is not zero".into());
    }
    let actual_sha256 = format!("{:x}", Sha256::digest(checkpoint.snapshots.to_bytes()?));
    if checkpoint.file_sha256 != actual_sha256 {
        return Err("snapshot-root checkpoint bytes do not match their SHA-256".into());
    }
    Ok(&entry.snapshot)
}

pub fn run_campaign_checkpointed<G: Workload>(
    workload: &G,
    config: &CampaignConfig<G>,
    origin: &CampaignOrigin<G>,
    stream: &mut dyn Write,
    progress: Option<&mut dyn Write>,
) -> Result<CampaignOutcome<G>, Box<dyn Error>>
where
    G::ArchiveReport: Serialize,
{
    run_campaign_checkpointed_with_options(
        workload,
        config,
        origin,
        stream,
        progress,
        CampaignExecutionOptions::default(),
    )
}

#[allow(clippy::too_many_lines)]
pub fn run_campaign_checkpointed_with_options<G: Workload>(
    workload: &G,
    config: &CampaignConfig<G>,
    origin: &CampaignOrigin<G>,
    stream: &mut dyn Write,
    mut progress: Option<&mut dyn Write>,
    options: CampaignExecutionOptions,
) -> Result<CampaignOutcome<G>, Box<dyn Error>>
where
    G::ArchiveReport: Serialize,
{
    let work_budget = options.work_budget;
    let placement = options.placement.as_ref();
    let duration_memory_reserve = DurationPolicies::<G::Key>::memory_reserve_bytes();
    if work_budget == Some(0) {
        return Err("work budget must be nonzero".into());
    }
    if config.workers == 0 {
        return Err("campaign mode requires at least one worker".into());
    }
    if !archive_entry_limit_is_valid(config.archive_entry_limit) {
        return Err("campaign archive entry limit is outside its bounded range".into());
    }
    if config.window == 0 {
        return Err("campaign admission window must hold at least one reservation".into());
    }
    if config.memory_budget_mib == Some(0) {
        return Err("campaign memory budget must be nonzero".into());
    }
    if let Some(memory_budget_mib) = config.memory_budget_mib {
        let budget = memory_budget_mib.saturating_mul(1024 * 1024);
        if budget
            <= workload
                .draw_state_memory_reserve_bytes(&config.run)
                .saturating_add(duration_memory_reserve)
        {
            return Err("campaign memory budget is too small for the bounded draw state".into());
        }
    }
    let mut search_checkpoint = match origin {
        CampaignOrigin::SearchCheckpoint { path } => Some(CheckpointReader::open(path)?),
        _ => None,
    };
    let origin_record = resolve_origin(workload, config, origin, search_checkpoint.as_ref())?;
    let draw_origin = match origin {
        CampaignOrigin::Genesis => None,
        CampaignOrigin::SnapshotRoot { .. } => None,
        CampaignOrigin::SearchCheckpoint { .. } => None,
        CampaignOrigin::Archive {
            file_sha256,
            report,
            ..
        } => Some((file_sha256.as_str(), report.as_ref())),
    };
    let (mut draw_state, draw_header) = initial_draw_state(workload, &config.run, draw_origin)?;
    let mut duration_policies = DurationPolicies::<G::Key>::new();
    if !memory_is_within_reserve(
        workload.draw_state_memory_bytes(&draw_state),
        workload.draw_state_memory_reserve_bytes(&config.run),
    ) {
        return Err("initial draw state exceeds its deterministic memory reserve".into());
    }
    let mut header = stream_header(workload, config, &origin_record, draw_header);
    header.work_budget = work_budget;
    let mut writer = StreamWriter::new(stream);
    writer.write_line(&header)?;

    let mut core = CoordinatorCore::new(
        workload,
        &config.run,
        config.archive_entry_limit,
        config.memory_budget_mib,
    );
    let mut counters = CampaignCounters::new();
    let mut telemetry = CampaignTelemetry::default();
    let workers = config.workers as usize;
    let mut rand = RomuDuoJrRand::with_seed(derive_selection_seed(config.campaign_seed));

    #[allow(clippy::disallowed_methods)]
    let mut telemetry_started = std::time::Instant::now();
    let mut reserved = 0_u64;
    let profile_printed = std::env::var_os("HARMONY_COORDINATOR_PROFILE").is_some();
    let mut coordinator_profile = LiveCoordinatorProfile::default();
    let (bootstrapped, first_worker_start) = mpsc::channel::<()>();
    let first_worker_start = Mutex::new(first_worker_start);
    let mut spec_records = BTreeMap::<usize, JobSpecRecord<G>>::new();
    let action_cost = workload.action_cost_fn();

    let retention = config.retention;
    let mut admission = telemetry.admission.clone();
    let mut idle_clock = IdleClock::new(workers);
    let mut coordinator_schedstat = None;
    let ((), worker_telemetry) = with_worker_pool(
        config.workers,
        |worker| {
            if worker == 0 {
                first_worker_start
                    .lock()
                    .map_err(|_| "the first worker's start signal lock was poisoned".to_owned())?
                    .recv()
                    .map_err(|_| "the campaign stopped before its bootstrap finished".to_owned())?;
            }
            ThreadPlacement::place(placement, PlacedThread::Worker(worker))?;
            workload.new_target()
        },
        |target, spec: JobSpec<G>| {
            let reservation = spec.reservation;
            let work_before = workload.execution_work(target);
            workload
                .execute_job(
                    &config.run,
                    target,
                    &spec.snapshot,
                    &spec.replay,
                    spec.parent_milestones,
                    &spec.suffix,
                    retention,
                    config.stop_rollout_on_objective,
                )
                .and_then(|result| {
                    let result_sha256 = workload
                        .result_sha256(&result)
                        .map_err(|error| error.to_string())?;
                    let execution_work = execution_work_delta(
                        work_before,
                        workload.execution_work(target),
                        "worker",
                    )?;
                    Ok((reservation, result, execution_work, result_sha256))
                })
                .map_err(|error| error.to_string())
        },
        |target| workload.telemetry(target),
        |pool| -> Result<(), Box<dyn Error>> {
            ThreadPlacement::place(placement, PlacedThread::Coordinator)?;
            let bootstrap_started = now();
            let resume = match search_checkpoint.take() {
                Some(reader) => Some(restore_search_checkpoint(
                    workload,
                    config,
                    reader,
                    &mut core,
                    &mut draw_state,
                    &mut duration_policies,
                    &mut counters,
                )?),
                None => {
                    bootstrap_campaign(
                        workload,
                        config,
                        origin,
                        &mut core,
                        &draw_state,
                        &duration_policies,
                        &mut counters,
                    )?;
                    None
                }
            };
            telemetry.bootstrap_ns = nanos_since(bootstrap_started);
            if let (Some(path), Some(input)) =
                (&config.objective_witness_path, &core.objective_witness)
            {
                std::fs::write(path, serde_json::to_vec_pretty(input)?)?;
            }

            bootstrapped.send(())?;
            drop(bootstrapped);
            #[allow(clippy::disallowed_methods)]
            let search_started = std::time::Instant::now();
            telemetry_started = search_started;
            let started = config.wall_budget.map(|_| telemetry_started);
            let mut admitted = 0_usize;
            let mut planned_clock = 0_u64;
            let mut resumed_in_flight = None;
            if let Some(resume) = resume {
                rand = resume.rand;
                reserved = resume.reserved;
                coordinator_profile = resume.profile;
                admitted = resume.admitted;
                planned_clock = resume.planned_clock;
                resumed_in_flight = Some(resume.in_flight);
            }
            let mut checkpoints = options
                .checkpoints
                .clone()
                .map(|plan| {
                    CheckpointWriter::create(
                        plan,
                        G::checkpoint_marks(&core.evidence),
                        core.archive.top_progress(),
                    )
                })
                .transpose()?;
            idle_clock = IdleClock::new(workers);
            coordinator_schedstat = thread_schedstat();
            let select = |core: &mut CoordinatorCore<G>,
                          rand: &mut RomuDuoJrRand,
                          draw_state: &mut DrawTables<G::Action>,
                          duration_policies: &DurationPolicies<G::Key>,
                          writer: &mut StreamWriter<'_>,
                          counters: &mut CampaignCounters,
                          reserved: &mut u64|
             -> Result<Option<SelectedJob<G>>, Box<dyn Error>> {
                if *reserved >= config.execution_budget
                    || work_budget.is_some_and(|budget| {
                        counters
                            .bootstrap_execution_work
                            .saturating_add(counters.job_execution_work)
                            >= budget
                    })
                    || stop_reservations_after_objective(
                        config.stop_campaign_on_objective,
                        core.objective_witness.is_some(),
                    )
                {
                    return Ok(None);
                }
                if let (Some(started), Some(wall_budget)) = (started, config.wall_budget)
                    && started.elapsed() >= wall_budget
                {
                    return Ok(None);
                }
                let mut consecutive_skips = 0_u64;
                let (continuation_energy, continuation) =
                    continuation_attempt(core, config.campaign_seed, *reserved);
                if let Some(continuation) = continuation {
                    let parent_index = continuation.parent_index;
                    let suffix = continuation.suffix;
                    let (mixture_weight, splice_weight) = (0, u8::MAX);
                    let mut mutation_seed = rand.next_u64();
                    while energy_strategy(mutation_seed, mixture_weight, splice_weight)?
                        != EnergyStrategy::Splice
                    {
                        mutation_seed = rand.next_u64();
                    }
                    let parent_id = continuation.parent_id;
                    let selector = SelectorDraw {
                        path: SelectorPath::Continuation,
                        tier_rank: None,
                        best_preference: None,
                    };
                    let draw_checkpoint_before = workload.draw_checkpoint(draw_state)?;
                    let splice = Some(CampaignSpliceRecord::Tail {
                        donor_id: continuation.donor,
                        leaf_id: continuation.leaf,
                        tail_postcard: postcard::to_allocvec(&suffix)?,
                    });
                    *reserved = reserved.saturating_add(1);
                    core.archive.pin_metadata(parent_id)?;
                    let (snapshot, replay, snapshot_id) =
                        core.archive.pin_job_origin(parent_index)?;
                    let entry = &core.archive.entries[parent_index];
                    return Ok(Some((
                        JobSpec {
                            reservation: 0,
                            snapshot,
                            replay,
                            parent_milestones: entry.milestones,
                            suffix,
                        },
                        PendingJob {
                            snapshot_id,
                            parent_id,
                            continuation_energy,
                            continuation_wave: continuation.wave.saturating_add(1),
                            continuation_edge: Some((
                                continuation.source,
                                continuation.destination,
                            )),
                            mutation_seed,
                            mixture_weight,
                            splice_weight,
                            splice,
                            selector,
                            draw_checkpoint_before,
                            duration_draw: None,
                            duration_admission_sequence_at_draw: None,
                            duration_remaining_work: None,
                            duration_checkpoint_at_draw: None,
                            suffix_limit: None,
                            planned_finish: 0,
                        },
                    )));
                }
                loop {
                    let (parent_index, selector) = core.archive.select_parent(rand)?;
                    let parent_id = core
                        .archive
                        .stable_id(parent_index)
                        .ok_or("selected archive slot is missing")?;
                    let mutation_seed = rand.next_u64();
                    let (mixture_weight, splice_weight) = match config.mixture {
                        DrawMixture::Energy { scale } => {
                            (core.mixture_energy.biased_weight(scale), 0)
                        }
                        DrawMixture::EnergySplice { scale } => {
                            core.mixture_energy.splice_weights(scale)
                        }
                        _ => (DEFAULT_MIXTURE_WEIGHT, 0),
                    };
                    let draw_checkpoint_before = workload.draw_checkpoint(draw_state)?;
                    let (spliced, splice) =
                        if energy_strategy(mutation_seed, mixture_weight, splice_weight)?
                            == EnergyStrategy::Splice
                        {
                            match core
                                .archive
                                .splice_tail_for_campaign(parent_index, LONGEST_SPLICE_TAIL)
                            {
                                Some(CampaignSpliceTail {
                                    donor_id,
                                    leaf_id,
                                    actions,
                                }) => {
                                    let tail_postcard = postcard::to_allocvec(&actions)?;
                                    (
                                        Some(actions),
                                        Some(CampaignSpliceRecord::Tail {
                                            donor_id: core
                                                .archive
                                                .stable_id(donor_id)
                                                .ok_or("splice donor slot is missing")?,
                                            leaf_id: core
                                                .archive
                                                .stable_id(leaf_id)
                                                .ok_or("splice leaf slot is missing")?,
                                            tail_postcard,
                                        }),
                                    )
                                }
                                None => (None, Some(CampaignSpliceRecord::Unavailable)),
                            }
                        } else {
                            (None, None)
                        };
                    let remaining_work = work_budget.and_then(|budget| {
                        NonZeroU64::new(
                            budget.saturating_sub(
                                counters
                                    .bootstrap_execution_work
                                    .saturating_add(counters.job_execution_work),
                            ),
                        )
                    });
                    let mut duration_checkpoint_at_draw = None;
                    let duration_draw = if spliced.is_none() {
                        workload
                            .duration_request(
                                &config.run,
                                core.archive.entries[parent_index].key,
                                remaining_work,
                            )
                            .map(|request| {
                                duration_checkpoint_at_draw =
                                    duration_policies.context_checkpoint(request.context);
                                let mut duration_rand = RomuDuoJrRand::with_seed(mutation_seed);
                                duration_policies.draw(
                                    request.context,
                                    &mut duration_rand,
                                    request.max_duration,
                                )
                            })
                    } else {
                        None
                    };
                    let duration_remaining_work = duration_draw.and(remaining_work);
                    let duration_admission_sequence_at_draw = duration_draw.map(|_| core.sequence);
                    let previous = core.archive.last_action(parent_index);
                    let suffix_limit = spliced
                        .is_none()
                        .then(|| core.suffix_limit(parent_id, parent_index));
                    let mut suffix = match (spliced, duration_draw) {
                        (Some(tail), _) => tail,
                        (None, Some(draw)) => workload.expand_suffix_duration(
                            &config.run,
                            draw_state,
                            MixtureDraw {
                                mixture: config.mixture,
                                weight: mixture_weight,
                                splice_weight,
                            },
                            mutation_seed,
                            previous,
                            draw,
                        )?,
                        (None, None) => workload.expand_suffix(
                            &config.run,
                            draw_state,
                            MixtureDraw {
                                mixture: config.mixture,
                                weight: mixture_weight,
                                splice_weight,
                            },
                            mutation_seed,
                            previous,
                        )?,
                    };
                    if let Some(limit) = suffix_limit {
                        suffix.truncate(usize::from(limit));
                    }
                    let all_prefixes_archived = consecutive_skips < CONSECUTIVE_SKIP_LIMIT
                        && core.all_prefixes_archived(parent_index, &suffix);
                    if all_prefixes_archived {
                        let duration_checkpoint_before = duration_draw
                            .and_then(|draw| duration_policies.context_checkpoint(draw.context));
                        let draw_checkpoint_after = workload.finish_stream_record(
                            &config.run,
                            draw_state,
                            &[],
                            &core.evidence,
                        )?;
                        writer.write_line(&CampaignStreamRecord::Skip(CampaignSkipRecord {
                            parent_id,
                            mutation_seed,
                            mixture_weight,
                            splice_weight,
                            splice,
                            selector,
                            draw_checkpoint_before,
                            draw_checkpoint_after,
                            duration_draw,
                            duration_admission_sequence_at_draw,
                            duration_remaining_work,
                            duration_checkpoint_at_draw,
                            duration_checkpoint_after: duration_checkpoint_before.clone(),
                            duration_checkpoint_before,
                            suffix_limit,
                        }))?;
                        core.archive.record_selection(parent_index, &selector);
                        core.archive.maintain_memory_budget()?;
                        core.archive.prepare_selection();
                        counters.duplicates_skipped = counters.duplicates_skipped.saturating_add(1);
                        consecutive_skips = consecutive_skips.saturating_add(1);
                        continue;
                    }
                    *reserved = reserved.saturating_add(1);
                    core.start_suffix_job(parent_id, suffix_limit);
                    core.archive.pin_metadata(parent_id)?;
                    let (snapshot, replay, snapshot_id) =
                        core.archive.pin_job_origin(parent_index)?;
                    let entry = &core.archive.entries[parent_index];
                    return Ok(Some((
                        JobSpec {
                            reservation: 0,
                            snapshot,
                            replay,
                            parent_milestones: entry.milestones,
                            suffix,
                        },
                        PendingJob {
                            snapshot_id,
                            parent_id,
                            continuation_energy,
                            continuation_wave: 0,
                            continuation_edge: None,
                            mutation_seed,
                            mixture_weight,
                            splice_weight,
                            splice,
                            selector,
                            draw_checkpoint_before,
                            duration_draw,
                            duration_admission_sequence_at_draw,
                            duration_remaining_work,
                            duration_checkpoint_at_draw,
                            suffix_limit,
                            planned_finish: 0,
                        },
                    )));
                }
            };

            let pipeline_depth = config.window;
            let mut pending = BTreeMap::<usize, PendingJob<G>>::new();
            let mut completed = BTreeMap::<usize, CompletedJob<G>>::new();
            let mut schedule = BTreeSet::<(u64, usize)>::new();
            let mut running = 0_usize;
            for job in resumed_in_flight.take().unwrap_or_default() {
                let index = core
                    .archive
                    .index_of_id(job.pending.snapshot_id)
                    .ok_or("search checkpoint in-flight job names a missing snapshot entry")?;
                let snapshot = core.archive.entries[index]
                    .snapshot
                    .clone()
                    .ok_or("search checkpoint in-flight job has no stored snapshot")?;
                core.start_suffix_job(job.pending.parent_id, job.pending.suffix_limit);
                let key = (job.pending.planned_finish, job.reservation);
                schedule.insert(key);
                pool.dispatch(
                    key,
                    JobSpec {
                        reservation: job.reservation,
                        snapshot,
                        replay: job.spec.replay.clone(),
                        parent_milestones: job.spec.parent_milestones,
                        suffix: job.spec.suffix.clone(),
                    },
                )?;
                running += 1;
                if checkpoints.is_some() {
                    spec_records.insert(job.reservation, job.spec);
                }
                pending.insert(job.reservation, job.pending);
            }
            let prefill = if !pending.is_empty() {
                0
            } else {
                pipeline_depth
            };
            for _ in 0..prefill {
                let selection_started = profile_now();
                let selected = select(
                    &mut core,
                    &mut rand,
                    &mut draw_state,
                    &duration_policies,
                    &mut writer,
                    &mut counters,
                    &mut reserved,
                )?;
                coordinator_profile.selection_ns = coordinator_profile
                    .selection_ns
                    .saturating_add(profile_elapsed(selection_started));
                coordinator_profile.selections = coordinator_profile.selections.saturating_add(1);
                let Some((mut spec, mut pending_job)) = selected else {
                    break;
                };
                coordinator_profile.note_dispatch(
                    &spec,
                    matches!(pending_job.splice, Some(CampaignSpliceRecord::Tail { .. })),
                    action_cost,
                );
                let reservation = usize::try_from(reserved.saturating_sub(1))?;
                spec.reservation = reservation;
                pending_job.planned_finish = planned_finish(planned_clock, &spec, action_cost);
                let key = (pending_job.planned_finish, reservation);
                if pending.insert(reservation, pending_job).is_some() {
                    return Err("campaign reserved one job twice".into());
                }
                if checkpoints.is_some() {
                    spec_records.insert(reservation, JobSpecRecord::of(&spec));
                }
                schedule.insert(key);
                pool.dispatch(key, spec)?;
                running += 1;
            }
            idle_clock.update(running, IdleReason::NoJob);

            while !pending.is_empty() || !completed.is_empty() {
                let next_admission = schedule.first().map(|(_, reservation)| *reservation);
                let mut ready_reply = if next_admission
                    .is_some_and(|reservation| completed.contains_key(&reservation))
                {
                    pool.try_receive()?
                } else if pending.is_empty() {
                    return Err("campaign reorder window ended with an admission gap".into());
                } else {
                    let receive_started = profile_now();
                    let reply = pool.receive()?;
                    let waited = profile_elapsed(receive_started);
                    coordinator_profile.receive_wait_ns =
                        coordinator_profile.receive_wait_ns.saturating_add(waited);
                    let waited = u64::try_from(waited).unwrap_or(u64::MAX);
                    if completed.is_empty() {
                        admission.receive_all_running_ns =
                            admission.receive_all_running_ns.saturating_add(waited);
                    } else {
                        admission.receive_head_of_line_ns =
                            admission.receive_head_of_line_ns.saturating_add(waited);
                    }
                    Some(reply)
                };
                while let Some(reply) = ready_reply {
                    coordinator_profile.receives = coordinator_profile.receives.saturating_add(1);
                    let physical_worker = reply.worker;
                    let outcome = reply.outcome.map_err(|error| -> Box<dyn Error> {
                        format!("campaign worker {physical_worker} failed: {error}").into()
                    })?;
                    if physical_worker >= config.workers {
                        return Err(
                            "campaign worker replied with an unknown physical identifier".into(),
                        );
                    }
                    running = running
                        .checked_sub(1)
                        .ok_or("campaign worker replied without queued work")?;
                    let (reservation, result, execution_work, result_sha256) = outcome;
                    let held = Some(reservation) != next_admission;
                    idle_clock.update(
                        running,
                        if held {
                            IdleReason::AdmissionOrder
                        } else {
                            IdleReason::NoJob
                        },
                    );
                    let pending_job = pending
                        .remove(&reservation)
                        .ok_or("campaign worker replied for an unknown reservation")?;
                    if completed
                        .insert(
                            reservation,
                            CompletedJob {
                                held_since: held.then(now),
                                pending: pending_job,
                                result,
                                execution_work,
                                result_sha256,
                            },
                        )
                        .is_some()
                    {
                        return Err("campaign worker completed one reservation twice".into());
                    }
                    ready_reply = pool.try_receive()?;
                }

                while let Some(&(finish, reservation)) = schedule.first() {
                    let Some(completed_job) = completed.remove(&reservation) else {
                        break;
                    };
                    schedule.pop_first();
                    planned_clock = finish;
                    spec_records.remove(&reservation);
                    let pending_job = completed_job.pending;
                    let result = completed_job.result;
                    let execution_work = completed_job.execution_work;
                    let result_sha256 = completed_job.result_sha256;
                    if let Some(since) = completed_job.held_since {
                        let held = nanos_since(since);
                        admission.results_held = admission.results_held.saturating_add(1);
                        admission.results_held_ns = admission.results_held_ns.saturating_add(held);
                        admission.results_held_max_ns = admission.results_held_max_ns.max(held);
                    }
                    let tracked_duration = pending_job
                        .duration_draw
                        .filter(|_| execution_work > 0)
                        .map(|draw| draw.duration);
                    let duration_checkpoint_before = pending_job
                        .duration_draw
                        .and_then(|draw| duration_policies.context_checkpoint(draw.context));
                    let objectives_before = core.objectives_reached;
                    let admission_started = profile_now();
                    core.archive
                        .set_admission_wave(pending_job.continuation_wave);
                    core.finish_suffix_job(pending_job.parent_id, pending_job.suffix_limit);
                    let (sequence, decisions, duration_admission) = core.admit_job_tracking(
                        workload,
                        pending_job.parent_id,
                        result,
                        pending_job.suffix_limit.is_some(),
                        |action| {
                            tracked_duration.is_some_and(|duration| {
                                workload.duration_of_action(&config.run, action) == Some(duration)
                            })
                        },
                    )?;
                    if duration_admission.applied {
                        let draw = pending_job
                            .duration_draw
                            .ok_or("duration application was reported without a duration draw")?;
                        duration_policies.observe(
                            draw.context,
                            draw.duration,
                            duration_admission.useful,
                            NonZeroU64::new(execution_work)
                                .ok_or("duration application requires positive execution work")?,
                        )?;
                    }
                    let duration_checkpoint_after = pending_job
                        .duration_draw
                        .and_then(|draw| duration_policies.context_checkpoint(draw.context));
                    coordinator_profile.admission_ns = coordinator_profile
                        .admission_ns
                        .saturating_add(profile_elapsed(admission_started));
                    coordinator_profile.admissions =
                        coordinator_profile.admissions.saturating_add(1);
                    let bookkeeping_started = profile_now();
                    let parent_index = core
                        .archive
                        .index_of_id(pending_job.parent_id)
                        .ok_or("completed job parent is no longer resident")?;
                    let isolated_continuation =
                        pending_job.selector.path == SelectorPath::Continuation;
                    if isolated_continuation {
                        core.archive.record_isolated_continuation(parent_index);
                    } else {
                        core.archive
                            .record_selection(parent_index, &pending_job.selector);
                    }
                    let retained_ids = retained_archive_indexes(&core, &decisions);
                    let new_cell_descendant = retained_ids
                        .iter()
                        .any(|id| core.archive.opened_new_cell(*id));
                    let new_slot_descendant = retained_ids
                        .iter()
                        .any(|id| core.archive.opened_new_slot(*id));
                    if !isolated_continuation {
                        core.archive
                            .record_selection_outcome(parent_index, !retained_ids.is_empty());
                    }
                    if isolated_continuation {
                        let (landed, replaced) = continuation_arrival::<G>(
                            &core.archive,
                            pending_job.continuation_edge,
                            &decisions,
                        );
                        core.archive.record_continuation_outcome(
                            landed,
                            replaced,
                            new_cell_descendant,
                            pending_job.continuation_wave,
                        );
                        core.archive.add_continuation_execution_work(execution_work);
                    }
                    record_mixture_outcome(
                        &mut core.mixture_energy,
                        config.mixture,
                        pending_job.selector.path,
                        pending_job.mutation_seed,
                        (pending_job.mixture_weight, pending_job.splice_weight),
                        new_slot_descendant,
                        execution_work,
                    )?;
                    if objectives_before == 0
                        && let (Some(path), Some(input)) =
                            (&config.objective_witness_path, &core.objective_witness)
                    {
                        std::fs::write(path, serde_json::to_vec_pretty(input)?)?;
                    }
                    let draw_checkpoint_after =
                        finish_record(workload, &config.run, &mut draw_state, &core, &decisions)?;
                    let draw_state_memory_bytes = workload.draw_state_memory_bytes(&draw_state);
                    if !memory_is_within_reserve(
                        draw_state_memory_bytes,
                        workload.draw_state_memory_reserve_bytes(&config.run),
                    ) {
                        return Err(
                            "live draw state exceeds its deterministic memory reserve".into()
                        );
                    }
                    if !memory_is_within_reserve(
                        duration_policies.memory_bytes(),
                        duration_memory_reserve,
                    ) {
                        return Err(
                            "live adaptive duration state exceeds its memory reserve".into()
                        );
                    }
                    core.archive.unpin_job_origin(pending_job.snapshot_id);
                    core.archive.unpin_metadata(pending_job.parent_id);
                    let compaction_started = profile_now();
                    let compactions_before = core.archive.history_compactions();
                    core.archive.maintain_memory_budget()?;
                    core.archive.prepare_selection();
                    record_compaction_elapsed(
                        &mut coordinator_profile,
                        compactions_before,
                        core.archive.history_compactions(),
                        profile_elapsed(compaction_started),
                    );
                    coordinator_profile.bookkeeping_ns = coordinator_profile
                        .bookkeeping_ns
                        .saturating_add(profile_elapsed(bookkeeping_started));
                    let stream_started = profile_now();
                    writer.write_line(&CampaignStreamRecord::Job(CampaignJobRecord {
                        continuation_energy: pending_job.continuation_energy,
                        sequence,
                        reservation: u64::try_from(reservation)?,
                        parent_id: pending_job.parent_id,
                        mutation_seed: pending_job.mutation_seed,
                        execution_work,
                        result_sha256,
                        decisions,
                        mixture_weight: pending_job.mixture_weight,
                        splice_weight: pending_job.splice_weight,
                        splice: pending_job.splice,
                        selector: pending_job.selector,
                        draw_checkpoint_before: pending_job.draw_checkpoint_before,
                        draw_checkpoint_after,
                        duration_draw: pending_job.duration_draw,
                        duration_admission_sequence_at_draw: pending_job
                            .duration_admission_sequence_at_draw,
                        duration_remaining_work: pending_job.duration_remaining_work,
                        duration_checkpoint_at_draw: pending_job.duration_checkpoint_at_draw,
                        duration_checkpoint_before,
                        duration_checkpoint_after,
                        suffix_limit: pending_job.suffix_limit,
                    }))?;
                    coordinator_profile.stream_write_ns = coordinator_profile
                        .stream_write_ns
                        .saturating_add(profile_elapsed(stream_started));
                    counters.job_execution_work =
                        counters.job_execution_work.saturating_add(execution_work);
                    if objectives_before == 0 && core.objectives_reached > 0 {
                        counters.note_first_objective(sequence);
                    }
                    if let Some(sink) = progress.as_deref_mut()
                        && progress_checkpoint_due(sequence)
                    {
                        let host_times = profile_printed.then(|| {
                            HostTimes::measure(coordinator_schedstat, idle_clock.totals())
                        });
                        write_live_progress(
                            &core,
                            &counters,
                            host_times.map(|host_times| (&coordinator_profile, host_times)),
                            draw_state_memory_bytes,
                            telemetry_started,
                            false,
                            sink,
                        )?;
                        if let Some(host_times) = host_times {
                            eprintln!(
                                "coordinator-profile executions={sequence} coordinator_cpu_ns={} coordinator_run_wait_ns={} idle_admission_order_ns={} idle_no_job_ns={} receive_wait_ns={} admission_ns={} bookkeeping_ns={} history_compaction_ns={} stream_write_ns={} selection_ns={} receives={} admissions={} selections={} entries={} active_entries={} historical_input_actions={} stored_input_actions={} input_index_nodes={} resident_snapshots={} resident_snapshot_bytes={} entry_metadata_memory_bytes={} input_index_memory_bytes={} cell_memory_bytes={} history_memory_bytes={} draw_state_memory_bytes={} resident_memory_bytes={} snapshot_evictions={} history_compactions={} historical_entries_dropped={} input_reconstructions={} completed_buffered={} job_execution_work={} replay_jobs={} replay_actions={} replay_cost={} suffix_actions={} suffix_cost={}",
                                host_times.coordinator_cpu_ns,
                                host_times.coordinator_run_wait_ns,
                                host_times.idle_admission_order_ns,
                                host_times.idle_no_job_ns,
                                coordinator_profile.receive_wait_ns,
                                coordinator_profile.admission_ns,
                                coordinator_profile.bookkeeping_ns,
                                coordinator_profile.history_compaction_ns,
                                coordinator_profile.stream_write_ns,
                                coordinator_profile.selection_ns,
                                coordinator_profile.receives,
                                coordinator_profile.admissions,
                                coordinator_profile.selections,
                                core.archive.entries.len(),
                                core.archive.active_count(),
                                core.archive.historical_input_actions(),
                                core.archive.stored_input_actions(),
                                core.archive.input_index_nodes(),
                                core.archive.resident_snapshot_count(),
                                core.archive.resident_snapshot_bytes(),
                                core.archive.entry_metadata_memory_bytes(),
                                core.archive.input_index_memory_bytes(),
                                core.archive.cell_memory_bytes(),
                                core.archive.history_memory_bytes(),
                                draw_state_memory_bytes,
                                core.archive
                                    .resident_memory_bytes()
                                    .saturating_add(draw_state_memory_bytes),
                                core.archive.snapshot_evictions(),
                                core.archive.history_compactions(),
                                core.archive.historical_entries_dropped(),
                                core.archive.input_reconstructions(),
                                completed.len(),
                                counters.job_execution_work,
                                coordinator_profile.replay_jobs,
                                coordinator_profile.replay_actions,
                                coordinator_profile.replay_cost,
                                coordinator_profile.suffix_actions,
                                coordinator_profile.suffix_cost,
                            );
                        }
                    }
                    admitted = admitted.saturating_add(1);
                    let selection_started = profile_now();
                    let selected = select(
                        &mut core,
                        &mut rand,
                        &mut draw_state,
                        &duration_policies,
                        &mut writer,
                        &mut counters,
                        &mut reserved,
                    )?;
                    coordinator_profile.selection_ns = coordinator_profile
                        .selection_ns
                        .saturating_add(profile_elapsed(selection_started));
                    coordinator_profile.selections =
                        coordinator_profile.selections.saturating_add(1);
                    if let Some((mut spec, mut pending_job)) = selected {
                        coordinator_profile.note_dispatch(
                            &spec,
                            matches!(pending_job.splice, Some(CampaignSpliceRecord::Tail { .. })),
                            action_cost,
                        );
                        let reservation = usize::try_from(reserved.saturating_sub(1))?;
                        spec.reservation = reservation;
                        pending_job.planned_finish =
                            planned_finish(planned_clock, &spec, action_cost);
                        let key = (pending_job.planned_finish, reservation);
                        if pending.insert(reservation, pending_job).is_some() {
                            return Err("campaign reserved one job twice".into());
                        }
                        if checkpoints.is_some() {
                            spec_records.insert(reservation, JobSpecRecord::of(&spec));
                        }
                        schedule.insert(key);
                        pool.dispatch(key, spec)?;
                        running += 1;
                    }
                    idle_clock.update(
                        running,
                        if completed.is_empty() {
                            IdleReason::NoJob
                        } else {
                            IdleReason::AdmissionOrder
                        },
                    );
                    if let Some(checkpoints) = checkpoints.as_mut()
                        && let Some(reason) = checkpoints.due(
                            core.sequence,
                            G::checkpoint_marks(&core.evidence),
                            core.archive.top_progress(),
                        )
                    {
                        write_search_checkpoint(
                            workload,
                            config,
                            checkpoints,
                            reason,
                            &core,
                            &draw_state,
                            &duration_policies,
                            &rand,
                            &counters,
                            &coordinator_profile,
                            reserved,
                            admitted,
                            planned_clock,
                            &schedule,
                            &pending,
                            &completed,
                            &spec_records,
                        )?;
                    }
                }
                idle_clock.update(
                    running,
                    if completed.is_empty() {
                        IdleReason::NoJob
                    } else {
                        IdleReason::AdmissionOrder
                    },
                );
            }
            if !completed.is_empty() || !schedule.is_empty() {
                return Err("campaign reorder window ended with an admission gap".into());
            }
            if let Some(checkpoints) = checkpoints.as_mut() {
                write_search_checkpoint(
                    workload,
                    config,
                    checkpoints,
                    "final",
                    &core,
                    &draw_state,
                    &duration_policies,
                    &rand,
                    &counters,
                    &coordinator_profile,
                    reserved,
                    admitted,
                    planned_clock,
                    &schedule,
                    &pending,
                    &completed,
                    &spec_records,
                )?;
            }
            pool.close();
            Ok(())
        },
    )?;
    telemetry.search_ns = nanos_since(telemetry_started);
    telemetry.admission = admission;
    telemetry.workers = worker_telemetry;
    idle_clock.finish(&mut telemetry.admission);
    telemetry.sum_targets();
    telemetry.coordinator = serde_json::to_value(&coordinator_profile)?;
    let persistence_started = now();

    core.archive.preserve_inactive_snapshots(false)?;
    core.archive.compact_history_for_final_report()?;
    core.finish_curve();
    if let Some(sink) = progress {
        write_live_progress(
            &core,
            &counters,
            profile_printed.then(|| {
                (
                    &coordinator_profile,
                    HostTimes::measure(
                        coordinator_schedstat,
                        (
                            telemetry.admission.idle_admission_order_ns,
                            telemetry.admission.idle_no_job_ns,
                        ),
                    ),
                )
            }),
            workload
                .draw_state_memory_bytes(&draw_state)
                .saturating_add(duration_policies.memory_bytes()),
            telemetry_started,
            true,
            sink,
        )?;
    }
    let stream_sha256 = writer.finish()?;
    counters.draw_state_memory_bytes = workload
        .draw_state_memory_bytes(&draw_state)
        .saturating_add(duration_policies.memory_bytes());
    let (mut report, checkpoint) = build_report(
        workload,
        &header,
        origin_record,
        core,
        &counters,
        stream_sha256,
        config.materialize_final_artifacts,
    );
    telemetry.persistence_ns = nanos_since(persistence_started);
    report.telemetry = telemetry;
    Ok((report, checkpoint))
}

fn bootstrap_campaign<G: Workload>(
    workload: &G,
    config: &CampaignConfig<G>,
    origin: &CampaignOrigin<G>,
    core: &mut CoordinatorCore<G>,
    draw_state: &DrawTables<G::Action>,
    duration_policies: &DurationPolicies<G::Key>,
    counters: &mut CampaignCounters,
) -> Result<(), Box<dyn Error>> {
    core.archive
        .enable_continuations(usize::from(SUFFIX_DOUBLING_LIMIT));
    let mut bootstrap_target = workload.new_target().map_err(|error| -> Box<dyn Error> {
        format!("failed to build the bootstrap target: {error}").into()
    })?;
    let work_before = workload.execution_work(&bootstrap_target);
    counters.tree_import =
        bootstrap_core(workload, &config.run, core, &mut bootstrap_target, origin)?;
    counters.bootstrap_execution_work = execution_work_delta(
        work_before,
        workload.execution_work(&bootstrap_target),
        "bootstrap",
    )?;
    if core.objectives_reached > 0 {
        counters.note_first_objective(0);
    }
    drop(bootstrap_target);
    let bootstrap_memory_bytes = core
        .archive
        .resident_memory_bytes()
        .saturating_add(workload.draw_state_memory_bytes(draw_state))
        .saturating_add(duration_policies.memory_bytes());
    if !resident_memory_is_within_budget(bootstrap_memory_bytes, config.memory_budget_mib) {
        return Err("campaign bootstrap state exceeds its deterministic memory budget".into());
    }
    core.archive.prepare_selection();
    Ok(())
}

fn search_checkpoint_header<G: Workload>(
    workload: &G,
    config: &CampaignConfig<G>,
    reason: &str,
    executions: u64,
    reserved: u64,
    admitted: usize,
    planned_clock: u64,
) -> CheckpointHeader {
    let mut policies = recorded_policies(workload, &config.run);
    for (field, value) in [
        ("schedule_policy", schedule_policy_identifier(config.window)),
        ("mixture_policy", draw_mixture_identifier(config.mixture)),
        (
            "retention_policy",
            retention_policy_identifier(config.retention).to_owned(),
        ),
        ("parent_scheduler", SELECTOR_IDENTIFIER.to_owned()),
        ("continuation_policy", CONTINUATION_IDENTIFIER.to_owned()),
        (
            PREFERENCE_PORTFOLIO_FIELD,
            preference_portfolio_identifier::<G::Key>(),
        ),
        (
            "stop_rollout_on_objective",
            config.stop_rollout_on_objective.to_string(),
        ),
        (
            "stop_campaign_on_objective",
            config.stop_campaign_on_objective.to_string(),
        ),
    ] {
        policies.insert(field.to_owned(), value);
    }
    CheckpointHeader {
        format: SEARCH_CHECKPOINT_FORMAT.to_owned(),
        reason: reason.to_owned(),
        workload_identity_sha256: workload.workload_identity_sha256(),
        campaign_seed: config.campaign_seed,
        window: config.window,
        archive_entry_limit: config.archive_entry_limit,
        memory_budget_mib: config.memory_budget_mib,
        policies,
        executions,
        reserved,
        admitted,
        planned_clock,
    }
}

#[allow(clippy::too_many_arguments)]
fn search_checkpoint_policy_changes(
    header: &CheckpointHeader,
    expected: &CheckpointHeader,
) -> Result<BTreeMap<String, PolicyChange>, Box<dyn Error>> {
    let fields = header
        .policies
        .keys()
        .chain(expected.policies.keys())
        .collect::<BTreeSet<_>>();
    let mut changes = BTreeMap::new();
    let mut fixed = Vec::new();
    for field in fields {
        let checkpoint = header.policies.get(field);
        let run = expected.policies.get(field);
        if checkpoint == run {
            continue;
        }
        match (checkpoint, run) {
            (Some(checkpoint), Some(run)) if RESUMABLE_POLICY_FIELDS.contains(&field.as_str()) => {
                changes.insert(
                    field.clone(),
                    PolicyChange {
                        checkpoint: checkpoint.clone(),
                        run: run.clone(),
                    },
                );
            }
            _ => fixed.push(field.as_str()),
        }
    }
    if !fixed.is_empty() {
        return Err(format!("search checkpoint policies differ: {}", fixed.join(", ")).into());
    }
    Ok(changes)
}

fn restore_search_checkpoint<G: Workload>(
    workload: &G,
    config: &CampaignConfig<G>,
    mut reader: CheckpointReader,
    core: &mut CoordinatorCore<G>,
    draw_state: &mut DrawTables<G::Action>,
    duration_policies: &mut DurationPolicies<G::Key>,
    counters: &mut CampaignCounters,
) -> Result<SearchResume<G>, Box<dyn Error>> {
    let header = reader.header.clone();
    let expected = search_checkpoint_header(workload, config, &header.reason, 0, 0, 0, 0);
    if header.workload_identity_sha256 != expected.workload_identity_sha256 {
        return Err("search checkpoint belongs to a different workload".into());
    }
    if header.window != expected.window {
        return Err("search checkpoint admission window must match the campaign".into());
    }
    if header.archive_entry_limit != expected.archive_entry_limit
        || header.memory_budget_mib != expected.memory_budget_mib
    {
        return Err("search checkpoint limits differ from the campaign".into());
    }
    let changes = search_checkpoint_policy_changes(&header, &expected)?;
    let state: CoreCheckpoint<G> = reader.next()?;
    let archive: Archive<G::Action, G::Key, G::Milestones, G::Snapshot> = reader.next()?;
    let evidence: Vec<u8> = reader.next()?;
    let draw: Vec<u8> = reader.next()?;
    let durations = reader.next()?;
    let mut rand: RomuDuoJrRand = reader.next()?;
    let restored_counters: CampaignCounters = reader.next()?;
    let profile: LiveCoordinatorProfile = reader.next()?;
    let in_flight: Vec<InFlightJob<G>> = reader.next()?;
    let snapshots = reader.snapshots::<G::Snapshot>()?;
    reader.finish()?;
    core.restore_state(state)?;
    core.archive = archive;
    let charge: fn(&G::Snapshot) -> usize = G::snapshot_memory_charge;
    core.archive
        .restore_runtime(workload.action_cost_fn(), Some(charge), snapshots)?;
    if changes.contains_key(PREFERENCE_PORTFOLIO_FIELD)
        || changes.contains_key(PREFERENCE_POLICY_FIELD)
    {
        core.archive.rerank_slot_holders();
    }
    core.archive
        .resume_continuations(usize::from(SUFFIX_DOUBLING_LIMIT));
    core.evidence = G::evidence_from_checkpoint(&evidence)?;
    *draw_state = if changes.contains_key(DRAW_TABLE_POLICY_FIELD) {
        let parameters = workload.draw_table_parameters(&config.run);
        let mut tables = DrawTables::new(parameters)?;
        fold_draw_sources(
            &mut tables,
            parameters,
            core.archive
                .entries
                .iter()
                .map(|entry| entry.input_suffix.as_slice()),
        )?;
        tables.flush()?;
        tables
    } else {
        DrawTables::from_resume_bytes(&draw)?
    };
    *duration_policies = DurationPolicies::from_checkpoint(durations)?;
    *counters = restored_counters;
    if header.campaign_seed != config.campaign_seed {
        rand = RomuDuoJrRand::with_seed(derive_selection_seed(config.campaign_seed));
    }
    let reserved = usize::try_from(header.reserved)?;
    let ordered = in_flight
        .windows(2)
        .all(|pair| pair[0].reservation < pair[1].reservation);
    if !ordered
        || in_flight
            .last()
            .is_some_and(|job| job.reservation >= reserved)
        || reserved.checked_sub(header.admitted) != Some(in_flight.len())
        || in_flight
            .iter()
            .any(|job| job.pending.planned_finish < header.planned_clock)
    {
        return Err("search checkpoint in-flight jobs do not match its admission count".into());
    }
    if core.sequence != u64::try_from(header.admitted)? || core.sequence != header.executions {
        return Err("search checkpoint admission count disagrees with its archive".into());
    }
    Ok(SearchResume {
        rand,
        reserved: header.reserved,
        admitted: header.admitted,
        planned_clock: header.planned_clock,
        profile,
        in_flight,
    })
}

#[allow(clippy::too_many_arguments)]
fn write_search_checkpoint<G: Workload>(
    workload: &G,
    config: &CampaignConfig<G>,
    checkpoints: &mut CheckpointWriter<<G::Key as ArchiveKey>::Progress>,
    reason: &str,
    core: &CoordinatorCore<G>,
    draw_state: &DrawTables<G::Action>,
    duration_policies: &DurationPolicies<G::Key>,
    rand: &RomuDuoJrRand,
    counters: &CampaignCounters,
    profile: &LiveCoordinatorProfile,
    reserved: u64,
    admitted: usize,
    planned_clock: u64,
    schedule: &BTreeSet<(u64, usize)>,
    pending: &BTreeMap<usize, PendingJob<G>>,
    completed: &BTreeMap<usize, CompletedJob<G>>,
    spec_records: &BTreeMap<usize, JobSpecRecord<G>>,
) -> Result<(), Box<dyn Error>> {
    let reservations = schedule
        .iter()
        .map(|(_, reservation)| *reservation)
        .collect::<BTreeSet<_>>();
    let in_flight = reservations
        .into_iter()
        .map(|reservation| -> Result<_, Box<dyn Error>> {
            let pending = pending
                .get(&reservation)
                .or_else(|| completed.get(&reservation).map(|job| &job.pending))
                .ok_or("search checkpoint lost an in-flight reservation")?;
            let spec = spec_records
                .get(&reservation)
                .ok_or("search checkpoint lost an in-flight job input")?;
            Ok(InFlightJobRef {
                reservation,
                spec,
                pending,
            })
        })
        .collect::<Result<Vec<_>, _>>()?;
    let header = search_checkpoint_header(
        workload,
        config,
        reason,
        core.sequence,
        reserved,
        admitted,
        planned_clock,
    );
    let evidence = G::evidence_checkpoint(&core.evidence)?;
    let draw = draw_state.to_resume_bytes()?;
    checkpoints.write(&header, core.archive.resident_snapshot_entries(), |out| {
        postcard::to_io(&core.checkpoint_state(), &mut *out)?;
        postcard::to_io(&core.archive, &mut *out)?;
        postcard::to_io(&evidence, &mut *out)?;
        postcard::to_io(&draw, &mut *out)?;
        postcard::to_io(&duration_policies.checkpoint(), &mut *out)?;
        postcard::to_io(rand, &mut *out)?;
        postcard::to_io(counters, &mut *out)?;
        postcard::to_io(profile, &mut *out)?;
        postcard::to_io(&in_flight, &mut *out)?;
        Ok(())
    })
}

fn finish_record<G: Workload>(
    workload: &G,
    run: &G::Run,
    draw_state: &mut DrawTables<G::Action>,
    core: &CoordinatorCore<G>,
    decisions: &[CampaignAdmissionDecision],
) -> Result<Option<EmpiricalStepCheckpoint>, Box<dyn Error>> {
    let mut retained_inputs = Vec::new();
    for decision in decisions {
        let CampaignAdmissionDecision::Retained { id } = decision else {
            continue;
        };
        let index = core
            .archive
            .index_of_id(*id)
            .ok_or("retained draw-table entry is missing from the run archive")?;
        let entry = core
            .archive
            .entries
            .get(index)
            .ok_or("retained draw-table entry is missing from the run archive")?;
        retained_inputs.push(entry.input_suffix.clone());
    }
    let retained = retained_inputs
        .iter()
        .map(|suffix| (0, suffix.as_slice()))
        .collect::<Vec<_>>();
    workload.finish_stream_record(run, draw_state, &retained, &core.evidence)
}

fn recorded_policies<G: Workload>(workload: &G, run: &G::Run) -> WorkloadPolicies {
    let mut policies = workload.policies(run);
    policies.insert(
        DRAW_TABLE_POLICY_FIELD.to_owned(),
        draw_table_identifier(workload.draw_table_parameters(run)),
    );
    policies
}

fn resolve_recorded_policies<G: Workload>(
    workload: &G,
    policies: &WorkloadPolicies,
) -> Result<G::Run, Box<dyn Error>> {
    let mut workload_policies = policies.clone();
    let recorded = workload_policies
        .remove(DRAW_TABLE_POLICY_FIELD)
        .ok_or("campaign stream is missing its draw table policy")?;
    let parameters = draw_table_from_identifier(&recorded)?;
    let run = workload.resolve_recorded(&workload_policies)?;
    if workload.draw_table_parameters(&run) != parameters {
        return Err("campaign stream draw table policy does not match this build".into());
    }
    Ok(run)
}

fn fold_draw_sources<'a, A: Copy + Ord + Serialize + 'a>(
    tables: &mut DrawTables<A>,
    parameters: EmpiricalStepParameters,
    suffixes: impl Iterator<Item = &'a [A]>,
) -> Result<(), Box<dyn Error>> {
    let mut pending = 0_u64;
    for suffix in suffixes {
        tables.fold_source(suffix)?;
        pending = pending.saturating_add(1);
        if pending >= parameters.update_every_records {
            tables.flush()?;
            pending = 0;
        }
    }
    Ok(())
}

fn initial_draw_state<G: Workload>(
    workload: &G,
    run: &G::Run,
    origin: Option<(&str, &G::ArchiveReport)>,
) -> Result<InitialDrawState<G>, Box<dyn Error>> {
    let parameters = workload.draw_table_parameters(run);
    let mut tables = DrawTables::new(parameters)?;
    let source_sha256 = match origin {
        None => format!("{:x}", Sha256::digest([])),
        Some((file_sha256, report)) => {
            let entries = workload.source_entries(report);
            let parent_len: BTreeMap<u64, usize> = entries
                .iter()
                .map(|entry| (entry.id, entry.input.actions.len()))
                .collect();
            fold_draw_sources(
                &mut tables,
                parameters,
                entries.iter().map(|entry| {
                    let prefix = entry
                        .parent_id
                        .and_then(|parent| parent_len.get(&parent).copied())
                        .unwrap_or(0);
                    entry.input.actions.get(prefix..).unwrap_or(&[])
                }),
            )?;
            file_sha256.to_owned()
        }
    };
    tables.flush()?;
    let initial = tables.checkpoint()?;
    let header = DrawTableHeader {
        source_sha256,
        parameters,
        initial,
    };
    Ok((tables, Some(header)))
}

#[allow(clippy::too_many_lines)]
pub fn replay_campaign_checkpointed<G: Workload>(
    workload: &G,
    stream_bytes: &[u8],
    origin_report: Option<&G::ArchiveReport>,
    origin_checkpoint: Option<&CampaignCheckpoint<G::Snapshot>>,
) -> Result<CampaignOutcome<G>, Box<dyn Error>>
where
    G::ArchiveReport: Serialize,
{
    let stream_sha256 = format!("{:x}", Sha256::digest(stream_bytes));
    let duration_memory_reserve = DurationPolicies::<G::Key>::memory_reserve_bytes();
    let text = std::str::from_utf8(stream_bytes)?;
    let mut lines = text.lines();
    let header: CampaignStreamHeader<DrawTableHeader> =
        serde_json::from_str(lines.next().ok_or("campaign stream is empty")?)?;
    if header.schema_version != CAMPAIGN_SCHEMA_VERSION {
        return Err("campaign stream schema version is not recognized".into());
    }
    if header.preference_portfolio != preference_portfolio_identifier::<G::Key>() {
        return Err("campaign stream preference portfolio does not match the key".into());
    }
    if !archive_entry_limit_is_valid(header.archive_entry_limit) {
        return Err("recorded archive entry limit is outside the compiled bound".into());
    }
    if header.memory_budget_mib == Some(0) {
        return Err("recorded memory budget must be greater than zero".into());
    }
    if header.work_budget == Some(0) {
        return Err("recorded work budget must be nonzero".into());
    }
    if header.format != workload.stream_format() {
        return Err("campaign stream format is not recognized".into());
    }
    if !schedule_policy_is_supported(&header.schedule_policy) {
        return Err("campaign stream schedule policy is not recognized".into());
    }
    if !progress_policy_is_supported(&header.progress_policy) {
        return Err("campaign stream progress policy is not recognized".into());
    }
    if header.workload_identity_sha256 != workload.workload_identity_sha256() {
        return Err("campaign replay workload identity does not match the recorded stream".into());
    }
    if header.action_cost_unit != workload.action_cost_unit() {
        return Err("campaign replay action-cost unit does not match the recorded stream".into());
    }
    if header.execution_work_unit != workload.execution_work_unit() {
        return Err(
            "campaign replay execution-work unit does not match the recorded stream".into(),
        );
    }
    let record_lines = lines.collect::<Vec<_>>();
    let mut required_draw_versions = DrawVersionSchedule::default();
    let mut replay_job_reservations = BTreeMap::<u64, u64>::new();
    for (index, line) in record_lines.iter().enumerate() {
        let record: CampaignStreamRecord<EmpiricalStepCheckpoint, G::Key> =
            serde_json::from_str(line)?;
        let before = match record {
            CampaignStreamRecord::Job(job) => {
                if replay_job_reservations
                    .insert(job.reservation, job.parent_id)
                    .is_some()
                {
                    return Err("campaign stream admits one reservation twice".into());
                }
                job.draw_checkpoint_before
            }
            CampaignStreamRecord::Skip(skip) => skip.draw_checkpoint_before,
        };
        if let Some(before) = before {
            required_draw_versions.require(workload.draw_checkpoint_version(&before), index);
        }
    }
    if !replay_job_reservations
        .keys()
        .copied()
        .eq(0..u64::try_from(replay_job_reservations.len())?)
    {
        return Err("campaign stream job reservations are not contiguous".into());
    }
    let replay_job_parents = replay_job_reservations.into_values().collect::<Vec<_>>();
    let replay_job_metadata = replay_job_parents
        .iter()
        .map(|parent_id| vec![*parent_id])
        .collect::<Vec<_>>();
    let resume_input = match header.origin_kind.as_str() {
        ORIGIN_GENESIS => {
            if origin_report.is_some() {
                return Err("genesis campaign replay does not take a source archive".into());
            }
            if origin_checkpoint.is_some() {
                return Err("genesis campaign replay does not take a snapshot checkpoint".into());
            }
            Input::default()
        }
        ORIGIN_SNAPSHOT_ROOT => {
            if origin_report.is_some() {
                return Err("snapshot-root replay does not take a source archive".into());
            }
            if origin_checkpoint.is_none() {
                return Err("snapshot-root replay requires its snapshot checkpoint".into());
            }
            Input::default()
        }
        ORIGIN_ARCHIVE => {
            let source =
                origin_report.ok_or("archive campaign replay requires the source archive")?;
            workload.resume_input(source)?
        }
        ORIGIN_SEARCH_CHECKPOINT => {
            return Err("a stream that resumes from a search checkpoint cannot be replayed".into());
        }
        _ => return Err("campaign stream origin kind is not recognized".into()),
    };
    let resume_input_sha256 = format!("{:x}", Sha256::digest(serde_json::to_vec(&resume_input)?));
    if resume_input_sha256 != header.resume_input_sha256
        || resume_input.actions.len() != header.resume_actions
    {
        return Err("campaign replay resume input does not match the recorded stream".into());
    }

    let replay_retention = retention_policy_from_identifier(&header.retention_policy)?;
    if header.parent_scheduler != SELECTOR_IDENTIFIER {
        return Err("campaign stream parent scheduler is not recognized".into());
    }
    let expected_resume = if header.origin_kind == ORIGIN_SNAPSHOT_ROOT {
        SNAPSHOT_ROOT_RESUME_IDENTIFIER
    } else {
        RESUME_IDENTIFIER
    };
    if header.resume_policy != expected_resume {
        return Err("campaign stream resume policy is not recognized".into());
    }
    let replay_mixture = draw_mixture_from_identifier(&header.mixture_policy)?;
    let replay_run = resolve_recorded_policies(workload, &header.workload_policies)?;
    let action_cost = workload.action_cost_fn();
    if let Some(checkpoint) = origin_checkpoint {
        let sha256_matches =
            header.origin_checkpoint_sha256.as_deref() == Some(checkpoint.file_sha256.as_str());
        let logical_path_matches = header.origin_kind != ORIGIN_SNAPSHOT_ROOT
            || header.origin_checkpoint_path.as_deref() == Some(checkpoint.path.as_str());
        if !sha256_matches || !logical_path_matches {
            return Err("campaign replay checkpoint does not match the recorded stream".into());
        }
    }
    let draw_origin = match header.origin_kind.as_str() {
        ORIGIN_ARCHIVE => Some((
            header.origin_archive_sha256.as_deref().unwrap_or_default(),
            origin_report.ok_or("archive campaign replay requires the source archive")?,
        )),
        ORIGIN_GENESIS | ORIGIN_SNAPSHOT_ROOT => None,
        _ => return Err("campaign stream origin kind is not recognized".into()),
    };
    let (mut draw_state, replay_draw_header) =
        initial_draw_state(workload, &replay_run, draw_origin)?;
    let mut duration_policies = DurationPolicies::<G::Key>::new();
    if let Some(memory_budget_mib) = header.memory_budget_mib {
        let budget = memory_budget_mib.saturating_mul(1024 * 1024);
        if budget
            <= workload
                .draw_state_memory_reserve_bytes(&replay_run)
                .saturating_add(duration_memory_reserve)
        {
            return Err("recorded memory budget is too small for the bounded draw state".into());
        }
    }
    if !memory_is_within_reserve(
        workload.draw_state_memory_bytes(&draw_state),
        workload.draw_state_memory_reserve_bytes(&replay_run),
    ) {
        return Err("replay draw state exceeds its deterministic memory reserve".into());
    }
    if replay_draw_header != header.draw_header {
        return Err("re-derived draw table does not match the recorded header".into());
    }
    workload.remember_draw_version(&mut draw_state, &required_draw_versions)?;
    let mut core = CoordinatorCore::new(
        workload,
        &replay_run,
        header.archive_entry_limit,
        header.memory_budget_mib,
    );
    core.record_progress = true;
    core.bounded_progress_curve = true;
    core.archive
        .enable_continuations(usize::from(SUFFIX_DOUBLING_LIMIT));
    let mut counters = CampaignCounters::new();
    let mut target = workload.new_target().map_err(|error| -> Box<dyn Error> {
        format!("failed to build the replay target: {error}").into()
    })?;
    let work_before = workload.execution_work(&target);
    counters.tree_import = match header.origin_kind.as_str() {
        ORIGIN_GENESIS => {
            core.bootstrap(workload, &replay_run, &mut target)?;
            None
        }
        ORIGIN_SNAPSHOT_ROOT => {
            core.bootstrap_snapshot_root(
                workload,
                &replay_run,
                &mut target,
                origin_checkpoint.ok_or("snapshot-root replay requires its snapshot checkpoint")?,
            )?;
            None
        }
        ORIGIN_ARCHIVE => Some(core.import_tree(
            workload,
            &replay_run,
            &mut target,
            origin_report.ok_or("archive campaign replay requires the source archive")?,
            origin_checkpoint.map(|checkpoint| &checkpoint.snapshots),
        )?),
        _ => return Err("campaign stream origin kind is not recognized".into()),
    };
    counters.bootstrap_execution_work = execution_work_delta(
        work_before,
        workload.execution_work(&target),
        "replay bootstrap",
    )?;
    if core.objectives_reached > 0 {
        counters.note_first_objective(0);
    }
    let bootstrap_memory_bytes = core
        .archive
        .resident_memory_bytes()
        .saturating_add(workload.draw_state_memory_bytes(&draw_state))
        .saturating_add(duration_policies.memory_bytes());
    if !resident_memory_is_within_budget(bootstrap_memory_bytes, header.memory_budget_mib) {
        return Err(
            "campaign replay bootstrap state exceeds its deterministic memory budget".into(),
        );
    }

    core.archive.prepare_selection();

    let replay_window_depth = schedule_policy_window(&header.schedule_policy)
        .ok_or("campaign stream schedule policy is not recognized")?;
    let mut duration_admissions = VecDeque::new();
    let mut duration_work = VecDeque::from([(0, counters.bootstrap_execution_work)]);
    let mut replay_metadata_uses = BTreeMap::<u64, u32>::new();
    let mut replay_job_snapshots =
        BTreeMap::<usize, (Arc<G::Snapshot>, Vec<G::Action>, u64)>::new();
    let mut replay_continuations = BTreeMap::<usize, ContinuationReservation<G>>::new();
    let mut replay_continuation_energy = BTreeMap::<usize, Option<u16>>::new();
    let mut replay_selections = BTreeMap::<usize, (u64, u64)>::new();
    let mut replay_planned_clock = 0_u64;
    let mut last_admitted = None::<(u64, usize)>;
    core.archive.preserve_inactive_snapshots(false)?;
    for (job_slot, parent_id) in replay_job_parents
        .iter()
        .take(replay_window_depth)
        .enumerate()
    {
        let (energy, continuation) =
            continuation_attempt(&mut core, header.campaign_seed, u64::try_from(job_slot)?);
        replay_continuation_energy.insert(job_slot, energy);
        if let Some(continuation) = continuation {
            replay_continuations.insert(job_slot, continuation);
        }
        let parent_index = core
            .archive
            .index_of_id(*parent_id)
            .ok_or("initial replay job names a parent the archive does not hold")?;
        replay_job_snapshots.insert(job_slot, core.archive.pin_job_origin(parent_index)?);
        replay_selections.insert(job_slot, (replay_planned_clock, core.sequence));
        for metadata_id in &replay_job_metadata[job_slot] {
            let uses = replay_metadata_uses.entry(*metadata_id).or_default();
            *uses = uses
                .checked_add(1)
                .ok_or("recorded metadata use count overflow")?;
        }
    }
    core.archive
        .preserve_recorded_metadata_uses(replay_metadata_uses.clone());

    let mut replay_admissions = 0_usize;
    for (replay_record_index, line) in record_lines.into_iter().enumerate() {
        draw_state.release_versions(&required_draw_versions, replay_record_index);
        let record: CampaignStreamRecord<EmpiricalStepCheckpoint, G::Key> =
            serde_json::from_str(line)?;
        match record {
            CampaignStreamRecord::Skip(skip) => {
                let parent_index = core
                    .archive
                    .index_of_id(skip.parent_id)
                    .ok_or("recorded skip names a parent the archive does not hold")?;
                let strategy =
                    energy_strategy(skip.mutation_seed, skip.mixture_weight, skip.splice_weight)?;
                let spliced = replay_splice::<G>(strategy, skip.splice)?;
                let draw_checkpoint_before = skip.draw_checkpoint_before;
                if spliced.is_some()
                    && (skip.duration_draw.is_some()
                        || skip.duration_admission_sequence_at_draw.is_some()
                        || skip.duration_remaining_work.is_some()
                        || skip.duration_checkpoint_at_draw.is_some())
                {
                    return Err("recorded splice carries unexpected duration evidence".into());
                }
                let recorded_duration_draw =
                    spliced.is_none().then_some(skip.duration_draw).flatten();
                let duration_remaining_work = validate_duration_reservation(
                    recorded_duration_draw.as_ref(),
                    skip.duration_admission_sequence_at_draw,
                    skip.duration_remaining_work,
                    core.sequence,
                    core.sequence,
                    header.work_budget,
                    counters
                        .bootstrap_execution_work
                        .saturating_add(counters.job_execution_work),
                    &duration_work,
                )?;
                let duration_draw = if spliced.is_none() {
                    validate_duration_draw(
                        workload,
                        &replay_run,
                        core.archive.entries[parent_index].key,
                        header.work_budget,
                        duration_remaining_work,
                        recorded_duration_draw,
                    )?
                } else {
                    None
                };
                if let Some(draw) = duration_draw {
                    let admission_sequence = skip
                        .duration_admission_sequence_at_draw
                        .ok_or("recorded duration choice is missing its admission sequence")?;
                    if admission_sequence != core.sequence {
                        return Err(
                            "recorded skip duration was not drawn at its selection point".into(),
                        );
                    }
                    let expected_checkpoint = duration_checkpoint_at_reservation(
                        &duration_policies,
                        &duration_admissions,
                        draw.context,
                        admission_sequence,
                    );
                    if expected_checkpoint != skip.duration_checkpoint_at_draw {
                        return Err("recorded skip duration state diverged at selection".into());
                    }
                    verify_duration_draw(&draw, expected_checkpoint.as_ref(), skip.mutation_seed)?;
                } else if skip.duration_checkpoint_at_draw.is_some() {
                    return Err("recorded stream carries duration state without a choice".into());
                }
                let duration_checkpoint_before = duration_draw
                    .and_then(|draw| duration_policies.context_checkpoint(draw.context));
                if duration_checkpoint_before != skip.duration_checkpoint_before {
                    return Err("replayed skip duration state diverged before expansion".into());
                }
                let suffix_limit = replay_suffix_limit(spliced.is_none(), skip.suffix_limit)?;
                let mut suffix = match (spliced, duration_draw) {
                    (Some(tail), _) => tail,
                    (None, draw) => workload.expand_suffix_recorded_duration(
                        &replay_run,
                        &draw_state,
                        MixtureDraw {
                            mixture: replay_mixture,
                            weight: skip.mixture_weight,
                            splice_weight: skip.splice_weight,
                        },
                        draw_checkpoint_before.as_ref(),
                        skip.mutation_seed,
                        core.archive.last_action(parent_index),
                        draw,
                    )?,
                };
                if let Some(limit) = suffix_limit {
                    suffix.truncate(usize::from(limit));
                }
                if !core.all_prefixes_archived(parent_index, &suffix) {
                    return Err("recorded skip is not a duplicate at its stream position".into());
                }
                if skip.selector.path == SelectorPath::Continuation {
                    return Err("continuations cannot be recorded skips".into());
                }
                verify_selector_annotation(&skip.selector)?;
                core.archive.record_selection(parent_index, &skip.selector);
                core.archive.maintain_memory_budget()?;
                core.archive.prepare_selection();
                counters.duplicates_skipped = counters.duplicates_skipped.saturating_add(1);
                let draw_checkpoint_after = workload.finish_stream_record(
                    &replay_run,
                    &mut draw_state,
                    &[],
                    &core.evidence,
                )?;
                if draw_checkpoint_after != skip.draw_checkpoint_after {
                    return Err("replayed skip draw-table checkpoint diverged".into());
                }
                let duration_checkpoint_after = duration_draw
                    .and_then(|draw| duration_policies.context_checkpoint(draw.context));
                if duration_checkpoint_after != skip.duration_checkpoint_after {
                    return Err("replayed skip duration state diverged after expansion".into());
                }
                workload.remember_draw_version(&mut draw_state, &required_draw_versions)?;
            }
            CampaignStreamRecord::Job(job) => {
                if job.selector.path == SelectorPath::Continuation
                    && (job.mixture_weight != 0
                        || job.splice_weight != u8::MAX
                        || !matches!(&job.splice, Some(CampaignSpliceRecord::Tail { .. })))
                {
                    return Err(
                        "continuation job lacks its registered schedule or complete tail".into(),
                    );
                }
                let replay_job_slot = usize::try_from(job.reservation)?;
                let admission_index = replay_admissions;
                replay_admissions = replay_admissions.saturating_add(1);
                let (planned_start, selection_sequence) = replay_selections
                    .remove(&replay_job_slot)
                    .ok_or("recorded job was admitted before its selection")?;
                let taken_continuation = replay_continuations.remove(&replay_job_slot);
                continuation_reservation_matches::<G>(
                    taken_continuation.as_ref(),
                    replay_continuation_energy
                        .remove(&replay_job_slot)
                        .ok_or("recorded job has no reconstructed reservation")?,
                    &job.selector,
                    job.splice.as_ref(),
                    job.continuation_energy,
                    job.sequence,
                )?;
                let parent_index = core
                    .archive
                    .index_of_id(job.parent_id)
                    .ok_or("recorded job names a parent the archive does not hold")?;
                let ((snapshot, replay, snapshot_id), parent_milestones) = {
                    let entry = core
                        .archive
                        .entries
                        .get(parent_index)
                        .ok_or("recorded job names a parent the archive does not hold")?;
                    (
                        replay_job_snapshots
                            .remove(&replay_job_slot)
                            .ok_or("recorded job has no replayed in-flight snapshot")?,
                        entry.milestones,
                    )
                };
                let strategy =
                    energy_strategy(job.mutation_seed, job.mixture_weight, job.splice_weight)?;
                let spliced = replay_splice::<G>(strategy, job.splice.clone())?;
                let draw_checkpoint_before = job.draw_checkpoint_before;
                if spliced.is_some()
                    && (job.duration_draw.is_some()
                        || job.duration_admission_sequence_at_draw.is_some()
                        || job.duration_remaining_work.is_some()
                        || job.duration_checkpoint_at_draw.is_some())
                {
                    return Err("recorded splice carries unexpected duration evidence".into());
                }
                let recorded_duration_draw =
                    spliced.is_none().then_some(job.duration_draw).flatten();
                let duration_remaining_work = validate_duration_reservation(
                    recorded_duration_draw.as_ref(),
                    job.duration_admission_sequence_at_draw,
                    job.duration_remaining_work,
                    core.sequence,
                    selection_sequence,
                    header.work_budget,
                    counters
                        .bootstrap_execution_work
                        .saturating_add(counters.job_execution_work),
                    &duration_work,
                )?;
                let duration_draw = if spliced.is_none() {
                    validate_duration_draw(
                        workload,
                        &replay_run,
                        core.archive.entries[parent_index].key,
                        header.work_budget,
                        duration_remaining_work,
                        recorded_duration_draw,
                    )?
                } else {
                    None
                };
                if let Some(draw) = duration_draw {
                    let admission_sequence = job
                        .duration_admission_sequence_at_draw
                        .ok_or("recorded duration choice is missing its admission sequence")?;
                    let expected_checkpoint = duration_checkpoint_at_reservation(
                        &duration_policies,
                        &duration_admissions,
                        draw.context,
                        admission_sequence,
                    );
                    if expected_checkpoint != job.duration_checkpoint_at_draw {
                        return Err("recorded job duration state diverged at selection".into());
                    }
                    verify_duration_draw(&draw, expected_checkpoint.as_ref(), job.mutation_seed)?;
                } else if job.duration_checkpoint_at_draw.is_some() {
                    return Err("recorded stream carries duration state without a choice".into());
                }
                let duration_checkpoint_before = duration_draw
                    .and_then(|draw| duration_policies.context_checkpoint(draw.context));
                if duration_checkpoint_before != job.duration_checkpoint_before {
                    return Err("replayed job duration state diverged before expansion".into());
                }
                let suffix_limit = replay_suffix_limit(spliced.is_none(), job.suffix_limit)?;
                let mut suffix = match (spliced, duration_draw) {
                    (Some(tail), _) => tail,
                    (None, draw) => workload.expand_suffix_recorded_duration(
                        &replay_run,
                        &draw_state,
                        MixtureDraw {
                            mixture: replay_mixture,
                            weight: job.mixture_weight,
                            splice_weight: job.splice_weight,
                        },
                        draw_checkpoint_before.as_ref(),
                        job.mutation_seed,
                        core.archive.last_action(parent_index),
                        draw,
                    )?,
                };
                if let Some(limit) = suffix_limit {
                    suffix.truncate(usize::from(limit));
                }
                let finish = replay
                    .iter()
                    .chain(&suffix)
                    .map(action_cost)
                    .fold(planned_start, u64::saturating_add);
                if last_admitted.is_some_and(|last| last >= (finish, replay_job_slot)) {
                    return Err(format!(
                        "replayed job {} was admitted out of planned-finish order",
                        job.sequence
                    )
                    .into());
                }
                last_admitted = Some((finish, replay_job_slot));
                replay_planned_clock = finish;
                let job_execution_work_before = workload.execution_work(&target);
                let result = workload.execute_job(
                    &replay_run,
                    &mut target,
                    &snapshot,
                    &replay,
                    parent_milestones,
                    &suffix,
                    replay_retention,
                    header.stop_rollout_on_objective,
                )?;
                let execution_work = execution_work_delta(
                    job_execution_work_before,
                    workload.execution_work(&target),
                    "replayed job",
                )?;
                if execution_work != job.execution_work {
                    return Err(format!(
                        "replayed job {} measured {execution_work} execution-work units against recorded {}",
                        job.sequence, job.execution_work
                    )
                    .into());
                }
                let digest = workload.result_sha256(&result)?;
                if digest != job.result_sha256 {
                    return Err(format!(
                        "replayed job {} result digest {digest} diverged from recorded {}",
                        job.sequence, job.result_sha256
                    )
                    .into());
                }
                let tracked_duration = duration_draw
                    .filter(|_| execution_work > 0)
                    .map(|draw| draw.duration);
                drop(snapshot);
                let objectives_before = core.objectives_reached;
                let continuation_wave = taken_continuation
                    .as_ref()
                    .map_or(0, |taken| taken.wave.saturating_add(1));
                core.archive.set_admission_wave(continuation_wave);
                let (sequence, decisions, duration_admission) = core.admit_job_tracking(
                    workload,
                    job.parent_id,
                    result,
                    suffix_limit.is_some(),
                    |action| {
                        tracked_duration.is_some_and(|duration| {
                            workload.duration_of_action(&replay_run, action) == Some(duration)
                        })
                    },
                )?;
                if sequence != job.sequence {
                    return Err(format!(
                        "replayed admission order {sequence} diverged from recorded {}",
                        job.sequence
                    )
                    .into());
                }
                if decisions != job.decisions {
                    return Err(format!(
                        "replayed job {} admission decisions diverged from the recorded stream",
                        job.sequence
                    )
                    .into());
                }
                if duration_admission.applied {
                    let draw = duration_draw
                        .ok_or("duration application was reported without a duration draw")?;
                    let evicted = duration_policies.eviction_checkpoint(draw.context);
                    duration_policies.observe(
                        draw.context,
                        draw.duration,
                        duration_admission.useful,
                        NonZeroU64::new(execution_work)
                            .ok_or("duration application requires positive execution work")?,
                    )?;
                    duration_admissions.push_back(DurationAdmissionRecord {
                        sequence,
                        context: draw.context,
                        before: duration_checkpoint_before.clone(),
                        evicted,
                    });
                }
                let duration_checkpoint_after = duration_draw
                    .and_then(|draw| duration_policies.context_checkpoint(draw.context));
                if duration_checkpoint_after != job.duration_checkpoint_after {
                    return Err("replayed job duration state diverged after admission".into());
                }
                let draw_checkpoint_after =
                    finish_record(workload, &replay_run, &mut draw_state, &core, &decisions)?;
                if draw_checkpoint_after != job.draw_checkpoint_after {
                    return Err(format!(
                        "replayed job {} draw-table checkpoint diverged",
                        job.sequence
                    )
                    .into());
                }
                let draw_state_memory_bytes = workload.draw_state_memory_bytes(&draw_state);
                if !memory_is_within_reserve(
                    draw_state_memory_bytes,
                    workload.draw_state_memory_reserve_bytes(&replay_run),
                ) {
                    return Err("replay draw state exceeds its deterministic memory reserve".into());
                }
                if !memory_is_within_reserve(
                    duration_policies.memory_bytes(),
                    duration_memory_reserve,
                ) {
                    return Err("replay adaptive duration state exceeds its memory reserve".into());
                }
                workload.remember_draw_version(&mut draw_state, &required_draw_versions)?;
                verify_selector_annotation(&job.selector)?;
                if job.selector.path == SelectorPath::Continuation {
                    core.archive.record_isolated_continuation(parent_index);
                    let new_cell_descendant = retained_archive_indexes(&core, &decisions)
                        .iter()
                        .any(|id| core.archive.opened_new_cell(*id));
                    let (landed, replaced) = continuation_arrival::<G>(
                        &core.archive,
                        taken_continuation
                            .as_ref()
                            .map(|taken| (taken.source, taken.destination)),
                        &decisions,
                    );
                    core.archive.record_continuation_outcome(
                        landed,
                        replaced,
                        new_cell_descendant,
                        continuation_wave,
                    );
                    core.archive.add_continuation_execution_work(execution_work);
                } else {
                    core.archive.record_selection(parent_index, &job.selector);
                    let retained_ids = retained_archive_indexes(&core, &decisions);
                    core.archive
                        .record_selection_outcome(parent_index, !retained_ids.is_empty());
                }
                core.archive.unpin_job_origin(snapshot_id);
                core.archive.unpin_metadata(job.parent_id);
                core.archive.maintain_memory_budget()?;
                core.archive.prepare_selection();
                for metadata_id in &replay_job_metadata[replay_job_slot] {
                    if let Some(uses) = replay_metadata_uses.get_mut(metadata_id) {
                        *uses = uses.saturating_sub(1);
                        if *uses == 0 {
                            replay_metadata_uses.remove(metadata_id);
                        }
                    }
                }
                if let Some(parent_id) =
                    replay_job_parents.get(admission_index.saturating_add(replay_window_depth))
                {
                    let next_slot = admission_index.saturating_add(replay_window_depth);
                    let (energy, continuation) = continuation_attempt(
                        &mut core,
                        header.campaign_seed,
                        u64::try_from(next_slot)?,
                    );
                    replay_continuation_energy.insert(next_slot, energy);
                    if let Some(continuation) = continuation {
                        replay_continuations.insert(next_slot, continuation);
                    }
                    let parent_index = core
                        .archive
                        .index_of_id(*parent_id)
                        .ok_or("next replay job names a parent the archive does not hold")?;
                    replay_job_snapshots
                        .insert(next_slot, core.archive.pin_job_origin(parent_index)?);
                    replay_selections.insert(next_slot, (replay_planned_clock, core.sequence));
                    for metadata_id in &replay_job_metadata[next_slot] {
                        let uses = replay_metadata_uses.entry(*metadata_id).or_default();
                        *uses = uses
                            .checked_add(1)
                            .ok_or("recorded metadata use count overflow")?;
                    }
                }
                core.archive
                    .preserve_recorded_metadata_uses(replay_metadata_uses.clone());
                counters.job_execution_work =
                    counters.job_execution_work.saturating_add(execution_work);
                duration_work.push_back((
                    sequence,
                    counters
                        .bootstrap_execution_work
                        .saturating_add(counters.job_execution_work),
                ));
                let oldest_selection = replay_selections
                    .first_key_value()
                    .map_or(core.sequence, |(_, (_, selection))| *selection);
                while duration_work
                    .front()
                    .is_some_and(|(sequence, _)| *sequence < oldest_selection)
                {
                    duration_work.pop_front();
                }
                while duration_admissions
                    .front()
                    .is_some_and(|admission| admission.sequence <= oldest_selection)
                {
                    duration_admissions.pop_front();
                }
                if objectives_before == 0 && core.objectives_reached > 0 {
                    counters.note_first_objective(sequence);
                }
            }
        }
    }
    core.archive.preserve_inactive_snapshots(false)?;
    core.archive.compact_history_for_final_report()?;
    core.finish_curve();

    let origin = CampaignOriginRecord {
        kind: header.origin_kind.clone(),
        path: header.origin_path.clone(),
        archive_sha256: header.origin_archive_sha256.clone(),
        checkpoint_path: header.origin_checkpoint_path.clone(),
        checkpoint_sha256: header.origin_checkpoint_sha256.clone(),
        checkpoint_policy_changes: header.origin_checkpoint_policy_changes.clone(),
        resume_input_sha256: header.resume_input_sha256.clone(),
        resume_actions: header.resume_actions,
    };
    counters.draw_state_memory_bytes = workload
        .draw_state_memory_bytes(&draw_state)
        .saturating_add(duration_policies.memory_bytes());
    Ok(build_report(
        workload,
        &header,
        origin,
        core,
        &counters,
        stream_sha256,
        true,
    ))
}

#[cfg(test)]
#[path = "campaign_continuation_tests.rs"]
mod continuation_tests;

#[cfg(test)]
mod tests {
    use std::sync::Arc;

    use super::{
        ArchiveReportState, CampaignActionResult, CampaignAdmissionDecision, CampaignCandidate,
        CampaignConfig, CampaignCounters, CampaignExecutionOptions, CampaignJobRecord,
        CampaignJobResult, CampaignOrigin, CampaignOutcome, CampaignProgressRecord,
        CampaignSpliceRecord, CampaignStreamHeader, CampaignStreamRecord, CampaignTypes,
        ContinuationAccounting, CoordinatorCore, DrawTables, DurationAdmission,
        EmpiricalStepCheckpoint, EnergyStrategy, Evaluation, InputPolicy, LONGEST_SPLICE_TAIL,
        LiveCoordinatorProfile, MAX_PROGRESS_CURVE_POINTS, PROGRESS_CHECKPOINT_INTERVAL,
        PlacedThread, Reporting, RomuDuoJrRand, SnapshotCheckpoint, SnapshotCheckpointEntry,
        TargetExecution, ThreadPlacement, WorkloadPolicies, archive_entry_limit_is_valid,
        compact_progress_curve, default_window, draws_continuation, draws_highest_preference,
        execution_work_delta, finish_record, full_selector_report_due, is_zero_usize,
        memory_is_within_reserve, postcard_value_sha256, profile_elapsed, progress_checkpoint_due,
        progress_line_interval, progress_policy_is_supported, record_compaction_elapsed,
        record_mixture_outcome, replay_campaign_checkpointed, replay_splice,
        resident_memory_is_within_budget, retained_archive_indexes, run_campaign_checkpointed,
        run_campaign_checkpointed_with_options, schedule_policy_identifier,
        schedule_policy_is_supported, schedule_policy_window, stop_reservations_after_objective,
    };
    use crate::search::archive::{
        ArchiveEntryReport, ArchiveKey, Input, ProgressPoint, RetentionPolicy, SelectorDraw,
        SelectorPath, entries_by_suffix,
    };
    use crate::search::draw::{DrawMixture, MixtureDraw, MixtureEnergy};
    use crate::search::rollout::{ExecutionDisposition, Outcome, Rollout, execute_suffix};
    use serde::{Deserialize, Serialize};
    use sha2::{Digest, Sha256};
    use std::{
        collections::BTreeSet,
        error::Error,
        time::{Duration, Instant},
    };

    #[derive(Clone, Copy, Debug, Deserialize, Eq, Hash, Ord, PartialEq, PartialOrd, Serialize)]
    struct TestAction {
        input: u8,
        work_units: u8,
    }

    impl TestAction {
        fn new(input: u8, work_units: u8) -> Self {
            Self {
                input,
                work_units: work_units.max(1),
            }
        }
    }

    fn test_action_cost(action: &TestAction) -> u64 {
        u64::from(action.work_units).saturating_mul(2)
    }

    #[derive(Clone, Copy, Debug, Deserialize, Eq, Ord, PartialEq, PartialOrd, Serialize)]
    struct TestKey(u8);

    impl ArchiveKey for TestKey {
        type Place = u8;
        type Progress = ();
        type Identity = ();

        fn place(self) -> Self::Place {
            self.0
        }

        fn progress(self) -> Self::Progress {}

        fn identity(self) -> Self::Identity {}

        type Lineage = ();

        fn complete(self, parent: Option<(Self, &Self::Lineage)>) -> Self {
            match parent {
                Some((parent, ())) if self.0 == INHERITS_PARENT_PLACE => parent,
                _ => self,
            }
        }

        fn record(_lineage: &mut Self::Lineage, _key: Self) {}
    }

    const INHERITS_PARENT_PLACE: u8 = u8::MAX;

    #[derive(Default)]
    struct LiveTargets {
        refuse: bool,
        live: std::sync::atomic::AtomicUsize,
        most: std::sync::atomic::AtomicUsize,
    }

    #[derive(Default)]
    struct TestTarget {
        value: u8,
        execution_work: u64,
        _counted: Option<TargetCount>,
    }

    struct TargetCount(Arc<LiveTargets>);

    impl Drop for TargetCount {
        fn drop(&mut self) {
            self.0
                .live
                .fetch_sub(1, std::sync::atomic::Ordering::SeqCst);
        }
    }

    impl TestTarget {
        fn apply(&mut self, action: &TestAction) {
            self.value = self.value.wrapping_add(action.input);
            self.execution_work = self
                .execution_work
                .saturating_add(u64::from(action.work_units));
        }

        fn snapshot(&self) -> Result<u8, Box<dyn Error>> {
            Ok(self.value)
        }
    }

    #[derive(Clone, Debug, Deserialize, Eq, PartialEq, Serialize)]
    struct TestArchiveReport {
        #[serde(with = "entries_by_suffix")]
        entries: Vec<ArchiveEntryReport<TestAction, TestKey, ()>>,
    }

    struct TestWorkload {
        bootstrap_objective: bool,
        targets: Option<Arc<LiveTargets>>,
    }
    impl CampaignTypes for TestWorkload {
        type Target = TestTarget;
        type Action = TestAction;
        type Key = TestKey;
        type Milestones = ();
        type Progress = ();
        type Snapshot = u8;
        type Observations = ();
        type Evidence = ();
        type ArchiveReport = TestArchiveReport;
        type Run = ();
    }

    impl Reporting for TestWorkload {
        fn stream_format(&self) -> &'static str {
            "test-campaign-v1"
        }
        fn checkpoint_format(&self) -> &'static str {
            "test-checkpoint-v1"
        }
        fn workload_identity_sha256(&self) -> String {
            "test-image".to_owned()
        }
        fn action_cost_unit(&self) -> &'static str {
            "test-cost"
        }
        fn execution_work_unit(&self) -> &'static str {
            "test-work"
        }
        fn result_sha256(
            &self,
            result: &CampaignJobResult<Self>,
        ) -> Result<String, Box<dyn Error>> {
            postcard_value_sha256(result)
        }

        fn archive_report(
            &self,
            _evidence: &Self::Evidence,
            state: ArchiveReportState<Self>,
        ) -> Self::ArchiveReport {
            TestArchiveReport {
                entries: state.entries,
            }
        }
    }

    impl InputPolicy for TestWorkload {
        fn policies(&self, _run: &Self::Run) -> WorkloadPolicies {
            WorkloadPolicies::new()
        }
        fn resolve_recorded(
            &self,
            _policies: &WorkloadPolicies,
        ) -> Result<Self::Run, Box<dyn Error>> {
            Ok(())
        }
        fn sample_alphabet(
            &self,
            _run: &Self::Run,
            _previous: Option<&Self::Action>,
            rand: &mut RomuDuoJrRand,
        ) -> Result<Self::Action, Box<dyn Error>> {
            Ok(TestAction::new(rand.next_u64() as u8, 1))
        }
        fn expand_suffix(
            &self,
            _run: &Self::Run,
            _state: &DrawTables<Self::Action>,
            _mixture: MixtureDraw,
            mutation_seed: u64,
            _previous: Option<&Self::Action>,
        ) -> Result<Vec<Self::Action>, Box<dyn Error>> {
            let long = mutation_seed >> 32 & 1 == 1;
            let length = 1 + usize::from(long);
            Ok(vec![
                TestAction::new(mutation_seed as u8, 1 + u8::from(long));
                length
            ])
        }
        fn expand_suffix_recorded(
            &self,
            run: &Self::Run,
            state: &DrawTables<Self::Action>,
            mixture: MixtureDraw,
            _before: Option<&EmpiricalStepCheckpoint>,
            mutation_seed: u64,
            previous: Option<&Self::Action>,
        ) -> Result<Vec<Self::Action>, Box<dyn Error>> {
            self.expand_suffix(run, state, mixture, mutation_seed, previous)
        }
    }

    impl TargetExecution for TestWorkload {
        fn new_target(&self) -> Result<Self::Target, String> {
            let Some(targets) = &self.targets else {
                return Ok(TestTarget::default());
            };
            if targets.refuse {
                return Err("the test target refused to start".to_owned());
            }
            let live = targets
                .live
                .fetch_add(1, std::sync::atomic::Ordering::SeqCst)
                + 1;
            targets
                .most
                .fetch_max(live, std::sync::atomic::Ordering::SeqCst);
            Ok(TestTarget {
                _counted: Some(TargetCount(Arc::clone(targets))),
                ..TestTarget::default()
            })
        }
        fn reset(&self, target: &mut Self::Target) {
            target.value = 0;
        }
        fn restore(
            &self,
            target: &mut Self::Target,
            snapshot: &Self::Snapshot,
        ) -> Result<(), Box<dyn Error>> {
            target.value = *snapshot;
            Ok(())
        }
        fn execution_work(&self, target: &Self::Target) -> u64 {
            target.execution_work
        }
        fn telemetry(&self, target: &Self::Target) -> crate::search::telemetry::TargetCounters {
            crate::search::telemetry::TargetCounters::from([(
                "work".to_owned(),
                target.execution_work,
            )])
        }
        fn apply_action(
            &self,
            target: &mut Self::Target,
            action: &Self::Action,
            _milestones: &mut Self::Milestones,
        ) -> Result<(), Box<dyn Error>> {
            target.apply(action);
            Ok(())
        }
        fn snapshot(&self, target: &mut Self::Target) -> Result<Self::Snapshot, Box<dyn Error>> {
            target.snapshot()
        }
        fn action_cost_fn(&self) -> fn(&Self::Action) -> u64 {
            test_action_cost
        }

        fn snapshot_memory_charge(_snapshot: &Self::Snapshot) -> usize {
            1
        }
    }

    impl Evaluation for TestWorkload {
        fn execution_disposition(&self, _target: &Self::Target) -> ExecutionDisposition {
            ExecutionDisposition::Runnable
        }

        fn objective_reached(
            &self,
            _run: &Self::Run,
            target: &Self::Target,
        ) -> Result<bool, Box<dyn Error>> {
            Ok(self.bootstrap_objective && target.execution_work == 0)
        }

        fn current_key(&self, target: &Self::Target) -> Result<Self::Key, Box<dyn Error>> {
            Ok(TestKey(target.value))
        }

        fn complete_candidate_key(
            &self,
            key: Self::Key,
            _snapshot: &Self::Snapshot,
        ) -> Result<Self::Key, Box<dyn Error>> {
            Ok(key)
        }

        fn merge_milestones(&self, _into: &mut Self::Milestones, _from: Self::Milestones) {}
        fn aggregate_milestones(_evidence: &Self::Evidence) -> Self::Milestones {}
        fn aggregate_progress(_evidence: &Self::Evidence) -> Self::Progress {}
        fn merge_origin_evidence(
            &self,
            _evidence: &mut Self::Evidence,
            _source: &Self::ArchiveReport,
        ) {
        }
        fn merge_snapshot_root_evidence(
            &self,
            _evidence: &mut Self::Evidence,
            _target: &Self::Target,
        ) -> Result<(), Box<dyn Error>> {
            Ok(())
        }
        fn merge_import_evidence(
            &self,
            _evidence: &mut Self::Evidence,
            _milestones: Self::Milestones,
            _input: &Input<Self::Action>,
        ) {
        }
        fn merge_action_evidence<F>(
            &self,
            _evidence: &mut Self::Evidence,
            _action: &CampaignActionResult<Self>,
            _sequence: u64,
            _input: F,
        ) -> Result<(), Box<dyn Error>>
        where
            F: FnOnce() -> Result<Input<Self::Action>, Box<dyn Error>>,
        {
            Ok(())
        }
        fn source_entries<'a>(
            &self,
            source: &'a Self::ArchiveReport,
        ) -> &'a [ArchiveEntryReport<Self::Action, Self::Key, Self::Milestones>] {
            &source.entries
        }
        fn resume_input(
            &self,
            source: &Self::ArchiveReport,
        ) -> Result<Input<Self::Action>, Box<dyn Error>> {
            source
                .entries
                .iter()
                .max_by_key(|entry| (entry.key, entry.id))
                .map(|entry| entry.input.clone())
                .ok_or_else(|| "test fixture has no source archive".into())
        }
    }

    struct TestRollout<'a> {
        target: &'a mut TestTarget,
        initial_terminal: bool,
        terminal_after: Option<u8>,
        objective_after: Option<u8>,
        failed_after: Option<u8>,
        fail_apply: bool,
        fail_probe: bool,
        probe_calls: Vec<u8>,
    }

    impl<'a> TestRollout<'a> {
        fn new(target: &'a mut TestTarget) -> Self {
            Self {
                target,
                initial_terminal: false,
                terminal_after: None,
                objective_after: None,
                failed_after: None,
                fail_apply: false,
                fail_probe: false,
                probe_calls: Vec::new(),
            }
        }
    }

    impl Rollout<TestWorkload> for TestRollout<'_> {
        fn apply(
            &mut self,
            action: &TestAction,
            _milestones: &mut (),
        ) -> Result<(), Box<dyn Error>> {
            if self.fail_apply {
                return Err("test apply failed".into());
            }
            self.target.apply(action);
            Ok(())
        }

        fn observations(&self) -> Vec<()> {
            vec![()]
        }

        fn outcome(&self) -> Result<Outcome, Box<dyn Error>> {
            if self.initial_terminal && self.target.execution_work == 0 {
                return Ok(Outcome {
                    disposition: ExecutionDisposition::Terminal,
                    ..Outcome::default()
                });
            }
            if self
                .failed_after
                .is_some_and(|limit| self.target.value >= limit)
            {
                return Ok(Outcome {
                    disposition: ExecutionDisposition::Failed,
                    ..Outcome::default()
                });
            }
            let objective_reached = self
                .objective_after
                .is_some_and(|limit| self.target.value >= limit);
            let disposition = if self
                .terminal_after
                .is_some_and(|limit| self.target.value >= limit)
            {
                ExecutionDisposition::Terminal
            } else {
                ExecutionDisposition::default()
            };
            Ok(Outcome {
                objective_reached,
                disposition,
            })
        }

        fn snapshot(&mut self) -> Result<u8, Box<dyn Error>> {
            self.target.snapshot()
        }

        fn key(&self) -> Result<TestKey, Box<dyn Error>> {
            Ok(TestKey(self.target.value))
        }

        fn probe(&mut self, snapshot: &u8) -> Result<bool, Box<dyn Error>> {
            if self.fail_probe {
                return Err("test probe failed".into());
            }
            self.probe_calls.push(*snapshot);
            self.target.value = snapshot.wrapping_add(1);
            self.target.value = *snapshot;
            Ok(true)
        }
    }

    fn test_core() -> (TestWorkload, (), CoordinatorCore<TestWorkload>, TestTarget) {
        let workload = TestWorkload {
            bootstrap_objective: false,
            targets: None,
        };
        let run = ();
        let mut core = CoordinatorCore::new(&workload, &run, 1_024, None);
        let mut target = TestTarget::default();
        core.bootstrap(&workload, &run, &mut target)
            .expect("bootstrap generic core");
        (workload, run, core, target)
    }

    #[test]
    fn rollout_stops_on_an_already_terminal_parent() {
        let mut target = TestTarget::default();
        let mut rollout = TestRollout::new(&mut target);
        rollout.initial_terminal = true;
        let result = execute_suffix(
            &mut rollout,
            (),
            &[TestAction::new(1, 1)],
            RetentionPolicy::Unprobed,
            false,
        )
        .expect("terminal parent is a valid no-op rollout");
        assert!(result.actions.is_empty());
        assert!(result.preparation_failure.is_none());
        assert_eq!(rollout.target.value, 0);

        let mut target = TestTarget::default();
        let mut failed = TestRollout::new(&mut target);
        failed.failed_after = Some(0);
        let result = execute_suffix(
            &mut failed,
            (),
            &[TestAction::new(1, 1)],
            RetentionPolicy::Unprobed,
            false,
        )
        .expect("failed parent is a reportable preparation failure");
        assert!(result.actions.is_empty());
        assert_eq!(result.preparation_failure, Some(vec![()]));
    }

    #[test]
    fn rollout_runs_every_suffix_action_and_restores_after_each_probe() {
        let mut target = TestTarget::default();
        let mut rollout = TestRollout::new(&mut target);
        let result = execute_suffix(
            &mut rollout,
            (),
            &[
                TestAction::new(1, 1),
                TestAction::new(2, 1),
                TestAction::new(4, 1),
            ],
            RetentionPolicy::ProbeAtAdmission,
            false,
        )
        .expect("rollout");
        assert_eq!(result.actions.len(), 3);
        assert_eq!(
            result.actions[0].candidate.as_ref().map(|c| c.key),
            Some(TestKey(1))
        );
        assert_eq!(
            result.actions[1].candidate.as_ref().map(|c| c.key),
            Some(TestKey(3))
        );
        assert_eq!(
            result.actions[2].candidate.as_ref().map(|c| c.key),
            Some(TestKey(7))
        );
        assert_eq!(rollout.probe_calls, vec![1, 3, 7]);
        assert_eq!(rollout.target.value, 7, "probe restores the live target");
    }

    #[test]
    fn rollout_stops_on_terminal_actions_and_propagates_failures() {
        let mut target = TestTarget::default();
        let mut rollout = TestRollout::new(&mut target);
        rollout.terminal_after = Some(2);
        rollout.objective_after = Some(2);
        let result = execute_suffix(
            &mut rollout,
            (),
            &[
                TestAction::new(1, 1),
                TestAction::new(1, 1),
                TestAction::new(1, 1),
            ],
            RetentionPolicy::Unprobed,
            false,
        )
        .expect("terminal action rollout");
        assert_eq!(result.actions.len(), 2);
        assert!(result.actions[1].outcome.objective_reached);
        assert!(result.actions[1].candidate.is_none());

        let mut target = TestTarget::default();
        let mut apply_failure = TestRollout::new(&mut target);
        apply_failure.fail_apply = true;
        assert!(
            execute_suffix(
                &mut apply_failure,
                (),
                &[TestAction::new(1, 1)],
                RetentionPolicy::Unprobed,
                false,
            )
            .is_err()
        );

        let mut target = TestTarget::default();
        let mut probe_failure = TestRollout::new(&mut target);
        probe_failure.fail_probe = true;
        assert!(
            execute_suffix(
                &mut probe_failure,
                (),
                &[TestAction::new(1, 1)],
                RetentionPolicy::ProbeAtAdmission,
                false,
            )
            .is_err()
        );
    }

    #[test]
    fn runnable_objectives_keep_candidates_and_stop_only_the_current_suffix() {
        let mut target = TestTarget::default();
        let mut rollout = TestRollout::new(&mut target);
        rollout.objective_after = Some(1);
        let result = execute_suffix(
            &mut rollout,
            (),
            &[TestAction::new(1, 1), TestAction::new(1, 1)],
            RetentionPolicy::Unprobed,
            true,
        )
        .expect("runnable objective rollout");
        assert_eq!(result.actions.len(), 1);
        assert!(result.actions[0].outcome.objective_reached);
        assert_eq!(
            result.actions[0].outcome.disposition,
            ExecutionDisposition::Runnable
        );
        assert_eq!(
            result.actions[0].candidate.as_ref().map(|c| c.key),
            Some(TestKey(1))
        );

        let mut target = TestTarget {
            value: 1,
            ..TestTarget::default()
        };
        let mut continuation = TestRollout::new(&mut target);
        continuation.objective_after = Some(1);
        let result = execute_suffix(
            &mut continuation,
            (),
            &[TestAction::new(1, 1)],
            RetentionPolicy::Unprobed,
            true,
        )
        .expect("continuation after a latched objective");
        assert_eq!(result.actions.len(), 1);
        assert!(!result.actions[0].outcome.objective_reached);
        assert_eq!(
            result.actions[0].candidate.as_ref().map(|c| c.key),
            Some(TestKey(2))
        );
    }

    #[test]
    fn terminal_and_failed_outcomes_are_distinct_and_have_no_candidates() {
        let mut target = TestTarget::default();
        let mut terminal = TestRollout::new(&mut target);
        terminal.terminal_after = Some(1);
        let result = execute_suffix(
            &mut terminal,
            (),
            &[TestAction::new(1, 1), TestAction::new(1, 1)],
            RetentionPolicy::Unprobed,
            false,
        )
        .expect("terminal outcome");
        assert_eq!(result.actions.len(), 1);
        assert!(!result.actions[0].outcome.objective_reached);
        assert_eq!(
            result.actions[0].outcome.disposition,
            ExecutionDisposition::Terminal
        );
        assert!(result.actions[0].candidate.is_none());

        let mut target = TestTarget::default();
        let mut failed = TestRollout::new(&mut target);
        failed.failed_after = Some(1);
        let result = execute_suffix(
            &mut failed,
            (),
            &[TestAction::new(1, 1), TestAction::new(1, 1)],
            RetentionPolicy::Unprobed,
            false,
        )
        .expect("failed outcome");
        assert_eq!(result.actions.len(), 1);
        assert_eq!(
            result.actions[0].outcome.disposition,
            ExecutionDisposition::Failed
        );
        assert_eq!(result.actions[0].observations, vec![()]);
        assert!(result.actions[0].candidate.is_none());
    }

    #[test]
    fn coordinator_counts_terminal_objectives_and_execution_failures_separately() {
        let (workload, _run, mut core, _target) = test_core();
        let terminal_objective = TestAction::new(1, 1);
        core.admit_job(
            &workload,
            0,
            CampaignJobResult {
                preparation_failure: None,
                actions: vec![CampaignActionResult {
                    action: terminal_objective,
                    observations: Vec::new(),
                    milestones: (),
                    outcome: Outcome {
                        objective_reached: true,
                        disposition: ExecutionDisposition::Terminal,
                    },
                    candidate: None,
                }],
            },
        )
        .expect("admit terminal objective");
        assert_eq!(core.terminal_endpoints, 1);
        assert_eq!(core.terminal_objectives, 1);
        assert_eq!(core.execution_failures, 0);

        let failed = TestAction::new(2, 1);
        core.admit_job(
            &workload,
            0,
            CampaignJobResult {
                preparation_failure: None,
                actions: vec![CampaignActionResult {
                    action: failed,
                    observations: vec![()],
                    milestones: (),
                    outcome: Outcome {
                        objective_reached: false,
                        disposition: ExecutionDisposition::Failed,
                    },
                    candidate: None,
                }],
            },
        )
        .expect("admit failed execution");
        assert_eq!(core.terminal_endpoints, 1);
        assert_eq!(core.terminal_objectives, 1);
        assert_eq!(core.execution_failures, 1);
    }

    #[test]
    fn coordinator_admits_one_preparation_failure_without_actions() {
        let (workload, _run, mut core, _target) = test_core();
        let (sequence, decisions) = core
            .admit_job(
                &workload,
                0,
                CampaignJobResult {
                    preparation_failure: Some(vec![()]),
                    actions: Vec::new(),
                },
            )
            .expect("admit preparation failure");
        assert_eq!(sequence, 1);
        assert!(decisions.is_empty());
        assert_eq!(core.execution_failures, 1);
        assert_eq!(core.archive.retained, 1);

        let action = TestAction::new(1, 1);
        let error = core
            .admit_job(
                &workload,
                0,
                CampaignJobResult {
                    preparation_failure: Some(vec![()]),
                    actions: vec![CampaignActionResult {
                        action,
                        observations: Vec::new(),
                        milestones: (),
                        outcome: Outcome::default(),
                        candidate: None,
                    }],
                },
            )
            .expect_err("preparation failure cannot fabricate actions");
        assert_eq!(
            error.to_string(),
            "preparation failure result also carries actions"
        );
        assert_eq!(core.execution_failures, 1);
    }

    #[test]
    fn bootstrap_records_an_objective_at_the_empty_input() {
        let workload = TestWorkload {
            bootstrap_objective: true,
            targets: None,
        };
        let run = ();
        let mut core = CoordinatorCore::new(&workload, &run, 1_024, None);
        let mut target = TestTarget::default();
        core.bootstrap(&workload, &run, &mut target)
            .expect("bootstrap root");
        assert_eq!(core.objectives_reached, 1);
        assert_eq!(core.objective_witness, Some(Input::default()));
    }

    #[test]
    fn bootstrap_objective_stops_reservation_and_replays_with_both_stop_policies() {
        for (stop_rollout_on_objective, stop_campaign_on_objective) in
            [(false, false), (true, false), (false, true), (true, true)]
        {
            let witness_path = std::env::temp_dir().join(format!(
                "harmony-bootstrap-objective-{}-{stop_rollout_on_objective}-{stop_campaign_on_objective}.json",
                std::process::id()
            ));
            let config = CampaignConfig {
                campaign_seed: 7,
                workers: 1,
                execution_budget: 1,
                host: "test".to_owned(),
                wall_budget: None,
                stop_rollout_on_objective,
                stop_campaign_on_objective,
                archive_entry_limit: 16,
                window: 1,
                memory_budget_mib: None,
                materialize_final_artifacts: true,
                run: (),
                mixture: DrawMixture::AlphabetOnly,
                retention: RetentionPolicy::Unprobed,
                objective_witness_path: Some(witness_path.clone()),
            };
            let workload = TestWorkload {
                bootstrap_objective: true,
                targets: None,
            };
            let mut stream = Vec::new();
            let live = run_campaign_checkpointed(
                &workload,
                &config,
                &CampaignOrigin::Genesis,
                &mut stream,
                None,
            )
            .expect("bootstrap objective campaign");
            assert_eq!(live.0.objectives_reached, 1);
            assert_eq!(live.0.objective_witness, Some(Input::default()));
            assert_eq!(
                live.0.executions_completed,
                if stop_campaign_on_objective { 0 } else { 1 }
            );
            assert_eq!(live.0.stop_rollout_on_objective, stop_rollout_on_objective);
            assert_eq!(
                live.0.stop_campaign_on_objective,
                stop_campaign_on_objective
            );
            assert_eq!(
                std::fs::read(&witness_path).expect("bootstrap witness file"),
                serde_json::to_vec_pretty(&Input::<TestAction>::default())
                    .expect("empty witness encodes")
            );

            let replayed = replay_campaign_checkpointed(&workload, &stream, None, None)
                .expect("bootstrap objective replay");
            assert_eq!(replayed, live);
            std::fs::remove_file(witness_path).expect("remove bootstrap witness file");
        }
    }

    const RECORDED_HEADER: &str = r#"{"schema_version":10,"format":"campaign-v1","campaign_seed":7,
"schedule_policy":"planned_finish_window_2_v5","progress_policy":"mechanical_watermark_bounded_1024_v2",
"host":"box","origin_kind":"genesis","origin_path":null,"origin_archive_sha256":null,
"resume_input_sha256":"ab","resume_actions":0,"execution_budget":10,"stop_rollout_on_objective":true,"stop_campaign_on_objective":true,"wall_budget_seconds":null,
"archive_entry_limit":128,"action_vocabulary":"test_inputs",
"key_policy":"test_key","duration_policy":"stratified",
"step_policy":"step_uniform","replacement_policy":"least_cost_per_group",
"resume_policy":"whole_tree","retention_policy":"unprobed",
"parent_scheduler":"tier_pace_yield_cell_recent_count_decay_v1","preference_portfolio":"preference_portfolio_v1:1,1","executor_mode":"snapshot_resume_archive",
"selection_seed_derivation":"x","mixture_policy":"biased_half","workload_identity_sha256":"cd",
"action_cost_unit":"test_cost","execution_work_unit":"test_work"}"#;

    #[test]
    fn incremental_postcard_digest_matches_encoded_bytes() {
        let value = (17_u64, vec![0_u8, 1, 15, 16, 255], Some("deterministic"));
        let encoded = postcard::to_allocvec(&value).expect("fixture encodes");
        let expected = format!("{:x}", Sha256::digest(encoded));
        let actual = postcard_value_sha256(&value).expect("incremental digest succeeds");

        assert_eq!(actual, expected);
        assert_eq!(actual.len(), 64);
    }

    #[test]
    fn progress_curve_compaction_is_bounded_and_evenly_spaced() {
        let mut curve: Vec<ProgressPoint<(), ()>> = (1..=MAX_PROGRESS_CURVE_POINTS)
            .map(|sample| ProgressPoint {
                executions: u64::try_from(sample).expect("sample fits u64") * 100,
                milestones: (),
                progress: None,
                active_entries: sample,
                occupied_cells: sample,
                terminal_endpoints: 0,
                execution_failures: 0,
            })
            .collect();

        let interval = compact_progress_curve(&mut curve, 100);

        assert_eq!(interval, 200);
        assert_eq!(curve.len(), MAX_PROGRESS_CURVE_POINTS / 2);
        assert!(
            curve
                .iter()
                .all(|point| point.executions.is_multiple_of(interval))
        );
        assert_eq!(curve.first().map(|point| point.executions), Some(200));
        assert_eq!(
            curve.last().map(|point| point.executions),
            Some(u64::try_from(MAX_PROGRESS_CURVE_POINTS).expect("bound fits u64") * 100)
        );
    }

    #[test]
    fn progress_curve_boundaries_and_final_point_are_exact() {
        let mut below: Vec<ProgressPoint<(), ()>> = (1..MAX_PROGRESS_CURVE_POINTS)
            .map(|sample| ProgressPoint {
                executions: u64::try_from(sample).expect("sample fits u64") * 100,
                milestones: (),
                progress: None,
                active_entries: sample,
                occupied_cells: sample,
                terminal_endpoints: 0,
                execution_failures: 0,
            })
            .collect();
        let unchanged = below.clone();
        assert_eq!(compact_progress_curve(&mut below, 100), 100);
        assert_eq!(below, unchanged);
        assert!(is_zero_usize(&0));
        assert!(!is_zero_usize(&1));

        let (_game, _run, mut core, _target) = test_core();
        core.sequence = 0;
        core.finish_curve();
        assert!(core.curve.is_empty());
        core.sequence = 7;
        core.finish_curve();
        core.finish_curve();
        assert_eq!(
            core.curve
                .iter()
                .map(|point| point.executions)
                .collect::<Vec<_>>(),
            vec![7]
        );

        core.curve = (1..=MAX_PROGRESS_CURVE_POINTS)
            .map(|sample| ProgressPoint {
                executions: u64::try_from(sample).expect("sample fits u64") * 100,
                milestones: (),
                progress: Some(()),
                active_entries: sample,
                occupied_cells: sample,
                terminal_endpoints: 0,
                execution_failures: 0,
            })
            .collect();
        core.curve_interval = 100;
        core.bounded_progress_curve = false;
        core.compact_progress_curve_if_needed();
        assert_eq!(core.curve.len(), MAX_PROGRESS_CURVE_POINTS);
        core.curve.pop();
        core.bounded_progress_curve = true;
        core.compact_progress_curve_if_needed();
        assert_eq!(core.curve.len(), MAX_PROGRESS_CURVE_POINTS - 1);
        core.curve.push(ProgressPoint {
            executions: u64::try_from(MAX_PROGRESS_CURVE_POINTS).expect("bound fits u64") * 100,
            milestones: (),
            progress: Some(()),
            active_entries: MAX_PROGRESS_CURVE_POINTS,
            occupied_cells: MAX_PROGRESS_CURVE_POINTS,
            terminal_endpoints: 0,
            execution_failures: 0,
        });
        core.bounded_progress_curve = true;
        core.compact_progress_curve_if_needed();
        assert_eq!(core.curve.len(), MAX_PROGRESS_CURVE_POINTS / 2);
        assert_eq!(core.curve_interval, 200);
    }

    #[test]
    fn sidecar_checkpoint_boundaries_use_completed_execution_count() {
        let checkpoints = (1..=200)
            .filter(|&executions| progress_checkpoint_due(executions))
            .collect::<Vec<_>>();
        assert_eq!(checkpoints, vec![1, 100, 200]);
        for executions in [0, 2, 99, 101] {
            assert!(!progress_checkpoint_due(executions));
        }
    }

    #[test]
    fn progress_lines_thin_to_a_bounded_count_per_doubling() {
        let span = PROGRESS_CHECKPOINT_INTERVAL * MAX_PROGRESS_CURVE_POINTS as u64;
        assert_eq!(
            progress_line_interval(2 * span - 1),
            PROGRESS_CHECKPOINT_INTERVAL
        );
        assert_eq!(
            progress_line_interval(2 * span),
            2 * PROGRESS_CHECKPOINT_INTERVAL
        );
        assert!(progress_checkpoint_due(2 * span + 200));
        assert!(!progress_checkpoint_due(2 * span + 100));
        for doubling in 1..8 {
            let start = span << doubling;
            let lines = (start..2 * start)
                .step_by(PROGRESS_CHECKPOINT_INTERVAL as usize)
                .filter(|&executions| progress_checkpoint_due(executions))
                .count();
            assert_eq!(lines, MAX_PROGRESS_CURVE_POINTS);
            let reports = (start..2 * start)
                .step_by(PROGRESS_CHECKPOINT_INTERVAL as usize)
                .filter(|&executions| full_selector_report_due(executions))
                .collect::<Vec<_>>();
            assert_eq!(reports, vec![start]);
            assert!(progress_checkpoint_due(start));
        }
        assert!(full_selector_report_due(span));
        assert!(!full_selector_report_due(span / 2));
        assert!(progress_line_interval(u64::MAX) > PROGRESS_CHECKPOINT_INTERVAL);
    }

    #[test]
    fn reservations_continue_after_objective_only_when_requested() {
        assert!(stop_reservations_after_objective(true, true));
        assert!(!stop_reservations_after_objective(false, true));
        assert!(!stop_reservations_after_objective(true, false));
    }

    #[test]
    fn coordinator_classifies_new_and_duplicate_boundaries() {
        let (workload, _run, mut core, mut target) = test_core();
        let action = TestAction::new(0x01, 4);
        target.apply(&action);
        let snapshot = target.snapshot().expect("snapshot candidate");
        let result = CampaignJobResult::<TestWorkload> {
            preparation_failure: None,
            actions: vec![CampaignActionResult {
                action,
                observations: Vec::new(),
                milestones: (),
                outcome: Outcome::default(),
                candidate: Some(CampaignCandidate {
                    key: TestKey(target.value),
                    viable: true,
                    snapshot,
                }),
            }],
        };

        let (first_sequence, first) = core
            .admit_job(&workload, 0, result.clone())
            .expect("admit new boundary");
        assert_eq!(first_sequence, 1);
        assert_eq!(first, vec![CampaignAdmissionDecision::Retained { id: 1 }]);
        assert!(core.all_prefixes_archived(0, &[action]));
        assert!(!core.all_prefixes_archived(0, &[]));

        let (second_sequence, second) = core
            .admit_job(&workload, 0, result)
            .expect("admit duplicate boundary");
        assert_eq!(second_sequence, 2);
        assert_eq!(second, vec![CampaignAdmissionDecision::Duplicate { id: 1 }]);
        assert_eq!(core.archive.retained, 2);
    }

    #[test]
    fn duration_credit_follows_the_action_that_created_novelty() {
        let (workload, _run, mut core, _target) = test_core();
        let tracked = TestAction::new(0x01, 4);
        let seed = CampaignJobResult::<TestWorkload> {
            preparation_failure: None,
            actions: vec![CampaignActionResult {
                action: tracked,
                observations: Vec::new(),
                milestones: (),
                outcome: Outcome::default(),
                candidate: Some(CampaignCandidate {
                    key: TestKey(1),
                    viable: true,
                    snapshot: 1,
                }),
            }],
        };
        core.admit_job(&workload, 0, seed)
            .expect("seed tracked boundary");

        let untracked = TestAction::new(0x01, 7);
        let result = CampaignJobResult::<TestWorkload> {
            preparation_failure: None,
            actions: vec![
                CampaignActionResult {
                    action: tracked,
                    observations: Vec::new(),
                    milestones: (),
                    outcome: Outcome::default(),
                    candidate: Some(CampaignCandidate {
                        key: TestKey(1),
                        viable: true,
                        snapshot: 1,
                    }),
                },
                CampaignActionResult {
                    action: untracked,
                    observations: Vec::new(),
                    milestones: (),
                    outcome: Outcome::default(),
                    candidate: Some(CampaignCandidate {
                        key: TestKey(2),
                        viable: true,
                        snapshot: 2,
                    }),
                },
            ],
        };
        let (_, decisions, duration) = core
            .admit_job_tracking(&workload, 0, result, false, |action| *action == tracked)
            .expect("admit mixed novelty");
        assert_eq!(
            decisions,
            vec![
                CampaignAdmissionDecision::Duplicate { id: 1 },
                CampaignAdmissionDecision::Retained { id: 2 },
            ]
        );
        assert_eq!(
            duration,
            DurationAdmission {
                applied: true,
                useful: false,
            }
        );
    }

    #[test]
    fn a_probe_refused_state_in_another_place_resets_the_suffix_limit() {
        let (workload, _run, mut core, _target) = test_core();
        let home = core.archive.entries[0].key.0;
        let refused = |value: u8| CampaignJobResult::<TestWorkload> {
            preparation_failure: None,
            actions: vec![CampaignActionResult {
                action: TestAction::new(0x01, 1),
                observations: Vec::new(),
                milestones: (),
                outcome: Outcome::default(),
                candidate: Some(CampaignCandidate {
                    key: TestKey(value),
                    viable: false,
                    snapshot: value,
                }),
            }],
        };
        core.admit_job_tracking(&workload, 0, refused(home), true, |_| false)
            .expect("admit a refused state in the parent's place");
        assert_eq!(core.archive.suffix_limit(0), 2);
        core.admit_job_tracking(&workload, 0, refused(INHERITS_PARENT_PLACE), true, |_| {
            false
        })
        .expect("admit a refused state whose completed key keeps the parent's place");
        assert_eq!(core.archive.suffix_limit(0), 2);
        core.admit_job_tracking(&workload, 0, refused(home.wrapping_add(1)), true, |_| false)
            .expect("admit a refused state in another place");
        assert_eq!(core.archive.suffix_limit(0), 1);
    }

    #[test]
    fn a_parent_with_a_job_in_flight_at_its_suffix_limit_draws_one_action() {
        let (_workload, _run, mut core, _target) = test_core();
        let parent = core.archive.stable_id(0).expect("the root has an id");
        core.archive
            .record_suffix_outcome(0, 1, false, false, false);
        assert_eq!(core.suffix_limit(parent, 0), 2);
        core.start_suffix_job(parent, Some(1));
        assert_eq!(core.suffix_limit(parent, 0), 2);
        core.start_suffix_job(parent, Some(2));
        assert_eq!(core.suffix_limit(parent, 0), 1);
        core.archive
            .record_suffix_outcome(0, 2, false, false, false);
        assert_eq!(core.suffix_limit(parent, 0), 4);
        core.start_suffix_job(parent, Some(4));
        core.start_suffix_job(parent, Some(4));
        core.finish_suffix_job(parent, Some(4));
        assert_eq!(core.suffix_limit(parent, 0), 1);
        core.finish_suffix_job(parent, Some(4));
        assert_eq!(core.suffix_limit(parent, 0), 4);
        core.start_suffix_job(parent, None);
        assert_eq!(core.suffix_limit(parent, 0), 4);
    }

    #[test]
    fn coordinator_counts_objectives_and_keeps_the_first_witness() {
        let (workload, _run, mut core, _target) = test_core();
        let winning = TestAction::new(0x81, 7);
        let result = CampaignJobResult::<TestWorkload> {
            preparation_failure: None,
            actions: vec![CampaignActionResult {
                action: winning,
                observations: Vec::new(),
                milestones: (),
                outcome: Outcome {
                    objective_reached: true,
                    disposition: ExecutionDisposition::Runnable,
                },
                candidate: Some(CampaignCandidate {
                    key: TestKey(winning.input),
                    viable: true,
                    snapshot: winning.input,
                }),
            }],
        };
        let winning_action = result.actions[0].clone();
        let (sequence, decisions) = core
            .admit_job(&workload, 0, result)
            .expect("admit objective");
        assert_eq!(sequence, 1);
        assert_eq!(
            decisions,
            vec![
                CampaignAdmissionDecision::Objective,
                CampaignAdmissionDecision::Retained { id: 1 },
            ]
        );
        assert_eq!(core.objectives_reached, 1);
        assert_eq!(
            core.objective_witness,
            Some(Input {
                actions: vec![winning]
            })
        );

        let later = CampaignJobResult {
            preparation_failure: None,
            actions: vec![CampaignActionResult {
                action: TestAction::new(0x01, 9),
                ..winning_action
            }],
        };
        core.admit_job(&workload, 0, later)
            .expect("admit a second objective");
        assert_eq!(core.objectives_reached, 2);
        assert_eq!(
            core.objective_witness,
            Some(Input {
                actions: vec![winning]
            })
        );
        let (report, _) = core.into_archive_report_and_snapshots(&workload, 0, true);
        assert_eq!(
            report.entries.len(),
            3,
            "objective retains its runnable candidates"
        );
    }

    #[test]
    fn whole_tree_import_rebuilds_inputs_and_reroots_sparse_parents() {
        let workload = TestWorkload {
            bootstrap_objective: false,
            targets: None,
        };
        let run = ();
        let mut target = TestTarget::default();
        let action = |input: u8| TestAction::new(input, 1);
        let entry =
            |id: u64, parent_id: Option<u64>, actions: Vec<TestAction>| ArchiveEntryReport {
                id,
                parent_id,
                created_execution: 0,
                input: Input { actions },
                key: TestKey(0),
                milestones: (),
                selector: None,
            };
        let source = TestArchiveReport {
            entries: vec![
                entry(0, None, Vec::new()),
                entry(1, Some(0), vec![action(0x01)]),
                entry(2, Some(1), vec![action(0x01), action(0x02)]),
                entry(3, Some(1), vec![action(0x01), action(0x80)]),
                entry(9, Some(7), vec![action(0x01), action(0x02), action(0x40)]),
            ],
        };
        let mut core = CoordinatorCore::new(&workload, &run, 32_768, None);
        let suffix_json = serde_json::to_string(&source).expect("serialize source archive");
        assert!(suffix_json.contains("\"input_suffix\""));
        let rebuilt: TestArchiveReport =
            serde_json::from_str(&suffix_json).expect("load suffix archive");
        assert_eq!(rebuilt, source);
        let counts = core
            .import_tree(&workload, &run, &mut target, &source, None)
            .expect("import source archive");
        assert_eq!(counts.rerooted, 1);
        assert_eq!(counts.terminal, 0);
        assert_eq!(counts.imported + counts.rejected, 4);
        let reports = core.archive.take_entry_reports_and_snapshots().0;
        assert_eq!(reports[0].input.actions.len(), 0);
        for report in &reports[1..] {
            let parent = usize::try_from(report.parent_id.expect("parent")).expect("index");
            let parent_input = &reports[parent].input.actions;
            assert_eq!(
                report.input.actions.get(..parent_input.len()),
                Some(parent_input.as_slice())
            );
            assert_eq!(report.created_execution, 0);
        }
        assert_eq!(
            reports.len(),
            usize::try_from(counts.imported).expect("imported count") + 1
        );
    }

    #[test]
    fn recorded_splice_tail_validates_strategy_and_bounds() {
        let (_game, _run, _core, _target) = test_core();
        let action = TestAction::new(0x01, 4);
        let encoded = |actions: Vec<TestAction>| CampaignSpliceRecord::Tail {
            donor_id: 90,
            leaf_id: 91,
            tail_postcard: postcard::to_allocvec(&actions).expect("encode splice tail"),
        };

        assert_eq!(
            replay_splice::<TestWorkload>(EnergyStrategy::Splice, Some(encoded(vec![action])))
                .expect("replay explicit tail"),
            Some(vec![action])
        );
        assert_eq!(
            replay_splice::<TestWorkload>(
                EnergyStrategy::Splice,
                Some(CampaignSpliceRecord::Unavailable),
            )
            .expect("replay unavailable tail"),
            None
        );
        assert!(
            replay_splice::<TestWorkload>(EnergyStrategy::Splice, Some(encoded(Vec::new())))
                .is_err()
        );
        assert!(
            replay_splice::<TestWorkload>(
                EnergyStrategy::Splice,
                Some(encoded(vec![action; LONGEST_SPLICE_TAIL + 1])),
            )
            .is_err()
        );
        assert_eq!(
            replay_splice::<TestWorkload>(
                EnergyStrategy::Splice,
                Some(encoded(vec![action; LONGEST_SPLICE_TAIL])),
            )
            .expect("tail at cap is valid")
            .map(|tail| tail.len()),
            Some(LONGEST_SPLICE_TAIL)
        );
        assert!(
            replay_splice::<TestWorkload>(
                EnergyStrategy::Alphabet,
                Some(CampaignSpliceRecord::Unavailable),
            )
            .is_err()
        );
        assert!(replay_splice::<TestWorkload>(EnergyStrategy::Splice, None).is_err());
    }

    #[test]
    fn coordinator_profile_helpers_measure_elapsed_time() {
        #[allow(clippy::disallowed_methods)]
        let started = Instant::now()
            .checked_sub(Duration::from_millis(1))
            .expect("one millisecond before now");
        assert!(profile_elapsed(started) > 0);

        let mut profile = LiveCoordinatorProfile::default();
        record_compaction_elapsed(&mut profile, 4, 4, 10);
        record_compaction_elapsed(&mut profile, 4, 3, 20);
        assert_eq!(profile.history_compaction_ns, 0);
        record_compaction_elapsed(&mut profile, 4, 5, 30);
        assert_eq!(profile.history_compaction_ns, 30);
    }

    #[test]
    fn admission_bookkeeping_helpers_preserve_retained_meaning() {
        let (workload, run, mut core, mut target) = test_core();
        let action = TestAction::new(0x01, 4);
        target.apply(&action);
        let snapshot = target.snapshot().expect("snapshot candidate");
        let result = CampaignJobResult::<TestWorkload> {
            preparation_failure: None,
            actions: vec![CampaignActionResult {
                action,
                observations: Vec::new(),
                milestones: (),
                outcome: Outcome::default(),
                candidate: Some(CampaignCandidate {
                    key: TestKey(target.value),
                    viable: true,
                    snapshot,
                }),
            }],
        };
        let (_, admission) = core
            .admit_job(&workload, 0, result)
            .expect("admit second archive entry");
        assert_eq!(
            admission,
            vec![CampaignAdmissionDecision::Retained { id: 1 }]
        );
        let decisions = [
            CampaignAdmissionDecision::Retained { id: 0 },
            CampaignAdmissionDecision::Retained { id: 1 },
            CampaignAdmissionDecision::Duplicate { id: 0 },
            CampaignAdmissionDecision::Rejected,
        ];
        assert_eq!(retained_archive_indexes(&core, &decisions), vec![0, 1]);

        let (mut draw_state, _header) =
            super::initial_draw_state(&workload, &run, None).expect("initialize draw state");
        assert!(
            finish_record(
                &workload,
                &run,
                &mut draw_state,
                &core,
                &[CampaignAdmissionDecision::Retained { id: u64::MAX }],
            )
            .is_err()
        );
    }

    #[test]
    fn sliding_window_depth_is_the_only_selection_staleness() {
        let depth = default_window(3);
        assert_eq!(depth, 3);

        let mut next_selection = 0_usize;
        let mut selected = Vec::new();
        for next_admission in 0..=depth {
            while next_selection < next_admission + depth {
                selected.push((next_selection, next_admission));
                next_selection += 1;
            }
            assert_eq!(next_selection, next_admission + depth);
        }

        assert_eq!(selected.first(), Some(&(0, 0)));
        assert_eq!(selected.last(), Some(&(depth * 2 - 1, depth)));
        assert!(
            selected
                .iter()
                .all(|(reservation, admitted)| *reservation < admitted + depth)
        );
        assert!(
            selected
                .iter()
                .skip(depth)
                .all(|(reservation, admitted)| *admitted >= reservation - depth)
        );
    }

    #[test]
    fn the_first_objective_counters_exclude_jobs_that_drain_after_the_objective() {
        let mut counters = CampaignCounters::new();
        counters.bootstrap_execution_work = 1_000;
        counters.job_execution_work = 250;
        counters.note_first_objective(11);
        assert_eq!(counters.work_to_first_objective, Some(1_250));
        assert_eq!(counters.executions_to_first_objective, Some(11));

        for (sequence, drained) in [(12, 90), (13, 140), (14, 70)] {
            counters.job_execution_work = counters.job_execution_work.saturating_add(drained);
            counters.note_first_objective(sequence);
        }
        assert_eq!(counters.work_to_first_objective, Some(1_250));
        assert_eq!(counters.executions_to_first_objective, Some(11));
        assert_eq!(
            counters
                .bootstrap_execution_work
                .saturating_add(counters.job_execution_work),
            1_550
        );
    }

    #[test]
    fn a_run_that_never_reaches_its_objective_has_no_first_objective_counters() {
        let mut counters = CampaignCounters::new();
        counters.bootstrap_execution_work = 10;
        counters.job_execution_work = 20;
        assert_eq!(counters.work_to_first_objective, None);
        assert_eq!(counters.executions_to_first_objective, None);
    }

    #[test]
    fn schedule_policy_dispatch_accepts_only_current_windows() {
        let current = schedule_policy_identifier(default_window(1));
        assert_eq!(current, "planned_finish_window_1_v5");
        assert_eq!(schedule_policy_window(&current), Some(1));
        assert!(schedule_policy_is_supported("planned_finish_window_64_v5"));
        assert!(!schedule_policy_is_supported("deterministic_window_64_v4"));
        assert!(!schedule_policy_is_supported("planned_finish_window_0_v5"));
        assert!(!schedule_policy_is_supported("unknown-schedule"));
        assert_eq!(
            schedule_policy_window("planned_finish_window_16_v5"),
            Some(16)
        );
    }

    #[test]
    fn recorded_resource_bounds_and_progress_policies_validate_at_boundaries() {
        let max = crate::search::archive::MAX_ARCHIVE_ENTRIES;
        assert!(!archive_entry_limit_is_valid(0));
        assert!(archive_entry_limit_is_valid(1));
        assert!(archive_entry_limit_is_valid(max));
        assert!(!archive_entry_limit_is_valid(max.saturating_add(1)));

        assert!(memory_is_within_reserve(0, 0));
        assert!(memory_is_within_reserve(1, 2));
        assert!(memory_is_within_reserve(2, 2));
        assert!(!memory_is_within_reserve(2, 1));
        assert!(resident_memory_is_within_budget(usize::MAX, None));
        assert!(resident_memory_is_within_budget(64 * 1024 * 1024, Some(64)));
        assert!(!resident_memory_is_within_budget(
            64 * 1024 * 1024 + 1,
            Some(64)
        ));

        assert!(progress_policy_is_supported(
            super::CAMPAIGN_PROGRESS_POLICY
        ));
        assert!(!progress_policy_is_supported("mechanical_watermark_v1"));
        assert!(!progress_policy_is_supported("unknown-progress"));
    }

    #[test]
    fn execution_work_delta_rejects_a_counter_rewind() {
        assert_eq!(execution_work_delta(7, 11, "worker").unwrap(), 4);
        let error = execution_work_delta(11, 7, "worker").unwrap_err();
        assert_eq!(error.to_string(), "worker execution-work counter rewound");
    }

    #[test]
    fn a_recorded_header_still_reads_and_writes_its_field_names() {
        let compact = RECORDED_HEADER.replace('\n', "");
        let header: CampaignStreamHeader<()> =
            serde_json::from_str(&compact).expect("recorded header parses");
        assert_eq!(header.schedule_policy, "planned_finish_window_2_v5");
        assert_eq!(
            header.progress_policy,
            "mechanical_watermark_bounded_1024_v2"
        );
        assert_eq!(header.mixture_policy, "biased_half");
        assert_eq!(header.resume_policy, "whole_tree");
        assert_eq!(header.schema_version, super::CAMPAIGN_SCHEMA_VERSION);
        assert_eq!(header.draw_header, None);
        let expected: WorkloadPolicies = [
            ("action_vocabulary", "test_inputs"),
            ("key_policy", "test_key"),
            ("duration_policy", "stratified"),
            ("step_policy", "step_uniform"),
            ("replacement_policy", "least_cost_per_group"),
        ]
        .into_iter()
        .map(|(field, value)| (field.to_owned(), value.to_owned()))
        .collect();
        assert_eq!(header.workload_policies, expected);

        let written = serde_json::to_value(&header).expect("header serializes");
        let object = written.as_object().expect("header is an object");
        for field in expected.keys() {
            assert_eq!(
                object.get(field).and_then(serde_json::Value::as_str),
                Some(expected[field].as_str())
            );
        }
        let recorded: serde_json::Value =
            serde_json::from_str(&compact).expect("recorded header parses");
        let recorded_fields: BTreeSet<&String> = recorded
            .as_object()
            .expect("recorded header is an object")
            .keys()
            .collect();
        assert_eq!(object.keys().collect::<BTreeSet<_>>(), recorded_fields);
    }

    #[test]
    fn replay_rejects_missing_or_unknown_campaign_schema_versions() {
        let compact = RECORDED_HEADER.replace('\n', "");
        let mut missing: serde_json::Value =
            serde_json::from_str(&compact).expect("recorded header parses");
        missing
            .as_object_mut()
            .expect("header is an object")
            .remove("schema_version");
        assert!(
            replay_campaign_checkpointed::<TestWorkload>(
                &TestWorkload {
                    bootstrap_objective: false,
                    targets: None,
                },
                serde_json::to_string(&missing)
                    .expect("header re-encodes")
                    .as_bytes(),
                None,
                None,
            )
            .is_err()
        );

        let mut unknown: serde_json::Value =
            serde_json::from_str(&compact).expect("recorded header parses");
        unknown["schema_version"] = serde_json::json!(1);
        assert!(
            replay_campaign_checkpointed::<TestWorkload>(
                &TestWorkload {
                    bootstrap_objective: false,
                    targets: None,
                },
                serde_json::to_string(&unknown)
                    .expect("header re-encodes")
                    .as_bytes(),
                None,
                None,
            )
            .is_err()
        );
    }

    #[test]
    fn a_checkpoint_in_an_older_layout_fails_on_its_format() {
        #[derive(Serialize)]
        struct OlderLayout {
            format: &'static str,
            ids: Vec<u64>,
        }
        let older = postcard::to_allocvec(&OlderLayout {
            format: "test-checkpoint-v0",
            ids: vec![7],
        })
        .expect("older layout encodes");
        assert!(postcard::from_bytes::<SnapshotCheckpoint<u8>>(&older).is_err());
        let error = SnapshotCheckpoint::<u8>::from_bytes(&older, "test-checkpoint-v1")
            .expect_err("an older checkpoint is rejected")
            .to_string();
        assert_eq!(error, "snapshot checkpoint format is not recognized");

        let current = SnapshotCheckpoint {
            format: "test-checkpoint-v1".to_owned(),
            entries: vec![SnapshotCheckpointEntry {
                id: 7,
                snapshot: 9_u8,
            }],
        };
        let bytes = current.to_bytes().expect("checkpoint encodes");
        assert_eq!(
            SnapshotCheckpoint::<u8>::from_bytes(&bytes, "test-checkpoint-v1")
                .expect("current checkpoint decodes"),
            current
        );
        assert_eq!(
            SnapshotCheckpoint::<u8>::from_bytes(&bytes, "test-checkpoint-v2")
                .expect_err("a different format is rejected")
                .to_string(),
            "snapshot checkpoint format is not recognized"
        );
    }

    #[test]
    fn a_recorded_job_keeps_its_draw_checkpoint_field_names() {
        let line = r#"{"event":"job","sequence":1,"reservation":1,"parent_id":0,"mutation_seed":9,
"execution_work":12,"result_sha256":"ef","decisions":[],"mixture_weight":128,"splice_weight":128,
"selector":{"path":"tiers","tier_rank":0},
"draw_checkpoint_before":{"records":3,"retained_successes":1,"table_sha256":"aa"},
"draw_checkpoint_after":{"records":4,"retained_successes":2,"table_sha256":"bb"}}"#
            .replace('\n', "");
        let record: CampaignStreamRecord<EmpiricalStepCheckpoint> =
            serde_json::from_str(&line).expect("record parses");
        let CampaignStreamRecord::Job(job) = record else {
            panic!("expected a job record");
        };
        assert_eq!(
            job.splice, None,
            "jobs without a splice carry no splice evidence"
        );
        assert_eq!(job.selector.path, SelectorPath::Tiers);
        assert_eq!(
            job.draw_checkpoint_before,
            Some(EmpiricalStepCheckpoint {
                records: 3,
                retained_successes: 1,
                table_sha256: "aa".to_owned(),
            })
        );
        let written = serde_json::to_value(&job).expect("job serializes");
        let object = written.as_object().expect("job is an object");
        let recorded: serde_json::Value = serde_json::from_str(&line).expect("record parses");
        let recorded_fields: BTreeSet<&String> = recorded
            .as_object()
            .expect("recorded job is an object")
            .keys()
            .filter(|field| field.as_str() != "event")
            .collect();
        assert_eq!(object.keys().collect::<BTreeSet<_>>(), recorded_fields);
        let round_trip: CampaignJobRecord<EmpiricalStepCheckpoint> =
            serde_json::from_value(written).expect("job round-trips");
        assert_eq!(round_trip, job);
        let _ = SelectorDraw {
            path: SelectorPath::Tiers,
            tier_rank: Some(0),
            best_preference: None,
        };
    }

    #[test]
    fn a_job_records_its_dispatch_time_splice_resolution() {
        let line = r#"{"event":"job","sequence":1,"reservation":1,"worker":0,"parent_id":3,"mutation_seed":9,
"execution_work":12,"result_sha256":"ef","decisions":[],"mixture_weight":85,"splice_weight":85,
"splice":{"outcome":"tail","donor_id":4,"leaf_id":9,"tail_postcard":[1,2]},
"selector":{"path":"tiers","tier_rank":1}}"#
            .replace('\n', "");
        let record: CampaignStreamRecord<EmpiricalStepCheckpoint> =
            serde_json::from_str(&line).expect("record parses");
        let CampaignStreamRecord::Job(job) = record else {
            panic!("expected a job record");
        };
        assert_eq!(
            job.splice,
            Some(super::CampaignSpliceRecord::Tail {
                donor_id: 4,
                leaf_id: 9,
                tail_postcard: vec![1, 2],
            })
        );
        let written = serde_json::to_vec(&job).expect("job serializes");
        let round_trip: CampaignJobRecord<EmpiricalStepCheckpoint> =
            serde_json::from_slice(&written).expect("job round-trips");
        assert_eq!(round_trip, job);
    }
    #[test]
    fn a_key_without_a_preference_runs_and_replays_with_no_continuation_bank() {
        let config = CampaignConfig {
            campaign_seed: 31,
            workers: 2,
            execution_budget: 200,
            host: "test".to_owned(),
            wall_budget: None,
            stop_rollout_on_objective: false,
            stop_campaign_on_objective: false,
            archive_entry_limit: 32,
            window: 4,
            memory_budget_mib: Some(8),
            materialize_final_artifacts: true,
            run: (),
            mixture: DrawMixture::EnergySplice { scale: 6 },
            retention: RetentionPolicy::Unprobed,
            objective_witness_path: None,
        };
        let workload = TestWorkload {
            bootstrap_objective: false,
            targets: None,
        };
        let mut stream = Vec::new();
        let mut progress = Vec::new();
        let live = run_campaign_checkpointed(
            &workload,
            &config,
            &CampaignOrigin::Genesis,
            &mut stream,
            Some(&mut progress),
        )
        .expect("campaign without a preference");
        let text = std::str::from_utf8(&stream).expect("stream is utf-8");
        assert!(!text.contains("\"path\":\"continuation\""));
        assert!(!text.contains("continuation_energy"));
        let progress = String::from_utf8(progress).expect("progress is utf-8");
        let last: CampaignProgressRecord<serde_json::Value> =
            serde_json::from_str(progress.lines().last().expect("a progress line"))
                .expect("progress record parses");
        assert_eq!(last.continuations, ContinuationAccounting::default());
        assert_eq!(
            replay_campaign_checkpointed(&workload, &stream, None, None)
                .expect("replay without a preference"),
            live
        );
    }

    #[test]
    fn the_report_carries_worker_telemetry_that_replay_equality_ignores() {
        let config = three_worker_config();
        let workload = TestWorkload {
            bootstrap_objective: false,
            targets: None,
        };
        let mut stream = Vec::new();
        let live = run_campaign_checkpointed(
            &workload,
            &config,
            &CampaignOrigin::Genesis,
            &mut stream,
            None,
        )
        .expect("campaign");
        let telemetry = &live.0.telemetry;
        assert_eq!(telemetry.workers.len(), 3);
        assert_eq!(
            telemetry
                .workers
                .iter()
                .map(|worker| worker.jobs)
                .sum::<u64>(),
            live.0.executions_completed
        );
        assert_eq!(
            telemetry.target["work"],
            live.0.execution_work - live.0.bootstrap_execution_work
        );
        assert!(telemetry.search_ns > 0);
        assert!(telemetry.coordinator["admissions"].as_u64() == Some(live.0.executions_completed));
        let replayed =
            replay_campaign_checkpointed(&workload, &stream, None, None).expect("replay");
        assert!(replayed.0.telemetry.workers.is_empty());
        assert_eq!(replayed, live);
    }

    fn job_lines(stream: &[u8]) -> Vec<(usize, CampaignJobRecord<EmpiricalStepCheckpoint>)> {
        std::str::from_utf8(stream)
            .expect("stream is text")
            .lines()
            .enumerate()
            .skip(1)
            .filter_map(|(index, line)| {
                match serde_json::from_str::<CampaignStreamRecord<EmpiricalStepCheckpoint>>(line)
                    .expect("stream record parses")
                {
                    CampaignStreamRecord::Job(job) => Some((index, job)),
                    CampaignStreamRecord::Skip(_) => None,
                }
            })
            .collect()
    }

    #[test]
    fn jobs_are_admitted_in_planned_finish_order_and_replay() {
        let mut config = three_worker_config();
        config.window = 6;
        let workload = TestWorkload {
            bootstrap_objective: false,
            targets: None,
        };
        let mut stream = Vec::new();
        let live = run_campaign_checkpointed(
            &workload,
            &config,
            &CampaignOrigin::Genesis,
            &mut stream,
            None,
        )
        .expect("campaign");
        let reservations = job_lines(&stream)
            .into_iter()
            .map(|(_, job)| job.reservation)
            .collect::<Vec<_>>();
        let mut ordered = reservations.clone();
        ordered.sort_unstable();
        assert_eq!(
            ordered,
            (0..u64::try_from(reservations.len()).unwrap()).collect::<Vec<_>>()
        );
        assert_ne!(
            reservations, ordered,
            "a cheaper later reservation is admitted first"
        );
        let replayed =
            replay_campaign_checkpointed(&workload, &stream, None, None).expect("replay");
        assert_eq!(replayed, live);
    }

    #[test]
    fn replay_refuses_jobs_admitted_out_of_planned_finish_order() {
        let mut config = three_worker_config();
        config.window = 6;
        let workload = TestWorkload {
            bootstrap_objective: false,
            targets: None,
        };
        let mut stream = Vec::new();
        run_campaign_checkpointed(
            &workload,
            &config,
            &CampaignOrigin::Genesis,
            &mut stream,
            None,
        )
        .expect("campaign");
        let lines = std::str::from_utf8(&stream)
            .unwrap()
            .lines()
            .map(str::to_owned)
            .collect::<Vec<_>>();
        let jobs = job_lines(&stream);
        let refused = jobs.windows(2).filter(|pair| {
            let mut tampered = lines.clone();
            tampered[pair[0].0] = lines[pair[0].0].replacen(
                &format!("\"reservation\":{},", pair[0].1.reservation),
                &format!("\"reservation\":{},", pair[1].1.reservation),
                1,
            );
            tampered[pair[1].0] = lines[pair[1].0].replacen(
                &format!("\"reservation\":{},", pair[1].1.reservation),
                &format!("\"reservation\":{},", pair[0].1.reservation),
                1,
            );
            replay_campaign_checkpointed(&workload, tampered.join("\n").as_bytes(), None, None)
                .is_err_and(|error| error.to_string().contains("out of planned-finish order"))
        });
        assert!(refused.count() > jobs.len() / 2);
    }

    fn run_placed(placement: ThreadPlacement) -> Result<CampaignOutcome<TestWorkload>, String> {
        run_campaign_checkpointed_with_options(
            &TestWorkload {
                bootstrap_objective: false,
                targets: None,
            },
            &three_worker_config(),
            &CampaignOrigin::Genesis,
            &mut Vec::new(),
            None,
            CampaignExecutionOptions {
                placement: Some(placement),
                ..CampaignExecutionOptions::default()
            },
        )
        .map_err(|error| error.to_string())
    }

    #[test]
    fn a_campaign_never_holds_more_targets_than_workers() {
        let targets = Arc::new(LiveTargets::default());
        run_campaign_checkpointed(
            &TestWorkload {
                bootstrap_objective: false,
                targets: Some(Arc::clone(&targets)),
            },
            &three_worker_config(),
            &CampaignOrigin::Genesis,
            &mut Vec::new(),
            None,
        )
        .expect("campaign");
        assert_eq!(targets.most.load(std::sync::atomic::Ordering::SeqCst), 3);
        assert_eq!(targets.live.load(std::sync::atomic::Ordering::SeqCst), 0);
    }

    #[test]
    fn a_failed_bootstrap_returns_its_error_with_workers_waiting() {
        let error = run_campaign_checkpointed(
            &TestWorkload {
                bootstrap_objective: false,
                targets: Some(Arc::new(LiveTargets {
                    refuse: true,
                    ..LiveTargets::default()
                })),
            },
            &three_worker_config(),
            &CampaignOrigin::Genesis,
            &mut Vec::new(),
            None,
        )
        .expect_err("a refused bootstrap target fails the campaign");
        assert!(
            error
                .to_string()
                .contains("failed to build the bootstrap target"),
            "{error}"
        );
    }

    #[test]
    fn placement_runs_once_on_the_coordinator_and_each_worker_thread() {
        let placed = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
        let record = std::sync::Arc::clone(&placed);
        let placement = ThreadPlacement::new(move |thread| {
            record
                .lock()
                .expect("placement record")
                .push((thread, std::thread::current().id()));
            Ok(())
        });
        let placed_run = run_placed(placement).expect("placed campaign");
        let unplaced = run_campaign_checkpointed(
            &TestWorkload {
                bootstrap_objective: false,
                targets: None,
            },
            &three_worker_config(),
            &CampaignOrigin::Genesis,
            &mut Vec::new(),
            None,
        )
        .expect("campaign");
        assert_eq!(placed_run, unplaced);
        let mut placed = placed.lock().expect("placement record").clone();
        placed.sort_by_key(|(thread, _)| match thread {
            PlacedThread::Coordinator => 0,
            PlacedThread::Worker(worker) => worker + 1,
        });
        assert_eq!(
            placed.iter().map(|(thread, _)| *thread).collect::<Vec<_>>(),
            vec![
                PlacedThread::Coordinator,
                PlacedThread::Worker(0),
                PlacedThread::Worker(1),
                PlacedThread::Worker(2),
            ]
        );
        let threads = placed
            .iter()
            .map(|(_, id)| format!("{id:?}"))
            .collect::<std::collections::BTreeSet<_>>();
        assert_eq!(threads.len(), 4);
    }

    #[test]
    fn a_placement_failure_fails_the_campaign() {
        for refused in [PlacedThread::Coordinator, PlacedThread::Worker(1)] {
            let placement = ThreadPlacement::new(move |thread| {
                if thread == refused {
                    Err(format!("{thread:?} refused"))
                } else {
                    Ok(())
                }
            });
            let error = run_placed(placement).expect_err("refused placement");
            assert!(error.contains("refused"), "{error}");
        }
    }

    fn three_worker_config() -> CampaignConfig<TestWorkload> {
        CampaignConfig {
            campaign_seed: 5,
            workers: 3,
            execution_budget: 60,
            host: "test".to_owned(),
            wall_budget: None,
            stop_rollout_on_objective: false,
            stop_campaign_on_objective: false,
            archive_entry_limit: 32,
            window: 3,
            memory_budget_mib: None,
            materialize_final_artifacts: true,
            run: (),
            mixture: DrawMixture::AlphabetOnly,
            retention: RetentionPolicy::Unprobed,
            objective_witness_path: None,
        }
    }

    #[test]
    fn the_continuation_draw_takes_a_fixed_one_reservation_in_four() {
        let taken = (0..4096)
            .filter(|reservation| draws_continuation(11, *reservation))
            .count();
        assert!(
            (896..1152).contains(&taken),
            "one in four of 4096 reservations, got {taken}"
        );
    }

    #[test]
    fn the_continuation_draw_is_seeded_by_the_campaign_and_the_reservation() {
        assert_eq!(draws_continuation(11, 3), draws_continuation(11, 3));
        assert!(
            (0..512).any(|reservation| draws_continuation(11, reservation)
                != draws_continuation(12, reservation))
        );
    }

    #[test]
    fn the_highest_preference_draw_is_one_pop_in_four_and_independent_of_the_attempt() {
        let taken = (0..4096)
            .filter(|reservation| draws_highest_preference(11, *reservation))
            .count();
        assert!(
            (896..1152).contains(&taken),
            "one in four of 4096 reservations, got {taken}"
        );
        assert!(
            (0..512).any(|reservation| draws_highest_preference(11, reservation)
                != draws_continuation(11, reservation))
        );
    }

    #[test]
    fn a_continuation_outcome_leaves_the_draw_weights_alone() {
        let mut energy = MixtureEnergy::default();
        let mixture = DrawMixture::EnergySplice { scale: 4 };
        let before = energy.splice_weights(4);
        for seed in 0..64_u64 {
            record_mixture_outcome(
                &mut energy,
                mixture,
                SelectorPath::Continuation,
                seed,
                (128, 128),
                seed % 3 == 0,
                10,
            )
            .expect("continuation outcome");
        }
        assert_eq!(energy.splice_weights(4), before);
        assert_eq!(
            energy.biased_weight(4),
            MixtureEnergy::default().biased_weight(4)
        );
        for _ in 0..16 {
            record_mixture_outcome(
                &mut energy,
                mixture,
                SelectorPath::Tiers,
                1,
                (128, 128),
                false,
                10,
            )
            .expect("ordinary outcome");
        }
        assert_ne!(energy.splice_weights(4), before);
    }
}

#!/usr/bin/env python3
# /// script
# requires-python = ">=3.11"
# dependencies = []
# ///
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Render the historical-bug roster table into workloads/bugs/historical/README.md.

Reads every ``workloads/bugs/historical/*/case.json`` and, optionally, a directory
of report files produced by the historical-bug benchmark workflow. Report
directories are named ``<case id>.<mode>`` and hold the ``report.json`` the CLI
wrote, so a report attaches to a case without any extra bookkeeping.

``--check`` compares the rendered table with what is committed and exits
non-zero when they differ, so quality CI can enforce the table later.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

BEGIN = "<!-- render-historical-bugs:begin -->"
END = "<!-- render-historical-bugs:end -->"

COLUMNS = (
    "bug",
    "searched version",
    "upstream fix",
    "status",
    "CI",
    "discovery",
    "latest sample replay",
    "executions to first hit",
    "replay command",
)


def repo_root() -> Path:
    return Path(__file__).resolve().parent.parent


def load_cases(root: Path) -> list[dict]:
    cases = []
    for path in sorted(root.glob("workloads/bugs/historical/*/case.json")):
        case = json.loads(path.read_text())
        case["_dir"] = path.parent
        cases.append(case)
    return cases


def load_reports(reports_dir: Path | None) -> dict[tuple[str, str], dict]:
    """Newest report per (case id, mode), keyed by report file mtime."""
    found: dict[tuple[str, str], tuple[float, dict]] = {}
    if reports_dir is None:
        return {}
    for path in sorted(reports_dir.rglob("report.json")):
        parts = path.parent.name.split(".")
        if len(parts) < 2:
            continue
        mode = parts[-1]
        case_id = ".".join(parts[:-1])
        try:
            report = json.loads(path.read_text())
        except (OSError, json.JSONDecodeError):
            continue
        key = (case_id, mode)
        stamp = path.stat().st_mtime
        if key not in found or stamp >= found[key][0]:
            found[key] = (stamp, report)
    return {key: report for key, (_, report) in found.items()}


def replay_outcome(reports: dict, case_id: str) -> str:
    """The newest declared-sample replay verdict, as plain words."""
    modes = sorted(
        mode for reported_case, mode in reports if reported_case == case_id and mode.startswith("sample")
    )
    for mode in reversed(modes):
        report = reports.get((case_id, mode))
        if report is None:
            continue
        replays = report.get("replays") or []
        if not replays:
            return "no replays"
        hits = sum(1 for replay in replays if replay.get("bug"))
        word = "bug found" if hits else "silent"
        return f"{word} ({hits}/{len(replays)}, {mode})"
    return "—"


def first_hit(reports: dict, case_id: str) -> str:
    report = reports.get((case_id, "search"))
    if report is None:
        return "—"
    if not report.get("bug_found"):
        return "not found"
    execution = report.get("first_bug_execution")
    return "—" if execution is None else str(execution)


def replay_command(case: dict) -> str:
    """Show the command shape for a reproducer from the current run."""
    if case.get("ci", {}).get("status", "runnable") != "runnable":
        return "—"
    return "`harmony debug replay RUN --finding 1 --repeat 1 --out REPLAY`"


def render(cases: list[dict], reports: dict) -> str:
    lines = [
        "| " + " | ".join(COLUMNS) + " |",
        "|" + "---|" * len(COLUMNS),
    ]
    for case in cases:
        case_id = case["id"]
        versions = case.get("versions", {})
        searched = case.get("workload", {}).get("version", versions.get("affected", "?"))
        fixed = versions.get("fixed", "?")
        row = (
            f"[{case_id}]({case_id}/README.md)",
            searched,
            fixed,
            case.get("status", "?"),
            case.get("ci", {}).get("status", "runnable")
            + (
                f": {case['ci']['reason']}"
                if case.get("ci", {}).get("status") == "deferred"
                else ""
            ),
            case.get("discovery_mode", "?"),
            replay_outcome(reports, case_id),
            first_hit(reports, case_id),
            replay_command(case),
        )
        lines.append("| " + " | ".join(row) + " |")
    return "\n".join(lines)


def splice(readme: str, table: str) -> str:
    start = readme.find(BEGIN)
    end = readme.find(END)
    if start == -1 or end == -1 or end < start:
        raise SystemExit(
            f"workloads/bugs/historical/README.md is missing the {BEGIN} / {END} markers"
        )
    head = readme[: start + len(BEGIN)]
    tail = readme[end:]
    return f"{head}\n{table}\n{tail}"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--reports",
        type=Path,
        default=None,
        help="directory holding <case>.<mode>/report.json trees",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="exit non-zero when the committed table is stale, and write nothing",
    )
    args = parser.parse_args()

    root = repo_root()
    readme_path = root / "workloads/bugs/historical/README.md"
    cases = load_cases(root)
    if not cases:
        raise SystemExit("no workloads/bugs/historical/*/case.json found")
    reports = load_reports(args.reports)

    readme = readme_path.read_text()
    rendered = splice(readme, render(cases, reports))
    if args.check:
        if rendered != readme:
            print(
                "workloads/bugs/historical/README.md roster is stale; "
                "run scripts/render-historical-bugs.py",
                file=sys.stderr,
            )
            return 1
        return 0
    if rendered != readme:
        readme_path.write_text(rendered)
        print(f"wrote {readme_path}")
    else:
        print(f"{readme_path} already current")
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env bash
# SPDX-License-Identifier: AGPL-3.0-or-later
# Install the external code-quality binaries used by the quality checks
# (.github/workflows/repository-checks.yml, .pre-commit-config.yaml, and
# CONTRIBUTING.md).
#
# These are *tools*, not crate dependencies — they are exempt from the
# These quality binaries are developer tools rather than crate dependencies.
#
# Idempotent: `cargo install` is a no-op when the requested version is already
# present, so re-running is a fast success. Safe to run on macOS and Linux.
set -euo pipefail

if ! command -v cargo >/dev/null 2>&1; then
    echo "cargo not found; install Rust first (see scripts/provision-host.sh)" >&2
    exit 1
fi

# crate            provides
#   cargo-nextest    fast, process-isolated test runner (checks)
#   cargo-llvm-cov   source-based coverage          (quality-b)
#   cargo-mutants@27.1.0 mutation testing          (quality-c; pinned for CI parity)
#   cargo-deny       advisories/licenses/bans/sources (checks)
tools=(
    cargo-nextest
    cargo-llvm-cov
    cargo-mutants@27.1.0
    cargo-deny
)

for tool in "${tools[@]}"; do
    echo "== installing ${tool} (no-op if already current)"
    cargo install --locked "${tool}"
done

echo "== installed versions"
cargo nextest --version
cargo llvm-cov --version
cargo mutants --version
cargo deny --version

# Wire up the local fast-feedback git hooks (.githooks/pre-push: fmt, clippy,
# nextest) via core.hooksPath. Convenience only —
# the check of record is the self-hosted runner (.github/workflows/).
# Skip with `git push --no-verify`. Run from inside the repo.
if git rev-parse --git-dir >/dev/null 2>&1; then
    echo "== configuring git hooks (core.hooksPath = .githooks)"
    git config core.hooksPath .githooks

    if command -v pre-commit >/dev/null 2>&1; then
        echo "== installing pinned pre-commit hook environments"
        pre-commit install-hooks
    else
        echo "== note: the credential-leak pre-commit hook requires pre-commit:"
        echo "     brew install pre-commit        # macOS"
        echo "     pipx install pre-commit        # portable alternative"
        echo "     pre-commit install-hooks"
    fi
fi

# Miri runs only in CI (the components' Analysis workflows), but the unsafe⇒Miri
# review rule (AGENTS.md)
# means reviewers run it locally on crates whose diff touches `unsafe`.
# Suggest the toolchain (don't force a multi-hundred-MB download on every tool install).
if ! cargo +nightly-2026-06-16 miri --version >/dev/null 2>&1; then
    echo "== note: for local Miri runs on unsafe-touching diffs, install the pinned nightly + miri:"
    echo "     rustup toolchain install nightly-2026-06-16 --component miri"
fi

# SPDX-License-Identifier: AGPL-3.0-or-later
"""Executable runner contracts; no licensed assets or emulator required."""
import argparse
import copy
import importlib.util
import json
import os
import re
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('search_eval', Path(__file__).with_name('eval.py'))
eval = importlib.util.module_from_spec(spec)
spec.loader.exec_module(eval)


class EvaluationTests(unittest.TestCase):
    def test_aggregate_keeps_outcomes_when_throughput_is_unavailable(self):
        items = [{'case':'nova', 'status':'complete', 'result':{'solved':False, 'frames_per_second':rate}}
                 for rate in (None, 100.0, float('inf'))]
        row = eval.aggregates(items)[0]
        self.assertEqual(row['valid_trials'], 3)
        self.assertEqual(row['throughput_trials'], 1)
        self.assertEqual(row['median_search_frames_per_second'], 100.0)
        self.assertIsNone(eval.aggregates(items[:1])[0]['median_search_frames_per_second'])

    def test_named_progress_distinguishes_missing_unreached_and_replayed(self):
        item = {'cell':'metroid-s1', 'search_request':{'game':'metroid'}, 'last_progress':{}, 'result':{}}
        self.assertIsNone(eval.named_progress(item))
        self.assertIn('older reporting schema', eval.metroid_html([item]))
        progress = {'format':'metroid-named-progress-v1', 'first_seen':{
            name:None for name in eval.METROID_MILESTONES}, 'max_missile_capacity':10, 'max_energy_tanks':1}
        progress['first_seen']['kraid_area'] = {'execution':42, 'route_action_end_frame':500}
        item['last_progress']['workload_diagnostics'] = {'named_progress':progress}
        replay = copy.deepcopy(progress)
        replay['first_seen']['kraid_area'] = None
        item['result']['witness'] = {'diagnostics':{'named_progress':replay}}
        text = eval.metroid_html([item])
        self.assertIn('execution 42', text)
        self.assertIn('none observed', text)
        self.assertIsNone(eval.named_progress(item, witness=True)['first_seen']['kraid_area'])
        self.assertIsNone(eval.named_progress(item)['first_seen']['kraid_defeated'])
        item.update(case='metroid',status='complete')
        item['result'].update(solved=False)
        missing = copy.deepcopy(item)
        missing['last_progress'] = {}
        row = eval.aggregates([item, missing])[0]['metroid_milestones']
        self.assertEqual(row['kraid_area']['observed'], 1)
        self.assertEqual(row['kraid_area']['reported_trials'], 1)
        self.assertEqual(row['kraid_area']['unavailable_trials'], 1)
        self.assertEqual(row['kraid_defeated']['observed'], 0)
        self.assertIsNone(row['kraid_defeated']['median_first_execution_among_observed'])
        del progress['first_seen']['mother_brain_defeated']
        row = eval.aggregates([item])[0]['metroid_milestones']['mother_brain_defeated']
        self.assertEqual(row['reported_trials'], 0)
        self.assertEqual(row['unavailable_trials'], 1)
        self.assertIn('not recorded: Mother Brain defeated', eval.metroid_html([item]))



    def test_current_named_progress_schema_reaches_html_and_aggregate(self):
        progress = {'format':'metroid-named-progress-v2', 'first_seen':{
            name:None for name in eval.METROID_MILESTONES}, 'max_missile_capacity':10, 'max_energy_tanks':1}
        progress['first_seen']['escape_started'] = {'execution':12, 'route_action_end_frame':403}
        item = {'cell':'metroid-s1', 'case':'metroid', 'status':'complete',
                'search_request':{'game':'metroid'}, 'result':{'solved':False},
                'last_progress':{'workload_diagnostics':{'named_progress':progress,
                    'observation_filter':'live gameplay observations supplied to this accumulator'}}}
        self.assertEqual(eval.named_progress(item), progress)
        self.assertIn('Escape started — execution 12', eval.metroid_html([item]))
        self.assertEqual(eval.aggregates([item])[0]['metroid_milestones']['escape_started']['observed'], 1)
        item['max_process_rss_bytes'] = 2 * 1048576
        item['peak_disk_logical_bytes_sampled'] = 0
        text = eval.metroid_html([item])
        self.assertIn('Peak RSS MiB', text)
        self.assertIn('Peak output disk MiB', text)
        self.assertIn('<td rowspan="2">2.0</td><td rowspan="2">unavailable</td><td rowspan="2">0.0</td>', text)
        item['last_progress']['resident_memory_bytes'] = 1048576
        text = eval.report_html([item], 'Resources')
        self.assertIn('Last logical memory MiB', text)
        self.assertIn('<td rowspan="1">2.0</td><td rowspan="1">1.0</td><td rowspan="1">0.0</td>', text)

    def test_every_metroid_milestone_lands_in_its_named_column(self):
        columns = [name for names in eval.METROID_COLUMNS.values() for name in names]
        self.assertEqual(sorted(columns), sorted(eval.METROID_MILESTONES))
        progress = {'format':'metroid-named-progress-v3', 'first_seen':{
            name:None for name in eval.METROID_MILESTONES}, 'max_missile_capacity':0, 'max_energy_tanks':0}
        for name in ('brinstar', 'tourian', 'tourian_far', 'kraid_room', 'bombs', 'zebetite_destroyed'):
            progress['first_seen'][name] = {'execution':7, 'route_action_end_frame':90}
        item = {'cell':'ladder-seg5-s11', 'search_request':{'game':'metroid'}, 'result':{},
                'last_progress':{'workload_diagnostics':{'named_progress':progress}}}
        row = re.search(r'<td>ladder-seg5-s11</td><td>Search branches</td>'
                        r'<td>(.*?)</td><td>(.*?)</td><td>(.*?)</td>', eval.metroid_html([item]))
        gear, areas, bosses = row.groups()
        self.assertEqual(gear, 'Bombs')
        self.assertEqual(areas, 'Brinstar, Kraid&#x27;s room, Tourian, Tourian far corridor')
        self.assertEqual(bosses, 'Zebetite destroyed')

    def test_a_manifest_selector_is_rejected_by_name(self):
        self.suite['search']['selector'] = 'depth'
        with self.assertRaisesRegex(ValueError, 'sets search.selector'): eval.expand_suite(self.suite)

    def test_comparison_refuses_a_changed_root_input(self):
        a, b = self.root/'a', self.root/'b'
        original = self.matrix(a)
        self.matrix(b)
        for root in ('/roots/other-s1.json', None):
            changed = copy.deepcopy(original)
            changed['search_request']['root_input'] = '/roots/kraid-s1.json'
            eval.write_json(a/original['cell']/'summary.json', changed)
            changed['search_request']['root_input'] = root
            eval.write_json(b/original['cell']/'summary.json', changed)
            with self.assertRaisesRegex(ValueError, 'root input changed for smb-s1-w1-m16'): eval.compare(a, b)
        eval.write_json(b/original['cell']/'summary.json', eval.read_json(a/original['cell']/'summary.json'))
        self.assertTrue(eval.compare(a, b)['pairs'][0]['comparable'])

    def test_export_includes_only_named_milestone_tapes_and_rejects_symlinks(self):
        matrix = self.root/'matrix'
        item = self.matrix(matrix)
        directory = matrix/item['cell']/'campaign/milestone-inputs'
        directory.mkdir()
        (directory/'bombs.json').write_text('{"actions":[]}')
        (directory/'private.nes').write_bytes(b'private sentinel')
        eval.export(matrix, self.root/'public')
        self.assertTrue((self.root/'public'/item['cell']/'campaign/milestone-inputs/bombs.json').is_file())
        self.assertFalse(any(p.suffix == '.nes' for p in (self.root/'public').rglob('*')))
        (directory/'bombs.json').unlink()
        (directory/'bombs.json').symlink_to(directory/'private.nes')
        with self.assertRaises(ValueError): eval.export(matrix, self.root/'other')

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.addCleanup(self.tmp.cleanup)
        self.suite = json.loads(Path(__file__).with_name('qualification.json').read_text())
        self.suite['cases'] = self.suite['cases'][:1]
        self.suite['workers'] = [1]
        self.suite['memory_mib'] = [16]

    def test_duplicate_axes_and_path_components_are_rejected(self):
        for axis in ('seeds', 'workers', 'memory_mib'):
            bad = copy.deepcopy(self.suite)
            bad[axis] *= 2
            with self.assertRaises(ValueError): eval.expand_suite(bad)
        for name in ('..', '.', '../elsewhere', '/absolute'):
            bad = copy.deepcopy(self.suite)
            bad['cases'][0]['id'] = name
            with self.assertRaises(ValueError): eval.expand_suite(bad)

    def test_unknown_settings_and_empty_selection_fail_before_dispatch(self):
        bad = copy.deepcopy(self.suite)
        bad['search']['excutions'] = 1
        with self.assertRaises(ValueError): eval.expand_suite(bad)
        with self.assertRaises(ValueError): eval.expand_suite(self.suite, ['missing'])
        self.assertEqual(len(eval.expand_suite(self.suite)), 1)

    def test_asset_hashes_are_checked_against_inventory_and_suite(self):
        rom = self.root / 'private.nes'
        core = self.root / 'private.so'
        rom.write_bytes(b'private ROM sentinel')
        core.write_bytes(b'core sentinel')
        job = eval.expand_suite(self.suite)[0]
        job['case']['rom_sha256'] = eval.digest(rom)
        assets = {'smb': {'path': str(rom), 'sha256': eval.digest(rom)}, 'core': {'path': str(core), 'sha256': eval.digest(core)}}
        self.assertEqual(eval.resolve_assets(job, assets)['rom_sha256'], eval.digest(rom))
        rom.write_bytes(b'different ROM')
        with self.assertRaises(ValueError): eval.resolve_assets(job, assets)
        assets['smb']['sha256'] = eval.digest(rom)
        with self.assertRaises(ValueError): eval.resolve_assets(job, assets)

    def test_tail_preserves_partial_records(self):
        path = self.root / 'progress.jsonl'
        tail = eval.Tail(path)
        self.assertEqual(tail.read(), {})
        path.write_text('{"execution_work":12')
        self.assertEqual(tail.read(), {})
        with path.open('a') as stream: stream.write('}\n{"execution_work":24}\n')
        self.assertEqual(tail.read(), {'execution_work': 24})
        self.assertEqual(tail.read(), {'execution_work': 24})

    def fake_run(self, body, require_solved=False, finish=30, disk=1):
        # Ordinary fixtures test exit semantics, not interpreter startup latency.
        # The watchdog contract supplies its own short deadline explicitly.
        binary = self.root / 'fake-eval'
        binary.write_text('#!/usr/bin/env python3\nimport json,sys,time\nfrom pathlib import Path\np=Path(sys.argv[2]);p.mkdir()\n' + body)
        binary.chmod(0o755)
        jobs = eval.expand_suite(self.suite)
        job = jobs[0]
        job['case']['require_solved'] = require_solved
        job['request']['wall_seconds'] = 0
        out = self.root / 'runs'
        out.mkdir()
        args = argparse.Namespace(out=out, binary=binary, suite_id='test', suite_sha256='0'*64,
                                  finish_seconds=finish, disk_limit_gib=disk, sample_seconds=.02)
        return eval.run_one(job, job['request'], args, [], {}, {'hostname': 'test'})

    def test_failure_keeps_observed_progress(self):
        result = self.fake_run('(p/"progress.jsonl").write_text(\'{"executions":7,"execution_work":123}\\n\')\nsys.exit(9)\n')
        self.assertEqual(result['status'], 'error')
        self.assertEqual(result['exit_code'], 9)
        self.assertEqual(result['last_progress']['execution_work'], 123)
        self.assertIsNone(result['result'])
        self.assertTrue(result['runner']['coordinator_profile'])

    def test_unavailable_rss_samples_stay_unavailable_in_summaries(self):
        with patch.object(eval.ProcessMetrics, 'sample', return_value={
                'rss_bytes': None, 'read_bytes': None, 'write_bytes': None}):
            result = self.fake_run('sys.exit(9)\n')
        self.assertIsNone(result['peak_process_tree_rss_bytes_sampled'])
        self.assertEqual(result['rss_by_phase_bytes_sampled'], {'preparation': None})
        self.assertIsNone(result['io_bytes_last_sample']['read_bytes'])
        self.assertGreater(result['max_process_rss_bytes'], 0)

    def test_watchdog_kills_only_the_run_and_retains_timeout(self):
        result = self.fake_run('(p/"progress.jsonl").write_text(\'{"executions":1}\\n\')\ntime.sleep(30)\n', finish=.1)
        self.assertEqual(result['status'], 'timeout')
        self.assertLess(result['elapsed_seconds'], 2)
        self.assertLess(result['exit_code'], 0)

    def test_disk_limit_is_a_visible_failure(self):
        result = self.fake_run('(p/"large").write_bytes(b"x"*100000)\ntime.sleep(30)\n', disk=.00001)
        self.assertEqual(result['status'], 'disk_limit')

    def test_large_final_progress_does_not_exhaust_disk_during_verification(self):
        progress = {'executions': 7, 'execution_work': 123, 'resident_memory_bytes': 4096,
                    'deepest_key': 'final', 'selector': {'draws_by_cell': {
                        f'cell-{index}': index for index in range(6000)}},
                    'retained_diagnostics': {'places': list(range(4000))},
                    'workload_diagnostics': {'named_progress': {'first_seen': {'finish': None}}}}
        body = ('progress = ' + repr(progress) + '\n'
                '(p/"progress.jsonl").write_text(json.dumps(progress) + "\\n")\n'
                '(p/"phase.json").write_text(\'{"phase":"verification"}\')\n'
                'while (p.parent/"resources.jsonl").read_text().count(\'"executions":7\') < 24:\n'
                '    time.sleep(.01)\n'
                '(p/"result.json").write_text(\'{"solved":false}\')\n')
        result = self.fake_run(body, disk=.0005)
        self.assertEqual(result['status'], 'complete')
        self.assertEqual(result['last_progress'], progress)
        cell = self.root / 'runs' / result['cell']
        self.assertEqual(json.loads((cell/'campaign/progress.jsonl').read_text()), progress)
        samples = [json.loads(line) for line in (cell/'resources.jsonl').read_text().splitlines()]
        measured = [sample for sample in samples if sample['executions'] == 7]
        self.assertGreaterEqual(len(measured), 12)
        self.assertTrue(all(sample['search']['resident_memory_bytes'] == 4096 for sample in measured))
        self.assertLess((cell/'resources.jsonl').stat().st_size, 16 * 1024)
        self.assertLess(result['final_disk']['logical_bytes'], .0005 * 1024**3)

    def test_unsolved_required_case_is_a_regression(self):
        result = self.fake_run('(p/"result.json").write_text(\'{"solved":false}\')\n', require_solved=True)
        self.assertEqual(result['status'], 'regression')
        self.assertEqual(result['final_disk'], eval.disk_usage(self.root / 'runs' / result['cell']))

    def matrix(self, path):
        path.mkdir()
        item = {'cell': 'smb-s1-w1-m16', 'case': 'smb', 'origin': 'genesis', 'status': 'complete',
                'identity': {'policies': {'key': 'minimal-v1'}},
                'search_request': {'game': 'smb', 'seed': 1, 'workers': 1, 'memory_mib': 16},
                'host': {'hostname': 'test'}, 'result': {'solved': True, 'frames_to_first_victory': 12,
                'frames_emulated': 16, 'frames_per_second': 4}, 'last_progress': {},
                'max_process_rss_bytes': 1024, 'peak_disk_logical_bytes_sampled': 2048}
        eval.write_json(path/'results.json', [item])
        eval.write_json(path/'matrix.json', {'cells': [item['cell']]})
        eval.write_json(path/'suite.json', {'id': 'test'})
        cell = path/item['cell']
        (cell/'campaign').mkdir(parents=True)
        eval.write_json(cell/'summary.json', item)
        (cell/'resources.jsonl').write_text('{}\n')
        return item

    def film_args(self, matrix, binary, max_frames=72000, tail_frames=180):
        return argparse.Namespace(matrix=matrix, binary=binary, max_frames=max_frames, tail_frames=tail_frames)

    def renderable(self, matrix):
        item = self.matrix(matrix)
        cell = matrix/item['cell']
        eval.write_json(cell/'request.private.json', {
            'game': 'nova', 'level': 9, 'rom': '/assets/nova.nes', 'core': '/assets/core.so',
            'rom_sha256': 'a'*64, 'core_sha256': 'b'*64})
        eval.write_json(cell/'campaign/witness-input.json', {'actions': [{'buttons': 0, 'hold_frames': 2}]})
        eval.write_json(cell/'campaign/result.json', {'solved': True, 'witness': {'victory': True}})
        return item

    def test_the_render_command_carries_the_recorded_scenario_identity(self):
        request = {'game': 'nova', 'level': 9, 'whole_game': True, 'rom': '/r.nes', 'core': '/c.so',
                   'rom_sha256': 'a'*64, 'core_sha256': 'b'*64}
        command = eval.film_command(Path('nes-film'), request, Path('run/campaign'), Path('run/film'), 4096, 180)
        self.assertIn('--whole-game', command)
        self.assertEqual(command[command.index('--level')+1], '9')
        self.assertEqual(command[command.index('--max-frames')+1], '4096')
        self.assertEqual(command[command.index('--evidence')+1], 'run/campaign/result.json')
        self.assertNotIn('--ai', command)
        stb = eval.film_command(Path('nes-film'), {**request, 'game': 'stb', 'level': None, 'ai': 'easy',
                                                   'whole_game': False}, Path('c'), Path('f'), 100, 10)
        self.assertEqual(stb[stb.index('--ai')+1], 'easy')
        self.assertNotIn('--level', stb)
        self.assertNotIn('--whole-game', stb)

    def test_a_run_with_no_renderable_input_reports_media_unavailable(self):
        matrix = self.root/'matrix'
        item = self.matrix(matrix)
        eval.write_json(matrix/item['cell']/'request.private.json', {'game': 'nova'})
        with self.assertRaises(ValueError):
            eval.film(self.film_args(matrix, Path('/nonexistent/nes-film')))
        index = eval.read_json(matrix/'films.json')
        self.assertEqual(index['films'], [])
        self.assertEqual(index['unavailable'][0]['cell'], item['cell'])
        self.assertIn('no renderable input', index['unavailable'][0]['reason'])
        self.assertEqual(index['failed'], [])

    def test_a_failed_render_fails_the_command_and_stays_in_the_index(self):
        matrix = self.root/'matrix'
        item = self.renderable(matrix)
        binary = self.root/'nes-film'
        binary.write_text('#!/bin/sh\necho rendering refused >&2\nexit 3\n')
        binary.chmod(0o755)
        with self.assertRaises(ValueError):
            eval.film(self.film_args(matrix, binary))
        index = eval.read_json(matrix/'films.json')
        self.assertEqual(index['films'], [])
        self.assertEqual(index['failed'][0]['exit_code'], 3)
        self.assertIn('rendering refused', (matrix/item['cell']/'film/render.log').read_text())

    def test_a_rendered_film_reaches_the_index_report_and_export(self):
        matrix, public = self.root/'matrix', self.root/'public'
        item = self.renderable(matrix)
        binary = self.root/'nes-film'
        binary.write_text('#!/bin/sh\nout=$(echo "$@" | tr " " "\\n" | grep -A1 -x -- --out | tail -1)\n'
                          'printf x > "$out/witness.mp4"\n'
                          'cat > "$out/film.json" <<\'JSON\'\n'
                          '{"format":"nes-film-v1","endpoint_verified":true,"clip":{"policy":"whole input",'
                          '"skipped_frames":0},"video":{"frames":300,"audio_frames":7350},'
                          '"capture":{"duration_seconds":5.0,"mp4_sha256":"c"}}\nJSON\n')
        binary.chmod(0o755)
        eval.film(self.film_args(matrix, binary))
        index = eval.read_json(matrix/'films.json')
        self.assertEqual(index['films'][0]['cell'], item['cell'])
        self.assertEqual(index['unavailable'], [])
        eval.write_json(matrix/'film-verification.json',
                        {'verified': [item['cell']], 'problems': {}})
        eval.export(matrix, public)
        self.assertTrue((public/item['cell']/'film/witness.mp4').is_file())
        self.assertIn('film with game audio', (public/'index.html').read_text())
        media = eval.read_json(public/'roster.json')[0]['media']
        self.assertTrue(media['available'])
        self.assertEqual(media['mp4'], item['cell'] + '/film/witness.mp4')
        self.assertIn('films.json', eval.read_json(public/'checksums.json'))
        self.assertIn('film-verification.json', eval.read_json(public/'checksums.json'))

    def test_a_film_the_media_check_rejected_is_not_published_as_media(self):
        matrix, public = self.root/'matrix', self.root/'public'
        item = self.renderable(matrix)
        eval.write_json(matrix/'films.json', {'films': [
            {'cell': item['cell'], 'endpoint_verified': True, 'clip': {'policy': 'whole input'},
             'video': {'frames': 300, 'audio_frames': 7350},
             'capture': {'duration_seconds': 5.0, 'mp4_sha256': 'c'}}], 'unavailable': [], 'failed': []})
        eval.write_json(matrix/'film-verification.json',
                        {'verified': [], 'problems': {item['cell']: ['the audio track is silent']}})
        eval.export(matrix, public)
        media = eval.read_json(public/'roster.json')[0]['media']
        self.assertFalse(media['available'])
        self.assertIn('the audio track is silent', media['reason'])
        self.assertNotIn('film with game audio', (public/'index.html').read_text())

    def test_a_film_nothing_checked_is_not_published_as_media(self):
        matrix, public = self.root/'matrix', self.root/'public'
        item = self.renderable(matrix)
        eval.write_json(matrix/'films.json', {'films': [
            {'cell': item['cell'], 'endpoint_verified': True, 'clip': {'policy': 'whole input'},
             'video': {'frames': 300, 'audio_frames': 7350},
             'capture': {'duration_seconds': 5.0, 'mp4_sha256': 'c'}}], 'unavailable': [], 'failed': []})
        eval.export(matrix, public)
        media = eval.read_json(public/'roster.json')[0]['media']
        self.assertFalse(media['available'])
        self.assertIn('never checked', media['reason'])

    def test_a_panel_without_a_media_index_records_every_cell_as_unavailable(self):
        matrix, public = self.root/'matrix', self.root/'public'
        self.matrix(matrix)
        eval.export(matrix, public)
        media = eval.read_json(public/'roster.json')[0]['media']
        self.assertFalse(media['available'])
        self.assertIn('no media', media['reason'])


    def test_comparison_refuses_changed_policies_budgets_and_missing_cells(self):
        a, b = self.root/'a', self.root/'b'
        original = self.matrix(a)
        self.matrix(b)
        self.assertTrue(eval.compare(a, b)['pairs'][0]['comparable'])
        for field, key, value in [('identity', 'policies', {'key': 'hinted'}), ('search_request', 'memory_mib', 32), ('search_request', 'frames', 100), ('search_request', 'actions', 512)]:
            changed = copy.deepcopy(original)
            changed[field][key] = value
            eval.write_json(b/'results.json', [changed])
            with self.assertRaises(ValueError): eval.compare(a, b)
        eval.write_json(b/'results.json', [])
        with self.assertRaises(ValueError): eval.compare(a, b)

    def test_export_is_allowlisted_and_checksummed(self):
        private, public = self.root/'private', self.root/'public'
        item = self.matrix(private)
        for name in ('rom.nes', 'checkpoint.json', 'stream.jsonl', 'request.private.json'):
            (private/item['cell']/'campaign'/name).write_text('DO NOT PUBLISH')
        eval.export(private, public)
        for path in public.rglob('*'):
            if path.is_file(): self.assertNotIn('DO NOT PUBLISH', path.read_text())
        checksums = eval.read_json(public/'checksums.json')
        self.assertIn('index.html', checksums)
        self.assertIn('roster.json', checksums)
        for path, expected in checksums.items(): self.assertEqual(eval.digest(public/path), expected)

    def test_roster_keeps_mechanism_budgets_outcome_replay_and_resources(self):
        item = self.matrix(self.root/'matrix')
        item['origin'] = 'power-on stage genesis'
        item['identity'] = {'backend': 'native', 'policies': {'key': 'fixed-v1'}}
        item['search_request'].update({
            'game': 'mm2', 'seed': 7, 'executions': 123,
            'frames': 789, 'wall_seconds': 42, 'workers': 2, 'memory_mib': 64,
            'selector': 'selector-v1', 'mixture': 'mixture-v1',
            'verification': 'witness'})
        item['result'].update({
            'progress': {'stage_clear': 1}, 'verification': 'witness',
            'witness': {'snapshot_sha256': 'a' * 64}, 'victory_observed': True,
            'stop_reason': 'victory'})
        item['last_progress'] = {'resident_memory_bytes': 2 * 1048576}
        row = eval.roster_row(item)
        self.assertEqual(row['game'], 'mm2')
        self.assertEqual(row['budgets']['frames'], 789)
        self.assertEqual(row['mechanism']['selector'], 'selector-v1')
        self.assertEqual(row['outcome'], 'victory within declared frame budget')
        self.assertEqual(row['replay']['confirmation'], 'bounded witness replay ×2 confirmed')
        self.assertEqual(row['resources']['last_logical_memory_bytes'], 2 * 1048576)
        report = eval.report_html([item], 'Roster')
        for value in ('mm2', 'power-on stage genesis', 'selector-v1', 'bounded witness replay ×2 confirmed'):
            self.assertIn(value, report)

    def test_changed_affinity_keeps_quality_comparable_but_flags_timing(self):
        a, b = self.root/'a', self.root/'b'
        original = self.matrix(a)
        self.matrix(b)
        for path, cpus in ((a, [0]), (b, [1])):
            changed = copy.deepcopy(original)
            changed['cpu_set'] = cpus
            eval.write_json(path/'results.json', [changed])
            eval.write_json(path/'matrix.json', {'cells': [changed['cell']], 'runner': {'jobs': 1}})
        pair = eval.compare(a, b)['pairs'][0]
        self.assertTrue(pair['comparable'])
        self.assertTrue(pair['same_host'])
        self.assertTrue(pair['same_runner_configuration'])
        self.assertFalse(pair['timing_environment_matches'])

    def test_comparison_reports_identical_recorded_search(self):
        a, b = self.root/'a', self.root/'b'
        original = self.matrix(a)
        self.matrix(b)
        for path in (a, b):
            changed = copy.deepcopy(original)
            changed['result']['stream_sha256'] = 'a' * 64
            eval.write_json(path/'results.json', [changed])
        pair = eval.compare(a, b)['pairs'][0]
        self.assertTrue(pair['same_recorded_search'])

    def test_export_refuses_symlinks(self):
        private, public = self.root/'private', self.root/'public'
        item = self.matrix(private)
        secret = self.root/'secret'
        secret.write_text('private')
        (private/item['cell']/'campaign'/'result.json').symlink_to(secret)
        with self.assertRaises(ValueError): eval.export(private, public)
        self.assertFalse(public.exists())

    def test_censored_runs_are_not_imputed_as_completion_times(self):
        item = self.matrix(self.root/'matrix')
        censored = copy.deepcopy(item)
        censored['result']['solved'] = False
        censored['result']['frames_to_first_victory'] = None
        rows = eval.aggregates([item, censored])
        self.assertEqual(rows[0]['solve_fraction_of_valid'], .5)
        self.assertEqual(rows[0]['median_frames_to_victory_among_successes'], 12)
        low, high = rows[0]['solve_fraction_wilson95']
        self.assertLess(low, .2)
        self.assertGreater(high, .8)

    def test_solve_intervals_include_observed_fraction_at_boundaries(self):
        self.assertIsNone(eval.solve_interval(0, 0))
        for total in range(1, 101):
            for solved in range(total + 1):
                low, high = eval.solve_interval(solved, total)
                self.assertLessEqual(0., low)
                self.assertLessEqual(low, solved / total)
                self.assertLessEqual(solved / total, high)
                self.assertLessEqual(high, 1.)

    def test_completion_figures_keep_failed_and_censored_trials_in_denominator(self):
        import plots
        solved = {'result': {'solved': True, 'frames_to_first_victory': 12}}
        censored = {'result': {'solved': False, 'frames_to_first_victory': 99}}
        failed = {'result': None}
        self.assertEqual(plots.completions([solved, censored, failed], 'frames_to_first_victory'),
                         ([0, 12], [0, 1 / 3]))

    @unittest.skipUnless(importlib.util.find_spec('matplotlib'), 'matplotlib is not installed')
    def test_figures_render_from_progress_lines(self):
        import plots
        with tempfile.TemporaryDirectory() as directory:
            matrix = Path(directory) / 'matrix'
            cell = 'smb-s1-w2-m256'
            (matrix / cell / 'campaign').mkdir(parents=True)
            progress = [{'executions': n, 'execution_work': 40 * n, 'search_elapsed_millis': 10 * n,
                         'resident_memory_bytes': 4096 * n, 'historical_cells': n,
                         'progress': {'deepest': n}} for n in (1, 100, 200)]
            (matrix / cell / 'campaign/progress.jsonl').write_text(
                ''.join(json.dumps(line) + '\n' for line in progress))
            (matrix / cell / 'resources.jsonl').write_text(json.dumps(
                {'elapsed_seconds': 1, 'rss_bytes': 1 << 20, 'disk': {'logical_bytes': 1 << 20}}) + '\n')
            summary = {'cell': cell, 'case': 'smb', 'status': 'complete', 'origin': 'power-on',
                       'search_request': {'workers': 2, 'memory_mib': 256, 'seed': 1},
                       'result': {'solved': True, 'frames_to_first_victory': 8000, 'frames_emulated': 8000,
                                  'frames_per_second': 1000.},
                       'max_process_rss_bytes': 1 << 20, 'peak_disk_logical_bytes_sampled': 1 << 20}
            eval.write_json(matrix / 'matrix.json', {'cells': [cell]})
            eval.write_json(matrix / 'results.json', [summary])
            out = Path(directory) / 'figures'
            plots.render([('run', matrix)], out)
            self.assertTrue((out / 'smb-w2-m256.svg').is_file())
            self.assertTrue((out / 'smb-w2-m256-observations.svg').is_file())


if __name__ == '__main__':
    unittest.main()

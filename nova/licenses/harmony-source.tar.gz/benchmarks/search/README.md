<!-- SPDX-License-Identifier: AGPL-3.0-or-later -->

# Local search evaluation

This suite evaluates Dissonance search mechanisms against fixed NES workloads.
It is designed for a private Linux host with licensed ROMs; ordinary CI uses
synthetic engine/runner tests and source-built games. A stage fixture is never
counted as a whole-game solve. No run starts from a supplied solution tape.

## Run

Build the pinned QuickNES core with `scripts/build-quicknes-core.sh`. Build Nova
and Super Tilt Bro with the scripts in `workloads/nes/scripts`. Supply your own
SMB, MM2, and Metroid ROMs. Put their absolute paths and SHA-256 values in a
private inventory outside the repository:

```json
{
  "core": {"path": "/private/assets/quicknes_libretro.so", "sha256": "YOUR_CORE_SHA256"},
  "smb": {"path": "/private/assets/smb.nes", "sha256": "0b3d9e1f01ed1668205bab34d6c82b0e281456e137352e4f36a9b2cfa3b66dea"},
  "mm2": {"path": "/private/assets/mm2.nes", "sha256": "49136b412ff61beac6e40d0bbcd8691a39a50cd2744fdcdde3401eed53d71edf"},
  "metroid": {"path": "/private/assets/metroid.nes", "sha256": "e6e6b7014685adae447ebb3833242815747bc1e5df83ade79f693fb67cf565b6"},
  "nova": {"path": "/private/assets/nova.nes", "sha256": "9107be62a08a0ae51a01f900bd18a95a52fe043f53e9cae4a64d1e8e73114b08"},
  "stb": {"path": "/private/assets/stb.nes", "sha256": "6f80d56ce0b242a4faceafafea321feb1c364ab8e7937646e8580ae9289a4ec3"}
}
```

From the repository root, with Python 3.9+, the pinned Rust toolchain, and Linux
`taskset` available:

```sh
python3 benchmarks/search/eval.py build --out /private/builds/search-001 --jobs 24
python3 benchmarks/search/eval.py run benchmarks/search/qualification.json \
  --assets /private/assets.json --binary /private/builds/search-001/nes-eval \
  --build-info /private/builds/search-001/build-info.json \
  --out /private/runs/qualification-001 --jobs 6 --cpus 24 \
  --memory-capacity-mib 40000
python3 benchmarks/search/eval.py run benchmarks/search/evaluation.json \
  --assets /private/assets.json --binary /private/builds/search-001/nes-eval \
  --build-info /private/builds/search-001/build-info.json \
  --out /private/runs/evaluation-001 --jobs 3 --cpus 24 \
  --memory-capacity-mib 40000
```

The scheduled and dispatched
[Benchmarks / Dissonance Workloads / NES](../../.github/workflows/dissonance-workloads-nes-benchmarks.yml)
runs the source-built public capability panel from `nightly.json`. Each case has
an independent matrix job that builds its game and the pinned QuickNES core,
then uses the same `nes-eval` runner as the private panels with `--case`.
Each job retains the three registered seeds, films every scenario, and exports
its own HTML report and `roster.json`; exports contain no ROM or core. An
always-running Results job combines these rosters, links case reports, and fails
on missing or conflicting evidence. The custom lint requires the case matrix to
match this manifest exactly. Pull requests run the bounded jobs in
[Checks / Dissonance Workloads / NES](../../.github/workflows/dissonance-workloads-nes-checks.yml)
instead; [docs/WORKFLOWS.md](../../docs/WORKFLOWS.md) is the contract.

Run the licensed panels on the private Linux host with the caller-supplied
inventory and keep both the matrix and export directories on that host:

```sh
benchmarks/search/run-private.sh /private/assets.json /private/runs/evaluation-001 \
  benchmarks/search/evaluation.json
benchmarks/search/run-private.sh /private/assets.json /private/runs/smb-reference-001 \
  benchmarks/search/smb-reference.json
```

The script accepts only the two registered private manifests. It verifies every
asset hash through `eval.py`, performs the bounded witness replay required by
those manifests, and leaves the HTML/JSON report in a sibling `-public`
directory. The report is local evidence; the script does not fetch, upload, or
publish licensed assets or their private requests.

Repeat the qualified whole-game SMB check with the same identified build:

```sh
python3 benchmarks/search/eval.py run benchmarks/search/smb-reference.json \
  --assets /private/assets.json --binary /private/builds/search-001/nes-eval \
  --build-info /private/builds/search-001/build-info.json \
  --out /private/runs/smb-reference-001 --jobs 1 --cpus 24 \
  --memory-capacity-mib 8192
```

This searches from a new game on each registered seed and fails if any cell
misses its declared victory budget.

Builds and matrix output directories must be new. The build helper checks that
source identity is unchanged during compilation and records compiler versions,
source hash, flags and executable hash. `--build-info` is checked against the
binary when it includes a binary digest. An arbitrary supplied legacy build
identity is an operator attestation; absent build information is reported as
unavailable, never inferred from an unrelated current checkout.

`--case ID` restricts a run to explicitly selected registered cases. The runner
allocates disjoint CPU sets and reserves each cell's logical memory budget plus
`--overhead-mib` (default 1024) against host capacity. These are scheduling
reservations, not OS memory enforcement. Keep other heavy processes off the
host for publishable timing comparisons. CPU affinity, host model, concurrent
job limit, budgets, executable, core, ROM, adapter and mechanism identities are
retained in every matrix. Native resource sampling uses Linux `/proc`; missing
platform measurements must not be interpreted as zero. Coordinator profiling is
enabled for benchmark cells and recorded in both the matrix runner metadata and
each cell summary. Older summaries omit that field; their runner source must be
checked before assuming a profiling setting.

Resource samples retain scalar search progress fields alongside host counters.
Full selector, census and workload diagnostics stay in `campaign/progress.jsonl`
and the final summary's `last_progress`. Resource polling does not copy those
nested reports repeatedly while the native evaluator exports or verifies tapes,
so an unchanged final census cannot multiply telemetry storage at every sample.

A request's `window` counts reservations per worker. The pilot and full native
evaluation use a two-reservation window.
The dedicated SMB regression panel retains its original one-reservation profile
as a separate stress condition.

A Metroid case may carry `root_input`, the path to a milestone input recorded
by an earlier run. The campaign then starts from the state that input reaches
instead of power-on, every recorded input is relative to that state, and
`gained` counts items and tanks taken beyond it. `{seed}` in the path is
replaced with the cell's seed, so each seed can continue its own line.
`compare` reads each cell's `summary.json` and refuses two matrices whose cells
for one case name different root inputs, so it never combines a rooted run
with a power-on run.

An `nes-eval` request can write search checkpoints into `checkpoints/` in its
output directory. `checkpoint_every` writes one every that many executions, and
`checkpoint_on_progress` writes one whenever the workload reaches a new named
milestone or the archive opens a higher tier. `resume` names a checkpoint file
and continues that search. The executions and frame budgets count from the
original power-on, so a resumed run stops where the original would have. A
resume with the same seed repeats the original progress lines after the
checkpoint; a different seed keeps the archive and draws new choices. Resumed
runs use witness verification, because their stream starts at the checkpoint.

## Registered panels

| Manifest | Purpose |
| --- | --- |
| `qualification.json` | Six small cases: all five games plus whole-game Nova configuration. Full stream/checkpoint replay and twice-repeated witness replay; 500 executions per case. |
| `ci.json` | Source-built Nova (level and whole-game origins) and STB through the common runner, with full small-campaign replay and a frame cap. No licensed commercial ROM is used. |
| `nightly.json` | Scheduled/manual source-built capability panel: the five registered isolated Nova levels, whole-game Nova, and STB Easy/Fair/Hard across seeds 1–3. Long runs use bounded witness replay; isolated levels and STB Hard retain their distinct outcome semantics. |
| `pilot.json` | Three exploratory seeds on SMB, Nova level 1 and whole game, Metal Man, Metroid new game and STB Hard. |
| `alphabet-control.json` | The same development pilot origins and budgets with alphabet-only mutation. This exploratory panel does not require every case to solve. |
| `metroid-long-horizon.json` | Metroid new game on three reused development seeds at 3 million executions, 4 workers and 8 GiB, with alphabet-only mutation. |
| `metroid-long-horizon-energy-splice.json` | The same three seeds and budgets drawing through the retained-input table, against the alphabet-only arm of `metroid-long-horizon.json`. |
| `metroid-ladder.json` | One case per Metroid chain segment, each starting from that segment's recorded `root_input`, on seeds 11–13 at 4 workers, 6 GiB and 3 million executions. Score it with `eval.py ladder`. |
| `throughput-checkpoint.json` | The 18-cell throughput panel with the adopted two-result-slot profile, for an isolated comparison of unchanged policies before and after implementation changes. |
| `evaluation.json` | Main-mechanism control: five seeds across SMB, five Nova level fixtures plus whole-game Nova, all eight MM2 Robot Master stages, Metroid new game, and STB Easy/Fair/Hard. |
| `smb-reference.json` | Practical fresh whole-game SMB recipe: 24 workers, 2,048 MiB, count weighting, two-reservation window, 600,000 executions and 120 million frames. Five fresh validation seeds; every cell must solve. |
| `smb-regression.json` | Fresh whole-game SMB at 24 workers and both 256/2048 MiB, five seeds. Every cell must solve within its declared budget. |
| `smb-regression-three.json` | The same case at 256 MiB on the first three seeds, the check run on every build that changes only the Metroid side. Every cell must solve. |
| `throughput.json` | Short isolated 24-worker runs across all five games, three seeds, a two-reservation window and 512 MiB. Whole-game completion is not required in this work-limited panel. |

Seeds 20260905–20260907 form the development pilot. The dedicated SMB check adds
20260908–20260909; those seeds have now been observed in count-policy validation.
The practical SMB reference validates on 20260910–20260914. Before any broad
evaluation cell ran, its seeds were moved to the separate, preregistered panel
20260920–20260924, preserving unobserved trials for
validating a mechanism selected from the development runs. Performance panels have explicit
frame, execution and wall ceilings. SMB's dedicated regression panel allows
2,000,000 executions under a 400-million-frame cap and a 1,800-second wall; the
broad eight-worker panel allows 600,000 executions under an 80-million-frame
cap. The regression panel's earlier 400,000-execution ceiling sat inside the
spread of its own solve points, measured from 267,067 to 685,954 executions
across its ten cells, so which cells solved varied run to run. Its ceiling is a
floor for whether a run completes at all; compare runs by the recorded
`executions_to_first_victory`, not by whether a cell cleared the ceiling. The practical SMB reference allows 600,000
executions and 120 million frames at 24 workers. It solved all four development
seeds (including seed 1) in 122–167 seconds and all five fresh validation seeds
in 89–251 seconds, including witness verification. One validation seed needed
598,013 executions, close to the 600,000 ceiling. These are distinct resource
conditions.

All manifests specify exact ROM hashes and normal menu origins. MM2 is currently
an independent-stage panel; it does not claim full-game evaluation. Metroid
progress is reported even when its ending is not reached. Nova whole-game runs
require all 40 cleared-level flags from level 1; a single cleared level cannot
satisfy that predicate. Isolated later-level Nova setup is a declared fixture.

Copy a manifest to change **search** mechanisms for an ablation. Keep case IDs,
origins, seed panel, ROM/core, adapter policies and resource budgets fixed. The
comparison command rejects mismatches rather than quietly combining them.
Prototype claims are not accepted merely because a previous single seed
succeeded. Register a fresh continuation candidate against the slot graph before
running a full panel.

Continuation replay remains an explicit experiment. The qualified native
execution profile and SMB reference are the recommended adoption results. These
seed panels are now observed regression references; register new unseen seeds
before another promotion decision.

## Metroid ladder

```sh
python3 benchmarks/search/eval.py ladder /private/runs/ladder-001 \
  /private/runs/ladder-002 --out /private/ladder-scores
```

`ladder` scores matrices run over `metroid-ladder.json`, one column per
source. It reads only cases whose id names a segment, such as `ladder-seg4`.
Every seed of a root starts from the same state, so a root holds a milestone
when every seed that reported progress shows it in that seed's first recorded
observation, along with every milestone before it. The root's ladder is the rest of the chain's
milestone sequence. A milestone passes when at least two distinct seeds reach
it, and the score counts passed milestones in a row from the front of the
ladder. Reaching the ending passes every milestone before it. Two more tables
give each root's continuation graph counters and its emulator work per
execution. `--out` writes one JSON document per source, and `ladder` accepts
those documents as sources in place of a matrix directory.
`milestones.py` prints the execution at which each Metroid cell first reached
each named milestone.

## Evidence and resource accounting

Each cell writes a private request, logs, `summary.json`, `resources.jsonl`, and
a `campaign` directory containing identities, progress, compact reports and
witness inputs. Failed, timed-out and required-but-unsolved runs remain visible.
Completed cell summaries and the results index are saved incrementally; an
incomplete matrix cannot be silently exported or compared as a complete panel.
The watchdog kills only its own process group after the search wall budget plus
`--finish-seconds`, or when its sampled disk footprint exceeds
`--disk-limit-gib`. The search itself stops issuing reservations at its wall
limit, then drains admitted work and verifies evidence.

- **Search quality:** verified completion, first-victory executions and emulator
  frames, objective progress/milestones, deaths and retained novelty cells. The
  novelty ledger is compacted under memory pressure and is not cumulative world
  coverage. Aggregate evidence
  can combine explored branches; it is not a claimed single trajectory.
- **Throughput:** actual admitted NES execution work in frames / search wall
  time and executions / search wall time. Work includes snapshot-to-parent
  replay and suffix execution, while admission probes and power-on setup stay
  outside the logical counter. Power-on worker construction is inside the timed
  search call but excluded from its admitted work counter. Final internal
  campaign compaction is also inside this timer. External report export and
  witness/campaign verification have separate durations.
- **Memory:** sampled process-group RSS by phase, OS maximum process RSS, logical
  archive/snapshot/index/history/draw-state charges, evictions and compactions.
  OS RSS and logical charges answer different questions and are both retained.
- **Output disk:** sampled current/peak and final logical and allocated bytes
  inside the cell output directory, categorized by stream, checkpoints, media,
  telemetry and reports/logs. The final footprint includes the summary. Shared
  assets/build bundles and runtime files elsewhere are excluded. In particular,
  QuickNES creates and unlinks private temporary core copies while their mappings
  remain live. These output metrics are not total process or host filesystem
  occupancy. Process I/O is logged separately; sampling can miss short-lived peaks.
  Broader runtime-file accounting is tracked in
  [#274](https://github.com/pH14/harmony/issues/274).

- **I/O and CPU:** sampled `/proc` read/write bytes, CPU seconds and OS block
  operation/context-switch counts. The final sampled byte totals are lower bounds
  if a process exits between samples; block operations are not byte counts.
- **Coordinator:** optional phase timing and dispatched action costs. Declared
  replay/suffix cost is labelled separately from actual execution work; this
  NES adapter reports that work in frames.

The HTML run table and Metroid milestone table show peak process RSS, the last
reported logical archive charge, and peak sampled output disk in MiB. In the
milestone table these columns span the search-union and trajectory rows because
they measure the whole benchmark cell, including verification. Missing samples
remain `unavailable`; a measured zero stays zero. Raw byte values, allocated disk
bytes, and phase-specific memory remain in each summary and telemetry stream.

Performance runs hash and discard the full event stream while retaining compact
reports and a best/winning input. This bounds disk growth without pretending a
full verification stream was saved. Each witness is replayed twice on fresh
native targets; every claimed victory must reproduce. Qualification uses
`verification: campaign`, limited to at most 5,000 executions, and additionally
re-executes the complete stream and compares the report and portable checkpoint.
These modes and verification time are explicit in the matrix. No large-run
full-campaign verification is implied by a witness-only result.

## Films

```sh
python3 benchmarks/search/eval.py film /private/runs/evaluation-001 \
  --binary /private/builds/search-001/nes-film --max-frames 72000
```

`film` renders each completed cell's own recorded input to an MP4 with game
audio through the `nes-film` renderer described in the
[NES package README](../../workloads/nes/README.md). It reads the cell's
`witness-input.json` and `result.json`, so it never starts a second search. A
cell that produced no renderable input is recorded as unavailable with a reason;
a render that fails is recorded as failed and fails the command. `films.json`
indexes all three states beside each cell's `film/render.log`.
`scripts/verify-nes-films.py` then rechecks every film's digest, frame count,
audio stream, mean volume, audio coverage and duration, and checks each film
against the digest, input and identity `films.json` recorded for its cell. It
writes its verdict per cell to `film-verification.json`, and the roster and HTML
report count a film as media only when that record accepts it.

`eval.py build` builds `nes-film` alongside `nes-eval` and records its hash.
`--max-frames` bounds each render. A long input is still emulated in full and
rendered as a trailing window ending at the recorded endpoint; the ceiling, the
clip policy and the dropped frame count are in each `film.json`. The HTML report
carries a Media column linking the film with its duration and clip policy, and a
cell with no media stays in the roster as unavailable instead of disappearing
from it.

## Compare and publish

```sh
python3 benchmarks/search/eval.py compare /private/runs/baseline \
  /private/runs/candidate --out /private/comparison.json
python3 benchmarks/search/eval.py export /private/runs/candidate \
  --out /private/public/search-001
```

The export is a standalone HTML report plus allowlisted JSON/JSONL, discovered
controller inputs, rendered films with their `film.json` and render log, and
SHA-256 checksums. It excludes ROMs, cores, snapshots,
full streams, private requests, arbitrary files and logs. Symlinks are rejected.
Copy the export directory to your static publication location; publishing is a
separate operator action. Source-built STB artifacts also carry the license
notice in `workloads/nes/STB-ARTIFACT-LICENSE.md` when redistributed as required.

Keep one immutable directory per revision/run. Case IDs, policy identities and
seed/resource axes support longitudinal comparisons without renaming away
regressions. Solve fractions include Wilson 95% intervals; failed infrastructure
runs are counted separately, and missing victories are censored at their budget.
The reported median victory frame count is conditional on success. Do not
replace an unsolved run with the budget as an invented completion time or infer
statistical confidence from a three-seed pilot.

Generate standalone PNG/SVG figures on the publication machine (the benchmark
host needs no plotting dependencies):

```sh
python3 -m pip install -r benchmarks/search/requirements-plots.txt
python3 benchmarks/search/plots.py --run baseline=/private/public/baseline \
  --run candidate=/private/public/candidate --out /private/public/figures-001
```

The figure generator verifies matching cells, adapters and budgets, and records
input hashes. It shows individual seeds, verified completion by frames, coverage,
throughput, process RSS, logical memory, disk, and the workload's named progress
observations. Numeric map labels are not interpreted as distances to a solution.
Each new revision can be added as another labelled series; retain the previous
run exports and figure directories unchanged. Different resource panels require
separate figures. `compare` flags changed hosts, CPU affinity and runner limits.
Dynamic scheduling can assign a seed a different CPU set when another seed
finishes first, and disjoint logical CPUs may share a physical core. Concurrent
panel timings describe that workload mix; use admitted frames for search quality
and `--jobs 1` on an otherwise quiet host for precise throughput claims. Matching
recorded environment fields alone does not prove physical isolation.

## Checks

```sh
python3 -m unittest discover -s benchmarks/search -p 'test_*.py'
cargo test --manifest-path dissonance/searcher/Cargo.toml
cargo test --manifest-path workloads/nes/Cargo.toml --lib
python3 scripts/check-dependency-boundaries.py
```

The runner tests plant failures, timeouts, disk overuse, changed assets/policies,
missing cells and publication leaks. The engine's generic continuation fixture
requires actual reuse and memory pressure before comparing live/replay results.
Licensed-ROM qualification runs locally. CI also builds Nova and STB from pinned
sources and exercises the common binary, runner, full campaign replay and compact
export; its short qualification budgets do not claim whole-game completion.

When compared arms run jobs of different lengths, set `search.frames` to a
positive NES-frame work budget as well as an execution ceiling and wall limit.
Selection stops when measured work reaches the threshold and drains the
existing reservation window. Total work can therefore exceed the threshold;
the overshoot is logged. A victory first observed beyond the frame budget is
preserved and verified as evidence but does **not** pass the suite's success
check. The optional work budget is recorded in the deterministic header/report.
Omitting it leaves the campaign without a work-budget cutoff.

## Deep progress and historical comparisons

A fast independent-stage panel is not a substitute for preserving demonstrated
whole-game reach. The 005 Mega Man panel starts each Robot Master stage separately;
the earlier Wily 4 result chained searched victories and carried the resulting
weapons. Replay of that retained chain verifies current runtime compatibility,
not fresh-search recovery. The deep chained search regression remains an explicit
qualification gap.

Metroid reports now expose named equipment, area entry, and boss defeat separately,
with independent first-discovery tapes and a separate champion/victory trajectory.
The HTML export includes these fields and links to verified tapes. Older missing
observations display as unavailable. Resource figures, budgets, stop reasons, and
failures remain in every row; milestone timings are censored at each run's budget.

`metroid-long-horizon.json` and `metroid-long-horizon-energy-splice.json`
register a **development diagnostic**
using historical seeds 3, 4, and 5: four workers, 8 GiB logical archive,
3 million executions and 400 million admitted frames. Every arm uses the same
current adapter and executable. Only the
mutation mixture differs. These restore the earlier
work/memory scale. They do not reproduce the historical improvement-replay
implementation, exact reservation schedule, platform, or action stream. These reused seeds are not
fresh validation evidence. The earlier 005 Metroid panel used 500,000 executions,
2 GiB, eight workers, a capped suffix, and energy splice; it cannot establish
preservation of the earlier 3-million-execution results.

Run either manifest with the ordinary `eval.py run` command and private asset
inventory. Preserve the registered manifest and build identity before dispatch.
Publish solve status **and named milestones**, including runs with no further
discovery. Compare admitted work for search quality; use matched CPU types and
isolated runs for claims about throughput.

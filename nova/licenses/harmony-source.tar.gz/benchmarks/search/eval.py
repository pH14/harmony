#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Run, compare and export reproducible local search evaluations."""
from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import html
import itertools
import json
import os
from pathlib import Path
import platform
import re
import shutil
import signal
import statistics
import math
import subprocess
import sys
import time

SCHEMA = 'harmony-search-eval-v1'
ALLOWED_SEARCH = {'seed','workers','executions','frames','memory_mib','window','wall_seconds','mixture','verification','checkpoint_every','checkpoint_on_progress'}


def valid_id(value):
    return isinstance(value, str) and value not in {'.', '..'} and re.fullmatch(r'[a-zA-Z0-9_][a-zA-Z0-9_.-]*', value)


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''): value.update(block)
    return value.hexdigest()


def read_json(path, default=None):
    try: return json.loads(Path(path).read_text())
    except FileNotFoundError: return default


def write_json(path, value):
    path = Path(path)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n')
    temp.replace(path)


def source_identity(root):
    root = Path(root)
    manifest = []
    excluded = {'.git','target','build','__pycache__','.agents','.claude','.codex','node_modules'}
    for directory in ['dissonance','workloads','benchmarks/search']:
        for current, dirs, files in os.walk(root / directory):
            dirs[:] = sorted(d for d in dirs if d not in excluded)
            for name in sorted(files):
                path = Path(current) / name
                if not path.is_symlink(): manifest.append((str(path.relative_to(root)),digest(path)))
    for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','clippy.toml','.cargo/config.toml']:
        if (root/name).is_file(): manifest.append((name,digest(root/name)))
    h = hashlib.sha256(json.dumps(sorted(manifest),separators=(',',':')).encode()).hexdigest()
    try:
        revision = subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,stderr=subprocess.DEVNULL,text=True).strip()
        dirty = bool(subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True))
    except subprocess.CalledProcessError:
        revision,dirty = None,None
    return {'source_tree_sha256':h,'revision':revision,'dirty':dirty,'files':len(manifest)}


def disk_usage(root):
    logical = allocated = 0
    categories = {}
    for current, dirs, files in os.walk(root,followlinks=False):
        dirs[:] = [d for d in dirs if not (Path(current)/d).is_symlink()]
        for name in files:
            path=Path(current)/name
            try: stat=path.lstat()
            except FileNotFoundError: continue
            if path.is_symlink(): continue
            logical+=stat.st_size
            allocated+=getattr(stat,'st_blocks',0)*512
            category = 'stream' if name=='stream.jsonl' else 'checkpoint' if 'checkpoint' in name else 'media' if path.suffix in {'.mp4','.wav','.png','.rgb'} else 'telemetry' if name in {'resources.jsonl','progress.jsonl','events.jsonl'} else 'reports_and_logs'
            categories[category]=categories.get(category,0)+stat.st_size
    return {'logical_bytes':logical,'allocated_bytes':allocated,'categories':categories}


class ProcessMetrics:
    """Sample one isolated process group; retain exited members' I/O counters."""
    def __init__(self, group):
        self.group=group
        self.io={}

    def sample(self):
        rss=0
        if not Path('/proc').is_dir(): return {'rss_bytes':None,'write_bytes':None,'read_bytes':None}
        for directory in Path('/proc').iterdir():
            if not directory.name.isdigit(): continue
            try:
                # comm may contain spaces and parentheses; fields follow its final ')'.
                fields=(directory/'stat').read_text().rsplit(')',1)[1].split()
                if int(fields[2]) != self.group: continue
                key=(directory.name,fields[19])
                status=dict(line.split(':',1) for line in (directory/'status').read_text().splitlines() if ':' in line)
                rss+=int(status.get('VmRSS','0 kB').split()[0])*1024
                counters=dict(line.split(':',1) for line in (directory/'io').read_text().splitlines())
                self.io[key]=(int(counters['read_bytes']),int(counters['write_bytes']))
            except (FileNotFoundError,ProcessLookupError,PermissionError,ValueError,KeyError): continue
        return {'rss_bytes':rss,'read_bytes':sum(x[0] for x in self.io.values()),'write_bytes':sum(x[1] for x in self.io.values())}


class Tail:
    def __init__(self,path): self.path=Path(path); self.offset=0; self.pending=b''; self.last={}
    def read(self):
        try:
            with self.path.open('rb') as f:
                f.seek(self.offset); block=f.read(); self.offset=f.tell()
        except FileNotFoundError: return self.last
        lines=(self.pending+block).split(b'\n');self.pending=lines.pop()
        for line in lines:
            if line: self.last=json.loads(line)
        return self.last


def expand_suite(suite, selected=None):
    if suite.get('format') != SCHEMA: raise ValueError('unknown suite format')
    if not valid_id(suite['id']): raise ValueError('invalid suite id')
    for axis in ('seeds', 'workers', 'memory_mib'):
        values = suite[axis]
        if not values or any(type(x) is not int for x in values) or len(values) != len(set(values)):
            raise ValueError('empty, invalid or duplicate matrix axis: ' + axis)
    jobs=[]; names=set()
    for case in suite['cases']:
        name=case['id']
        if not valid_id(name) or name in names: raise ValueError('invalid or duplicate case id')
        names.add(name)
        if selected and name not in selected: continue
        settings={**suite['search'],**case.get('search',{})}
        if 'selector' in settings: raise ValueError('case '+name+' sets search.selector; nes-eval takes no selector, so remove it from the manifest')
        if set(settings)-ALLOWED_SEARCH: raise ValueError('unknown search settings: '+', '.join(sorted(set(settings)-ALLOWED_SEARCH)))
        for seed,workers,memory in itertools.product(suite['seeds'],suite['workers'],suite['memory_mib']):
            request={**settings,**{k:case[k] for k in ('game','level','stage','ai','whole_game','root_input','resume') if k in case},'seed':seed,'workers':workers,'memory_mib':memory}
            for field in ('root_input','resume'):
                if field in request: request[field]=str(request[field]).format(seed=seed)
            if request.get('checkpoint_every') is not None and (type(request['checkpoint_every']) is not int or request['checkpoint_every'] <= 0): raise ValueError('invalid checkpoint_every')
            if type(request.get('checkpoint_on_progress',False)) is not bool: raise ValueError('invalid checkpoint_on_progress')
            for field in ('seed','workers','memory_mib','executions','window','wall_seconds'):
                val=request[field]
                if type(val) is not int or val<0 or (field!='seed' and val==0): raise ValueError('invalid '+field)
            if request.get('frames') is not None and (type(request['frames']) is not int or request['frames'] <= 0): raise ValueError('invalid frames')
            cell=f'{name}-s{seed}-w{workers}-m{memory}'
            jobs.append({'id':cell,'case':case,'request':request})
    if selected and set(selected)-names: raise ValueError('unknown selected case')
    if not jobs: raise ValueError('empty evaluation matrix')
    return jobs


def resolve_assets(job, assets):
    request=job['request'].copy()
    for name in ('core',request['game']):
        item=assets[name]
        actual=digest(item['path'])
        if actual!=item['sha256']: raise ValueError('asset checksum mismatch: '+name)
        if name!='core' and actual!=job['case']['rom_sha256']: raise ValueError('ROM differs from frozen suite: '+name)
        prefix='core' if name=='core' else 'rom'
        request[prefix]=str(Path(item['path']).resolve());request[prefix+'_sha256']=actual
    for field in ('root_input','resume'):
        if request.get(field):
            path=Path(request[field])
            if not path.is_file(): raise ValueError(field.replace('_',' ')+' is missing: '+str(path))
            request[field]=str(path.resolve())
    return request


def host_identity():
    info={'hostname':platform.node(),'system':platform.system(),'release':platform.release(),'machine':platform.machine(),'logical_cpus':os.cpu_count()}
    if Path('/proc/cpuinfo').exists():
        model=next((x.split(':',1)[1].strip() for x in Path('/proc/cpuinfo').read_text().splitlines() if x.startswith('model name')),None)
        info['cpu_model']=model
    return info


def run_one(job,request,args,cpus,build,host):
    root=args.out/job['id'];root.mkdir()
    write_json(root/'request.private.json',request)
    campaign=root/'campaign'
    command=[str(args.binary),str(root/'request.private.json'),str(campaign)]
    if cpus: command=['taskset','-c',','.join(map(str,cpus)),*command]
    started=time.monotonic(); peak_rss=None;peak_disk=peak_allocated=0; last_frames=0;last_time=0.; last_phase=None
    phase_peaks = {}
    timed_out=False;disk_exceeded=False
    with (root/'stdout.log').open('wb') as stdout,(root/'stderr.log').open('wb') as stderr,(root/'resources.jsonl').open('w') as telemetry:
        environment = {**os.environ, 'HARMONY_COORDINATOR_PROFILE': '1'}
        process=subprocess.Popen(command,stdout=stdout,stderr=stderr,start_new_session=True,env=environment)
        metrics=ProcessMetrics(process.pid);tail=Tail(campaign/'progress.jsonl')
        deadline=request['wall_seconds']+args.finish_seconds
        try:
            while True:
                elapsed=time.monotonic()-started
                current=metrics.sample();disk=disk_usage(root);progress=tail.read()
                stage=read_json(campaign/'phase.json',{}).get('phase','preparation')
                frames=progress.get('execution_work',0)
                delta=elapsed-last_time
                sample={'elapsed_seconds':elapsed,'phase':stage,**current,'disk':disk,'executions':progress.get('executions',0),'frames_emulated':frames,'interval_frames_per_second':max(0,frames-last_frames)/delta if delta>0 and stage=='search' and last_phase=='search' else None,'search':{key:value for key,value in progress.items() if value is None or isinstance(value,(str,int,float,bool))}}
                telemetry.write(json.dumps(sample,separators=(',',':'),allow_nan=False)+'\n');telemetry.flush()
                if current['rss_bytes'] is not None:
                    peak_rss=max(peak_rss or 0,current['rss_bytes'])
                    phase_peaks[stage] = max(phase_peaks.get(stage) or 0, current['rss_bytes'])
                else:
                    phase_peaks.setdefault(stage, None)
                peak_disk=max(peak_disk,disk['logical_bytes']);peak_allocated=max(peak_allocated,disk['allocated_bytes'])
                last_frames=frames;last_time=elapsed;last_phase=stage
                pid,status,usage=os.wait4(process.pid,os.WNOHANG)
                if pid:
                    process.returncode=os.waitstatus_to_exitcode(status)
                    break
                if elapsed>deadline or disk['logical_bytes']>args.disk_limit_gib*1024**3:
                    timed_out=elapsed>deadline;disk_exceeded=not timed_out
                    os.killpg(process.pid,signal.SIGKILL)
                    _,status,usage=os.wait4(process.pid,0);process.returncode=os.waitstatus_to_exitcode(status)
                    break
                time.sleep(args.sample_seconds)
        except BaseException:
            if process.returncode is None:
                os.killpg(process.pid,signal.SIGKILL);_,status,usage=os.wait4(process.pid,0);process.returncode=os.waitstatus_to_exitcode(status)
            raise
    result=read_json(campaign/'result.json')
    status='timeout' if timed_out else 'disk_limit' if disk_exceeded else 'complete' if process.returncode==0 and result else 'error'
    if status=='complete' and job['case'].get('require_solved',False) and not result['solved']: status='regression'
    rss_scale=1 if platform.system()=='Darwin' else 1024
    summary={'format':SCHEMA,'suite':args.suite_id,'suite_sha256':args.suite_sha256,'cell':job['id'],'case':job['case']['id'],'origin':job['case']['origin'],'status':status,'exit_code':process.returncode,'host':host,'cpu_set':cpus,'build':build,'search_request':{k:v for k,v in request.items() if k not in {'rom','core'}},'identity':read_json(campaign/'identity.json'),'result':result,'elapsed_seconds':time.monotonic()-started,'peak_process_tree_rss_bytes_sampled':peak_rss,'max_process_rss_bytes':int(usage.ru_maxrss)*rss_scale,'cpu_seconds':usage.ru_utime+usage.ru_stime,'peak_disk_logical_bytes_sampled':peak_disk,'peak_disk_allocated_bytes_sampled':peak_allocated,'final_disk':disk_usage(root),'io_bytes_last_sample':current,'last_progress':tail.read()}
    summary['runner'] = {'coordinator_profile': environment['HARMONY_COORDINATOR_PROFILE'] == '1'}
    summary['rss_by_phase_bytes_sampled'] = phase_peaks
    summary['rusage'] = {'input_block_operations': usage.ru_inblock, 'output_block_operations': usage.ru_oublock,
                         'voluntary_context_switches': usage.ru_nvcsw, 'involuntary_context_switches': usage.ru_nivcsw}
    # The final disk footprint includes this report. Settle its decimal field widths.
    for _ in range(4):
        write_json(root/'summary.json',summary)
        final = disk_usage(root)
        if summary['final_disk'] == final: break
        summary['final_disk'] = final
        summary['peak_disk_logical_bytes_sampled'] = max(peak_disk, final['logical_bytes'])
        summary['peak_disk_allocated_bytes_sampled'] = max(peak_allocated, final['allocated_bytes'])
    print(json.dumps({'cell':job['id'],'status':status,'solved':result['solved'] if result else None,'seconds':round(summary['elapsed_seconds'],2)}),flush=True)
    return summary


def run_matrix(args):
    suite=read_json(args.suite);jobs=expand_suite(suite,args.case)
    args.suite_id=suite['id'];args.suite_sha256=digest(args.suite)
    args.out=args.out.resolve();args.binary=args.binary.resolve()
    if args.out.exists(): raise ValueError('matrix output must be a new directory')
    assets=read_json(args.assets)
    resolved=[(job,resolve_assets(job,assets)) for job in jobs]
    if args.sample_seconds<=0 or args.finish_seconds<=0 or args.jobs<=0 or args.disk_limit_gib<=0 or (args.cpus is not None and args.cpus<=0) or args.overhead_mib<0: raise ValueError('runner limits must be positive')
    cpus=sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else []
    if args.cpus: cpus=cpus[:args.cpus]
    capacity=len(cpus) if cpus else args.cpus or os.cpu_count()
    for job,_ in resolved:
        if job['request']['workers']>capacity or job['request']['memory_mib']+args.overhead_mib>args.memory_capacity_mib: raise ValueError('cell exceeds CPU or memory allocation')
    args.out.mkdir(parents=True)
    supplied_build = read_json(args.build_info) if args.build_info else None
    binary_hash = digest(args.binary)
    if supplied_build and supplied_build.get('binary_sha256', binary_hash) != binary_hash:
        raise ValueError('build identity does not match the executable')
    build={'binary_sha256':binary_hash,'source':supplied_build,'attestation':'supplied' if supplied_build else 'unavailable'}
    host=host_identity();write_json(args.out/'suite.json',suite);write_json(args.out/'matrix.json',{'format':SCHEMA,'build':build,'host':host,'cells':[j['id'] for j,_ in resolved],
        'runner':{'coordinator_profile':True,'jobs':args.jobs,'cpu_capacity':capacity,'memory_capacity_mib':args.memory_capacity_mib,'overhead_mib':args.overhead_mib,'sample_seconds':args.sample_seconds,'disk_limit_gib':args.disk_limit_gib,'finish_seconds':args.finish_seconds}})
    available=cpus.copy();memory=args.memory_capacity_mib;running={};results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
        while resolved or running:
            for job,request in resolved[:]:
                workers=request['workers'];charge=request['memory_mib']+args.overhead_mib
                if len(running)>=args.jobs or charge>memory or (cpus and workers>len(available)):continue
                allocation=available[:workers] if cpus else []
                if cpus: del available[:workers]
                memory-=charge;resolved.remove((job,request))
                future=pool.submit(run_one,job,request,args,allocation,build,host);running[future]=(allocation,charge,job)
            done,_=concurrent.futures.wait(running,return_when=concurrent.futures.FIRST_COMPLETED)
            for future in done:
                allocation,charge,job=running.pop(future);available=sorted(available+allocation);memory+=charge
                try:
                    results.append(future.result())
                except Exception as error:
                    failure = {'format':SCHEMA,'cell':job['id'],'case':job['case']['id'],'origin':job['case']['origin'],
                               'status':'infrastructure_error','error':str(error),'result':None,'identity':None,
                               'search_request':job['request'],'host':host,'build':build,'last_progress':{}}
                    failure_root = args.out/job['id']
                    failure_root.mkdir(exist_ok=True)
                    write_json(failure_root/'summary.json',failure)
                    results.append(failure)
                # Completed cells survive later failures or an interrupted matrix.
                write_json(args.out/'results.json',sorted(results,key=lambda x:x['cell']))
    write_json(args.out/'results.json',sorted(results,key=lambda x:x['cell']))
    return 0 if all(x['status']=='complete' for x in results) else 1


def load_results(matrix, require_complete=True):
    results = read_json(matrix / 'results.json')
    if not isinstance(results, list):
        raise ValueError('matrix has no completed results index')
    ids = [item['cell'] for item in results]
    if any(not valid_id(cell) for cell in ids) or len(ids) != len(set(ids)):
        raise ValueError('invalid or duplicate result cell')
    registered = read_json(matrix / 'matrix.json')['cells']
    if require_complete and set(ids) != set(registered):
        raise ValueError('matrix is incomplete; keep failed cells, do not silently drop them')
    return results


def solve_interval(solved, total):
    """Wilson 95% interval; small panels deliberately produce wide intervals."""
    if not total:
        return None
    z = 1.959963984540054
    p = solved / total
    denominator = 1 + z * z / total
    middle = (p + z * z / (2 * total)) / denominator
    radius = z * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total)) / denominator
    # Wilson's endpoints are exactly 0/1 at the boundary. Floating point
    # cancellation can otherwise put the observed fraction just outside its
    # interval, producing a negative error-bar length in publication plots.
    return [0. if solved == 0 else max(0., middle - radius),
            1. if solved == total else min(1., middle + radius)]


def aggregates(results):
    groups = {}
    for item in results:
        request = item.get('search_request', {})
        key = (item['case'], request.get('workers'), request.get('memory_mib'))
        groups.setdefault(key, []).append(item)
    rows = []
    for key, items in sorted(groups.items(), key=lambda x: str(x[0])):
        valid = [x for x in items if x['status'] in {'complete', 'regression'} and x.get('result')]
        solved = [x for x in valid if x['result']['solved']]
        rates = [x['result'].get('frames_per_second') for x in valid]
        rates = [r for r in rates if isinstance(r, (int, float)) and not isinstance(r, bool) and math.isfinite(r)]
        rows.append({'case': key[0], 'workers': key[1], 'memory_mib': key[2], 'trials': len(items),
                     'valid_trials': len(valid), 'errors': len(items) - len(valid), 'solved': len(solved),
                     'solve_fraction_of_valid': len(solved) / len(valid) if valid else None,
                     'solve_fraction_wilson95': solve_interval(len(solved), len(valid)),
                     'median_frames_to_victory_among_successes': statistics.median([x['result']['frames_to_first_victory'] for x in solved]) if solved else None,
                     'throughput_trials': len(rates),
                     'median_search_frames_per_second': statistics.median(rates) if rates else None})
        known = [named_progress(item) for item in valid if named_progress(item) is not None]
        if known:
            rows[-1]['metroid_milestones'] = {
                name: {
                    'observed': sum(value['first_seen'].get(name) is not None for value in known),
                    'reported_trials': sum(name in value['first_seen'] for value in known),
                    'unavailable_trials': len(valid) - sum(name in value['first_seen'] for value in known),
                    'median_first_execution_among_observed': statistics.median([
                        value['first_seen'][name]['execution'] for value in known
                        if value['first_seen'].get(name) is not None])
                        if any(value['first_seen'].get(name) is not None for value in known) else None,
                } for name in METROID_MILESTONES
            }
    return rows


def compare(base, candidate):
    left = {x['cell']: x for x in load_results(base)}
    right = {x['cell']: x for x in load_results(candidate)}
    left_runner = read_json(base / 'matrix.json').get('runner')
    right_runner = read_json(candidate / 'matrix.json').get('runner')
    if left.keys() != right.keys():
        raise ValueError('different registered cells; comparisons require matching suites')
    rows = []
    for cell in sorted(left):
        a, b = left[cell], right[cell]
        if a['origin'] != b['origin']:
            raise ValueError('origin mismatch: ' + cell)
        roots = [(read_json(matrix / cell / 'summary.json') or item).get('search_request', {}).get('root_input')
                 for matrix, item in ((base, a), (candidate, b))]
        if roots[0] != roots[1]:
            raise ValueError(f'root input changed for {cell}: {roots[0] or "power-on"} versus {roots[1] or "power-on"}')
        if not a.get('identity') or not b.get('identity'):
            rows.append({'cell': cell, 'comparable': False, 'baseline_status': a['status'], 'candidate_status': b['status']})
            continue
        if a['identity']['policies'] != b['identity']['policies']:
            raise ValueError('adapter policy changed: ' + cell)
        if 'actions' in a['search_request'] or 'actions' in b['search_request']:
            raise ValueError('action-capped campaign records cannot be compared: ' + cell)
        for key in ('game', 'level', 'stage', 'ai', 'whole_game', 'seed', 'workers', 'memory_mib', 'window', 'executions', 'frames', 'wall_seconds', 'rom_sha256', 'core_sha256', 'verification'):
            if a['search_request'].get(key) != b['search_request'].get(key):
                raise ValueError('comparison changed ' + key + ': ' + cell)
        row = {'cell': cell, 'comparable': True, 'baseline_status': a['status'], 'candidate_status': b['status'],
               'same_host': a['host'] == b['host'],
               'same_cpu_set': bool(a.get('cpu_set')) and a.get('cpu_set') == b.get('cpu_set'),
               'same_runner_configuration': left_runner is not None and left_runner == right_runner}
        row['timing_environment_matches'] = all(row[key] for key in
            ('same_host', 'same_cpu_set', 'same_runner_configuration'))
        for label, value in [('baseline', a), ('candidate', b)]:
            r = value['result'] or {}
            progress = value.get('last_progress', {})
            row[label] = {'solved': r.get('solved'), 'frames_to_victory': r.get('frames_to_first_victory'),
                          'stream_sha256': r.get('stream_sha256'),
                          'frames': r.get('frames_emulated', progress.get('execution_work')),
                          'search_seconds': r.get('search_seconds'), 'frames_per_second': r.get('frames_per_second'),
                          'peak_rss': value.get('max_process_rss_bytes'), 'peak_disk': value.get('peak_disk_logical_bytes_sampled'),
                          'progress': r.get('progress', progress.get('progress')),
                          'workload_diagnostics': progress.get('workload_diagnostics')}
        hashes = [row[label]['stream_sha256'] for label in ('baseline', 'candidate')]
        row['same_recorded_search'] = hashes[0] == hashes[1] if all(hashes) else None
        rows.append(row)
    return {'format': 'harmony-search-comparison-v1', 'pairs': rows,
            'timing_note': 'Matching recorded allocation does not establish host isolation. Concurrent jobs may share physical cores and finish at different times; use admitted frame cost for search quality and isolated runs for precise throughput claims.',
            'baseline': aggregates(list(left.values())), 'candidate': aggregates(list(right.values()))}


METROID_MILESTONES = {
    'morph_ball': 'Morph Ball', 'bombs': 'Bombs', 'long_beam': 'Long Beam',
    'high_jump': 'High Jump', 'screw_attack': 'Screw Attack', 'varia_suit': 'Varia Suit',
    'wave_beam': 'Wave Beam', 'ice_beam': 'Ice Beam', 'brinstar': 'Brinstar',
    'norfair': 'Norfair', 'kraid_area': "Kraid's area", 'ridley_area': "Ridley's area",
    'kraid_door': "Kraid's door", 'kraid_room': "Kraid's room", 'ridley_room': "Ridley's room",
    'tourian': 'Tourian', 'tourian_corridor': 'Tourian corridor', 'tourian_far': 'Tourian far corridor',
    'tourian_bottom': 'Tourian bottom', 'tourian_approach': 'Tourian approach', 'tourian_end': 'Tourian end',
    'mother_brain_room': "Mother Brain's room", 'kraid_defeated': 'Kraid defeated', 'ridley_defeated': 'Ridley defeated',
    'zebetite_destroyed': 'Zebetite destroyed', 'mother_brain_defeated': 'Mother Brain defeated',
    'escape_started': 'Escape started', 'ending': 'Ending', 'missile_capacity': 'Missile capacity gained',
    'energy_tank': 'Energy tank gained',
}
METROID_COLUMNS = {
    'gear': ['morph_ball', 'bombs', 'long_beam', 'high_jump', 'screw_attack', 'varia_suit', 'wave_beam', 'ice_beam',
             'missile_capacity', 'energy_tank'],
    'areas': ['brinstar', 'norfair', 'kraid_area', 'ridley_area', 'kraid_door', 'kraid_room', 'ridley_room', 'tourian',
              'tourian_corridor', 'tourian_far', 'tourian_bottom', 'tourian_approach', 'tourian_end', 'mother_brain_room'],
    'bosses': ['kraid_defeated', 'ridley_defeated', 'zebetite_destroyed', 'mother_brain_defeated', 'escape_started', 'ending'],
}


def named_progress(item, witness=False):
    result = item.get('result') or {}
    diagnostics = ((result.get('witness') or {}).get('diagnostics') if witness else
                   item.get('last_progress', {}).get('workload_diagnostics')) or {}
    value = diagnostics.get('named_progress') or {}
    return value if value.get('format') in {'metroid-named-progress-v1', 'metroid-named-progress-v2', 'metroid-named-progress-v3'} else None


RESOURCE_HEADERS = '<th>Peak RSS MiB</th><th>Last logical memory MiB</th><th>Peak output disk MiB</th>'


def resource_cells(item, rowspan=1):
    values = (item.get('max_process_rss_bytes'),
              (item.get('last_progress') or {}).get('resident_memory_bytes'),
              item.get('peak_disk_logical_bytes_sampled'))
    return ''.join(f'<td rowspan="{rowspan}">' +
                   ('unavailable' if value is None else f'{value / 1048576:,.1f}') + '</td>'
                   for value in values)


def mechanism(item):
    """Return the recorded search mechanism, without exposing private inputs."""
    request = item.get('search_request', {})
    identity = item.get('identity') or {}
    return {
        'backend': identity.get('backend', 'unavailable'),
        'adapter_policies': identity.get('policies', 'unavailable'),
        'selector': request.get('selector', 'unavailable'),
        'mixture': request.get('mixture', 'unavailable'),
    }


def outcome(item):
    result = item.get('result') or {}
    status = item.get('status', 'unavailable')
    if status not in {'complete', 'regression'}:
        return status
    if result.get('solved'):
        return 'victory within declared frame budget'
    if result.get('victory_observed'):
        return 'victory observed beyond declared frame budget'
    return result.get('stop_reason', 'unsolved')


def replay_confirmation(item):
    result = item.get('result') or {}
    witness = result.get('witness') or {}
    if not witness:
        return 'unavailable'
    count = result.get('witness_replays', 2)
    witness_text = f'bounded witness replay ×{count}'
    if result.get('verification') == 'campaign' or result.get('campaign_replay'):
        return witness_text + ' and full campaign replay confirmed'
    return witness_text + ' confirmed'


def progress_summary(item):
    result = item.get('result') or {}
    progress = result.get('progress')
    if progress is None:
        progress = (item.get('last_progress') or {}).get('progress')
    if progress is None:
        diagnostics = (item.get('last_progress') or {}).get('workload_diagnostics') or {}
        progress = diagnostics.get('named_progress')
    return progress if progress is not None else 'unavailable'


def film_index(matrix):
    """Per-cell media state, so a missing film reads as missing rather than absent.

    A rendered film counts as media only once verify-nes-films.py has accepted
    it, so a report can never advertise media its own check rejected.
    """
    index = read_json(Path(matrix) / 'films.json')
    if not index:
        return {}
    verification = read_json(Path(matrix) / 'film-verification.json')
    verified = set((verification or {}).get('verified', []))
    rejected = (verification or {}).get('problems', {})
    rows = {}
    for row in index.get('films', []):
        if verification is None:
            rows[row['cell']] = {'available': False,
                                 'reason': 'the film was never checked for a real audio stream'}
            continue
        if row['cell'] not in verified:
            rows[row['cell']] = {'available': False, 'reason': 'the media check rejected this film: '
                                 + '; '.join(rejected.get(row['cell'], ['no verdict was recorded']))}
            continue
        rows[row['cell']] = {'available': True, 'mp4': row['cell'] + '/film/witness.mp4',
                             'frames': row['video']['frames'], 'audio_frames': row['video']['audio_frames'],
                             'duration_seconds': row['capture']['duration_seconds'],
                             'mp4_sha256': row['capture']['mp4_sha256'],
                             'endpoint_verified': row['endpoint_verified'], 'clip': row['clip']}
    for row in index.get('unavailable', []):
        rows[row['cell']] = {'available': False, 'reason': row['reason']}
    for row in index.get('failed', []):
        rows[row['cell']] = {'available': False, 'reason': 'rendering failed with exit code ' + str(row['exit_code'])}
    return rows


def roster_row(item, films=None):
    request = item.get('search_request', {})
    result = item.get('result') or {}
    return {
        'cell': item.get('cell'),
        'case': item.get('case'),
        'game': request.get('game', 'unavailable'),
        'origin': item.get('origin', 'unavailable'),
        'mechanism': mechanism(item),
        'seed': request.get('seed'),
        'budgets': {
            'executions': request.get('executions'),
            'frames': request.get('frames'),
            'wall_seconds': request.get('wall_seconds'),
            'workers': request.get('workers'),
            'memory_mib': request.get('memory_mib'),
        },
        'outcome': outcome(item),
        'status': item.get('status', 'unavailable'),
        'solved': result.get('solved'),
        'progress': progress_summary(item),
        'replay': {
            'confirmation': replay_confirmation(item),
            'verification': result.get('verification', request.get('verification', 'unavailable')),
            'witness_replays': result.get('witness_replays'),
            'campaign_replay': result.get('campaign_replay'),
            'witness_snapshot_sha256': (result.get('witness') or {}).get('snapshot_sha256'),
        },
        'resources': {
            'peak_process_tree_rss_bytes_sampled': item.get('peak_process_tree_rss_bytes_sampled'),
            'max_process_rss_bytes': item.get('max_process_rss_bytes'),
            'last_logical_memory_bytes': (item.get('last_progress') or {}).get('resident_memory_bytes'),
            'peak_disk_logical_bytes_sampled': item.get('peak_disk_logical_bytes_sampled'),
            'cpu_seconds': item.get('cpu_seconds'),
        },
        'media': (films or {}).get(item.get('cell'), {'available': False, 'reason': 'no media was rendered for this panel'}),
        'failure': None if item.get('status') == 'complete' else {
            'status': item.get('status', 'unavailable'),
            'exit_code': item.get('exit_code'),
            'error': item.get('error'),
        },
    }


def roster(results, films=None):
    return [roster_row(item, films) for item in sorted(results, key=lambda x: x.get('cell', ''))]


def metroid_html(results):
    items = [item for item in results if item.get('search_request', {}).get('game') == 'metroid']
    if not items:
        return ''
    rows = []
    for item in items:
        progress = named_progress(item)
        witnessed = named_progress(item, witness=True)
        cell = html.escape(item['cell'])
        def names(value, keys):
            if value is None: return 'unavailable (older reporting schema)'
            observed = ', '.join(html.escape(METROID_MILESTONES[key]) for key in keys
                                if value['first_seen'].get(key) is not None) or 'none observed'
            unknown = ', '.join(html.escape(METROID_MILESTONES[key]) for key in keys if key not in value['first_seen'])
            return observed + ('; not recorded: ' + unknown if unknown else '')
        gear, areas, bosses = METROID_COLUMNS['gear'], METROID_COLUMNS['areas'], METROID_COLUMNS['bosses']
        for scope, value in [('Search branches', progress), ('Champion/victory replay', witnessed)]:
            rows.append('<tr>' + ''.join('<td>' + text + '</td>' for text in [
                cell, scope, names(value, gear), names(value, areas), names(value, bosses),
                html.escape(str(value['max_missile_capacity'])) if value else 'unavailable',
                html.escape(str(value['max_energy_tanks'])) if value else 'unavailable'])
                + (resource_cells(item, rowspan=2) if scope == 'Search branches' else '') + '</tr>')
    discoveries = []
    for item in items:
        progress = named_progress(item)
        if progress is None: continue
        proofs = (item.get('result') or {}).get('milestone_witnesses', {})
        cell = html.escape(item['cell'])
        for key, label in METROID_MILESTONES.items():
            stamp = progress['first_seen'].get(key)
            if stamp is None: continue
            link = (f'<a href="{cell}/campaign/milestone-inputs/{key}.json">verified input</a>'
                    if key in proofs else 'origin' if stamp['execution'] == 0 else 'no verified input')
            discoveries.append(f'<li>{cell}: {html.escape(label)} — execution {stamp["execution"]:,}; '
                               f'route action ends at frame {stamp["route_action_end_frame"]:,}; {link}</li>')
    return ('<h2>Metroid milestones</h2><p>Each milestone is an observation, not a prescribed route or reward. '
            'Search rows are unions across branches; replay rows describe one trajectory. Area entry does not imply '
            'boss defeat. Resource columns span both rows and describe the whole benchmark cell, including verification; '
            'logical memory is the last reported archive charge. Capacity includes boss bonuses and is not a count of missile pickups. '
            'Not observed means absent from captured observations up to the recorded stop; unavailable means the schema did not record it.</p>'
            '<div class="scroll"><table><thead><tr><th>Cell</th><th>Scope</th><th>Equipment</th><th>Areas entered</th>'
            '<th>Bosses / ending</th><th>Missile capacity</th><th>Energy tanks</th>' + RESOURCE_HEADERS + '</tr></thead><tbody>'
            + ''.join(rows) + '</tbody></table></div><details><summary>First discoveries and replay evidence</summary>'
            '<p>Execution is admitted search work. Route frame is an action endpoint on the discovered input, '
            'not cumulative emulated work or an exact pickup frame. Inputs are independently replayed twice.</p><ul>'
            + ''.join(discoveries) + '</ul></details>')


def report_html(results, title, films=None):
    def number(value):
        return 'unavailable' if value is None else f'{value:,.1f}' if isinstance(value, float) else f'{value:,}'
    rows = []
    for item in results:
        row = roster_row(item, films)
        cell = html.escape(row['cell'])
        budgets = row['budgets']
        budget_text = ('exec ≤' + number(budgets['executions']) +
                       '; frames ' + number(budgets['frames']) +
                       '; wall ≤' + number(budgets['wall_seconds']) + 's')
        mechanism_text = html.escape(json.dumps(row['mechanism'], sort_keys=True, separators=(',', ':')))
        progress_text = html.escape(json.dumps(row['progress'], sort_keys=True, separators=(',', ':')))
        replay_text = html.escape(row['replay']['confirmation'])
        media = row['media']
        media_text = (f'<a href="{html.escape(media["mp4"])}">film with game audio</a> · '
                      + number(media['duration_seconds']) + 's'
                      + ('' if media['clip']['skipped_frames'] == 0
                         else ' · ' + html.escape(media['clip']['policy']))
                      ) if media.get('available') else html.escape(media.get('reason', 'unavailable'))
        rows.append('<tr>' + ''.join('<td>' + str(x) + '</td>' for x in [
            f'<a href="{cell}/summary.json">{cell}</a>',
            html.escape(row['game']), html.escape(row['origin']), html.escape(str(row['seed'])),
            html.escape(budget_text), mechanism_text, html.escape(row['outcome']), progress_text,
            replay_text, media_text]) + resource_cells(item) + '</tr>')
    panels = ''.join('<li>' + html.escape(json.dumps(row, sort_keys=True)) + '</li>' for row in aggregates(results))
    return '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>''' + html.escape(title) + '''</title><style>body{font:15px/1.55 system-ui;margin:2rem;color:#162132;background:#f7f9fc}table{border-collapse:collapse;background:white;white-space:nowrap}th,td{padding:.55rem;text-align:right;border-bottom:1px solid #dce3ef}th:first-child,td:first-child{text-align:left}a{color:#1356a0}li{margin:.8rem 0;overflow-wrap:anywhere}.scroll{overflow:auto}h1{font-size:1.6rem}</style>
<h1>''' + html.escape(title) + '''</h1><p>Fresh search runs with frozen workload policies. Independent stage and level fixtures are separate from whole-game completion. Missing victories are censored at the recorded budget; failures remain visible.</p>
<p>Each row records the game, origin, seed, search mechanism, execution/frame/wall budgets, progress and outcome, replay confirmation, media, and resource costs. Every film is a native QuickNES replay of the input its own run recorded, carries game audio, and ends at the endpoint that run verified; a clipped film states the policy and keeps the endpoint. Frames include admitted emulator work and replay/probes inside search. Throughput excludes witness verification and external export. Peak RSS is the operating system's process maximum; disk peaks sample the cell output directory. Shared assets/builds and temporary files outside that directory are excluded. See each summary for phase measurements, process-group RSS, logical archive memory, I/O and provenance.</p>
<div class="scroll"><table><thead><tr><th>Cell</th><th>Game</th><th>Origin</th><th>Seed</th><th>Budgets</th><th>Mechanism</th><th>Outcome</th><th>Progress</th><th>Replay</th><th>Media</th>''' + RESOURCE_HEADERS + '</tr></thead><tbody>' + ''.join(rows) + '''</tbody></table></div>
''' + metroid_html(results) + '''<h2>Seed panels</h2><p>Wilson 95% intervals describe uncertainty in solve fractions. Time-to-victory medians include successes only and are not estimates for censored runs. Three-seed pilots are exploratory.</p><ul>''' + panels + '''</ul><p><a href="results.json">Results JSON</a> · <a href="roster.json">Roster JSON</a> · <a href="suite.json">Frozen matrix</a> · <a href="matrix.json">Build and host</a> · <a href="films.json">Media index</a> · <a href="checksums.json">SHA-256 manifest</a></p></html>'''


def film_command(binary, request, campaign, out, max_frames, tail_frames):
    command = [str(binary), '--game', request['game'], '--rom', request['rom'], '--core', request['core'],
               '--rom-sha256', request['rom_sha256'], '--core-sha256', request['core_sha256'],
               '--input', str(campaign / 'witness-input.json'), '--evidence', str(campaign / 'result.json'),
               '--out', str(out), '--max-frames', str(max_frames), '--tail-frames', str(tail_frames)]
    if request.get('level') is not None: command += ['--level', str(request['level'])]
    if request.get('ai') is not None: command += ['--ai', str(request['ai'])]
    if request.get('whole_game'): command.append('--whole-game')
    return command


def film(args):
    """Render every recorded run's own input, and account for the ones with none."""
    if not (args.matrix / 'results.json').is_file():
        write_json(args.matrix / 'films.json', {'format': SCHEMA, 'films': [], 'failed': [],
                                                'unavailable': [{'cell': None, 'case': None, 'status': 'error',
                                                                 'reason': 'the runner produced no matrix index'}]})
        raise ValueError('the runner produced no matrix index; media is unavailable for the whole panel')
    results = load_results(args.matrix)
    films, unavailable, failures = [], [], []
    for item in results:
        cell = item['cell']
        root = args.matrix / cell
        campaign = root / 'campaign'
        request = read_json(root / 'request.private.json')
        reason = None
        if request is None:
            reason = 'the runner recorded no search request'
        elif not (campaign / 'witness-input.json').is_file():
            reason = 'the search produced no renderable input: ' + item['status']
        elif not (campaign / 'result.json').is_file():
            reason = 'the search recorded no result to verify the input against: ' + item['status']
        if reason:
            unavailable.append({'cell': cell, 'case': item['case'], 'status': item['status'], 'reason': reason})
            continue
        out = root / 'film'
        out.mkdir(exist_ok=True)
        command = film_command(args.binary, request, campaign, out, args.max_frames, args.tail_frames)
        with (out / 'render.log').open('wb') as log:
            completed = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
        record = read_json(out / 'film.json')
        if completed.returncode != 0 or record is None:
            failures.append({'cell': cell, 'case': item['case'], 'status': item['status'],
                             'exit_code': completed.returncode,
                             'log': str((out / 'render.log').relative_to(args.matrix))})
            continue
        films.append({'cell': cell, 'case': item['case'], 'origin': item['origin'], **record})
    index = {'format': SCHEMA, 'suite': read_json(args.matrix / 'suite.json')['id'],
             'max_frames': args.max_frames, 'tail_frames': args.tail_frames,
             'films': films, 'unavailable': unavailable, 'failed': failures}
    write_json(args.matrix / 'films.json', index)
    print(json.dumps({'films': len(films), 'unavailable': len(unavailable), 'failed': len(failures)}), flush=True)
    if failures:
        raise ValueError('mandatory media failed for ' + ', '.join(row['cell'] for row in failures))
    if not films and results:
        raise ValueError('no registered cell produced a film; media is unavailable for the whole panel')


def export(matrix, out):
    if out.exists():
        raise ValueError('public export directory must be new')
    results = load_results(matrix)
    sources = []
    # Explicit allowlist. Verify every path before creating a partial public export.
    for item in results:
        for name in ('summary.json', 'resources.jsonl', 'campaign/identity.json', 'campaign/result.json',
                     'campaign/campaign.json', 'campaign/progress.jsonl', 'campaign/witness-input.json',
                     'campaign/victory-input.json', 'film/film.json', 'film/witness.mp4', 'film/render.log'):
            relative = Path(item['cell']) / name
            source = matrix / relative
            if source.resolve() != matrix.resolve() / relative:
                raise ValueError('export refuses symlinks: ' + str(relative))
            if source.is_file():
                sources.append((source, relative))
    for item in results:
        for name in METROID_MILESTONES:
            relative = Path(item['cell']) / 'campaign' / 'milestone-inputs' / (name + '.json')
            source = matrix / relative
            if source.resolve() != matrix.resolve() / relative:
                raise ValueError('export refuses symlinks: ' + str(relative))
            if source.is_file(): sources.append((source, relative))
    for name in ('results.json', 'suite.json', 'matrix.json', 'films.json',
                 'film-verification.json'):
        source = matrix / name
        if source.resolve() != matrix.resolve() / name:
            raise ValueError('export refuses symlinks: ' + name)
        if name in ('films.json', 'film-verification.json') and not source.is_file():
            continue
        sources.append((source, Path(name)))
    out.mkdir(parents=True)
    for source, relative in sources:
        destination = out / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
    films = film_index(matrix)
    (out / 'index.html').write_text(report_html(results, read_json(matrix / 'suite.json')['id'], films))
    write_json(out / 'aggregates.json', aggregates(results))
    write_json(out / 'roster.json', roster(results, films))
    checksums = {str(p.relative_to(out)): digest(p) for p in sorted(out.rglob('*')) if p.is_file()}
    write_json(out / 'checksums.json', checksums)


def build_binary(args):
    """Compile once into an immutable run bundle and attest the exact source tree."""
    root = args.root.resolve()
    if args.out.exists():
        raise ValueError('build output must be a new directory')
    before = source_identity(root)
    args.out.mkdir(parents=True)
    environment = {**os.environ, 'HARMONY_SEARCH_SOURCE_SHA256': before['source_tree_sha256']}
    command = ['cargo', 'build', '--release', '--locked', '--manifest-path', str(root / 'workloads/nes/Cargo.toml'),
               '--bin', 'nes-eval', '--bin', 'nes-film', '--target-dir', str(args.out.resolve() / 'target'), '-j', str(args.jobs)]
    with (args.out / 'build.log').open('wb') as log:
        subprocess.run(command, cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT, check=True)
    after = source_identity(root)
    if before != after:
        raise ValueError('source changed during compilation; discard this build and retry')
    binary = args.out / 'nes-eval'
    shutil.copy2(args.out / 'target/release/nes-eval', binary)
    film_binary = args.out / 'nes-film'
    shutil.copy2(args.out / 'target/release/nes-film', film_binary)
    metadata = {'format': 'harmony-search-build-v1', **before, 'binary_sha256': digest(binary),
                'film_binary_sha256': digest(film_binary),
                'rustc': subprocess.check_output(['rustc', '-Vv'], text=True),
                'cargo': subprocess.check_output(['cargo', '-V'], text=True).strip(),
                'profile': 'release', 'locked': True, 'rustflags': environment.get('RUSTFLAGS', '')}
    write_json(args.out / 'build-info.json', metadata)
    print(json.dumps(metadata), flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__);subs=parser.add_subparsers(dest='command',required=True)
    run=subs.add_parser('run');run.add_argument('suite',type=Path);run.add_argument('--assets',type=Path,required=True);run.add_argument('--binary',type=Path,required=True);run.add_argument('--out',type=Path,required=True);run.add_argument('--build-info',type=Path);run.add_argument('--case',action='append');run.add_argument('--jobs',type=int,default=1);run.add_argument('--cpus',type=int);run.add_argument('--memory-capacity-mib',type=int,default=8192);run.add_argument('--overhead-mib',type=int,default=1024);run.add_argument('--sample-seconds',type=float,default=1);run.add_argument('--finish-seconds',type=int,default=600);run.add_argument('--disk-limit-gib',type=float,default=8)
    cmp=subs.add_parser('compare');cmp.add_argument('baseline',type=Path);cmp.add_argument('candidate',type=Path);cmp.add_argument('--out',type=Path,required=True)
    exp=subs.add_parser('export');exp.add_argument('matrix',type=Path);exp.add_argument('--out',type=Path,required=True)
    reel=subs.add_parser('film');reel.add_argument('matrix',type=Path);reel.add_argument('--binary',type=Path,required=True);reel.add_argument('--max-frames',type=int,default=72000);reel.add_argument('--tail-frames',type=int,default=180)
    build=subs.add_parser('build');build.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2]);build.add_argument('--out',type=Path,required=True);build.add_argument('--jobs',type=int,default=os.cpu_count())
    lad=subs.add_parser('ladder');lad.add_argument('sources',nargs='+');lad.add_argument('--out',type=Path)
    identity=subs.add_parser('source');identity.add_argument('root',type=Path);identity.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    try:
        if args.command=='run':return run_matrix(args)
        if args.command=='build':build_binary(args)
        if args.command=='compare':write_json(args.out,compare(args.baseline,args.candidate))
        if args.command=='export':export(args.matrix,args.out)
        if args.command=='film':film(args)
        if args.command=='source':write_json(args.out,source_identity(args.root))
        if args.command=='ladder':
            import ladder
            ladder.score_sources(args.sources,args.out)
    except (ValueError,KeyError,OSError,subprocess.CalledProcessError) as error:
        parser.exit(2,str(error)+'\n')
    return 0

if __name__=='__main__':raise SystemExit(main())

// SPDX-License-Identifier: AGPL-3.0-or-later

use std::{
    collections::BTreeMap,
    io,
    ptr::NonNull,
    sync::{
        Arc,
        atomic::{AtomicBool, AtomicUsize, Ordering},
    },
};

pub const PAGE: usize = 4096;
pub const SEGMENT_BYTES: usize = 64 << 20;
pub const RELEASES_EXTENTS: bool = cfg!(all(target_os = "linux", not(miri)));

#[cfg(any(test, feature = "in-process"))]
pub(crate) fn checked_mapping_range(
    offset: usize,
    len: usize,
    backing_len: u64,
    page: usize,
) -> io::Result<(usize, usize, usize)> {
    let invalid = || io::Error::new(io::ErrorKind::InvalidInput, "invalid shared mapping range");
    if len == 0 || page == 0 {
        return Err(invalid());
    }
    let end = offset.checked_add(len).ok_or_else(invalid)?;
    if u64::try_from(end).map_err(|_| invalid())? > backing_len {
        return Err(invalid());
    }
    let skip = offset % page;
    let mapped = skip
        .checked_add(len)
        .filter(|len| *len <= isize::MAX as usize)
        .ok_or_else(invalid)?;
    Ok((offset - skip, skip, mapped))
}

#[cfg(all(
    any(test, feature = "in-process"),
    any(target_os = "linux", target_os = "macos")
))]
pub(crate) fn backing_len(fd: std::os::fd::BorrowedFd<'_>) -> io::Result<u64> {
    use std::os::fd::AsRawFd;
    let mut metadata = std::mem::MaybeUninit::<libc::stat>::zeroed();
    // SAFETY: fd remains borrowed and open; fstat only writes the local full-sized stat storage.
    if unsafe { libc::fstat(fd.as_raw_fd(), metadata.as_mut_ptr()) } != 0 {
        return Err(io::Error::last_os_error());
    }
    // SAFETY: successful fstat initialized the fields of the zero-initialized stat storage.
    let metadata = unsafe { metadata.assume_init() };
    u64::try_from(metadata.st_size)
        .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "negative backing length"))
}

struct Mapped(Arc<AtomicUsize>);

impl Mapped {
    fn new(count: &Arc<AtomicUsize>) -> Self {
        count.fetch_add(1, Ordering::Relaxed);
        Self(Arc::clone(count))
    }
}

impl Drop for Mapped {
    fn drop(&mut self) {
        self.0.fetch_sub(1, Ordering::Relaxed);
    }
}

struct Segment {
    base: NonNull<u8>,
    len: usize,
    backing: Backing,
    _mapped: Mapped,
}

// SAFETY: a Segment owns its mapping; every byte range in it is handed to exactly one
// writable extent and, after commit, is only read, so sharing the base pointer across threads
// never creates overlapping mutable access.
unsafe impl Send for Segment {}
// SAFETY: see the Send impl; shared references never read a range that a writer still holds.
unsafe impl Sync for Segment {}

#[cfg(all(any(target_os = "linux", target_os = "macos"), not(miri)))]
type Backing = std::os::fd::OwnedFd;

#[cfg(any(miri, not(any(target_os = "linux", target_os = "macos"))))]
type Backing = std::alloc::Layout;

impl Segment {
    #[cfg(all(any(target_os = "linux", target_os = "macos"), not(miri)))]
    fn new(len: usize, mapped: Mapped) -> io::Result<Self> {
        use std::os::fd::AsRawFd;
        let fd = shared_file(len)?;
        // SAFETY: fd is a live file of exactly len bytes; a fresh shared mapping aliases no Rust
        // object.
        let base = unsafe {
            libc::mmap(
                std::ptr::null_mut(),
                len,
                libc::PROT_READ | libc::PROT_WRITE,
                libc::MAP_SHARED,
                fd.as_raw_fd(),
                0,
            )
        };
        if base == libc::MAP_FAILED {
            return Err(io::Error::last_os_error());
        }
        let base = NonNull::new(base.cast::<u8>()).ok_or_else(io::Error::last_os_error)?;
        Ok(Self {
            base,
            len,
            backing: fd,
            _mapped: mapped,
        })
    }

    #[cfg(any(miri, not(any(target_os = "linux", target_os = "macos"))))]
    fn new(len: usize, mapped: Mapped) -> io::Result<Self> {
        let layout = std::alloc::Layout::from_size_align(len.max(PAGE), PAGE)
            .map_err(|error| io::Error::new(io::ErrorKind::InvalidInput, error))?;
        // SAFETY: layout has a nonzero size.
        let base = unsafe { std::alloc::alloc_zeroed(layout) };
        let base = NonNull::new(base).ok_or_else(|| io::Error::from(io::ErrorKind::OutOfMemory))?;
        Ok(Self {
            base,
            len,
            backing: layout,
            _mapped: mapped,
        })
    }

    #[cfg(all(target_os = "linux", not(miri)))]
    fn release(&self, offset: usize, len: usize) -> bool {
        use std::os::fd::AsRawFd;
        let (Ok(offset), Ok(len)) = (libc::off_t::try_from(offset), libc::off_t::try_from(len))
        else {
            return false;
        };
        // SAFETY: only Retirement::Unique reaches this call, after checking the
        // actual segment identity. Its capability consumes the writer or unwraps
        // the last committed owner, so no parent Rust reference reads the range.
        // export writers retain their ownership until their mappings retire;
        // the KEEP_SIZE flag preserves all other segment addresses and lengths.
        unsafe {
            libc::fallocate(
                self.backing.as_raw_fd(),
                libc::FALLOC_FL_PUNCH_HOLE | libc::FALLOC_FL_KEEP_SIZE,
                offset,
                len,
            ) == 0
        }
    }

    #[cfg(not(all(target_os = "linux", not(miri))))]
    fn release(&self, _: usize, _: usize) -> bool {
        false
    }

    fn range(&self, offset: usize, len: usize) -> *mut u8 {
        assert!(
            offset.checked_add(len).is_some_and(|end| end <= self.len),
            "extent outside its segment"
        );
        // SAFETY: offset + len is within the mapping, so the result stays in bounds.
        unsafe { self.base.as_ptr().add(offset) }
    }
}

impl Drop for Segment {
    #[cfg(all(any(target_os = "linux", target_os = "macos"), not(miri)))]
    fn drop(&mut self) {
        // SAFETY: base and len describe the mapping created in new, and no extent outlives
        // the Arc that owns this Segment.
        unsafe { libc::munmap(self.base.as_ptr().cast(), self.len) };
    }

    #[cfg(any(miri, not(any(target_os = "linux", target_os = "macos"))))]
    fn drop(&mut self) {
        // SAFETY: base was allocated in new with this layout, and no extent outlives the Arc
        // that owns this Segment.
        unsafe { std::alloc::dealloc(self.base.as_ptr(), self.backing) };
    }
}

#[cfg(all(target_os = "linux", not(miri)))]
pub fn raise_descriptor_limit() {
    let mut limit = libc::rlimit {
        rlim_cur: 0,
        rlim_max: 0,
    };
    // SAFETY: getrlimit and setrlimit read and write one plain struct owned by this frame.
    unsafe {
        if libc::getrlimit(libc::RLIMIT_NOFILE, &raw mut limit) == 0
            && limit.rlim_cur < limit.rlim_max
        {
            limit.rlim_cur = limit.rlim_max;
            libc::setrlimit(libc::RLIMIT_NOFILE, &raw const limit);
        }
    }
}

#[cfg(not(all(target_os = "linux", not(miri))))]
pub fn raise_descriptor_limit() {}

#[cfg(all(target_os = "linux", not(miri)))]
#[must_use]
pub fn descriptor_room() -> usize {
    let mut limit = libc::rlimit {
        rlim_cur: 0,
        rlim_max: 0,
    };
    // SAFETY: getrlimit writes one plain struct owned by this frame.
    if unsafe { libc::getrlimit(libc::RLIMIT_NOFILE, &raw mut limit) } != 0 {
        return usize::MAX;
    }
    usize::try_from(limit.rlim_cur / 2).unwrap_or(usize::MAX)
}

#[cfg(not(all(target_os = "linux", not(miri))))]
#[must_use]
pub fn descriptor_room() -> usize {
    usize::MAX
}

#[cfg(all(target_os = "linux", not(miri)))]
fn shared_file(len: usize) -> io::Result<std::os::fd::OwnedFd> {
    use std::os::fd::FromRawFd;
    // SAFETY: the name is a NUL-terminated literal.
    let raw = unsafe { libc::memfd_create(c"harmony-snapshot-cache".as_ptr(), libc::MFD_CLOEXEC) };
    if raw < 0 {
        return Err(io::Error::last_os_error());
    }
    // SAFETY: memfd_create returned a fresh descriptor that nothing else owns.
    let fd = unsafe { std::os::fd::OwnedFd::from_raw_fd(raw) };
    std::fs::File::from(fd.try_clone()?).set_len(len as u64)?;
    Ok(fd)
}

#[cfg(all(target_os = "macos", not(miri)))]
fn shared_file(len: usize) -> io::Result<std::os::fd::OwnedFd> {
    use std::os::fd::FromRawFd;
    use std::sync::atomic::{AtomicU64, Ordering};
    static NEXT: AtomicU64 = AtomicU64::new(0);
    let name = std::ffi::CString::new(format!(
        "/hsc-{}-{}",
        std::process::id(),
        NEXT.fetch_add(1, Ordering::Relaxed)
    ))
    .map_err(|error| io::Error::new(io::ErrorKind::InvalidInput, error))?;
    // SAFETY: name is NUL-terminated; O_EXCL makes this call the only owner of the object.
    let raw = unsafe {
        libc::shm_open(
            name.as_ptr(),
            libc::O_CREAT | libc::O_EXCL | libc::O_RDWR,
            0o600,
        )
    };
    if raw < 0 {
        return Err(io::Error::last_os_error());
    }
    // SAFETY: shm_open returned a fresh descriptor that nothing else owns.
    let fd = unsafe { std::os::fd::OwnedFd::from_raw_fd(raw) };
    // SAFETY: name is NUL-terminated; the open descriptor keeps the object alive.
    unsafe { libc::shm_unlink(name.as_ptr()) };
    std::fs::File::from(fd.try_clone()?).set_len(len as u64)?;
    Ok(fd)
}

pub(super) type Abandon = Box<dyn FnOnce(Reclamation) + Send>;

#[cfg(all(any(target_os = "linux", target_os = "macos"), not(miri)))]
#[derive(Clone, Copy, Debug)]
pub(crate) struct SharedRange<'a> {
    pub fd: std::os::fd::BorrowedFd<'a>,
    pub offset: usize,
    pub len: usize,
}

#[cfg(all(any(target_os = "linux", target_os = "macos"), not(miri)))]
impl Segment {
    fn shared(&self, offset: usize, len: usize) -> SharedRange<'_> {
        use std::os::fd::AsFd;
        SharedRange {
            fd: self.backing.as_fd(),
            offset,
            len,
        }
    }
}

struct Extent {
    segment: Arc<Segment>,
    segment_id: u64,
    offset: usize,
    len: usize,
    retired: AtomicBool,
}

pub(super) struct Reclamation(Extent);

enum Retirement {
    Unique(Reclamation),
    Shared(Arc<Extent>),
}

impl Retirement {
    fn extent(&self) -> &Extent {
        match self {
            Self::Unique(reclamation) => &reclamation.0,
            Self::Shared(extent) => extent,
        }
    }

    fn release(&self) -> bool {
        match self {
            Self::Unique(Reclamation(extent)) => extent.segment.release(extent.offset, extent.len),
            Self::Shared(_) => false,
        }
    }
}

pub struct WritableExtent {
    extent: Option<Extent>,
    abandon: Option<Abandon>,
}

impl std::fmt::Debug for WritableExtent {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let extent = self.extent();
        formatter
            .debug_struct("WritableExtent")
            .field("segment_id", &extent.segment_id)
            .field("offset", &extent.offset)
            .field("len", &extent.len)
            .finish_non_exhaustive()
    }
}

impl WritableExtent {
    fn extent(&self) -> &Extent {
        self.extent.as_ref().expect("live writable extent")
    }

    #[must_use]
    pub fn len(&self) -> usize {
        self.extent().len
    }

    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    pub fn bytes_mut(&mut self) -> &mut [u8] {
        let extent = self.extent();
        let start = extent.segment.range(extent.offset, extent.len);
        // SAFETY: this non-Clone extent uniquely owns the range. Committing or
        // reclaiming consumes that ownership and cannot coexist with this borrow.
        unsafe { std::slice::from_raw_parts_mut(start, extent.len) }
    }

    fn into_reclamation(mut self) -> Reclamation {
        self.abandon = None;
        Reclamation(self.extent.take().expect("live writable extent"))
    }

    pub(crate) fn commit(self) -> CommittedExtent {
        let Reclamation(extent) = self.into_reclamation();
        CommittedExtent {
            extent: Arc::new(extent),
        }
    }

    pub(super) fn set_abandon(&mut self, abandon: Abandon) {
        self.abandon = Some(abandon);
    }

    #[cfg(all(any(target_os = "linux", target_os = "macos"), not(miri)))]
    pub(crate) fn shared_range(&self) -> SharedRange<'_> {
        let extent = self.extent();
        extent.segment.shared(extent.offset, extent.len)
    }
}

impl Drop for WritableExtent {
    fn drop(&mut self) {
        if let Some(abandon) = self.abandon.take() {
            abandon(Reclamation(
                self.extent.take().expect("live writable extent"),
            ));
        }
    }
}

#[cfg(any(all(feature = "in-process", not(miri)), test))]
#[derive(Debug)]
pub(crate) struct BackingWitness(std::sync::Weak<Segment>);

#[cfg(any(all(feature = "in-process", not(miri)), test))]
impl BackingWitness {
    pub(crate) fn same_backing(&self, other: &Self) -> bool {
        std::sync::Weak::ptr_eq(&self.0, &other.0)
    }
}

#[derive(Clone)]
pub struct CommittedExtent {
    extent: Arc<Extent>,
}

impl std::fmt::Debug for CommittedExtent {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("CommittedExtent")
            .field("segment_id", &self.extent.segment_id)
            .field("offset", &self.extent.offset)
            .field("len", &self.extent.len)
            .finish_non_exhaustive()
    }
}

impl CommittedExtent {
    #[cfg(any(all(feature = "in-process", not(miri)), test))]
    pub(crate) fn backing_witness(&self) -> BackingWitness {
        BackingWitness(Arc::downgrade(&self.extent.segment))
    }

    #[must_use]
    pub fn bytes(&self) -> &[u8] {
        let extent = &self.extent;
        let start = extent.segment.range(extent.offset, extent.len);
        // SAFETY: commit consumed the unique writer. A reclamation capability
        // requires unwrapping the last owning Arc, so no reader can coexist with it.
        unsafe { std::slice::from_raw_parts(start, extent.len) }
    }

    pub(crate) fn span(&self) -> (u64, usize, usize) {
        (self.extent.segment_id, self.extent.offset, self.extent.len)
    }

    #[cfg(all(any(target_os = "linux", target_os = "macos"), not(miri)))]
    pub(crate) fn shared_range(&self) -> SharedRange<'_> {
        let extent = &self.extent;
        extent.segment.shared(extent.offset, extent.len)
    }

    #[cfg(test)]
    pub(crate) fn offset(&self) -> usize {
        self.extent.offset
    }
}

struct SegmentUse {
    segment: Arc<Segment>,
    used: usize,
    released: usize,
    extents: usize,
}

pub struct PageSegments {
    segment_bytes: usize,
    limit: usize,
    mapped: Arc<AtomicUsize>,
    open: Option<u64>,
    segments: BTreeMap<u64, SegmentUse>,
    next_id: u64,
    charged: usize,
}

impl std::fmt::Debug for PageSegments {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("PageSegments")
            .field("segment_bytes", &self.segment_bytes)
            .field("limit", &self.limit)
            .field("open", &self.open)
            .field("segments", &self.segments.len())
            .field("charged", &self.charged)
            .finish_non_exhaustive()
    }
}

#[must_use]
pub fn rounded(len: usize) -> Option<usize> {
    len.checked_next_multiple_of(PAGE)
}

impl PageSegments {
    #[must_use]
    pub fn new(segment_bytes: usize, limit: usize) -> Self {
        Self {
            segment_bytes: segment_bytes.max(PAGE),
            limit: limit.max(1),
            mapped: Arc::new(AtomicUsize::new(0)),
            open: None,
            segments: BTreeMap::new(),
            next_id: 0,
            charged: 0,
        }
    }

    #[must_use]
    pub fn charged(&self) -> usize {
        self.charged
    }

    #[must_use]
    pub fn segments(&self) -> usize {
        self.segments.len()
    }

    fn fits(&self, len: usize) -> Option<u64> {
        self.open.filter(|id| {
            self.segments
                .get(id)
                .is_some_and(|used| used.segment.len - used.used >= len)
        })
    }

    #[must_use]
    pub fn full(&self, len: usize) -> bool {
        self.mapped.load(Ordering::Relaxed) >= self.limit && self.fits(len).is_none()
    }

    pub fn allocate(&mut self, len: usize) -> io::Result<WritableExtent> {
        let len = rounded(len.max(1))
            .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "extent size overflow"))?;
        let id = match self.fits(len) {
            Some(id) => id,
            None => {
                if let Some(previous) = self.open.take() {
                    self.retire_if_empty(previous);
                }
                let segment = Arc::new(Segment::new(
                    self.segment_bytes.max(len),
                    Mapped::new(&self.mapped),
                )?);
                let id = self.next_id;
                self.next_id += 1;
                self.segments.insert(
                    id,
                    SegmentUse {
                        segment,
                        used: 0,
                        released: 0,
                        extents: 0,
                    },
                );
                self.open = Some(id);
                id
            }
        };
        let used = self.segments.get_mut(&id).expect("open segment");
        let offset = used.used;
        used.used += len;
        used.extents += 1;
        self.charged += len;
        Ok(WritableExtent {
            extent: Some(Extent {
                segment: Arc::clone(&used.segment),
                segment_id: id,
                offset,
                len,
                retired: AtomicBool::new(false),
            }),
            abandon: None,
        })
    }

    pub(crate) fn owns(&self, extent: &WritableExtent) -> bool {
        self.owns_extent(extent.extent())
    }

    fn owns_extent(&self, extent: &Extent) -> bool {
        self.segments
            .get(&extent.segment_id)
            .is_some_and(|used| Arc::ptr_eq(&used.segment, &extent.segment))
    }

    pub fn free(&mut self, extent: WritableExtent) {
        if self.owns(&extent) {
            self.reclaim(extent.into_reclamation());
        }
    }

    pub fn free_committed(&mut self, extent: CommittedExtent) {
        if !self.owns_extent(&extent.extent) {
            return;
        }
        let retirement = match Arc::try_unwrap(extent.extent) {
            Ok(extent) => Retirement::Unique(Reclamation(extent)),
            Err(extent) => Retirement::Shared(extent),
        };
        self.remove(retirement);
    }

    pub(super) fn reclaim(&mut self, reclamation: Reclamation) {
        self.remove(Retirement::Unique(reclamation));
    }

    fn remove(&mut self, retirement: Retirement) {
        let extent = retirement.extent();
        let segment_id = extent.segment_id;
        let len = extent.len;
        let Some(used) = self.segments.get_mut(&segment_id) else {
            return;
        };
        if !Arc::ptr_eq(&used.segment, &extent.segment)
            || extent.retired.swap(true, Ordering::Relaxed)
        {
            return;
        }
        used.extents -= 1;
        if used.extents > 0 && retirement.release() {
            used.released += len;
            self.charged -= len;
        }
        if used.extents == 0 && self.open == Some(segment_id) {
            self.open = None;
        }
        self.retire_if_empty(segment_id);
    }

    fn retire_if_empty(&mut self, segment_id: u64) {
        if self
            .segments
            .get(&segment_id)
            .is_some_and(|used| used.extents == 0)
            && let Some(used) = self.segments.remove(&segment_id)
        {
            self.charged -= used.used - used.released;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[cfg(any(target_os = "linux", target_os = "macos"))]
    #[test]
    #[cfg_attr(miri, ignore = "requires host filesystem access; run separately in CI")]
    fn backing_length_borrows_the_descriptor_without_closing_it() {
        use std::os::fd::AsFd;
        let file = tempfile::NamedTempFile::new().unwrap();
        file.as_file().set_len(4096).unwrap();
        assert_eq!(backing_len(file.as_file().as_fd()).unwrap(), 4096);
        file.as_file().set_len(17).unwrap();
        assert_eq!(backing_len(file.as_file().as_fd()).unwrap(), 17);
    }

    #[test]
    fn mapping_range_validation_checks_backing_bounds_and_slice_lengths() {
        assert_eq!(
            checked_mapping_range(4097, 4096, 8193, 4096).unwrap(),
            (4096, 1, 4097)
        );
        for (offset, len, backing, page) in [
            (0, 0, 4096, 4096),
            (0, 1, 1, 0),
            (4096, 2, 4097, 4096),
            (usize::MAX, 1, u64::MAX, 4096),
            (0, usize::MAX, u64::MAX, 4096),
            (1, isize::MAX as usize, u64::MAX, 4096),
        ] {
            assert!(checked_mapping_range(offset, len, backing, page).is_err());
        }
    }

    #[test]
    fn extents_are_page_aligned_disjoint_and_charged() {
        let mut segments = PageSegments::new(4 * PAGE, usize::MAX);
        let mut a = segments.allocate(10).unwrap();
        let mut b = segments.allocate(PAGE + 1).unwrap();
        assert_eq!((a.len(), b.len()), (PAGE, 2 * PAGE));
        assert_eq!(segments.charged(), 3 * PAGE);
        a.bytes_mut().fill(1);
        b.bytes_mut().fill(2);
        let a = a.commit();
        let b = b.commit();
        assert!(a.bytes().iter().all(|&byte| byte == 1));
        assert!(b.bytes().iter().all(|&byte| byte == 2));
        assert_eq!((a.offset(), b.offset()), (0, PAGE));
        assert_eq!(a.span().0, b.span().0);
    }

    #[test]
    fn a_segment_is_released_when_its_last_extent_dies_after_it_closes() {
        let dead = if RELEASES_EXTENTS { 0 } else { PAGE };
        let mut segments = PageSegments::new(2 * PAGE, usize::MAX);
        let a = segments.allocate(PAGE).unwrap().commit();
        let b = segments.allocate(PAGE).unwrap().commit();
        segments.free_committed(a);
        assert_eq!(segments.charged(), PAGE + dead, "the open segment stays");
        let c = segments.allocate(PAGE).unwrap().commit();
        assert_ne!(c.span().0, b.span().0);
        assert_eq!(segments.segments(), 2);
        assert_eq!(
            segments.charged(),
            2 * PAGE + dead,
            "a dead extent is charged until its pages are released"
        );
        let reader = b.clone();
        segments.free_committed(b);
        assert_eq!(segments.segments(), 1);
        assert_eq!(segments.charged(), PAGE);
        assert!(
            reader.bytes().iter().all(|&byte| byte == 0),
            "readers keep the mapping"
        );
    }

    #[test]
    fn a_freed_extent_keeps_its_bytes_while_a_copy_reads_them() {
        let mut segments = PageSegments::new(2 * PAGE, usize::MAX);
        let mut a = segments.allocate(PAGE).unwrap();
        a.bytes_mut().fill(1);
        let a = a.commit();
        let _b = segments.allocate(PAGE).unwrap().commit();
        let reader = a.clone();
        let live = reader.bytes();
        segments.free_committed(a);
        assert_eq!(
            segments.charged(),
            2 * PAGE,
            "a copied extent stays charged"
        );
        assert!(live.iter().all(|&byte| byte == 1));
    }

    #[test]
    fn owned_reclamation_preserves_neighboring_live_views() {
        let mut segments = PageSegments::new(3 * PAGE, usize::MAX);
        let mut first = segments.allocate(PAGE).unwrap();
        let mut second = segments.allocate(PAGE).unwrap();
        let mut third = segments.allocate(PAGE).unwrap();
        first.bytes_mut().fill(0x5a);
        second.bytes_mut().fill(0x6b);
        third.bytes_mut().fill(0x7c);
        let third = third.commit();
        let first_view = first.bytes_mut();
        let third_view = third.bytes();
        segments.free(second);
        assert!(first_view.iter().all(|&byte| byte == 0x5a));
        assert!(third_view.iter().all(|&byte| byte == 0x7c));
        assert_eq!(
            segments.charged(),
            if RELEASES_EXTENTS { 2 * PAGE } else { 3 * PAGE }
        );
        segments.free(first);
        assert!(third_view.iter().all(|&byte| byte == 0x7c));
        segments.free_committed(third);
        assert_eq!((segments.charged(), segments.segments()), (0, 0));
    }

    #[test]
    fn foreign_committed_extent_cannot_reclaim_a_live_writable_view() {
        let mut owner = PageSegments::new(2 * PAGE, usize::MAX);
        let foreign = owner.allocate(PAGE).unwrap().commit();
        let mut victim = PageSegments::new(2 * PAGE, usize::MAX);
        let mut first = victim.allocate(PAGE).unwrap();
        let mut second = victim.allocate(PAGE).unwrap();
        first.bytes_mut().fill(0x5a);
        second.bytes_mut().fill(0x7c);
        let first_view = first.bytes_mut();
        let second_view = second.bytes_mut();
        victim.free_committed(foreign);
        assert!(first_view.iter().all(|&byte| byte == 0x5a));
        assert!(second_view.iter().all(|&byte| byte == 0x7c));
        assert_eq!(victim.charged(), 2 * PAGE);
        victim.free(second);
        assert!(first_view.iter().all(|&byte| byte == 0x5a));
        assert_eq!(victim.segments(), 1);
        assert_eq!(
            victim.charged(),
            if RELEASES_EXTENTS { PAGE } else { 2 * PAGE }
        );
        victim.free(first);
        assert_eq!((victim.charged(), victim.segments()), (0, 0));
        assert_eq!((owner.charged(), owner.segments()), (PAGE, 1));
    }

    #[test]
    fn foreign_writable_extent_and_abandonment_capability_cannot_reclaim_local_bytes() {
        let mut owner = PageSegments::new(2 * PAGE, usize::MAX);
        let foreign = owner.allocate(PAGE).unwrap();
        let foreign_capability = owner.allocate(PAGE).unwrap().into_reclamation();
        let mut victim = PageSegments::new(2 * PAGE, usize::MAX);
        let mut first = victim.allocate(PAGE).unwrap();
        let second = victim.allocate(PAGE).unwrap();
        first.bytes_mut().fill(0x5a);
        let live = first.bytes_mut();
        victim.free(foreign);
        victim.reclaim(foreign_capability);
        assert!(live.iter().all(|&byte| byte == 0x5a));
        assert_eq!(victim.charged(), 2 * PAGE);
        victim.free(second);
        assert!(live.iter().all(|&byte| byte == 0x5a));
        assert_eq!(victim.segments(), 1);
        victim.free(first);
        assert_eq!((victim.charged(), victim.segments()), (0, 0));
    }

    #[test]
    fn freeing_multiple_committed_copies_retires_the_allocation_only_once() {
        let mut segments = PageSegments::new(3 * PAGE, usize::MAX);
        let first = segments.allocate(PAGE).unwrap().commit();
        let second = segments.allocate(PAGE).unwrap().commit();
        let mut third = segments.allocate(PAGE).unwrap();
        third.bytes_mut().fill(0x5a);
        let third = third.commit();
        let live = third.bytes();
        segments.free_committed(first.clone());
        segments.free_committed(first);
        assert_eq!(segments.charged(), 3 * PAGE);
        segments.free_committed(second);
        assert!(live.iter().all(|&byte| byte == 0x5a));
        assert_eq!(segments.segments(), 1);
        assert_eq!(
            segments.charged(),
            if RELEASES_EXTENTS { 2 * PAGE } else { 3 * PAGE }
        );
        segments.free_committed(third);
        assert_eq!((segments.charged(), segments.segments()), (0, 0));
    }

    #[test]
    fn a_segment_limit_counts_every_mapped_segment() {
        let mut segments = PageSegments::new(2 * PAGE, 1);
        let a = segments.allocate(PAGE).unwrap().commit();
        assert!(!segments.full(PAGE));
        let b = segments.allocate(PAGE).unwrap().commit();
        assert!(segments.full(PAGE));
        let reader = a.clone();
        segments.free_committed(a);
        segments.free_committed(b);
        assert_eq!(segments.segments(), 0);
        assert!(segments.full(PAGE), "a reader keeps its segment mapped");
        drop(reader);
        assert!(!segments.full(PAGE));
    }

    #[test]
    fn a_large_extent_gets_its_own_segment() {
        let mut segments = PageSegments::new(2 * PAGE, usize::MAX);
        let _small = segments.allocate(PAGE).unwrap();
        let large = segments.allocate(5 * PAGE).unwrap();
        assert_eq!(large.len(), 5 * PAGE);
        assert_eq!(segments.segments(), 2);
    }

    #[test]
    fn an_abandoned_extent_runs_its_callback() {
        let mut segments = PageSegments::new(2 * PAGE, usize::MAX);
        let (sender, receiver) = std::sync::mpsc::channel();
        let mut extent = segments.allocate(PAGE).unwrap();
        extent.set_abandon(Box::new(move |Reclamation(extent)| {
            sender
                .send((extent.segment_id, extent.offset, extent.len))
                .unwrap();
        }));
        let id = extent.extent().segment_id;
        drop(extent);
        assert_eq!(receiver.try_recv().unwrap(), (id, 0, PAGE));
    }
}

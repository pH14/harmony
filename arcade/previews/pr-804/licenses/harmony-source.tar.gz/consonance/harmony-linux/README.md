<!-- SPDX-License-Identifier: AGPL-3.0-or-later -->

# harmony-linux

`harmony-linux` contains the guest-side environment for consonance: pinned
Linux sources and image builders, the `/dev/harmony` integration, guest agents,
and the no-std SDK used by those agents. Instruction audit tables and scanners
live in `scripts/`.

## Entry points

```sh
make -C consonance/harmony-linux fetch
make -C consonance/harmony-linux test-libvoidstar
make -C consonance/harmony-linux test-linux
make -C consonance/harmony-linux test
```

`fetch` downloads and verifies the pinned platform kernel, generic userland,
and static OCI runtime sources. Workload packages own their separate fetch
entrypoints.
`test-libvoidstar` runs the portable ABI and device-transaction checks.
`test-linux` builds the Linux artifacts twice and runs the image check; it
requires Linux, or a Linux/amd64 build container on macOS. Build output lives
in `consonance/harmony-linux/build/`; `GUEST_BUILD_ROOT` can select another
build root.

The root `flake.nix` provides separate locked platform and workload image
entrypoints on native Linux:

```sh
nix run .#platform-guest-images -- --output "$PWD/platform-output"
nix run .#workload-guest-images -- --output "$PWD/workload-output"
```

On Linux/x86_64 the platform builder produces the standard platform kernel and
direct fixture initramfs, plus the canonical OCI runtime artifacts when their
runtime inputs are supplied. Native Linux/aarch64 produces the corresponding
`aarch64` directory. The workload builder owns application image recipes and
application source inputs; those inputs are outside the platform closure. The
existing `.#guest-images` app remains an alias for the platform builder while
callers migrate to the explicit names. `nix run .#uml-images -- --output DIR`
builds the User-mode Linux profile described in `uml/README.md`.

The pinned BusyBox source is also available as a standalone flake package for
reproducible image preparation and CI reuse:

```sh
nix build .#busybox-source --no-link --print-out-paths
```

The resulting store path is the hash-verified `busybox-1.38.0.tar.bz2` source
from the same pin used by the guest image builder. Workload acceptance fetches
that archive from Buildroot's mirror, with the Nix package as a fallback, and
checks the same lock-file SHA-256 before building. An upstream download outage
therefore does not change the accepted source bytes.

## Components

- `linux/` builds the pinned kernels, direct platform fixtures, and the
  workload-free OCI runtime. Kernel patches provide the guest device,
  paravirtual clock, observation, and task-park interfaces; build scripts
  verify source and artifact hashes.
- `uml/` builds the User-mode Linux profile: the pinned kernel as a static
  host executable, a fixture initramfs, and the profile that hashes them. It
  applies `linux/patches/common` and `linux/patches/um`.
- `libvoidstar/` implements the SDK-facing dynamic ABI and communicates with
  `/dev/harmony`.
- `sdk/` provides the no-std event, state, assertion, lifecycle, and entropy
  hooks used by guest payloads.
- Workload packages under `workloads/` build their own images and fetch their
  own application inputs after the platform artifacts are prepared.

The guest transport is synchronous and serialized by the kernel driver. Guest
entropy comes from the host-provided seeded service; the compatibility library
does not provide a host-randomness fallback.

Workload image recipes that use GNU cpio require version 2.14 or newer so
`--reproducible` normalizes inode, device, and directory-link metadata before
an image hash is recorded.

Cold Nix guest builds fetch the pinned BusyBox archive from the Buildroot mirror
with the upstream URL as fallback. Both locations use the same locked SHA-256;
the mirror choice leaves the guest source version and bytes unchanged.

The x86 Nix OCI producer packs the minimal Linux fixture with the same reviewed
BusyBox binary as the OCI platform. Its fixed init only mounts proc/sysfs,
prints readiness and powers off; the archive contains no libvoidstar or dynamic
dependencies. `build-initramfs.sh --busybox FILE` selects that binary explicitly;
the standalone builder still builds its own BusyBox.

Failed N6 builds from the locked platform builder preserve the rejected guest
binaries, generated assembly/header and entropy-audit logs under
`OUTPUT/diagnostics/n6` before deleting the temporary build workspace. The
`guest-images` flake alias uses this platform builder. Retained diagnostics do
not turn a failed build into a qualified guest bundle; its exit status remains
nonzero and the strict executable-byte entropy audit still applies.

The standalone N6 producer builds the pinned musl runtime for its native
architecture by default, matching the other platform fixtures. This avoids
host-libc changes importing unused stdio machinery or opcode-shaped call
operands into the audited executable. `HARMONY_N6_CC` selects an explicit
compiler; every resulting executable still passes the same full-byte audit.

## x86 XSAVE behavior

The guest kernel canonicalizes complete XSAVE buffers while keeping AVX. The
x86 configuration uses `noxsaveopt noxsaves`; save/canonicalize sequences exclude
local interrupt handlers. Identity comparisons belong at completed
guest-initiated exits, not at diagnostic breakpoint stops inside those sequences.
The kernel configuration excludes unsupported LBR/AMX save paths and kexec.
The CLI, client defaults and workload adapters supply
`noxsaveopt noxsaves LD_BIND_NOW=1`; the OCI runtime also preserves eager binding
through supervisor startup, workload startup and runc re-execution.

The general fpstate and user signal-frame paths have distinct layouts and fault
handling. Successful paths overwrite raw bitmap register aliases and owned
stack storage before restoring interrupts. A conditional signal checked-access
failure can retain the raw bitmap in EDX. The x86 execution contract
excludes that post-success failure: successful mask-7 plain XSAVE has already
written both possible buffer pages, with one vCPU, disabled local IRQs, fixed
mappings, no PKU and healthy memory. Initial XSAVE faults precede the bitmap
read and do not establish coverage of this later conditional failure. External
NMI/MCE injection and arbitrary imported pending events are outside this
contract; the generic backend can represent them.

Outside the patched kernel, workloads must not execute FXSAVE/XSAVE-family saves or
XGETBV with ECX=1. XGETBV with a proven zero selector remains allowed. Static
linking alone does not exclude libc save routines; glibc's resolver trampolines
hold FXSAVE/XSAVE instructions but never run, because every image boots with
`LD_BIND_NOW=1` and the scanner rejects TLSdesc relocations. Generated code,
JITs, code mutation and writable executable memory are excluded by policy. These
restrictions do not qualify arbitrary images, SQL, ROMs or imported machine
states.

Production Faults preparation enforces the same static x86 save/selector rules
from packed ELF bytes for VM and UML execution, using typed iced-x86 decoding.
The complete loader shapes and unique nonoverlapping XGETBV selector-zero proof
remain the only static exceptions; TLSdesc and text relocations are refused.
A Linux conformance fixture sends the same retained compiled ELF bytes through
production preparation and this Python checker, including permitted restore
operations and standard math. This alignment does not enforce executable
provenance after loading or after memory perturbations.
A retained development-host KVM execution confirmed that an admitted program
can decode FXSAVE into writable memory, switch it to executable memory and run
it. This establishes a runtime instruction-domain escape, not replay divergence;
static admission and ordinary logical-state identity do not prove closure.

Raw XSAVE presence remains in restore data. Snapshot identity uses the core
layer's [logical identity](../vmm-core/README.md#published-xsave-identity-check),
which excludes only validated init x87/SSE presence metadata.
Matching finite executions does not establish general continuation equivalence.
Outstanding XSAVE and PAE behavior is tracked in
[#307](https://github.com/pH14/harmony/issues/307) and
[#314](https://github.com/pH14/harmony/issues/314).

## x86 userspace admission

Run the scanner on complete rootfs trees, including shared libraries and possible
`dlopen` inputs, with GNU objdump available:

```sh
python3 consonance/harmony-linux/scripts/x86-xstate-admission.py inventory ROOTFS --output candidate.json
python3 consonance/harmony-linux/scripts/x86-xstate-admission.py verify ROOTFS --output result.json
python3 consonance/harmony-linux/scripts/x86-xstate-admission.py inventory-initramfs INITRAMFS --output candidate.json
python3 consonance/harmony-linux/scripts/x86-xstate-admission.py verify-initramfs INITRAMFS --output result.json
python3 consonance/harmony-linux/scripts/x86-xstate-admission.py verify ROOTFS --execution-mode uml --output uml-result.json
```

`--objdump` selects the disassembler. Inventory discovers every ELF by file
contents regardless of executable permissions and records file digests, metadata,
symlink targets and every FXSAVE/XSAVE-family instruction site. Verify checks the
executable properties listed below on that same inventory. It compares nothing
against a stored digest, so rebuilding an image does not require a new approval.
Verification records its execution mode. The default is `vm`; all current
prepared-composition and virtual-time callers explicitly select that KVM mode.
UML checks must select `--execution-mode uml`, which refuses native transaction
entry through `XBEGIN` or a valid `XACQUIRE` prefix. Inventory also records the
related non-entry transactional controls. GNU objdump's `xbeginw` spelling is
normalized to `xbegin`; ordinary F2/F3 prefixes are not treated as transactions.
The Rust application preparation path independently applies the same UML rule
to the exact archived image without requiring instrumentation. Standalone
`XEND`, `XABORT`, `XTEST`, `XRELEASE` and TSX load-tracking controls do not enter
transactions and are admitted. Native math and standard libraries retain their
existing admission and advisory CPU-portability policy.
Actual launch configuration, kernel, ordered archive composition, ROM and SQL
inputs are additionally checked by the workload composition checker under
`workloads/guest-images/`.

Dependency analysis resolves symlinks inside the guest root and checks the
complete transitive ELF closure. The supported dynamic interpreter is
`/lib64/ld-linux-x86-64.so.2`, with default directories
`/lib/x86_64-linux-gnu`, `/usr/lib/x86_64-linux-gnu`, `/lib` and `/usr/lib`.
Missing dependencies, differing duplicate SONAMEs and ambiguous resolutions
fail closed. Other interpreters, loader caches, RPATH/RUNPATH and glibc-hwcaps
search are unsupported. Launch environment overrides are outside the contract.

The scanner covers the complete page-rounded executable mapping, including file
bytes before and after each declared load. It preserves the load, ELF entry,
allocated-section edges and function-symbol entries as decode anchors, follows
direct branches into operand bytes and other executable mappings of the same
ELF, and checks instructions crossing section or adjacent-load boundaries.
Overlapping executable mappings and data-page aliases are refused. The shared
coverage pass supplies both state-save and native-arithmetic policy checks.
Direct transfers outside the ELF and indirect entries still require control-flow
review of the full immutable dependency closure; scanning alone does not prove
those transfers safe.

Executable mappings are scanned for FXSAVE/XSAVE-family instructions and XGETBV;
restore instructions are inventoried separately. Verification rejects W+X
PT_LOAD segments, executable PT_GNU_STACK, DT_TEXTREL/DF_TEXTREL images and
TLSdesc relocations anywhere in the closure. Every XGETBV site must have a
recognized ECX-zero sequence within 32 unique fallthrough predecessors. The
recognizer follows full-width GPR copies and respects partial-register aliases
and CPUID clobbers. Ordinary conditional branches may leave the proved path;
no observed branch may enter it. LOOP-family instructions, calls and unknown
operations stop the proof. Selector and loader-trampoline proofs require unique decoded
predecessors and refuse any instruction overlapping another decode stream.
Address sorting alone cannot establish that a zeroing instruction dominates a
selector read. Boundary scanning reuses known instruction starts and deduplicates
unknown starts; its conservative prefix/opcode filter covers every refused
family before invoking the disassembler. Trusted control flow must also exclude
indirect entry that bypasses initialization; linear disassembly cannot enforce
that condition for arbitrary code.

Every FXSAVE/XSAVE/XSAVEC site must sit inside one of glibc's two loader
trampolines; other save variants are refused without an exemption.
The scanner recognizes each trampoline by its complete straight-line shape: the
stack alignment prologue, the register spills, a save to `0x40(%rsp)`, one
direct call, a matching restore, the register reloads and the exit. XSAVE
shapes require 64-byte alignment and equal save/restore masks. Legacy FXSAVE
shapes require 16-byte alignment, a 0x240-byte stack frame and paired FXRSTOR
with the same operand and encoding. No branch may enter the trampoline after its first instruction. No
address or file digest is pinned, so a rebuilt glibc or a static binary passes
when its trampolines keep this shape. `eager-resolver` is the lazy-binding
resolver; every image boots with `LD_BIND_NOW=1`, so it never runs.
`unused-tlsdesc` is the dynamic TLS descriptor trampoline; the scanner rejects
TLSdesc relocations anywhere in the closure, so it never runs either. A save
instruction anywhere else rejects the image.

Native arithmetic and standard math libraries are admitted. Reciprocal and
reciprocal-square-root estimates (RCP/RSQRT and their VEX/EVEX forms, including
FP16), and x87 transcendental operations can produce different result bits on
different CPU implementations. The rootfs checker inventories those operations
without refusing them; the production Faults scan does not require instruction
reviews for native arithmetic. Admission therefore does not establish universal
cross-CPU numerical reproducibility. Saved CLI replay warns about changed or
unknown CPU implementations through [CPU provenance](../../cli/README.md);
retained cross-implementation execution evidence is needed
to establish agreement for a particular composition and input.

| Native variation | Disposition | Boundary |
| --- | --- | --- |
| SYSCALL-saved AF | Clear both flags and R11 before the first tick | Owned x86 syscall ingress; arbitrary interrupted R11 is preserved |
| Native FXSAVE/XSAVE image bytes | Refuse workload saves; canonicalize owned kernel saves | Controlled rootfs and patched guest kernel |
| Reciprocal and x87 transcendental approximations | Admit native semantics; warn on CPU changes | CPU replay diagnostics; no universal result-bit equivalence |
| UML initial extended registers and PKRU | Clear XSAVE header and extended bytes; restore architectural init state | Owned x86 UML startup patch |
| Other permitted native arithmetic | Restricted qualification claim | Exact artifact, contract and implementation classes tested; no universal cross-vendor claim |

The initramfs adapter accepts one raw newc `070701` archive or its gzip encoding
and binds the exact input bytes. It inventories device nodes as metadata without
creating or opening host devices. ELF analysis uses a temporary projection of
regular files, directories and symlinks; guest metadata comes from the archive.
Traversal, duplicate entries, hardlinks, truncation, nonzero padding,
concatenated archives and unsupported types fail closed. Absolute symlinks retain
guest-root semantics; one terminal NUL in a kernel-generated symlink body is
accepted, while embedded NULs are rejected. Newc has no extended attributes.

These static checks do not enforce runtime filesystem immutability, W^X,
startup binding or the no-generated-code policy. The OCI root is writable;
execution remains limited to trusted, fixed workloads and loading behavior.

```sh
python3 consonance/harmony-linux/scripts/test_x86_xstate_admission.py -v
```

The scanner tests require GNU objdump; `OBJDUMP` selects a non-default executable.

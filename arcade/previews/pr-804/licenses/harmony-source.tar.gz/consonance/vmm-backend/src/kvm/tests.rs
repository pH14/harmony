// SPDX-License-Identifier: AGPL-3.0-or-later

use std::alloc::{Layout, alloc_zeroed, dealloc};
use std::collections::BTreeMap;

use kvm_bindings::{
    KVM_EXIT_FAIL_ENTRY, KVM_EXIT_HLT, KVM_EXIT_INTERNAL_ERROR, KVM_EXIT_IO,
    KVM_EXIT_IRQ_WINDOW_OPEN, KVM_EXIT_MMIO, KVM_EXIT_SHUTDOWN, KVM_EXIT_X86_RDMSR,
    KVM_EXIT_X86_WRMSR, KVM_MP_STATE_HALTED, KVM_MP_STATE_RUNNABLE, kvm_msr_entry, kvm_run,
};

use super::*;
use crate::arch::x86::{CpuidEntry, CpuidModel, MsrFilter, MsrRange};
use crate::arch::x86::{DebugRegs, DescriptorTable, Segment, VcpuEvents, VcpuRegs, VcpuSregs};
use crate::exit::Exit;
use crate::types::Gpa;
use crate::types::MpState;

struct SynRun {
    ptr: *mut u8,
    layout: Layout,
    len: usize,
}

const PIO_OFF: usize = 8192;

fn set_usable_test_segments(state: &mut VcpuState) {
    for segment in [
        &mut state.sregs.cs,
        &mut state.sregs.ds,
        &mut state.sregs.es,
        &mut state.sregs.fs,
        &mut state.sregs.gs,
        &mut state.sregs.ss,
        &mut state.sregs.tr,
        &mut state.sregs.ldt,
    ] {
        segment.present = 1;
    }
}

impl SynRun {
    fn new() -> Self {
        let len = 16384;
        assert!(
            size_of::<kvm_run>() <= PIO_OFF,
            "PIO area must clear kvm_run"
        );
        let layout = Layout::from_size_align(len, 4096).expect("layout");
        // SAFETY: non-zero size, power-of-two align.
        let ptr = unsafe { alloc_zeroed(layout) };
        assert!(!ptr.is_null(), "alloc failed");
        Self { ptr, layout, len }
    }
    fn run(&self) -> *mut kvm_run {
        self.ptr.cast::<kvm_run>()
    }
    fn page(&self) -> RunPage {
        // SAFETY: `ptr` backs `len` live zeroed bytes aligned for `kvm_run`.
        unsafe { RunPage::new(self.run(), self.len) }
    }
    fn byte(&self, off: usize) -> u8 {
        // SAFETY: `off < len`.
        unsafe { *self.ptr.add(off) }
    }
    fn set_byte(&self, off: usize, v: u8) {
        // SAFETY: `off < len`.
        unsafe { *self.ptr.add(off) = v };
    }
}
impl Drop for SynRun {
    fn drop(&mut self) {
        // SAFETY: `ptr`/`layout` from `alloc_zeroed`; freed once.
        unsafe { dealloc(self.ptr, self.layout) };
    }
}

fn set_reason(s: &SynRun, reason: u32) {
    // SAFETY: `run()` is a valid, owned `kvm_run`.
    unsafe { (*s.run()).exit_reason = reason };
}

#[test]
fn decode_io_out_reads_value_via_run_buf() {
    let s = SynRun::new();
    set_reason(&s, KVM_EXIT_IO);
    // SAFETY: writing union sub-fields of an owned, zeroed kvm_run.
    unsafe {
        let io = &mut (*s.run()).__bindgen_anon_1.io;
        io.direction = 1;
        io.size = 1;
        io.port = 0x3F8;
        io.count = 1;
        io.data_offset = PIO_OFF as u64;
    }
    s.set_byte(PIO_OFF, 0x42);

    let (exit, pending) = decode_exit(s.page()).unwrap().unwrap();
    assert_eq!(
        exit,
        Exit::Arch(X86Exit::Io {
            port: 0x3F8,
            size: 1,
            write: Some(0x42)
        })
    );
    assert_eq!(pending, Pending::None);
    assert!(decoded_exit_stages_completion(&exit, pending));
}

#[test]
fn decode_io_in_arms_pending() {
    let s = SynRun::new();
    set_reason(&s, KVM_EXIT_IO);
    // SAFETY: union sub-field writes.
    unsafe {
        let io = &mut (*s.run()).__bindgen_anon_1.io;
        io.direction = 0;
        io.size = 2;
        io.port = 0x60;
        io.count = 1;
        io.data_offset = PIO_OFF as u64;
    }
    let (exit, pending) = decode_exit(s.page()).unwrap().unwrap();
    assert_eq!(
        exit,
        Exit::Arch(X86Exit::Io {
            port: 0x60,
            size: 2,
            write: None
        })
    );
    assert_eq!(
        pending,
        Pending::IoIn {
            data_offset: PIO_OFF as u64,
            size: 2
        }
    );
    assert!(!decoded_exit_stages_completion(&exit, pending));
}

#[test]
fn decode_io_rep_string_fails_closed() {
    let s = SynRun::new();
    set_reason(&s, KVM_EXIT_IO);
    // SAFETY: union sub-field writes.
    unsafe {
        let io = &mut (*s.run()).__bindgen_anon_1.io;
        io.direction = 1;
        io.size = 1;
        io.port = 0x3F8;
        io.count = 7;
        io.data_offset = PIO_OFF as u64;
    }
    assert!(matches!(
        decode_exit(s.page()),
        Err(BackendError::Unsupported {
            what: "string/REP port I/O (io.count != 1)"
        })
    ));
}

#[test]
fn decode_io_out_offset_past_page_is_error_not_ub() {
    let s = SynRun::new();
    set_reason(&s, KVM_EXIT_IO);
    // SAFETY: union sub-field writes.
    unsafe {
        let io = &mut (*s.run()).__bindgen_anon_1.io;
        io.direction = 1;
        io.size = 4;
        io.port = 0x3F8;
        io.count = 1;
        io.data_offset = (s.len as u64) - 2;
    }
    assert!(matches!(
        decode_exit(s.page()),
        Err(BackendError::Memory(_))
    ));
}

#[test]
fn decode_mmio_store_and_load() {
    let s = SynRun::new();
    set_reason(&s, KVM_EXIT_MMIO);
    // SAFETY: union sub-field writes.
    unsafe {
        let m = &mut (*s.run()).__bindgen_anon_1.mmio;
        m.phys_addr = 0xFEE0_0000;
        m.len = 4;
        m.is_write = 1;
        m.data[..4].copy_from_slice(&0x1234_5678u32.to_le_bytes());
    }
    let (exit, pending) = decode_exit(s.page()).unwrap().unwrap();
    assert_eq!(
        exit,
        Exit::Common(CommonExit::Mmio {
            gpa: Gpa(0xFEE0_0000),
            size: 4,
            write: Some(0x1234_5678)
        })
    );
    assert_eq!(pending, Pending::None);
    assert!(decoded_exit_stages_completion(&exit, pending));

    let s = SynRun::new();
    set_reason(&s, KVM_EXIT_MMIO);
    // SAFETY: union sub-field writes.
    unsafe {
        let m = &mut (*s.run()).__bindgen_anon_1.mmio;
        m.phys_addr = 0xFEE0_0080;
        m.len = 4;
        m.is_write = 0;
    }
    let (exit, pending) = decode_exit(s.page()).unwrap().unwrap();
    assert_eq!(
        exit,
        Exit::Common(CommonExit::Mmio {
            gpa: Gpa(0xFEE0_0080),
            size: 4,
            write: None
        })
    );
    assert_eq!(pending, Pending::MmioLoad { len: 4 });
    assert!(!decoded_exit_stages_completion(&exit, pending));
}

#[test]
fn decode_rdmsr_and_wrmsr() {
    let s = SynRun::new();
    set_reason(&s, KVM_EXIT_X86_RDMSR);
    // SAFETY: union sub-field writes.
    unsafe { (*s.run()).__bindgen_anon_1.msr.index = 0x1B };
    let (exit, pending) = decode_exit(s.page()).unwrap().unwrap();
    assert_eq!(exit, Exit::Arch(X86Exit::Rdmsr { index: 0x1B }));
    assert_eq!(pending, Pending::Rdmsr);

    let s = SynRun::new();
    set_reason(&s, KVM_EXIT_X86_WRMSR);
    // SAFETY: union sub-field writes.
    unsafe {
        let m = &mut (*s.run()).__bindgen_anon_1.msr;
        m.index = 0x6E0;
        m.data = 0xDEAD_BEEF;
    }
    let (exit, pending) = decode_exit(s.page()).unwrap().unwrap();
    assert_eq!(
        exit,
        Exit::Arch(X86Exit::Wrmsr {
            index: 0x6E0,
            value: 0xDEAD_BEEF
        })
    );
    assert_eq!(pending, Pending::Wrmsr);
}

#[test]
fn decode_terminal_and_control_exits() {
    for (reason, want) in [
        (KVM_EXIT_HLT, Exit::Common(CommonExit::Idle)),
        (KVM_EXIT_SHUTDOWN, Exit::Common(CommonExit::Shutdown)),
    ] {
        let s = SynRun::new();
        set_reason(&s, reason);
        let (exit, pending) = decode_exit(s.page()).unwrap().unwrap();
        assert_eq!(exit, want);
        assert_eq!(pending, Pending::None);
    }
    let s = SynRun::new();
    set_reason(&s, KVM_EXIT_IRQ_WINDOW_OPEN);
    assert_eq!(decode_exit(s.page()).unwrap(), None);
}

#[test]
fn decode_error_and_unknown_exits_fail_closed() {
    for (reason, msg) in [
        (KVM_EXIT_INTERNAL_ERROR, "KVM_EXIT_INTERNAL_ERROR"),
        (0xDEAD_BEEF, "unhandled KVM exit reason"),
    ] {
        let s = SynRun::new();
        set_reason(&s, reason);
        match decode_exit(s.page()) {
            Err(BackendError::Internal(got)) => assert_eq!(got, msg),
            other => panic!("expected Internal({msg:?}), got {other:?}"),
        }
    }
}

#[test]
fn decode_entry_failure_preserves_hardware_reason_and_cpu() {
    for (hardware_reason, cpu) in [(0, 0), (0x8000_0021, 17), (u64::MAX, u32::MAX)] {
        let s = SynRun::new();
        set_reason(&s, KVM_EXIT_FAIL_ENTRY);
        // SAFETY: the owned, aligned, zeroed kvm_run has exit reason KVM_EXIT_FAIL_ENTRY; these writes initialize its active union member.
        unsafe {
            let entry = &mut (*s.run()).__bindgen_anon_1.fail_entry;
            entry.hardware_entry_failure_reason = hardware_reason;
            entry.cpu = cpu;
        }
        let error = decode_exit(s.page()).unwrap_err();
        assert!(matches!(error, BackendError::KvmEntryFailure {
            hardware_reason: got_reason, cpu: got_cpu,
        } if got_reason == hardware_reason && got_cpu == cpu));
        assert_eq!(
            error.to_string(),
            format!("KVM_EXIT_FAIL_ENTRY: hardware reason {hardware_reason:#018x}, CPU {cpu}")
        );
    }
}

#[test]
fn apply_complete_read_routes_by_pending() {
    let s = SynRun::new();
    apply_complete_read(
        s.page(),
        Pending::IoIn {
            data_offset: PIO_OFF as u64,
            size: 1,
        },
        0x55,
    )
    .unwrap();
    assert_eq!(s.byte(PIO_OFF), 0x55);

    let s = SynRun::new();
    apply_complete_read(s.page(), Pending::MmioLoad { len: 4 }, 0xAABB_CCDD).unwrap();
    // SAFETY: read back the union member just written.
    let data = unsafe { (*s.run()).__bindgen_anon_1.mmio.data };
    assert_eq!(&data[..4], &0xAABB_CCDDu32.to_le_bytes());

    let s = SynRun::new();
    apply_complete_read(s.page(), Pending::Rdmsr, 0x1234).unwrap();
    // SAFETY: read back the union member just written.
    let msr = unsafe { (*s.run()).__bindgen_anon_1.msr };
    assert_eq!(msr.data, 0x1234);
    assert_eq!(msr.error, 0);

    let s = SynRun::new();
    assert!(matches!(
        apply_complete_read(s.page(), Pending::Wrmsr, 1),
        Err(BackendError::NoPendingRead)
    ));
    assert!(matches!(
        apply_complete_read(s.page(), Pending::None, 1),
        Err(BackendError::NoPendingRead)
    ));
}

#[test]
fn apply_complete_fault_and_ok_set_msr_error() {
    for p in [Pending::Rdmsr, Pending::Wrmsr] {
        let s = SynRun::new();
        apply_complete_fault(s.page(), p).unwrap();
        // SAFETY: read back the union member.
        assert_eq!(unsafe { (*s.run()).__bindgen_anon_1.msr.error }, 1);
    }
    let s = SynRun::new();
    // SAFETY: union sub-field write.
    unsafe { (*s.run()).__bindgen_anon_1.msr.error = 9 };
    apply_complete_ok(s.page(), Pending::Wrmsr).unwrap();
    assert_eq!(unsafe { (*s.run()).__bindgen_anon_1.msr.error }, 0);

    let s = SynRun::new();
    assert!(matches!(
        apply_complete_fault(
            s.page(),
            Pending::IoIn {
                data_offset: 0,
                size: 1
            }
        ),
        Err(BackendError::BadCompletion)
    ));
    assert!(matches!(
        apply_complete_ok(s.page(), Pending::Rdmsr),
        Err(BackendError::BadCompletion)
    ));
}

#[test]
fn retire_staged_completion_is_a_noop_without_a_stage() {
    let s = SynRun::new();
    let mut pending = Pending::None;
    let mut stage = Stage::CLEAR;
    let mut entries = 0;
    retire_staged_completion(s.page(), &mut pending, &mut stage, || {
        entries += 1;
        Ok(())
    })
    .unwrap();
    assert_eq!(entries, 0, "a no-pending retirement must not enter KVM");
    assert!(!stage.staged);
    assert_eq!(pending, Pending::None);
    assert_eq!(s.page().immediate_exit(), 0);
}

#[test]
fn retire_staged_completion_uses_one_immediate_entry_and_preserves_next_exit() {
    let s = SynRun::new();
    let mut pending = Pending::IoIn {
        data_offset: PIO_OFF as u64,
        size: 1,
    };
    let mut stage = Stage::AWAITING_FINISH;
    let mut entries = 0;
    let mut next_scripted_exit = Some(KVM_EXIT_HLT);
    retire_staged_completion(s.page(), &mut pending, &mut stage, || {
        entries += 1;
        assert_eq!(s.page().immediate_exit(), 1);
        assert_eq!(next_scripted_exit, Some(KVM_EXIT_HLT));
        Err(std::io::Error::from_raw_os_error(libc::EINTR))
    })
    .unwrap();
    assert_eq!(entries, 1);
    assert_eq!(next_scripted_exit.take(), Some(KVM_EXIT_HLT));
    assert!(!stage.staged);
    assert_eq!(pending, Pending::None);
    assert_eq!(s.page().immediate_exit(), 0);
}

#[test]
fn retire_staged_completion_error_clears_one_shot_and_keeps_stage() {
    let s = SynRun::new();
    let mut pending = Pending::None;
    let mut stage = Stage::AWAITING_FINISH;
    let error = retire_staged_completion(s.page(), &mut pending, &mut stage, || {
        assert_eq!(s.page().immediate_exit(), 1);
        Err(std::io::Error::from_raw_os_error(libc::EIO))
    })
    .expect_err("a non-EINTR completion entry must fail closed");
    assert!(matches!(error, BackendError::Io(_)));
    assert_eq!(s.page().immediate_exit(), 0);
    assert!(
        stage.staged,
        "an uncertain completion remains conservatively staged"
    );
    assert_eq!(pending, Pending::None);
}

#[test]
fn retire_staged_write_completion_without_pending_uses_immediate_entry() {
    let s = SynRun::new();
    let mut pending = Pending::None;
    let mut stage = Stage::AWAITING_FINISH;
    let mut entries = 0;
    retire_staged_completion(s.page(), &mut pending, &mut stage, || {
        entries += 1;
        assert_eq!(s.page().immediate_exit(), 1);
        Err(std::io::Error::from_raw_os_error(libc::EINTR))
    })
    .unwrap();
    assert_eq!(entries, 1);
    assert!(!stage.staged);
    assert_eq!(pending, Pending::None);
    assert_eq!(s.page().immediate_exit(), 0);
}

#[test]
fn finish_staged_completion_returns_mmio_load_continuation_and_updates_pending() {
    let s = SynRun::new();
    let mut pending = Pending::IoIn {
        data_offset: PIO_OFF as u64,
        size: 1,
    };
    let mut stage = Stage::AWAITING_FINISH;
    let mut entries = 0;
    let next = finish_staged_completion(s.page(), &mut pending, &mut stage, || {
        entries += 1;
        assert_eq!(s.page().immediate_exit(), 1);
        set_reason(&s, KVM_EXIT_MMIO);
        // SAFETY: union sub-field writes to the owned synthetic run page.
        unsafe {
            let mmio = &mut (*s.run()).__bindgen_anon_1.mmio;
            mmio.phys_addr = 0xFEE0_0080;
            mmio.len = 4;
            mmio.is_write = 0;
        }
        Ok(())
    })
    .unwrap()
    .expect("successful completion entry returns its continuation");

    assert_eq!(entries, 1);
    assert_eq!(
        next,
        Exit::Common(CommonExit::Mmio {
            gpa: Gpa(0xFEE0_0080),
            size: 4,
            write: None,
        })
    );
    assert_eq!(pending, Pending::MmioLoad { len: 4 });
    assert!(
        !stage.staged,
        "a read continuation now awaits its host value"
    );
    assert_eq!(s.page().immediate_exit(), 0);
}

#[test]
fn finish_staged_completion_returns_mmio_store_continuation_and_keeps_stage() {
    let s = SynRun::new();
    let mut pending = Pending::None;
    let mut stage = Stage::AWAITING_FINISH;
    let next = finish_staged_completion(s.page(), &mut pending, &mut stage, || {
        assert_eq!(s.page().immediate_exit(), 1);
        set_reason(&s, KVM_EXIT_MMIO);
        // SAFETY: union sub-field writes to the owned synthetic run page.
        unsafe {
            let mmio = &mut (*s.run()).__bindgen_anon_1.mmio;
            mmio.phys_addr = 0xFEE0_0000;
            mmio.len = 4;
            mmio.is_write = 1;
            mmio.data[..4].copy_from_slice(&0x1234_5678u32.to_le_bytes());
        }
        Ok(())
    })
    .unwrap()
    .expect("successful completion entry returns its continuation");

    assert_eq!(
        next,
        Exit::Common(CommonExit::Mmio {
            gpa: Gpa(0xFEE0_0000),
            size: 4,
            write: Some(0x1234_5678),
        })
    );
    assert_eq!(pending, Pending::None);
    assert!(
        stage.staged,
        "a store continuation still has a KVM callback"
    );
    assert_eq!(s.page().immediate_exit(), 0);
}

#[test]
fn finish_staged_completion_returns_pio_read_continuation_and_arms_pending() {
    let s = SynRun::new();
    let mut pending = Pending::None;
    let mut stage = Stage::AWAITING_FINISH;
    let next = finish_staged_completion(s.page(), &mut pending, &mut stage, || {
        assert_eq!(s.page().immediate_exit(), 1);
        set_reason(&s, KVM_EXIT_IO);
        // SAFETY: union sub-field writes to the owned synthetic run page.
        unsafe {
            let io = &mut (*s.run()).__bindgen_anon_1.io;
            io.direction = 0;
            io.size = 2;
            io.port = 0x60;
            io.count = 1;
            io.data_offset = PIO_OFF as u64;
        }
        Ok(())
    })
    .unwrap()
    .expect("successful completion entry returns its continuation");

    assert_eq!(
        next,
        Exit::Arch(X86Exit::Io {
            port: 0x60,
            size: 2,
            write: None,
        })
    );
    assert_eq!(
        pending,
        Pending::IoIn {
            data_offset: PIO_OFF as u64,
            size: 2,
        }
    );
    assert!(
        !stage.staged,
        "a PIO read continuation awaits its host value"
    );
    assert_eq!(s.page().immediate_exit(), 0);
}

#[test]
fn finish_staged_completion_eintr_reaches_a_no_entry_fixpoint() {
    let s = SynRun::new();
    let mut pending = Pending::MmioLoad { len: 8 };
    let mut stage = Stage::AWAITING_FINISH;
    let guard = StateMutationGuard::default();
    let mut entries = 0;
    let first =
        finish_staged_completion_guarded(s.page(), &mut pending, &mut stage, &guard, || {
            entries += 1;
            assert_eq!(s.page().immediate_exit(), 1);
            Err(std::io::Error::from_raw_os_error(libc::EINTR))
        })
        .unwrap();
    assert_eq!(first, None);
    assert_eq!(entries, 1);
    assert_eq!(pending, Pending::None);
    assert!(!stage.staged);
    assert!(guard.ensure_healthy().is_ok());
    assert_eq!(s.page().immediate_exit(), 0);

    let second = finish_staged_completion(s.page(), &mut pending, &mut stage, || {
        entries += 1;
        Ok(())
    })
    .unwrap();
    assert_eq!(second, None);
    assert_eq!(entries, 1, "a consumed completion must not enter again");
    assert_eq!(s.page().immediate_exit(), 0);
}

#[test]
fn finish_staged_completion_raw_error_preserves_state_and_clears_flag() {
    let s = SynRun::new();
    let mut pending = Pending::IoIn {
        data_offset: PIO_OFF as u64,
        size: 2,
    };
    let mut stage = Stage::AWAITING_FINISH;
    let error = finish_staged_completion(s.page(), &mut pending, &mut stage, || {
        assert_eq!(s.page().immediate_exit(), 1);
        Err(std::io::Error::from_raw_os_error(libc::EIO))
    })
    .expect_err("a non-EINTR completion entry must fail closed");

    assert!(matches!(error, BackendError::Io(_)));
    assert_eq!(
        pending,
        Pending::IoIn {
            data_offset: PIO_OFF as u64,
            size: 2,
        }
    );
    assert!(
        stage.staged,
        "an uncertain completion remains staged for retry"
    );
    assert_eq!(s.page().immediate_exit(), 0);
}

#[test]
fn finish_staged_completion_rejects_non_device_continuations_without_mutation() {
    for reason in [
        KVM_EXIT_HLT,
        KVM_EXIT_IRQ_WINDOW_OPEN,
        KVM_EXIT_INTERNAL_ERROR,
    ] {
        let s = SynRun::new();
        let original_pending = Pending::MmioLoad { len: 4 };
        let mut pending = original_pending;
        let mut stage = Stage::AWAITING_FINISH;
        let error = finish_staged_completion(s.page(), &mut pending, &mut stage, || {
            assert_eq!(s.page().immediate_exit(), 1);
            set_reason(&s, reason);
            Ok(())
        })
        .expect_err("completion-only entry must accept only PIO/MMIO exits");

        assert!(matches!(error, BackendError::Internal(_)));
        assert_eq!(pending, original_pending);
        assert!(stage.staged);
        assert_eq!(s.page().immediate_exit(), 0);
    }
}

#[test]
fn retire_staged_completion_rejects_continuation_without_dropping_it() {
    let s = SynRun::new();
    let mut pending = Pending::None;
    let mut stage = Stage::AWAITING_FINISH;
    set_reason(&s, KVM_EXIT_MMIO);
    // SAFETY: union sub-field writes to the owned synthetic run page.
    unsafe {
        let mmio = &mut (*s.run()).__bindgen_anon_1.mmio;
        mmio.phys_addr = 0xFEE0_0000;
        mmio.len = 1;
        mmio.is_write = 1;
        mmio.data[0] = 0x42;
    }

    let error = retire_staged_completion(s.page(), &mut pending, &mut stage, || Ok(()))
        .expect_err("the legacy retire wrapper cannot discard a continuation");
    assert!(matches!(error, BackendError::PendingCompletion));
    assert_eq!(pending, Pending::None);
    assert!(stage.staged, "the returned store remains serviceable");
    assert_eq!(s.page().immediate_exit(), 0);
}

#[test]
fn cpuid_entries_maps_fields_and_significant_flag() {
    let model = CpuidModel {
        entries: vec![
            CpuidEntry {
                leaf: 1,
                subleaf: 0,
                subleaf_significant: false,
                eax: 0xA,
                ebx: 0xB,
                ecx: 0xC,
                edx: 0xD,
            },
            CpuidEntry {
                leaf: 0xD,
                subleaf: 1,
                subleaf_significant: true,
                eax: 1,
                ebx: 2,
                ecx: 3,
                edx: 4,
            },
        ],
        ..Default::default()
    };
    let out = cpuid_entries(&model);
    assert_eq!(out.len(), 2);
    assert_eq!(out[0].function, 1);
    assert_eq!(out[0].index, 0);
    assert_eq!(out[0].flags, 0);
    assert_eq!(
        (out[0].eax, out[0].ebx, out[0].ecx, out[0].edx),
        (0xA, 0xB, 0xC, 0xD)
    );
    assert_eq!(out[1].function, 0xD);
    assert_eq!(out[1].index, 1);
    assert_eq!(out[1].flags, kvm_bindings::KVM_CPUID_FLAG_SIGNIFCANT_INDEX);
}

#[test]
fn msr_count_checks_fail_closed_on_short_count() {
    assert!(ensure_full_msr_count(3, 3).is_ok());
    assert!(matches!(
        ensure_full_msr_count(2, 3),
        Err(BackendError::Internal(_))
    ));

    let entries = [
        kvm_msr_entry {
            index: 0x174,
            data: 11,
            ..Default::default()
        },
        kvm_msr_entry {
            index: 0x175,
            data: 22,
            ..Default::default()
        },
        kvm_msr_entry {
            index: 0x176,
            data: 33,
            ..Default::default()
        },
    ];
    let map = saved_msrs(&entries, 3, 3).unwrap();
    assert_eq!(map, BTreeMap::from([(0x174, 11), (0x175, 22), (0x176, 33)]));
    assert!(saved_msrs(&entries, 2, 3).is_err());
}

#[test]
fn validate_restore_shape_keys_and_xsave_len() {
    let filter = MsrFilter {
        allow_inkernel: vec![MsrRange {
            base: 0x174,
            count: 3,
        }],
    };
    let mut good = VcpuState {
        msrs: BTreeMap::from([(0x174, 0), (0x175, 0), (0x176, 0)]),
        xsave: vec![0u8; 4096],
        ..Default::default()
    };
    good.regs.rflags = 2;
    set_usable_test_segments(&mut good);
    assert!(validate_restore_shape(&good, Some(&filter), 4096, 48, false).is_ok());

    good.msrs.remove(&0x175);
    assert!(matches!(
        validate_restore_shape(&good, Some(&filter), 4096, 48, false),
        Err(BackendError::InvalidState)
    ));
    good.msrs.insert(0x175, 0);

    good.msrs.insert(0x200, 0);
    assert!(validate_restore_shape(&good, Some(&filter), 4096, 48, false).is_err());
    good.msrs.remove(&0x200);

    assert!(matches!(
        validate_restore_shape(&good, Some(&filter), 8192, 48, false),
        Err(BackendError::InvalidState)
    ));

    let mut empty = VcpuState {
        xsave: vec![0u8; 4096],
        ..Default::default()
    };
    empty.regs.rflags = 2;
    set_usable_test_segments(&mut empty);
    assert!(validate_restore_shape(&empty, None, 4096, 48, false).is_ok());
    assert!(validate_restore_shape(&good, None, 4096, 48, false).is_err());
}

#[test]
fn validate_restore_shape_requires_coherent_sregs_msr_aliases() {
    const EFER: u32 = 0xc000_0080;
    const FS_BASE: u32 = 0xc000_0100;
    const GS_BASE: u32 = 0xc000_0101;
    let filter = MsrFilter {
        allow_inkernel: vec![
            MsrRange {
                base: EFER,
                count: 1,
            },
            MsrRange {
                base: FS_BASE,
                count: 2,
            },
        ],
    };
    let mut coherent = VcpuState {
        msrs: BTreeMap::from([
            (EFER, 0x100),
            (FS_BASE, 0x1234_5000),
            (GS_BASE, 0x6789_0000),
        ]),
        xsave: vec![0; 4096],
        ..Default::default()
    };
    coherent.regs.rflags = 2;
    set_usable_test_segments(&mut coherent);
    coherent.sregs.efer = coherent.msrs[&EFER];
    coherent.sregs.fs.base = coherent.msrs[&FS_BASE];
    coherent.sregs.gs.base = coherent.msrs[&GS_BASE];
    assert!(validate_restore_shape(&coherent, Some(&filter), 4096, 48, false).is_ok());

    for index in [EFER, FS_BASE, GS_BASE] {
        let mut inconsistent = coherent.clone();
        *inconsistent.msrs.get_mut(&index).unwrap() ^= 1;
        assert!(matches!(
            validate_restore_shape(&inconsistent, Some(&filter), 4096, 48, false),
            Err(BackendError::InvalidState)
        ));
    }
}

#[test]
fn validate_restore_shape_requires_preservable_sysenter_values() {
    let filter = MsrFilter {
        allow_inkernel: vec![MsrRange {
            base: 0x174,
            count: 3,
        }],
    };
    let mut state = VcpuState {
        msrs: BTreeMap::from([
            (0x174, u64::from(u32::MAX)),
            (0x175, 0x0000_7fff_ffff_ffff),
            (0x176, 0xffff_8000_0000_0000),
        ]),
        xsave: vec![0; 4096],
        ..Default::default()
    };
    state.regs.rflags = 2;
    set_usable_test_segments(&mut state);
    assert!(validate_restore_shape(&state, Some(&filter), 4096, 48, false).is_ok());

    for (index, value) in [
        (0x174, 1 << 32),
        (0x175, 0x0000_8000_0000_0000),
        (0x176, 1 << 48),
    ] {
        let original = state.msrs.insert(index, value).unwrap();
        assert!(matches!(
            validate_restore_shape(&state, Some(&filter), 4096, 48, false),
            Err(BackendError::InvalidState)
        ));
        state.msrs.insert(index, original);
    }

    state.msrs.insert(0x175, 1 << 48);
    assert!(validate_restore_shape(&state, Some(&filter), 4096, 57, false).is_ok());
    state.msrs.insert(0x175, 1 << 63);
    assert!(matches!(
        validate_restore_shape(&state, Some(&filter), 4096, 57, false),
        Err(BackendError::InvalidState)
    ));

    state.msrs.insert(0x175, u64::from(u32::MAX));
    state.msrs.insert(0x176, u64::from(u32::MAX));
    assert!(validate_restore_shape(&state, Some(&filter), 4096, 48, true).is_ok());
    for index in [0x175, 0x176] {
        state.msrs.insert(index, 1 << 32);
        assert!(matches!(
            validate_restore_shape(&state, Some(&filter), 4096, 48, true),
            Err(BackendError::InvalidState)
        ));
        state.msrs.insert(index, u64::from(u32::MAX));
    }
}

#[test]
fn validate_restore_shape_requires_four_bit_cr8() {
    let mut state = VcpuState {
        xsave: vec![0; 4096],
        ..Default::default()
    };
    state.regs.rflags = 2;
    set_usable_test_segments(&mut state);
    state.sregs.cr8 = 0x0f;
    assert!(validate_restore_shape(&state, None, 4096, 48, false).is_ok());
    state.sregs.cr8 = 0x10;
    assert!(matches!(
        validate_restore_shape(&state, None, 4096, 48, false),
        Err(BackendError::InvalidState)
    ));
}

#[test]
fn validate_restore_shape_requires_architectural_rflags() {
    let mut state = VcpuState {
        xsave: vec![0; 4096],
        ..Default::default()
    };
    state.regs.rflags = 2;
    set_usable_test_segments(&mut state);
    assert!(validate_restore_shape(&state, None, 4096, 48, false).is_ok());
    state.regs.rflags = 0;
    assert!(matches!(
        validate_restore_shape(&state, None, 4096, 48, false),
        Err(BackendError::InvalidState)
    ));
    for bit in [3, 5, 15, 22, 63] {
        state.regs.rflags = 2 | (1 << bit);
        assert!(matches!(
            validate_restore_shape(&state, None, 4096, 48, false),
            Err(BackendError::InvalidState)
        ));
    }
    state.regs.rflags = 3;
    assert!(validate_restore_shape(&state, None, 4096, 48, false).is_ok());
}

#[test]
fn validate_restore_shape_requires_legal_virtual_8086_mode() {
    let mut state = VcpuState {
        xsave: vec![0; 4096],
        ..Default::default()
    };
    state.regs.rflags = 2 | (1 << 17);
    set_usable_test_segments(&mut state);
    assert!(matches!(
        validate_restore_shape(&state, None, 4096, 48, false),
        Err(BackendError::InvalidState)
    ));
    state.sregs.cr0 |= 1;
    assert!(validate_restore_shape(&state, None, 4096, 48, false).is_ok());
    state.sregs.efer |= 1 << 10;
    assert!(matches!(
        validate_restore_shape(&state, None, 4096, 48, false),
        Err(BackendError::InvalidState)
    ));
    state.regs.rflags = 2;
    assert!(validate_restore_shape(&state, None, 4096, 48, false).is_ok());
}

#[test]
fn validate_restore_shape_requires_ia32e_paging_for_pcide() {
    let mut state = VcpuState {
        xsave: vec![0; 4096],
        ..Default::default()
    };
    state.regs.rflags = 2;
    set_usable_test_segments(&mut state);
    state.sregs.cr4 = 1 << 17;
    for (cr0, cr4, efer) in [
        (0, 1 << 17, 0),
        ((1 << 31) | 1, 1 << 17, (1 << 10) | (1 << 8)),
        ((1 << 31) | 1, (1 << 17) | (1 << 5), 1 << 8),
    ] {
        state.sregs.cr0 = cr0;
        state.sregs.cr4 = cr4;
        state.sregs.efer = efer;
        assert!(matches!(
            validate_restore_shape(&state, None, 4096, 48, false),
            Err(BackendError::InvalidState)
        ));
    }
    state.sregs.cr0 = (1 << 31) | 1;
    state.sregs.cr4 = (1 << 17) | (1 << 5);
    state.sregs.efer = (1 << 10) | (1 << 8);
    assert!(validate_restore_shape(&state, None, 4096, 48, false).is_ok());
}

#[test]
fn validate_restore_shape_requires_segment_encoding_widths() {
    fn segment(state: &mut VcpuState, index: usize) -> &mut Segment {
        match index {
            0 => &mut state.sregs.cs,
            1 => &mut state.sregs.ds,
            2 => &mut state.sregs.es,
            3 => &mut state.sregs.fs,
            4 => &mut state.sregs.gs,
            5 => &mut state.sregs.ss,
            6 => &mut state.sregs.tr,
            7 => &mut state.sregs.ldt,
            _ => unreachable!(),
        }
    }

    let mut state = VcpuState {
        regs: VcpuRegs {
            rflags: 2,
            ..Default::default()
        },
        xsave: vec![0; 4096],
        ..Default::default()
    };
    set_usable_test_segments(&mut state);
    for index in 0..8 {
        let mut candidate = state.clone();
        segment(&mut candidate, index).type_ = 0x0f;
        segment(&mut candidate, index).dpl = 3;
        assert!(validate_restore_shape(&candidate, None, 4096, 48, false).is_ok());

        segment(&mut candidate, index).type_ = 0x10;
        assert!(matches!(
            validate_restore_shape(&candidate, None, 4096, 48, false),
            Err(BackendError::InvalidState)
        ));

        segment(&mut candidate, index).type_ = 0x0f;
        segment(&mut candidate, index).dpl = 4;
        assert!(matches!(
            validate_restore_shape(&candidate, None, 4096, 48, false),
            Err(BackendError::InvalidState)
        ));
    }
}

#[test]
fn validate_restore_shape_requires_one_bit_segment_fields() {
    for segment_index in 0..8 {
        for field in 0..7 {
            let mut state = VcpuState {
                regs: VcpuRegs {
                    rflags: 2,
                    ..Default::default()
                },
                xsave: vec![0; 4096],
                ..Default::default()
            };
            set_usable_test_segments(&mut state);
            let segment = match segment_index {
                0 => &mut state.sregs.cs,
                1 => &mut state.sregs.ds,
                2 => &mut state.sregs.es,
                3 => &mut state.sregs.fs,
                4 => &mut state.sregs.gs,
                5 => &mut state.sregs.ss,
                6 => &mut state.sregs.tr,
                _ => &mut state.sregs.ldt,
            };
            match field {
                0 => segment.present = 2,
                1 => segment.db = 2,
                2 => segment.s = 2,
                3 => segment.l = 2,
                4 => segment.g = 2,
                5 => segment.avl = 2,
                _ => segment.unusable = 2,
            }
            assert!(matches!(
                validate_restore_shape(&state, None, 4096, 48, false),
                Err(BackendError::InvalidState)
            ));
        }
    }
}

#[test]
fn validate_restore_shape_requires_canonical_unusable_segments() {
    fn segment(state: &mut VcpuState, index: usize) -> &mut Segment {
        match index {
            0 => &mut state.sregs.cs,
            1 => &mut state.sregs.ds,
            2 => &mut state.sregs.es,
            3 => &mut state.sregs.fs,
            4 => &mut state.sregs.gs,
            5 => &mut state.sregs.ss,
            6 => &mut state.sregs.tr,
            7 => &mut state.sregs.ldt,
            _ => unreachable!(),
        }
    }

    let mut state = VcpuState {
        regs: VcpuRegs {
            rflags: 2,
            ..Default::default()
        },
        xsave: vec![0; 4096],
        ..Default::default()
    };
    for index in 0..8 {
        let segment = segment(&mut state, index);
        segment.present = 1;
        segment.type_ = 3;
        segment.limit = 0xffff;
    }
    assert!(validate_restore_shape(&state, None, 4096, 48, false).is_ok());

    for index in 0..8 {
        let mut candidate = state.clone();
        segment(&mut candidate, index).present = 0;
        assert!(matches!(
            validate_restore_shape(&candidate, None, 4096, 48, false),
            Err(BackendError::InvalidState)
        ));

        let mut candidate = state.clone();
        segment(&mut candidate, index).unusable = 1;
        assert!(matches!(
            validate_restore_shape(&candidate, None, 4096, 48, false),
            Err(BackendError::InvalidState)
        ));

        let mut candidate = state.clone();
        *segment(&mut candidate, index) = Segment {
            base: 0x1234,
            selector: 3,
            unusable: 1,
            ..Segment::default()
        };
        assert!(validate_restore_shape(&candidate, None, 4096, 48, false).is_ok());
    }
}

#[test]
fn sysenter_policy_follows_host_la57_and_guest_vendor() {
    assert_eq!(kvm_sysenter_virtual_bits(&[]), 48);
    let mut la57 = kvm_cpuid_entry2 {
        function: 7,
        ecx: 1 << 16,
        ..Default::default()
    };
    assert_eq!(kvm_sysenter_virtual_bits(&[la57]), 57);
    la57.index = 1;
    assert_eq!(kvm_sysenter_virtual_bits(&[la57]), 48);

    let model = |vendor: &[u8; 12]| CpuidModel {
        entries: vec![CpuidEntry {
            leaf: 0,
            ebx: u32::from_le_bytes(vendor[..4].try_into().unwrap()),
            edx: u32::from_le_bytes(vendor[4..8].try_into().unwrap()),
            ecx: u32::from_le_bytes(vendor[8..].try_into().unwrap()),
            ..Default::default()
        }],
        ..Default::default()
    };
    assert!(!guest_intel_vendor(&model(b"AuthenticAMD")));
    assert!(!guest_intel_vendor(&model(b"HygonGenuine")));
    assert!(guest_intel_vendor(&model(b"GenuineIntel")));
    assert!(!guest_intel_vendor(&CpuidModel::default()));
}

#[test]
fn kvm_capabilities_report_the_stock_backend_name() {
    let c = kvm_capabilities();
    assert_eq!(c.name, "kvm-stock");
}

#[test]
fn mp_state_round_trips() {
    assert_eq!(mp_from_kvm(KVM_MP_STATE_HALTED), MpState::Halted);
    assert_eq!(mp_from_kvm(KVM_MP_STATE_RUNNABLE), MpState::Runnable);
    assert_eq!(mp_from_kvm(0x1234), MpState::Runnable);
    assert_eq!(mp_to_kvm(MpState::Halted), KVM_MP_STATE_HALTED);
    assert_eq!(mp_to_kvm(MpState::Runnable), KVM_MP_STATE_RUNNABLE);
    assert_eq!(mp_from_kvm(mp_to_kvm(MpState::Halted)), MpState::Halted);
}

fn distinct_regs() -> VcpuRegs {
    VcpuRegs {
        rax: 1,
        rbx: 2,
        rcx: 3,
        rdx: 4,
        rsi: 5,
        rdi: 6,
        rsp: 7,
        rbp: 8,
        r8: 9,
        r9: 10,
        r10: 11,
        r11: 12,
        r12: 13,
        r13: 14,
        r14: 15,
        r15: 16,
        rip: 17,
        rflags: 18,
    }
}

fn distinct_segment(n: u8) -> Segment {
    Segment {
        base: 0x1000 * u64::from(n) + 1,
        limit: 0x100 * u32::from(n) + 2,
        selector: (u16::from(n) << 3) | 3,
        type_: n | 0x10,
        present: 1,
        dpl: n & 3,
        db: n & 1,
        s: 1,
        l: (n >> 1) & 1,
        g: 1,
        avl: (n >> 2) & 1,
        unusable: 0,
    }
}

fn distinct_sregs() -> VcpuSregs {
    VcpuSregs {
        cs: distinct_segment(1),
        ds: distinct_segment(2),
        es: distinct_segment(3),
        fs: distinct_segment(4),
        gs: distinct_segment(5),
        ss: distinct_segment(6),
        tr: distinct_segment(7),
        ldt: distinct_segment(8),
        gdt: DescriptorTable {
            base: 0xA000,
            limit: 0xAA,
        },
        idt: DescriptorTable {
            base: 0xB000,
            limit: 0xBB,
        },
        cr0: 0x21,
        cr2: 0x22,
        cr3: 0x23,
        cr4: 0x24,
        cr8: 0x25,
        efer: 0x26,
        apic_base: 0xFEE0_0900,
        flags: 1,
        pdptrs: [0x31, 0x32, 0x33, 0x34],
    }
}

fn distinct_events() -> VcpuEvents {
    VcpuEvents {
        exception_injected: 1,
        exception_nr: 13,
        exception_has_error_code: 1,
        exception_pending: 1,
        exception_error_code: 0xABCD,
        exception_has_payload: 1,
        exception_payload: 0xCAFE_F00D,
        interrupt_injected: 1,
        interrupt_nr: 0x20,
        interrupt_soft: 1,
        interrupt_shadow: 1,
        nmi_injected: 1,
        nmi_pending: 1,
        nmi_masked: 1,
        sipi_vector: 0x99,
        flags: 0x55,
        smi_smm: 1,
        smi_pending: 1,
        smi_inside_nmi: 1,
        smi_latched_init: 1,
        triple_fault_pending: 1,
    }
}

#[test]
fn regs_sregs_events_round_trip() {
    let r = distinct_regs();
    assert_eq!(from_kvm_regs(&to_kvm_regs(&r)), r);

    let s = distinct_sregs();
    assert_eq!(from_kvm_sregs2(&to_kvm_sregs2(&s)), s);

    let e = distinct_events();
    assert_eq!(from_kvm_events(&to_kvm_events(&e)), e);

    let d = DebugRegs {
        db: [1, 2, 3, 4],
        dr6: 5,
        dr7: 6,
        flags: 7,
    };
    assert_eq!(from_kvm_debugregs(&to_kvm_debugregs(&d)), d);
}

#[test]
fn xcr0_round_trips_and_defaults_to_zero() {
    assert_eq!(xcr0_of(&xcrs_of(0x7)), 0x7);
    let empty = kvm_bindings::kvm_xcrs::default();
    assert_eq!(xcr0_of(&empty), 0);
}

#[test]
fn xsave_bytes_round_trip_and_length_check() {
    let mut x = kvm_bindings::kvm_xsave::default();
    x.region[0] = 0xDEAD_BEEF;
    x.region[1023] = 0x0BAD_F00D;
    let bytes = xsave_to_bytes(&x);
    assert_eq!(bytes.len(), 4096);
    let back = xsave_from_bytes(&bytes).unwrap();
    assert_eq!(back.region[0], 0xDEAD_BEEF);
    assert_eq!(back.region[1023], 0x0BAD_F00D);

    assert!(matches!(
        xsave_from_bytes(&[0u8; 100]),
        Err(BackendError::InvalidState)
    ));
}

impl SynRun {
    fn set_ready(&self, ready: bool) {
        // SAFETY: plain top-level field of the owned, zeroed `kvm_run`.
        unsafe { (*self.run()).ready_for_interrupt_injection = u8::from(ready) };
    }
    fn request_window(&self) -> u8 {
        // SAFETY: plain top-level field of the owned `kvm_run`.
        unsafe { (*self.run()).request_interrupt_window }
    }
    fn set_request_window(&self, on: bool) {
        // SAFETY: plain top-level field of the owned `kvm_run`.
        unsafe { (*self.run()).request_interrupt_window = u8::from(on) };
    }
}

fn unreachable_guest_mode() -> Result<bool> {
    panic!("guest mode is read only before queuing a vector")
}

#[test]
fn plan_irq_entry_defers_while_l1_is_in_nested_guest_mode() {
    let s = SynRun::new();
    s.set_ready(true);
    s.set_request_window(true);
    assert_eq!(
        plan_irq_entry(s.page(), Some(0x40), true, || Ok(true)).unwrap(),
        IrqEntry::Run
    );
    assert_eq!(s.request_window(), 0);
}

#[test]
fn plan_irq_entry_reports_a_failed_guest_mode_read() {
    let s = SynRun::new();
    s.set_ready(true);
    assert!(
        plan_irq_entry(s.page(), Some(0x40), true, || Err(
            BackendError::InvalidState
        ))
        .is_err()
    );
}

#[test]
fn plan_irq_entry_queues_when_ready() {
    let s = SynRun::new();
    s.set_ready(true);
    s.set_request_window(true);
    assert_eq!(
        plan_irq_entry(s.page(), Some(0x40), true, || Ok(false)).unwrap(),
        IrqEntry::Queue(0x40)
    );
    assert_eq!(s.request_window(), 0, "window request cleared when queuing");
}

#[test]
fn plan_irq_entry_requests_window_when_readiness_is_stale() {
    let s = SynRun::new();
    s.set_ready(true);
    assert_eq!(
        plan_irq_entry(s.page(), Some(0x40), false, unreachable_guest_mode).unwrap(),
        IrqEntry::Run
    );
    assert_eq!(s.request_window(), 1, "window armed until the next exit");
    assert_eq!(
        plan_irq_entry(s.page(), None, false, unreachable_guest_mode).unwrap(),
        IrqEntry::Run
    );
    assert_eq!(s.request_window(), 0);
}

#[test]
fn plan_irq_entry_requests_window_when_not_ready() {
    let s = SynRun::new();
    s.set_ready(false);
    assert_eq!(
        plan_irq_entry(s.page(), Some(0x40), true, unreachable_guest_mode).unwrap(),
        IrqEntry::Run
    );
    assert_eq!(s.request_window(), 1, "window armed when not injectable");
}

#[test]
fn plan_irq_entry_clears_window_when_nothing_pending() {
    let s = SynRun::new();
    s.set_ready(true);
    s.set_request_window(true);
    assert_eq!(
        plan_irq_entry(s.page(), None, true, unreachable_guest_mode).unwrap(),
        IrqEntry::Run
    );
    assert_eq!(s.request_window(), 0, "stale window request cleared");

    let s = SynRun::new();
    s.set_ready(false);
    s.set_request_window(true);
    assert_eq!(
        plan_irq_entry(s.page(), None, true, unreachable_guest_mode).unwrap(),
        IrqEntry::Run
    );
    assert_eq!(s.request_window(), 0);
}

#[test]
fn interrupt_fields_round_trip_through_vcpu_events() {
    let e = VcpuEvents {
        interrupt_injected: 1,
        interrupt_nr: 0x40,
        interrupt_soft: 0,
        interrupt_shadow: 1,
        ..Default::default()
    };
    let k = to_kvm_events(&e);
    assert_eq!(k.interrupt.injected, 1);
    assert_eq!(k.interrupt.nr, 0x40);
    assert_eq!(k.interrupt.shadow, 1);
    let back = from_kvm_events(&k);
    assert_eq!(back.interrupt_injected, 1);
    assert_eq!(back.interrupt_nr, 0x40);
    assert_eq!(back.interrupt_shadow, 1);
    assert_eq!(back, e);
}

#[test]
fn restore_sregs_invalidates_translations_and_installs_exact_snapshot() {
    for cr0 in [0x21, 0x10021, 0x80000021, 0x80010021] {
        let saved = VcpuSregs {
            cr0,
            cr3: 0x1000,
            cr4: 0x20,
            ..VcpuSregs::default()
        };
        let mut writes = Vec::new();
        restore_sregs2_with_flush(&saved, |sregs| {
            writes.push(from_kvm_sregs2(sregs));
            Ok(())
        })
        .unwrap();
        assert_eq!(writes.len(), 2);
        assert_ne!(writes[0].cr0, writes[1].cr0);
        assert_eq!(writes[0].cr0 ^ writes[1].cr0, 0x10000);
        let mut transient = writes[0];
        transient.cr0 = saved.cr0;
        assert_eq!(
            transient, saved,
            "only write protection changes temporarily"
        );
        assert_eq!(writes[1], saved, "the final state is the exact snapshot");
    }
}

#[test]
fn restore_sregs_stops_at_either_failed_write() {
    for failure in [1, 2] {
        let mut calls = 0;
        let result = restore_sregs2_with_flush(&VcpuSregs::default(), |_| {
            calls += 1;
            if calls == failure {
                Err(BackendError::Internal("rejected special registers"))
            } else {
                Ok(())
            }
        });
        assert!(result.is_err());
        assert_eq!(calls, failure);
    }
}

#[test]
fn event_restore_preserves_pending_and_clears_displaced_exceptions() {
    for event in [
        VcpuEvents::default(),
        VcpuEvents {
            exception_pending: 1,
            exception_nr: 13,
            exception_has_error_code: 1,
            ..Default::default()
        },
        VcpuEvents {
            exception_pending: 1,
            exception_nr: 14,
            exception_has_error_code: 1,
            exception_error_code: 7,
            exception_has_payload: 1,
            exception_payload: 0x1234_5000,
            ..Default::default()
        },
    ] {
        let set = to_kvm_restore_events(&event);
        assert_ne!(set.flags & kvm_bindings::KVM_VCPUEVENT_VALID_PAYLOAD, 0);
        let mut restored = from_kvm_events(&set);
        restored.flags = event.flags;
        assert_eq!(restored, event);
    }
}

#[test]
fn snapshot_preparation_requires_interruption_and_clears_its_request() {
    for outcome in 0..3 {
        let run = SynRun::new();
        let guard = StateMutationGuard::default();
        let mut entered = false;
        let mut pending = Pending::None;
        let mut stage = Stage::CLEAR;
        let result =
            prepare_snapshot_run_guarded(run.page(), 7, &mut pending, &mut stage, &guard, || {
                entered = true;
                assert_eq!(run.page().immediate_exit(), 1);
                // SAFETY: the synthetic run page is owned and initialized for the entire test.
                assert_eq!(unsafe { (*run.run()).cr8 }, 7);
                match outcome {
                    0 => Err(std::io::Error::from(std::io::ErrorKind::Interrupted)),
                    1 => Err(std::io::Error::from(std::io::ErrorKind::PermissionDenied)),
                    _ => Ok(()),
                }
            });
        assert!(entered);
        assert_eq!(result.is_ok(), outcome == 0);
        if outcome == 0 {
            assert_eq!(result.unwrap(), None);
        }
        assert_eq!(guard.ensure_healthy().is_ok(), outcome == 0);
        assert_eq!(run.page().immediate_exit(), 0);
    }
}

#[test]
fn snapshot_preparation_drains_a_staged_completion_in_the_same_run() {
    let run = SynRun::new();
    let mut entries = 0;
    let mut pending = Pending::None;
    let mut stage = Stage::AWAITING_FINISH;
    let guard = StateMutationGuard::default();
    let result =
        prepare_snapshot_run_guarded(run.page(), 9, &mut pending, &mut stage, &guard, || {
            entries += 1;
            assert_eq!(run.page().immediate_exit(), 1);
            // SAFETY: the synthetic run page is owned and initialized for the entire test.
            assert_eq!(unsafe { (*run.run()).cr8 }, 9);
            Err(std::io::Error::from(std::io::ErrorKind::Interrupted))
        });
    assert_eq!(entries, 1);
    assert_eq!(result.unwrap(), None);
    assert!(!stage.staged);
    assert_eq!(pending, Pending::None);
    assert!(guard.ensure_healthy().is_ok());
    assert_eq!(run.page().immediate_exit(), 0);
}

#[test]
fn unexpected_completion_exit_retires_the_backend_before_retry() {
    let run = SynRun::new();
    let mut pending = Pending::None;
    let mut stage = Stage::AWAITING_FINISH;
    let guard = StateMutationGuard::default();
    let error =
        prepare_snapshot_run_guarded(run.page(), 0, &mut pending, &mut stage, &guard, || {
            set_reason(&run, KVM_EXIT_HLT);
            Ok(())
        })
        .expect_err("a completion-only entry must reject guest control execution");
    assert!(matches!(error, BackendError::Internal(_)));
    assert!(stage.staged);
    assert!(matches!(
        guard.ensure_healthy(),
        Err(BackendError::Internal("backend state mutation failed"))
    ));
    assert!(matches!(
        prepare_snapshot_run_guarded(run.page(), 0, &mut pending, &mut stage, &guard, || panic!(
            "a retired backend must not retry the uncertain completion"
        )),
        Err(BackendError::Internal("backend state mutation failed"))
    ));
}

#[test]
fn unexpected_finish_exit_retires_the_backend_before_retry() {
    let run = SynRun::new();
    let mut pending = Pending::None;
    let mut stage = Stage::AWAITING_FINISH;
    let guard = StateMutationGuard::default();
    let error =
        finish_staged_completion_guarded(run.page(), &mut pending, &mut stage, &guard, || {
            set_reason(&run, KVM_EXIT_HLT);
            Ok(())
        })
        .expect_err("a completion-only entry must reject guest control execution");
    assert!(matches!(error, BackendError::Internal(_)));
    assert!(stage.staged);
    assert!(matches!(
        guard.ensure_healthy(),
        Err(BackendError::Internal("backend state mutation failed"))
    ));
}

#[test]
fn snapshot_preparation_rejects_run_inputs_before_entering() {
    for field in 0..3 {
        let run = SynRun::new();
        // SAFETY: all three fields are initialized members of the owned synthetic run page.
        unsafe {
            match field {
                0 => (*run.run()).kvm_valid_regs = 1,
                1 => (*run.run()).kvm_dirty_regs = 1,
                _ => (*run.run()).immediate_exit = 1,
            }
        }
        let mut pending = Pending::None;
        let mut stage = Stage::CLEAR;
        assert!(matches!(
            prepare_snapshot_run(run.page(), 7, &mut pending, &mut stage, || panic!(
                "must not enter with armed inputs"
            )),
            Err(BackendError::InvalidState)
        ));
        // SAFETY: the run page remains owned and live after the rejected preparation.
        assert_eq!(unsafe { (*run.run()).cr8 }, 0);
        assert_eq!(run.page().immediate_exit(), u8::from(field == 2));
    }
}

#[test]
fn acknowledged_out_then_finish_exit_then_restore_drains_with_one_entry() {
    let s = SynRun::new();
    set_out_tick(&s);

    let (exit, mut pending) = decode_exit(s.page()).unwrap().unwrap();
    let mut stage = Stage::of(&exit, pending);
    assert!(stage.drains_on_state_read());
    check_completion_clear(pending, stage, false)
        .expect("an acknowledged OUT keeps run, state reads, and restore available");

    let mut entries = 0;
    let continuation = finish_staged_completion(s.page(), &mut pending, &mut stage, || {
        entries += 1;
        assert_eq!(s.page().immediate_exit(), 1);
        Err(std::io::Error::from_raw_os_error(libc::EINTR))
    })
    .unwrap();
    assert_eq!(continuation, None);
    assert_eq!(entries, 1, "restore retires the OUT with exactly one entry");
    assert_eq!(stage, Stage::CLEAR);
    assert_eq!(pending, Pending::None);
    assert_eq!(s.page().immediate_exit(), 0);
    check_completion_clear(pending, stage, false).unwrap();
}

#[test]
fn unacknowledged_mmio_write_blocks_state_reads_before_finish_exit() {
    let s = SynRun::new();
    set_mmio_store(&s, 0xFEE0_0080, 0x20);

    let (exit, pending) = decode_exit(s.page()).unwrap().unwrap();
    let stage = Stage::of(&exit, pending);
    assert_eq!(stage, Stage::AWAITING_FINISH);
    assert!(!stage.drains_on_state_read());
    assert!(matches!(
        check_completion_clear(pending, stage, false),
        Err(BackendError::PendingCompletion)
    ));
    assert!(matches!(
        check_completion_clear(pending, stage, true),
        Err(BackendError::PendingCompletion)
    ));
    check_completion_clear(pending, Stage::CLEAR, false)
        .expect("finish_exit's own entry clears the stage and reopens state reads");
}

#[test]
fn mmio_write_continuation_of_an_acknowledged_out_drain_is_unacknowledged() {
    let s = SynRun::new();
    set_out_tick(&s);

    let (exit, mut pending) = decode_exit(s.page()).unwrap().unwrap();
    let mut stage = Stage::of(&exit, pending);
    assert!(stage.drains_on_state_read());

    let mut entries = 0;
    let continuation = prepare_snapshot_run(s.page(), 3, &mut pending, &mut stage, || {
        entries += 1;
        assert_eq!(s.page().immediate_exit(), 1);
        set_mmio_store(&s, 0xFEE0_00B0, 0);
        Ok(())
    })
    .unwrap();
    assert_eq!(entries, 1);
    assert_eq!(
        continuation,
        Some(Exit::Common(CommonExit::Mmio {
            gpa: Gpa(0xFEE0_00B0),
            size: 4,
            write: Some(0)
        }))
    );
    assert_eq!(pending, Pending::None);
    assert_eq!(
        stage,
        Stage::AWAITING_FINISH,
        "a store continuation waits for finish_exit even when the drained OUT was acknowledged"
    );
    assert!(
        !stage.drains_on_state_read(),
        "save reads the vCPU as it stands without an entry"
    );
    assert!(matches!(
        check_completion_clear(pending, stage, true),
        Err(BackendError::PendingCompletion)
    ));
    assert!(matches!(
        check_completion_clear(pending, stage, false),
        Err(BackendError::PendingCompletion)
    ));

    let mut finish_entries = 0;
    let next = finish_staged_completion(s.page(), &mut pending, &mut stage, || {
        finish_entries += 1;
        Err(std::io::Error::from_raw_os_error(libc::EINTR))
    })
    .unwrap();
    assert_eq!(next, None);
    assert_eq!(finish_entries, 1);
    assert_eq!(stage, Stage::CLEAR);
    check_completion_clear(pending, stage, false).unwrap();
}

fn set_out_tick(s: &SynRun) {
    set_reason(s, KVM_EXIT_IO);
    // SAFETY: union sub-field writes of an owned, zeroed kvm_run.
    unsafe {
        let io = &mut (*s.run()).__bindgen_anon_1.io;
        io.direction = 1;
        io.size = 4;
        io.port = 0x0CA3;
        io.count = 1;
        io.data_offset = PIO_OFF as u64;
    }
    s.set_byte(PIO_OFF, 1);
}

fn set_mmio_store(s: &SynRun, gpa: u64, value: u32) {
    set_reason(s, KVM_EXIT_MMIO);
    // SAFETY: union sub-field writes of an owned kvm_run.
    unsafe {
        let m = &mut (*s.run()).__bindgen_anon_1.mmio;
        m.phys_addr = gpa;
        m.len = 4;
        m.is_write = 1;
        m.data[..4].copy_from_slice(&value.to_le_bytes());
    }
}

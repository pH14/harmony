// SPDX-License-Identifier: AGPL-3.0-or-later

use std::io;
use std::os::fd::{AsRawFd, OwnedFd};
use std::process::Command;
#[cfg(test)]
use std::sync::atomic::{AtomicBool, AtomicI32, Ordering};
use std::time::{Duration, Instant};

use environment::channel::{HandlerFingerprint, Question, ServiceHandler};
use environment::input_spec::ServiceFactory;
use hypercall_proto::MAX_FRAME;
use rustix::event::{PollFd, PollFlags, Timespec, poll};
use sha2::{Digest, Sha256};
use snapshot_store::{PAGE_SIZE, PageHash};
use tempfile::TempDir;

use crate::bridge::{self, Event, Reader, STAMP_LEN, Services, Signal};
use crate::launch::{Exit, ExitReason, Guest, Launch, LaunchError, PHYSMEM_FD};
use crate::memory::{
    Checkpoints, GuestMemory, IMAGE_PAGES, MemoryError, Snapshot, data_extents, image_state,
};
use crate::profile::VerifiedProfile;

const CONTROL_MAGIC: u32 = 0x3143_5548;
const CAPTURE: u32 = 1;
const RESTORE: u32 = 2;
const MEMORY: u32 = 4;
const CONTINUE: u32 = 5;
const MEMORY_ALL: i64 = 1;
const MEMORY_CHUNK: usize = 65536;
const OMIT_HOST_MEMORY: u64 = 1;
const CONTROL_LEN: usize = 16;
const POLL: Duration = Duration::from_millis(5);
const RESTORE_ARGUMENT: &str = "harmony_restore";
const SIDECAR_MAGIC: &[u8; 8] = b"HUMLCKP3";
#[cfg(test)]
static TEST_HOLD_TERMINAL_POLL: AtomicBool = AtomicBool::new(false);
#[cfg(test)]
static TEST_TERMINAL_POLL_READY: AtomicBool = AtomicBool::new(false);
#[cfg(test)]
static TEST_TERMINAL_POLL_PID: AtomicI32 = AtomicI32::new(0);

fn checked_sidecar(
    sidecar: &[u8],
    expected_physical_bytes: u64,
) -> Result<(u64, Reader<'_>), SessionError> {
    let mut reader = Reader(
        sidecar
            .strip_prefix(SIDECAR_MAGIC)
            .ok_or_else(|| SessionError::Protocol("checkpoint sidecar: magic".into()))?,
    );
    let image_bytes = reader.u64().map_err(SessionError::Protocol)?;
    if image_bytes > crate::memory::IMAGE_BYTES as u64 {
        return Err(MemoryError::ImageTooLarge(image_bytes).into());
    }
    let physical_bytes = reader.u64().map_err(SessionError::Protocol)?;
    if physical_bytes != expected_physical_bytes {
        return Err(MemoryError::ImportedMemorySize {
            got: physical_bytes,
            expected: expected_physical_bytes,
        }
        .into());
    }
    Ok((image_bytes, reader))
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Stop {
    Event,
    Deadline(u64),
    SnapshotPoint(u64),
    Violation { moment: u64, id: u32, data: Vec<u8> },
    Exhausted(u64),
    Decision { moment: u64, question: Question },
    Closed,
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum Until {
    Events(usize),
    Moment(u64),
    SnapshotPoint(u64),
    End,
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Capture {
    pub omit_host_memory: bool,
}

#[derive(Debug, thiserror::Error)]
pub enum SessionError {
    #[error(transparent)]
    Launch(#[from] LaunchError),
    #[error(transparent)]
    Io(#[from] io::Error),
    #[error(transparent)]
    Memory(#[from] MemoryError),
    #[error("a session needs a bridge")]
    NoBridge,
    #[error("the guest is not paused at a request")]
    NotPaused,
    #[error("the guest sent no request for {0:?} of host time")]
    Hung(Duration),
    #[error("event {0} is not ahead of the guest")]
    Behind(usize),
    #[error("the guest stopped: {0:?}")]
    Stopped(ExitReason),
    #[error("UML state hash is unavailable: guest memory has no canonical cross-process digest")]
    StateHashUnavailable,
    #[error("bridge protocol: {0}")]
    Protocol(String),
    #[error("service resolution: {0}")]
    BadResolution(String),
    #[error("the guest refused the {operation}: errno {errno}")]
    Refused { operation: &'static str, errno: i64 },
    #[error("restoring at boot failed: {error}; console: {console}")]
    Boot {
        error: Box<SessionError>,
        console: String,
    },
}

#[derive(Debug)]
pub struct Checkpoint {
    memory: Snapshot,
    services: Services,
    request: Vec<u8>,
}

enum Ack {
    Done(i64),
    Memory(Report),
}

enum Report {
    All,
    Dirty(Vec<u64>),
}

pub struct Session {
    guest: Guest,
    socket: OwnedFd,
    services: Services,
    pending: Option<Vec<u8>>,
    failure: Option<String>,
    progress_limit: Option<Duration>,
    request: Vec<u8>,
    response: Vec<u8>,
    memory: GuestMemory,
    checkpoints: Checkpoints,
    memory_at: Option<Snapshot>,
    image_at: Option<Snapshot>,
    audit: bool,
    missed: Vec<u64>,
    host_guard: HostGuard,
}

#[derive(Clone, Copy)]
enum HostGuard {
    Strict(host_code_identity::StrictExecutableGuard),
    #[cfg(test)]
    TestFixture,
}

fn capture_host_guard() -> Result<HostGuard, SessionError> {
    #[cfg(target_os = "linux")]
    host_code_identity::reject_loader_overrides()?;
    Ok(HostGuard::Strict(
        host_code_identity::StrictExecutableGuard::capture()?.1,
    ))
}

fn check_host_guard(expected: HostGuard) -> Result<(), SessionError> {
    match expected {
        HostGuard::Strict(admitted) => {
            #[cfg(target_os = "linux")]
            host_code_identity::reject_loader_overrides()?;
            admitted.check()?;
        }
        #[cfg(test)]
        HostGuard::TestFixture => {}
    }
    Ok(())
}

impl Checkpoint {
    pub fn events(&self) -> &[Event] {
        &self.services.events
    }

    pub fn bytes(&self) -> Result<u64, SessionError> {
        Ok(self.memory.image_bytes()?)
    }

    pub fn owned_pages(&self) -> u64 {
        self.memory.owned_pages()
    }

    pub fn moment(&self) -> u64 {
        stamp(&self.request).unwrap_or(self.services.latest)
    }

    pub fn with_bridge_of(&self, other: &Checkpoint) -> Checkpoint {
        Checkpoint {
            memory: self.memory.share(),
            services: other.services.clone(),
            request: other.request.clone(),
        }
    }

    pub fn digest(&self) -> Result<[u8; 32], SessionError> {
        let mut digest = Sha256::new();
        digest.update(b"harmony-uml-checkpoint-v2\0");
        self.memory.digest(&mut digest)?;
        digest.update(self.sidecar()?);
        Ok(digest.finalize().into())
    }

    pub fn sidecar(&self) -> Result<Vec<u8>, SessionError> {
        let services = self.services.encode().map_err(SessionError::Protocol)?;
        let mut out =
            Vec::with_capacity(SIDECAR_MAGIC.len() + 32 + services.len() + self.request.len());
        out.extend_from_slice(SIDECAR_MAGIC);
        out.extend_from_slice(&self.bytes()?.to_le_bytes());
        out.extend_from_slice(&self.memory.physmem_bytes()?.to_le_bytes());
        out.extend_from_slice(&(services.len() as u64).to_le_bytes());
        out.extend_from_slice(&services);
        out.extend_from_slice(&(self.request.len() as u64).to_le_bytes());
        out.extend_from_slice(&self.request);
        Ok(out)
    }
}

impl Checkpoints {
    pub fn full<R>(
        &self,
        target: &Checkpoint,
        use_pages: impl FnOnce(&[(u64, &PageHash, &[u8; PAGE_SIZE])]) -> R,
    ) -> Result<R, SessionError> {
        self.require_owned_snapshot(&target.memory)?;
        let zero = self.zero()?;
        Ok(self.delta_pages(&zero, None, &target.memory, |delta| {
            use_pages(&delta.changed)
        })?)
    }

    pub fn import_full(
        &self,
        near: &Checkpoint,
        pages: &[(u64, &PageHash, &[u8; PAGE_SIZE])],
        sidecar: &[u8],
        factory: &ServiceFactory,
    ) -> Result<Checkpoint, SessionError> {
        self.require_owned_snapshot(&near.memory)?;
        let expected_physical_bytes = self.held()?.physmem_bytes as u64;
        checked_sidecar(sidecar, expected_physical_bytes)?;
        let base = Checkpoint {
            memory: self.zero()?,
            services: near.services.clone(),
            request: near.request.clone(),
        };
        self.import(&base, near, pages, sidecar, factory)
    }

    pub fn delta<R>(
        &self,
        base: &Checkpoint,
        parent: Option<&Checkpoint>,
        target: &Checkpoint,
        use_delta: impl FnOnce(&[(u64, &PageHash, &[u8; PAGE_SIZE])], &[u64]) -> R,
    ) -> Result<R, SessionError> {
        Ok(self.delta_pages(
            &base.memory,
            parent.map(|parent| &parent.memory),
            &target.memory,
            |delta| use_delta(&delta.changed, &delta.reverted),
        )?)
    }

    pub fn import(
        &self,
        base: &Checkpoint,
        near: &Checkpoint,
        pages: &[(u64, &PageHash, &[u8; PAGE_SIZE])],
        sidecar: &[u8],
        factory: &ServiceFactory,
    ) -> Result<Checkpoint, SessionError> {
        self.require_owned_snapshot(&base.memory)?;
        self.require_owned_snapshot(&near.memory)?;
        let malformed = |what: &str| SessionError::Protocol(format!("checkpoint sidecar: {what}"));
        let expected_physical_bytes = self.held()?.physmem_bytes as u64;
        let (image_bytes, mut reader) = checked_sidecar(sidecar, expected_physical_bytes)?;
        let length = |reader: &mut Reader<'_>| {
            reader
                .u64()
                .and_then(|length| usize::try_from(length).map_err(|error| error.to_string()))
                .map_err(SessionError::Protocol)
        };
        let services = length(&mut reader)
            .and_then(|services| reader.take(services).map_err(SessionError::Protocol))?;
        let services = Services::decode(services, factory).map_err(SessionError::Protocol)?;
        let request = length(&mut reader)
            .and_then(|request| reader.take(request).map_err(SessionError::Protocol))?
            .to_vec();
        if !reader.0.is_empty() {
            return Err(malformed("trailing bytes"));
        }
        if !(STAMP_LEN..=STAMP_LEN + MAX_FRAME).contains(&request.len()) {
            return Err(malformed("pending request length"));
        }
        if stamp(&request).is_some_and(|moment| moment < services.latest) {
            return Err(malformed("pending request is behind the recorded services"));
        }
        let memory = self.import_pages(&base.memory, &near.memory, pages, image_bytes)?;
        Ok(Checkpoint {
            memory,
            services,
            request,
        })
    }
}

impl Session {
    pub fn spawn(
        launch: &Launch,
        profile: &VerifiedProfile,
        checkpoints: &Checkpoints,
        restore: Option<&Checkpoint>,
        progress_limit: Option<Duration>,
    ) -> Result<Self, SessionError> {
        let work = launch.work_directory()?;
        let command = launch.command(profile, work.path())?;
        Self::start(command, work, launch, checkpoints, restore, progress_limit)
    }

    pub fn start(
        command: Command,
        work: TempDir,
        launch: &Launch,
        checkpoints: &Checkpoints,
        restore: Option<&Checkpoint>,
        progress_limit: Option<Duration>,
    ) -> Result<Self, SessionError> {
        let host_guard = capture_host_guard()?;
        Self::start_with_guard(
            command,
            work,
            launch,
            checkpoints,
            restore,
            progress_limit,
            host_guard,
        )
    }

    fn start_with_guard(
        mut command: Command,
        work: TempDir,
        launch: &Launch,
        checkpoints: &Checkpoints,
        restore: Option<&Checkpoint>,
        progress_limit: Option<Duration>,
        host_guard: HostGuard,
    ) -> Result<Self, SessionError> {
        if let Some(checkpoint) = restore {
            checkpoints.require_owned_snapshot(&checkpoint.memory)?;
        }
        let bridge = launch.bridge.ok_or(SessionError::NoBridge)?;
        let memory = GuestMemory::new()?;
        command.arg(format!("harmony_physmem={PHYSMEM_FD}"));
        if restore.is_some() {
            command.arg(RESTORE_ARGUMENT);
        }
        let (guest, socket) = Guest::start_bridged(
            command,
            work,
            launch,
            false,
            Some(memory.physmem.try_clone()?),
        )?;
        let socket = socket.ok_or(SessionError::NoBridge)?;
        check_host_guard(host_guard)?;
        let mut session = Self {
            guest,
            socket,
            services: Services::new(bridge.seed),
            pending: None,
            failure: None,
            progress_limit,
            request: vec![0; STAMP_LEN + MAX_FRAME],
            response: vec![0; MAX_FRAME],
            memory,
            checkpoints: checkpoints.clone(),
            memory_at: None,
            image_at: None,
            audit: false,
            missed: Vec::new(),
            host_guard,
        };
        if let Some(checkpoint) = restore
            && let Err(error) = session.restore_at_boot(checkpoint)
        {
            return Err(SessionError::Boot {
                error: Box::new(error),
                console: session.console_tail(),
            });
        }
        check_host_guard(host_guard)?;
        Ok(session)
    }

    fn restore_at_boot(&mut self, checkpoint: &Checkpoint) -> Result<(), SessionError> {
        let length = self.receive()?;
        if length != STAMP_LEN {
            return Err(SessionError::Protocol(format!(
                "expected the restore request, received {length} bytes"
            )));
        }
        self.restore_from(checkpoint)
    }

    pub fn console_tail(&self) -> String {
        let tail = self.guest.console_tail();
        String::from_utf8_lossy(&tail[tail.len().saturating_sub(4096)..]).into_owned()
    }

    pub fn events(&self) -> &[Event] {
        &self.services.events
    }

    pub fn moment(&self) -> u64 {
        self.pending
            .as_deref()
            .and_then(stamp)
            .unwrap_or(self.services.latest)
    }

    pub fn branch(
        &mut self,
        seed: u64,
        handler: Box<dyn ServiceHandler>,
        payloads: Vec<Vec<u8>>,
        coverage_schedule: Option<environment::channel::CoverageSchedule>,
    ) -> Result<(), SessionError> {
        check_host_guard(self.host_guard)?;
        let result = self
            .services
            .branch(seed, handler, payloads, coverage_schedule)
            .map_err(SessionError::Protocol);
        check_host_guard(self.host_guard)?;
        result
    }

    pub fn run_to(&mut self, events: usize) -> Result<Stop, SessionError> {
        if events <= self.services.events.len() {
            return Err(SessionError::Behind(events));
        }
        self.serve(Until::Events(events))
    }

    pub fn run_until(&mut self, deadline: u64) -> Result<Stop, SessionError> {
        self.serve(Until::Moment(deadline))
    }

    pub fn resolve_and_run(
        &mut self,
        deadline: u64,
        moment: u64,
        service: u16,
        id: u64,
        answer: &[u8],
    ) -> Result<Stop, SessionError> {
        check_host_guard(self.host_guard)?;
        let request = self
            .pending
            .as_deref()
            .ok_or_else(|| SessionError::BadResolution("no service decision is pending".into()))?;
        let prepared = self
            .services
            .prepare_resolution(request, moment, service, id, answer);
        check_host_guard(self.host_guard)?;
        let (services, response) = prepared.map_err(SessionError::BadResolution)?;
        let sent = bridge::send(&self.socket, &response);
        self.transport_result(sent)?;
        self.services = services;
        self.pending = None;
        self.serve(Until::Moment(deadline))
    }

    pub fn run_to_snapshot_point(&mut self, deadline: u64) -> Result<Stop, SessionError> {
        self.serve(Until::SnapshotPoint(deadline))
    }

    pub fn paused(&self) -> bool {
        self.pending.is_some()
    }

    pub fn service_handler_fingerprint(&self) -> Result<HandlerFingerprint, SessionError> {
        self.services
            .handler_fingerprint()
            .map_err(|error| SessionError::Protocol(format!("service handler: {error}")))
    }

    pub fn verify_service_handler_unchanged(
        &self,
        before: &HandlerFingerprint,
    ) -> Result<(), SessionError> {
        self.services
            .verify_handler_unchanged(before)
            .map_err(|error| SessionError::Protocol(format!("service handler: {error}")))
    }

    pub fn state_hash(&self) -> Result<[u8; 32], SessionError> {
        Err(SessionError::StateHashUnavailable)
    }

    pub fn bridge_state_digest(&self) -> Result<[u8; 32], SessionError> {
        check_host_guard(self.host_guard)?;
        let mut digest = Sha256::new();
        digest.update(b"harmony-uml-bridge-state-v1\0");
        digest.update(self.services.encode().map_err(SessionError::Protocol)?);
        if let Some(request) = &self.pending {
            digest.update(request);
        }
        let digest = digest.finalize().into();
        check_host_guard(self.host_guard)?;
        Ok(digest)
    }

    pub fn run(mut self) -> Result<Exit, SessionError> {
        self.serve(Until::End)?;
        let reason = loop {
            if let Some(reason) = self.guest.stopped()? {
                break reason;
            }
            std::thread::sleep(POLL);
        };
        self.finish(reason)
    }

    pub fn shutdown(&mut self) -> Result<(), SessionError> {
        self.guest.shutdown().map_err(Into::into)
    }

    pub fn kill(mut self) -> Result<Exit, SessionError> {
        self.finish(ExitReason::Killed)
    }

    pub fn settle_terminal_console(&mut self, limit: Duration) -> Result<ExitReason, SessionError> {
        let waited = now();
        let reason = loop {
            match self.guest.stopped()? {
                Some(
                    reason @ (ExitReason::Exited(_)
                    | ExitReason::Signaled(_)
                    | ExitReason::GuestPanic),
                ) => break reason,
                Some(reason) => return Err(SessionError::Stopped(reason)),
                None if waited.elapsed() >= limit => return Err(SessionError::Hung(limit)),
                None => std::thread::sleep(POLL),
            }
        };
        let exit = self.guest.finish(reason)?;
        if !exit.leftovers.is_empty() {
            return Err(SessionError::Protocol(format!(
                "guest left {} host processes after terminal stop",
                exit.leftovers.len()
            )));
        }
        match exit.reason {
            ExitReason::Exited(_) | ExitReason::GuestPanic => Ok(exit.reason),
            reason => Err(SessionError::Stopped(reason)),
        }
    }

    pub fn capture(&mut self, capture: Capture) -> Result<Checkpoint, SessionError> {
        check_host_guard(self.host_guard)?;
        let request = self.pending.clone().ok_or(SessionError::NotPaused)?;
        let flags = if capture.omit_host_memory {
            OMIT_HOST_MEMORY
        } else {
            0
        };
        self.send_control(CAPTURE, flags, true)?;
        let Ack::Memory(report) = self.acknowledgement(CAPTURE, "capture")? else {
            return Err(SessionError::Protocol(
                "the guest captured without reporting its memory".into(),
            ));
        };
        let previous = self.memory_at.take();
        let previous_image = self.image_at.take();
        let physmem_bytes = self.memory.map()?;
        let checkpoints = self.checkpoints.clone();
        let mut pages = checkpoints.pages(physmem_bytes)?;
        let parent = match (&report, &previous) {
            (Report::Dirty(_), Some(at)) => at.id(),
            _ => pages.root,
        };
        let parent_image = pages.image_bytes(parent)?;
        let written = self.physmem_pages(&report, physmem_bytes)?;
        let audit = if self.audit && matches!(report, Report::Dirty(_)) && previous.is_some() {
            Some(self.audit_candidates(&pages, parent, physmem_bytes)?)
        } else {
            None
        };
        // SAFETY: the guest waits for CONTINUE, so its physical memory does not
        // change, and the image file keeps its full length until the guest
        // writes the image after CONTINUE.
        let bytes = unsafe { self.memory.bytes() }.ok_or(MemoryError::Empty)?;
        if let Some(candidates) = audit {
            let missed = unexpected_pages(&pages, parent, candidates, &written, bytes)?;
            self.missed.extend(missed);
        }
        let mut builder = pages.store.derive(parent).map_err(MemoryError::from)?;
        for gfn in written {
            let at = usize::try_from(gfn).map_err(io::Error::other)? * PAGE_SIZE;
            builder
                .write_changed_page(gfn, &bytes[at..at + PAGE_SIZE])
                .map_err(MemoryError::from)?;
        }
        self.send_continue()?;
        let outcome = match self.acknowledgement(CAPTURE, "capture") {
            Ok(Ack::Done(length)) => {
                let length = length.unsigned_abs();
                self.memory
                    .restore_image_size(length)
                    .map(|()| length)
                    .map_err(SessionError::from)
            }
            Ok(Ack::Memory(_)) => Err(SessionError::Protocol(
                "the guest reported its memory twice".into(),
            )),
            Err(error) => Err(error),
        };
        let length = match outcome {
            Ok(length) => length,
            Err(error) => {
                let id = builder.seal(image_state(parent_image));
                drop(pages);
                self.memory_at = Some(checkpoints.adopt(id));
                return Err(error);
            }
        };
        let image_pages = length.max(parent_image).div_ceil(PAGE_SIZE as u64);
        // SAFETY: the guest has written the image and waits for the bridge
        // reply, so neither range changes, and the image file has its full
        // length again.
        let bytes = unsafe { self.memory.bytes() }.ok_or(MemoryError::Empty)?;
        for gfn in 0..image_pages {
            let at = usize::try_from(gfn).map_err(io::Error::other)? * PAGE_SIZE;
            builder
                .write_changed_page(gfn, &bytes[at..at + PAGE_SIZE])
                .map_err(MemoryError::from)?;
        }
        let id = builder.seal(image_state(length));
        let id = pages.shorten(id, bytes)?;
        drop(pages);
        drop(previous);
        drop(previous_image);
        let memory = checkpoints.adopt(id);
        self.memory_at = Some(memory.share());
        self.image_at = Some(memory.share());
        check_host_guard(self.host_guard)?;
        Ok(Checkpoint {
            memory,
            services: self.services.clone(),
            request,
        })
    }

    pub fn restore(&mut self, checkpoint: &Checkpoint) -> Result<(), SessionError> {
        check_host_guard(self.host_guard)?;
        if self.pending.is_none() {
            return Err(SessionError::NotPaused);
        }
        let result = self.restore_from(checkpoint);
        check_host_guard(self.host_guard)?;
        result
    }

    fn restore_from(&mut self, checkpoint: &Checkpoint) -> Result<(), SessionError> {
        self.checkpoints
            .require_owned_snapshot(&checkpoint.memory)?;
        let physmem_bytes = self.memory.map()?;
        let checkpoints = self.checkpoints.clone();
        let target = checkpoint.memory.id();
        let previous_image = self.image_at.take();
        {
            let pages = checkpoints.pages(physmem_bytes)?;
            let from = match &previous_image {
                Some(at) => at.id(),
                None => {
                    self.memory.clear_image()?;
                    pages.root
                }
            };
            // SAFETY: the image file has its full length and only the host
            // writes it while the guest is paused.
            let bytes = unsafe { self.memory.bytes() }.ok_or(MemoryError::Empty)?;
            let plan = pages
                .store
                .restore_pages(Some(from), target, &[])
                .map_err(MemoryError::from)?;
            for (gfn, data) in plan.into_iter().take_while(|(gfn, _)| *gfn < IMAGE_PAGES) {
                let at = usize::try_from(gfn).map_err(io::Error::other)? * PAGE_SIZE;
                bytes[at..at + PAGE_SIZE].copy_from_slice(data);
            }
        }
        drop(previous_image);
        self.image_at = Some(checkpoint.memory.share());
        self.send_control(RESTORE, 0, true)?;
        let Ack::Memory(report) = self.acknowledgement(RESTORE, "restore")? else {
            return Err(SessionError::Protocol(
                "the guest restored without reporting its memory".into(),
            ));
        };
        let previous = self.memory_at.take();
        {
            let pages = checkpoints.pages(physmem_bytes)?;
            let (from, dirty) = match (&report, &previous) {
                (Report::Dirty(_), Some(at)) => {
                    (at.id(), self.physmem_pages(&report, physmem_bytes)?)
                }
                _ => {
                    self.memory.clear_physmem()?;
                    (pages.root, Vec::new())
                }
            };
            let audit = if self.audit {
                Some(self.audit_candidates(&pages, target, physmem_bytes)?)
            } else {
                None
            };
            // SAFETY: the guest waits for CONTINUE, so only the host touches
            // its physical memory until then.
            let bytes = unsafe { self.memory.bytes() }.ok_or(MemoryError::Empty)?;
            let plan = pages
                .store
                .restore_pages(Some(from), target, &dirty)
                .map_err(MemoryError::from)?;
            for (gfn, data) in plan {
                if gfn < IMAGE_PAGES {
                    continue;
                }
                let at = usize::try_from(gfn).map_err(io::Error::other)? * PAGE_SIZE;
                bytes[at..at + PAGE_SIZE].copy_from_slice(data);
            }
            if let Some(candidates) = audit {
                let missed = unexpected_pages(&pages, target, candidates, &[], bytes)?;
                self.missed.extend(missed);
            }
        }
        drop(previous);
        self.memory_at = Some(checkpoint.memory.share());
        self.send_continue()?;
        let Ack::Done(_) = self.acknowledgement(RESTORE, "restore")? else {
            return Err(SessionError::Protocol(
                "the guest reported its memory twice".into(),
            ));
        };
        self.services = checkpoint.services.clone();
        self.pending = Some(checkpoint.request.clone());
        self.guest.reset_console()?;
        Ok(())
    }

    pub fn set_audit(&mut self, audit: bool) {
        self.audit = audit;
    }

    pub fn missed_writes(&self) -> &[u64] {
        &self.missed
    }

    fn audit_candidates(
        &self,
        pages: &crate::memory::Pages,
        expected: snapshot_store::SnapshotId,
        physmem_bytes: usize,
    ) -> Result<Vec<u64>, SessionError> {
        let mut candidates = self.physmem_pages(&Report::All, physmem_bytes)?;
        candidates.extend(
            pages
                .store
                .restore_pages(Some(pages.root), expected, &[])
                .map_err(MemoryError::from)?
                .into_iter()
                .map(|(gfn, _)| gfn)
                .filter(|&gfn| gfn >= IMAGE_PAGES),
        );
        candidates.sort_unstable();
        candidates.dedup();
        Ok(candidates)
    }

    fn physmem_pages(&self, report: &Report, physmem_bytes: usize) -> io::Result<Vec<u64>> {
        let frames = (physmem_bytes / PAGE_SIZE) as u64;
        Ok(match report {
            Report::Dirty(frames_written) => frames_written
                .iter()
                .filter(|&&frame| frame < frames)
                .map(|frame| IMAGE_PAGES + frame)
                .collect(),
            Report::All => data_extents(&self.memory.physmem, physmem_bytes as u64)?
                .into_iter()
                .flat_map(|(offset, length)| {
                    let first = offset / PAGE_SIZE as u64;
                    first..(offset + length).div_ceil(PAGE_SIZE as u64)
                })
                .map(|frame| IMAGE_PAGES + frame)
                .collect(),
        })
    }

    fn serve(&mut self, until: Until) -> Result<Stop, SessionError> {
        check_host_guard(self.host_guard)?;
        let result = self.serve_inner(until);
        check_host_guard(self.host_guard)?;
        result
    }

    fn serve_inner(&mut self, until: Until) -> Result<Stop, SessionError> {
        if let Some(moment) = self.pending.as_deref().and_then(stamp)
            && matches!(
                until,
                Until::Moment(deadline) | Until::SnapshotPoint(deadline) if moment >= deadline
            )
        {
            return Ok(Stop::Deadline(moment));
        }
        let mut held = self.pending.take();
        let mut due = None;
        let mut snapshot_point = false;
        loop {
            let length = if let Some(request) = held.take() {
                self.request[..request.len()].copy_from_slice(&request);
                request.len()
            } else {
                let length = match self.receive() {
                    Ok(0) => return Ok(due.unwrap_or(Stop::Closed)),
                    Ok(length) => length,
                    Err(error @ SessionError::Stopped(ExitReason::HostFailure)) => {
                        return Err(error);
                    }
                    Err(SessionError::Stopped(_)) => return Ok(due.unwrap_or(Stop::Closed)),
                    Err(error) => return Err(error),
                };
                if length > STAMP_LEN + MAX_FRAME {
                    return Err(SessionError::Protocol(format!("request of {length} bytes")));
                }
                let moment = stamp(&self.request[..length])
                    .ok_or_else(|| SessionError::Protocol(format!("request of {length} bytes")))?;
                let stop = match until {
                    _ if due.is_some() => due.take(),
                    Until::SnapshotPoint(_) if snapshot_point => Some(Stop::SnapshotPoint(moment)),
                    Until::Moment(deadline) | Until::SnapshotPoint(deadline)
                        if moment >= deadline =>
                    {
                        Some(Stop::Deadline(moment))
                    }
                    Until::Events(count) if self.services.events.len() >= count => {
                        Some(Stop::Event)
                    }
                    _ => None,
                };
                if let Some(stop) = stop {
                    self.pending = Some(self.request[..length].to_vec());
                    return Ok(stop);
                }
                length
            };
            let host_guard = self.host_guard;
            let reply = match self.services.exchange_guarded(
                || check_host_guard(host_guard).map_err(|error| error.to_string()),
                &self.request[..length],
                &mut self.response,
            ) {
                Ok(reply) => reply,
                Err(failure) => {
                    self.failure = Some(failure.clone());
                    return Err(SessionError::Protocol(failure));
                }
            };
            check_host_guard(self.host_guard)?;
            if let Some(Signal::Decision(question)) = &reply.signal {
                self.pending = Some(self.request[..length].to_vec());
                return Ok(Stop::Decision {
                    moment: self.services.latest,
                    question: question.clone(),
                });
            }
            let sent = bridge::send(&self.socket, &self.response[..reply.length]);
            self.transport_result(sent)?;
            let moment = self.services.latest;
            match reply.signal {
                Some(_) if until == Until::End => {}
                Some(Signal::Violation { id, data }) => {
                    due = Some(Stop::Violation { moment, id, data });
                }
                Some(Signal::Exhausted) => due = Some(Stop::Exhausted(moment)),
                Some(Signal::SnapshotPoint) => snapshot_point = true,
                Some(Signal::Decision(_)) => unreachable!(),
                None => {}
            }
        }
    }

    fn poll_bridge(&self, timeout: &Timespec) -> io::Result<PollFlags> {
        let mut waiting = [PollFd::new(&self.socket, PollFlags::IN | PollFlags::RDHUP)];
        match poll(&mut waiting, Some(timeout)) {
            Ok(_) => Ok(waiting[0].revents()),
            Err(rustix::io::Errno::INTR) => Ok(PollFlags::empty()),
            Err(error) => Err(error.into()),
        }
    }

    fn disconnected(&mut self, waited: Instant) -> SessionError {
        loop {
            match self.guest.stopped() {
                Ok(Some(reason)) => return SessionError::Stopped(reason),
                Err(error) => return error.into(),
                Ok(None) => {}
            }
            if let Some(limit) = self.progress_limit
                && waited.elapsed() >= limit
            {
                return SessionError::Hung(limit);
            }
            std::thread::sleep(POLL);
        }
    }

    fn transport_result<T>(&mut self, result: io::Result<T>) -> Result<T, SessionError> {
        match result {
            Ok(value) => Ok(value),
            Err(error)
                if matches!(
                    error.kind(),
                    io::ErrorKind::BrokenPipe
                        | io::ErrorKind::ConnectionReset
                        | io::ErrorKind::ConnectionAborted
                        | io::ErrorKind::NotConnected
                        | io::ErrorKind::UnexpectedEof
                ) =>
            {
                Err(self.disconnected(now()))
            }
            Err(error) => Err(error.into()),
        }
    }

    fn receive(&mut self) -> Result<usize, SessionError> {
        let waited = now();
        let timeout = Timespec::try_from(POLL).map_err(io::Error::other)?;
        loop {
            let ready = self.poll_bridge(&timeout)?;
            if !ready.is_empty() {
                let received = bridge::receive(&self.socket, &mut self.request);
                let length = self.transport_result(received)?;
                if length > self.request.len() {
                    return Err(SessionError::Protocol(format!("request of {length} bytes")));
                }
                if length != 0 {
                    return Ok(length);
                }
                if self
                    .poll_bridge(&Timespec::default())?
                    .intersects(PollFlags::HUP | PollFlags::RDHUP)
                {
                    return Err(self.disconnected(waited));
                }
                return Err(SessionError::Protocol(
                    "empty bridge packet from a live peer".into(),
                ));
            }
            #[cfg(test)]
            if self.guest.pid() == TEST_TERMINAL_POLL_PID.load(Ordering::Acquire) {
                TEST_TERMINAL_POLL_READY.store(true, Ordering::Release);
                while TEST_HOLD_TERMINAL_POLL.load(Ordering::Acquire) {
                    std::thread::sleep(Duration::from_millis(1));
                }
            }
            if let Some(reason) = self.guest.stopped()? {
                return Err(SessionError::Stopped(reason));
            }
            if let Some(limit) = self.progress_limit
                && waited.elapsed() >= limit
            {
                return Err(SessionError::Hung(limit));
            }
        }
    }

    fn send_control(&mut self, command: u32, flags: u64, image: bool) -> Result<(), SessionError> {
        let mut message = [0_u8; CONTROL_LEN];
        message[..4].copy_from_slice(&CONTROL_MAGIC.to_le_bytes());
        message[4..8].copy_from_slice(&command.to_le_bytes());
        message[8..].copy_from_slice(&flags.to_le_bytes());
        let result = if image {
            send_with_fd(&self.socket, &message, &self.memory.image)
        } else {
            bridge::send(&self.socket, &message)
        };
        self.transport_result(result)
    }

    fn send_continue(&mut self) -> Result<(), SessionError> {
        self.send_control(CONTINUE, 0, false)
    }

    fn acknowledgement(
        &mut self,
        command: u32,
        operation: &'static str,
    ) -> Result<Ack, SessionError> {
        let length = self.receive()?;
        let ack = &self.request[..length];
        let (Some(magic), Some(acked), Some(result)) =
            (ack.get(..4), ack.get(4..8), ack.get(8..CONTROL_LEN))
        else {
            return Err(SessionError::Protocol(format!(
                "expected a {operation} acknowledgement, received {length} bytes"
            )));
        };
        let magic = u32::from_le_bytes(magic.try_into().unwrap_or_default());
        let acked = u32::from_le_bytes(acked.try_into().unwrap_or_default());
        let result = i64::from_le_bytes(result.try_into().unwrap_or_default());
        if length != CONTROL_LEN || magic != CONTROL_MAGIC || (acked != command && acked != MEMORY)
        {
            return Err(SessionError::Protocol(format!(
                "expected a {operation} acknowledgement, received command {acked}"
            )));
        }
        if acked == MEMORY {
            return self.memory_report(result).map(Ack::Memory);
        }
        if result < 0 {
            return Err(SessionError::Refused {
                operation,
                errno: -result,
            });
        }
        Ok(Ack::Done(result))
    }

    fn memory_report(&mut self, flags: i64) -> Result<Report, SessionError> {
        if flags & MEMORY_ALL != 0 {
            return Ok(Report::All);
        }
        let frames = self.memory.physmem_bytes()? / PAGE_SIZE;
        let bitmap = frames.div_ceil(64) * 8;
        if self.request.len() < MEMORY_CHUNK {
            self.request.resize(MEMORY_CHUNK, 0);
        }
        let mut written = Vec::new();
        let mut received = 0;
        while received < bitmap {
            let chunk = (bitmap - received).min(MEMORY_CHUNK);
            let length = self.receive()?;
            if length != chunk {
                return Err(SessionError::Protocol(format!(
                    "expected {chunk} bytes of the {bitmap}-byte memory bitmap at {received}, received {length} bytes"
                )));
            }
            let first = (received / 8) as u64;
            for (index, word) in self.request[..chunk].chunks_exact(8).enumerate() {
                let mut word = u64::from_le_bytes(word.try_into().unwrap_or_default());
                while word != 0 {
                    written.push((first + index as u64) * 64 + u64::from(word.trailing_zeros()));
                    word &= word - 1;
                }
            }
            received += chunk;
        }
        Ok(Report::Dirty(written))
    }

    fn finish(&mut self, reason: ExitReason) -> Result<Exit, SessionError> {
        let reason = if self.failure.is_some() {
            ExitReason::BridgeFailure
        } else {
            reason
        };
        let mut exit = self.guest.finish(reason)?;
        exit.events = std::mem::take(&mut self.services.events);
        exit.bridge_failure = self.failure.take();
        Ok(exit)
    }
}

fn stamp(request: &[u8]) -> Option<u64> {
    request
        .first_chunk::<STAMP_LEN>()
        .map(|stamp| u64::from_le_bytes(*stamp))
}

#[expect(
    clippy::disallowed_methods,
    reason = "the progress watchdog measures host time the guest spends without a request"
)]
fn now() -> Instant {
    Instant::now()
}

fn send_with_fd(socket: &OwnedFd, message: &[u8], fd: &OwnedFd) -> io::Result<()> {
    let raw = fd.as_raw_fd();
    // SAFETY: CMSG_SPACE only computes a size from its argument.
    let space = unsafe { libc::CMSG_SPACE(size_of_val(&raw) as u32) } as usize;
    let mut control = vec![0_u8; space];
    let mut iov = libc::iovec {
        iov_base: message.as_ptr().cast_mut().cast(),
        iov_len: message.len(),
    };
    // SAFETY: an all-zero msghdr is a valid empty header.
    let mut header: libc::msghdr = unsafe { std::mem::zeroed() };
    header.msg_iov = &mut iov;
    header.msg_iovlen = 1;
    header.msg_control = control.as_mut_ptr().cast();
    header.msg_controllen = space as _;
    // SAFETY: `header` describes `control`, which has room for one cmsghdr
    // carrying one descriptor, so `CMSG_FIRSTHDR` returns a pointer into it
    // and `CMSG_DATA` points at the descriptor slot inside the same buffer.
    unsafe {
        let cmsg = libc::CMSG_FIRSTHDR(&header);
        (*cmsg).cmsg_level = libc::SOL_SOCKET;
        (*cmsg).cmsg_type = libc::SCM_RIGHTS;
        (*cmsg).cmsg_len = libc::CMSG_LEN(size_of_val(&raw) as u32) as _;
        libc::CMSG_DATA(cmsg).cast::<i32>().write_unaligned(raw);
    }
    loop {
        // SAFETY: `header` points at `iov`, `message` and `control`, which all
        // stay live and unmoved for the call.
        let sent = unsafe { libc::sendmsg(socket.as_raw_fd(), &header, libc::MSG_NOSIGNAL) };
        if sent >= 0 {
            return if sent.unsigned_abs() == message.len() {
                Ok(())
            } else {
                Err(io::Error::other("short control message"))
            };
        }
        let error = io::Error::last_os_error();
        if error.kind() != io::ErrorKind::Interrupted {
            return Err(error);
        }
    }
}

fn unexpected_pages(
    pages: &crate::memory::Pages,
    expected: snapshot_store::SnapshotId,
    candidates: Vec<u64>,
    skip: &[u64],
    bytes: &[u8],
) -> Result<Vec<u64>, SessionError> {
    let mut stored = [0_u8; PAGE_SIZE];
    let mut missed = Vec::new();
    for gfn in candidates {
        if skip.binary_search(&gfn).is_ok() {
            continue;
        }
        pages
            .store
            .read_page(expected, gfn, &mut stored)
            .map_err(MemoryError::from)?;
        let at = usize::try_from(gfn).map_err(io::Error::other)? * PAGE_SIZE;
        if bytes[at..at + PAGE_SIZE] != stored {
            missed.push(gfn - IMAGE_PAGES);
        }
    }
    Ok(missed)
}

#[cfg(test)]
mod tests {
    use std::os::fd::FromRawFd;
    use std::os::unix::process::CommandExt;

    use super::*;
    use environment::input_spec::nominal_factory;

    const PHYSMEM_BYTES: usize = 4 * PAGE_SIZE;

    #[derive(Clone)]
    struct WaitingHandler;

    impl ServiceHandler for WaitingHandler {
        fn identity(&self) -> &[u8] {
            b"waiting-handler"
        }

        fn configuration(&self) -> &[u8] {
            &[]
        }

        fn respond(
            &mut self,
            _: u64,
            _: &Question,
        ) -> Result<environment::channel::ServiceResponse, environment::channel::ChannelError>
        {
            panic!("guest answers require a recorded decision")
        }

        fn snapshot_state(&self) -> Result<Vec<u8>, environment::channel::ChannelError> {
            Ok(Vec::new())
        }

        fn restore_state(
            &mut self,
            state: &[u8],
        ) -> Result<(), environment::channel::ChannelError> {
            if state.is_empty() {
                Ok(())
            } else {
                Err(environment::channel::ChannelError::Malformed)
            }
        }

        fn clone_box(&self) -> Box<dyn ServiceHandler> {
            Box::new(self.clone())
        }
    }

    fn snapshot(
        checkpoints: &Checkpoints,
        parent: Option<&Snapshot>,
        pages: &[(u64, u8)],
    ) -> Snapshot {
        let mut held = checkpoints.pages(PHYSMEM_BYTES).unwrap();
        let parent = parent.map_or(held.root, Snapshot::id);
        let mut builder = held.store.derive(parent).unwrap();
        for &(gfn, fill) in pages {
            builder.write_changed_page(gfn, &[fill; PAGE_SIZE]).unwrap();
        }
        let id = builder.seal(image_state(24));
        drop(held);
        checkpoints.adopt(id)
    }

    fn checkpoint(memory: Snapshot, seed: u64, moment: Option<u64>) -> Checkpoint {
        let mut services = Services::new(seed);
        services.latest = 90;
        services.events.push(Event {
            moment: 80,
            id: 3,
            data: vec![1, 2, 3].into(),
        });
        Checkpoint {
            memory,
            services,
            request: moment.map_or_else(Vec::new, |moment| moment.to_le_bytes().to_vec()),
        }
    }

    #[test]
    fn checkpoint_digest_names_logical_target_across_parent_delta_layouts() {
        let checkpoints = Checkpoints::new();
        let setup = checkpoint(snapshot(&checkpoints, None, &[]), 7, Some(120));
        let parent = checkpoint(
            snapshot(&checkpoints, Some(&setup.memory), &[(1, 1)]),
            7,
            Some(120),
        );
        let through_parent = checkpoint(
            snapshot(&checkpoints, Some(&parent.memory), &[(2, 2)]),
            7,
            Some(120),
        );
        let direct = checkpoint(
            snapshot(&checkpoints, Some(&setup.memory), &[(1, 1), (2, 2)]),
            7,
            Some(120),
        );
        let anchor = checkpoints
            .delta(&setup, None, &through_parent, |pages, _| {
                pages.iter().map(|page| page.0).collect::<Vec<_>>()
            })
            .unwrap();
        let child = checkpoints
            .delta(&setup, Some(&parent), &through_parent, |pages, _| {
                pages.iter().map(|page| page.0).collect::<Vec<_>>()
            })
            .unwrap();
        assert_eq!(anchor, vec![1, 2]);
        assert_eq!(child, vec![2]);
        assert_eq!(through_parent.digest().unwrap(), direct.digest().unwrap());
        let divergent = checkpoint(
            snapshot(&checkpoints, Some(&direct.memory), &[(1, 3)]),
            7,
            Some(120),
        );
        assert_ne!(
            through_parent.digest().unwrap(),
            divergent.digest().unwrap()
        );
    }

    #[test]
    fn sidecar_rejects_a_corrupted_snapshot_image_length() {
        let checkpoints = Checkpoints::new();
        let target = checkpoint(snapshot(&checkpoints, None, &[(0, 1)]), 5, Some(120));
        assert_eq!(target.bytes().unwrap(), 24);
        let id = target.memory.id();
        checkpoints
            .held()
            .unwrap()
            .store
            .corrupt_vm_state_for_test(id, 0, 1)
            .unwrap();
        assert_eq!(checkpoints.full(&target, |pages| pages.len()).unwrap(), 1);
        assert!(matches!(
            target.sidecar(),
            Err(SessionError::Memory(MemoryError::Store(
                snapshot_store::StoreError::VmStateIntegrity
            )))
        ));
    }

    fn owned_delta(
        checkpoints: &Checkpoints,
        base: &Checkpoint,
        target: &Checkpoint,
    ) -> Vec<(u64, PageHash, [u8; PAGE_SIZE])> {
        checkpoints
            .delta(base, None, target, |changed, reverted| {
                assert!(reverted.is_empty());
                changed
                    .iter()
                    .map(|&(gfn, hash, data)| (gfn, *hash, *data))
                    .collect()
            })
            .unwrap()
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn dropping_checkpoints_during_delta_callbacks_releases_snapshots() {
        let checkpoints = Checkpoints::new();
        let base = checkpoint(snapshot(&checkpoints, None, &[(0, 1)]), 5, Some(120));
        let target = checkpoint(
            snapshot(&checkpoints, Some(&base.memory), &[(1, 2)]),
            5,
            Some(120),
        );
        let temporary = checkpoint(snapshot(&checkpoints, None, &[(2, 3)]), 5, Some(120));
        let shared = target.with_bridge_of(&target);

        assert_eq!(checkpoints.stats().unwrap().snapshots, 4);
        checkpoints
            .delta(&base, None, &target, |_, _| drop(temporary))
            .unwrap();
        assert_eq!(checkpoints.stats().unwrap().snapshots, 3);
        checkpoints
            .delta(&base, None, &target, |_, _| drop(shared))
            .unwrap();
        drop(target);
        drop(base);
        assert_eq!(checkpoints.stats().unwrap().snapshots, 1);
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn checkpoints_report_their_moment_events_and_image() {
        let checkpoints = Checkpoints::new();
        let stamped = checkpoint(snapshot(&checkpoints, None, &[(1, 1)]), 5, Some(120));
        assert_eq!(stamped.moment(), 120);
        assert_eq!(stamped.bytes().unwrap(), 24);
        assert_eq!(stamped.owned_pages(), 1);
        assert_eq!(stamped.events().len(), 1);
        assert_eq!(stamped.events()[0].moment, 80);

        let unstamped = checkpoint(snapshot(&checkpoints, None, &[(1, 1)]), 5, None);
        assert_eq!(unstamped.moment(), 90);
        assert_eq!(unstamped.digest().unwrap(), {
            let other = checkpoint(snapshot(&checkpoints, None, &[(1, 1)]), 5, None);
            other.digest().unwrap()
        });
        assert_ne!(unstamped.digest().unwrap(), stamped.digest().unwrap());

        let reseeded = checkpoint(snapshot(&checkpoints, None, &[(2, 2)]), 6, Some(200));
        let bridged = stamped.with_bridge_of(&reseeded);
        assert_eq!(bridged.moment(), 200);
        assert_eq!(bridged.memory.id(), stamped.memory.id());
        assert_eq!(bridged.sidecar().unwrap(), reseeded.sidecar().unwrap());
        assert_ne!(bridged.digest().unwrap(), stamped.digest().unwrap());
        assert_ne!(bridged.digest().unwrap(), reseeded.digest().unwrap());
        drop(stamped);
        assert_eq!(bridged.bytes().unwrap(), 24);
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn imported_checkpoints_reproduce_the_published_digest() {
        let publisher = Checkpoints::new();
        let base = checkpoint(snapshot(&publisher, None, &[(0, 1)]), 5, Some(10));
        let target = checkpoint(
            snapshot(&publisher, Some(&base.memory), &[(2, 7), (3, 8)]),
            9,
            Some(400),
        );
        let rows = owned_delta(&publisher, &base, &target);
        assert_eq!(rows.iter().map(|row| row.0).collect::<Vec<_>>(), vec![2, 3]);
        let borrowed: Vec<(u64, &PageHash, &[u8; PAGE_SIZE])> = rows
            .iter()
            .map(|(gfn, hash, data)| (*gfn, hash, data))
            .collect();

        let subscriber = Checkpoints::new();
        let subscriber_base = checkpoint(snapshot(&subscriber, None, &[(0, 1)]), 5, Some(10));
        assert_eq!(subscriber_base.digest().unwrap(), base.digest().unwrap());
        let sidecar = target.sidecar().unwrap();
        let imported = subscriber
            .import(
                &subscriber_base,
                &subscriber_base,
                &borrowed,
                &sidecar,
                &nominal_factory(),
            )
            .unwrap();
        assert_eq!(imported.digest().unwrap(), target.digest().unwrap());
        assert_eq!(imported.moment(), 400);
        assert_eq!(imported.events(), target.events());

        for malformed in [
            &b"HUMLCKP1"[..],
            &sidecar[..SIDECAR_MAGIC.len()],
            &sidecar[..SIDECAR_MAGIC.len() + 12],
            &sidecar[..sidecar.len() - 1],
        ] {
            assert!(matches!(
                subscriber.import(
                    &subscriber_base,
                    &subscriber_base,
                    &borrowed,
                    malformed,
                    &nominal_factory(),
                ),
                Err(SessionError::Protocol(_))
            ));
        }

        let mut trailing = sidecar.clone();
        trailing.push(0x5a);
        let request_field = sidecar.len() - STAMP_LEN - 8;
        let mut short = sidecar[..request_field + 9].to_vec();
        short[request_field..request_field + 8].copy_from_slice(&1_u64.to_le_bytes());
        let mut oversized = sidecar[..request_field + 8].to_vec();
        let oversized_len = STAMP_LEN + MAX_FRAME + 1;
        oversized[request_field..request_field + 8]
            .copy_from_slice(&(oversized_len as u64).to_le_bytes());
        oversized.resize(request_field + 8 + oversized_len, 0);
        oversized[request_field + 8..request_field + 16].copy_from_slice(&400_u64.to_le_bytes());
        let mut behind = sidecar.clone();
        behind[request_field + 8..request_field + 16].copy_from_slice(&89_u64.to_le_bytes());
        for (name, malformed) in [
            ("trailing", trailing),
            ("short request", short),
            ("oversized request", oversized),
            ("backward request", behind),
        ] {
            assert!(
                matches!(
                    subscriber.import(
                        &subscriber_base,
                        &subscriber_base,
                        &borrowed,
                        &malformed,
                        &nominal_factory(),
                    ),
                    Err(SessionError::Protocol(_))
                ),
                "{name} sidecar was accepted"
            );
        }
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn import_rejects_corrupted_pages_even_when_near_has_the_claimed_hash() {
        let checkpoints = Checkpoints::new();
        let base = checkpoint(snapshot(&checkpoints, None, &[(0, 1)]), 5, Some(120));
        let target = checkpoint(
            snapshot(&checkpoints, Some(&base.memory), &[(1, 2)]),
            5,
            Some(120),
        );
        let sidecar = target.sidecar().unwrap();
        let mut rows = owned_delta(&checkpoints, &base, &target);
        assert_eq!(rows.len(), 1);
        rows[0].2[0] ^= 1;
        let borrowed: Vec<_> = rows
            .iter()
            .map(|(gfn, hash, data)| (*gfn, hash, data))
            .collect();
        let before = checkpoints.stats().unwrap();

        for near in [&target, &base] {
            assert!(matches!(
                checkpoints.import(&base, near, &borrowed, &sidecar, &nominal_factory()),
                Err(SessionError::Memory(MemoryError::Store(
                    snapshot_store::StoreError::PageIntegrity { gfn: 1 }
                )))
            ));
            assert_eq!(checkpoints.stats().unwrap(), before);
        }

        let valid_rows = owned_delta(&checkpoints, &base, &target);
        let valid: Vec<_> = valid_rows
            .iter()
            .map(|(gfn, hash, data)| (*gfn, hash, data))
            .collect();
        let imported = checkpoints
            .import(&base, &target, &valid, &sidecar, &nominal_factory())
            .unwrap();
        assert_eq!(imported.digest().unwrap(), target.digest().unwrap());
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn import_rejects_malformed_page_rows_without_creating_a_snapshot() {
        let checkpoints = Checkpoints::new();
        let base = checkpoint(
            snapshot(&checkpoints, None, &[(0, 1), (1, 1)]),
            5,
            Some(120),
        );
        let near = checkpoint(
            snapshot(&checkpoints, Some(&base.memory), &[(1, 2)]),
            5,
            Some(120),
        );
        let target = checkpoint(
            snapshot(&checkpoints, Some(&base.memory), &[(0, 0), (1, 3)]),
            5,
            Some(120),
        );
        let rows = owned_delta(&checkpoints, &base, &target);
        assert_eq!(rows.iter().map(|row| row.0).collect::<Vec<_>>(), [0, 1]);
        let valid: Vec<_> = rows
            .iter()
            .map(|(gfn, hash, data)| (*gfn, hash, data))
            .collect();
        let reordered = [valid[1], valid[0]];
        let duplicate = [valid[0], valid[0]];
        let out_of_range = [(IMAGE_PAGES + 4, valid[0].1, valid[0].2)];
        let sidecar = target.sidecar().unwrap();
        let before = checkpoints.stats().unwrap();
        let base_digest = base.digest().unwrap();
        let near_digest = near.digest().unwrap();

        for pages in [&reordered[..], &duplicate[..]] {
            assert!(matches!(
                checkpoints.import(&base, &near, pages, &sidecar, &nominal_factory()),
                Err(SessionError::Memory(MemoryError::Store(
                    snapshot_store::StoreError::TargetPageOrder { .. }
                )))
            ));
            assert_eq!(checkpoints.stats().unwrap(), before);
            assert_eq!(base.digest().unwrap(), base_digest);
            assert_eq!(near.digest().unwrap(), near_digest);
        }
        assert!(matches!(
            checkpoints.import(&base, &near, &out_of_range, &sidecar, &nominal_factory()),
            Err(SessionError::Memory(MemoryError::Store(
                snapshot_store::StoreError::GfnOutOfRange { .. }
            )))
        ));
        assert_eq!(checkpoints.stats().unwrap(), before);
        assert_eq!(base.digest().unwrap(), base_digest);
        assert_eq!(near.digest().unwrap(), near_digest);

        let imported = checkpoints
            .import(&base, &near, &valid, &sidecar, &nominal_factory())
            .unwrap();
        assert_eq!(imported.digest().unwrap(), target.digest().unwrap());
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn checkpoint_operations_reject_foreign_owner_before_changing_the_store() {
        let first = Checkpoints::new();
        let foreign = checkpoint(snapshot(&first, None, &[(0, 1)]), 5, Some(120));
        let second = Checkpoints::new();
        let local = checkpoint(snapshot(&second, None, &[(0, 2)]), 5, Some(120));
        assert_ne!(foreign.memory.id(), local.memory.id());
        assert_ne!(foreign.digest().unwrap(), local.digest().unwrap());
        let before = second.stats().unwrap();
        let sidecar = local.sidecar().unwrap();

        assert!(matches!(
            second.full(&foreign, |_| ()),
            Err(SessionError::Memory(MemoryError::ForeignSnapshot))
        ));
        for result in [
            second.delta(&foreign, None, &local, |_, _| ()),
            second.delta(&local, Some(&foreign), &local, |_, _| ()),
            second.delta(&local, None, &foreign, |_, _| ()),
        ] {
            assert!(matches!(
                result,
                Err(SessionError::Memory(MemoryError::ForeignSnapshot))
            ));
        }
        for result in [
            second.import(&foreign, &local, &[], &sidecar, &nominal_factory()),
            second.import(&local, &foreign, &[], &sidecar, &nominal_factory()),
            second.import_full(&foreign, &[], &sidecar, &nominal_factory()),
        ] {
            assert!(matches!(
                result,
                Err(SessionError::Memory(MemoryError::ForeignSnapshot))
            ));
        }
        assert_eq!(second.stats().unwrap(), before);
        assert_ne!(foreign.digest().unwrap(), local.digest().unwrap());

        let exported = second
            .clone()
            .full(&local, |pages| {
                pages
                    .iter()
                    .map(|(gfn, _, data)| (*gfn, data[0]))
                    .collect::<Vec<_>>()
            })
            .unwrap();
        assert_eq!(exported, vec![(0, 2)]);
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn start_rejects_foreign_checkpoint_before_launch() {
        let first = Checkpoints::new();
        let foreign = checkpoint(snapshot(&first, None, &[(0, 1)]), 5, Some(120));
        let second = Checkpoints::new();
        let mut launch = Launch::new(std::env::temp_dir());
        launch.memory_mib = 1;
        launch.console_tail_bytes = 0;
        launch.console_limit_bytes = 0;
        launch.wall_limit = Duration::from_secs(1);
        assert!(matches!(
            Session::start_with_guard(
                Command::new("false"),
                tempfile::tempdir().unwrap(),
                &launch,
                &second,
                Some(&foreign),
                None,
                HostGuard::TestFixture,
            ),
            Err(SessionError::Memory(MemoryError::ForeignSnapshot))
        ));
        assert!(second.stats().is_none());
    }

    fn controlled_peer(
        directory: &std::path::Path,
        status: i32,
        limit: Duration,
    ) -> (Session, OwnedFd, std::path::PathBuf) {
        controlled_peer_with_limits(directory, status, Some(limit), Duration::from_secs(5))
    }

    fn controlled_peer_with_limits(
        directory: &std::path::Path,
        status: i32,
        limit: Option<Duration>,
        wall_limit: Duration,
    ) -> (Session, OwnedFd, std::path::PathBuf) {
        let release = directory.join("release");
        let mut launch = Launch::new(directory.to_path_buf());
        launch.bridge = Some(bridge::Bridge::new(7));
        launch.wall_limit = wall_limit;
        let mut command = Command::new("/bin/sh");
        command
            .args([
                "-c",
                "while [ ! -e \"$1\" ]; do sleep 0.001; done; sleep 0.02; case \"$2\" in -*) kill -\"${2#-}\" $$;; *) exit \"$2\";; esac",
                "checkpoint-peer",
            ])
            .arg(&release)
            .arg(status.to_string())
            .process_group(0);
        let checkpoints = Checkpoints::new();
        let mut session = Session::start_with_guard(
            command,
            launch.work_directory().unwrap(),
            &launch,
            &checkpoints,
            None,
            limit,
            HostGuard::TestFixture,
        )
        .unwrap();
        let (socket, peer) = bridge::socket_pair().unwrap();
        session.socket = socket;
        session.pending = Some(120_u64.to_le_bytes().to_vec());
        rustix::fs::ftruncate(&session.memory.physmem, PHYSMEM_BYTES as u64).unwrap();
        (session, peer, release)
    }

    fn memory_ack(peer: &OwnedFd, bitmap: bool) {
        let mut packet = Vec::new();
        packet.extend_from_slice(&CONTROL_MAGIC.to_le_bytes());
        packet.extend_from_slice(&MEMORY.to_le_bytes());
        packet.extend_from_slice(&(if bitmap { 0_i64 } else { MEMORY_ALL }).to_le_bytes());
        bridge::send(peer, &packet).unwrap();
        if bitmap {
            bridge::send(peer, &[0; 8]).unwrap();
        }
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn capture_and_restore_peer_closure_preserves_actual_child_status() {
        for restore in [false, true] {
            for final_ack in [false, true] {
                for (status, expected) in [
                    (0, ExitReason::Exited(0)),
                    (86, ExitReason::GuestPanic),
                    (87, ExitReason::HostFailure),
                ] {
                    let directory = tempfile::tempdir().unwrap();
                    let (mut session, peer, release) =
                        controlled_peer(directory.path(), status, Duration::from_secs(2));
                    let saved = checkpoint(snapshot(&session.checkpoints, None, &[]), 7, Some(120));
                    let responder = std::thread::spawn(move || {
                        let mut packet = [0; CONTROL_LEN];
                        assert_eq!(bridge::receive(&peer, &mut packet).unwrap(), CONTROL_LEN);
                        if final_ack {
                            memory_ack(&peer, true);
                            assert_eq!(bridge::receive(&peer, &mut packet).unwrap(), CONTROL_LEN);
                            assert_eq!(
                                u32::from_le_bytes(packet[4..8].try_into().unwrap()),
                                CONTINUE
                            );
                        }
                        drop(peer);
                        std::fs::write(release, []).unwrap();
                    });
                    let result = if restore {
                        session.restore(&saved)
                    } else {
                        session.capture(Capture::default()).map(|_| ())
                    };
                    assert!(
                        matches!(result, Err(SessionError::Stopped(reason)) if reason == expected),
                        "restore={restore}, final_ack={final_ack}, status={status}: {result:?}"
                    );
                    responder.join().unwrap();
                    let exit = session.kill().unwrap();
                    assert!(exit.leftovers.is_empty());
                    assert!(exit.work_removed);
                }
            }
        }
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn disconnected_decision_reply_preserves_status_and_does_not_publish_the_answer() {
        use hypercall_proto::{ServiceId, encode_request};

        for (status, expected) in [
            (0, ExitReason::Exited(0)),
            (86, ExitReason::GuestPanic),
            (87, ExitReason::HostFailure),
            (-9, ExitReason::Signaled(9)),
        ] {
            let directory = tempfile::tempdir().unwrap();
            let (mut session, peer, release) =
                controlled_peer(directory.path(), status, Duration::from_secs(2));
            session
                .services
                .branch(7, Box::new(WaitingHandler), Vec::new(), None)
                .unwrap();
            let mut payload = 19_u16.to_le_bytes().to_vec();
            payload.extend(7_u64.to_le_bytes());
            payload.extend(b"choose");
            let mut request = vec![0; STAMP_LEN + MAX_FRAME];
            request[..STAMP_LEN].copy_from_slice(&120_u64.to_le_bytes());
            let length =
                encode_request(ServiceId::Sdk, 3, 1, &payload, &mut request[STAMP_LEN..]).unwrap();
            request.truncate(STAMP_LEN + length);
            let mut response = [0; MAX_FRAME];
            assert!(matches!(
                session
                    .services
                    .exchange(&request, &mut response)
                    .unwrap()
                    .signal,
                Some(Signal::Decision(_))
            ));
            session.pending = Some(request);
            let before = session.bridge_state_digest().unwrap();
            drop(peer);
            std::fs::write(release, []).unwrap();
            let answer = environment::channel::Answer::Data(vec![42]).encode();
            let error = session
                .resolve_and_run(200, 120, 19, 7, &answer)
                .unwrap_err();
            assert!(
                matches!(error, SessionError::Stopped(reason) if reason == expected),
                "status={status}: {error}"
            );
            assert!(session.paused());
            assert_eq!(session.bridge_state_digest().unwrap(), before);
            let exit = session.kill().unwrap();
            assert!(exit.leftovers.is_empty());
            assert!(exit.work_removed);
        }
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn disconnected_live_control_peer_obeys_the_progress_limit() {
        let directory = tempfile::tempdir().unwrap();
        let limit = Duration::from_millis(25);
        let (mut session, peer, _) = controlled_peer(directory.path(), 87, limit);
        let responder = std::thread::spawn(move || {
            let mut packet = [0; CONTROL_LEN];
            assert_eq!(bridge::receive(&peer, &mut packet).unwrap(), CONTROL_LEN);
            drop(peer);
        });
        assert!(
            matches!(session.capture(Capture::default()), Err(SessionError::Hung(got)) if got == limit)
        );
        responder.join().unwrap();
        assert!(session.guest.stopped().unwrap().is_none());
        let exit = session.kill().unwrap();
        assert!(exit.leftovers.is_empty());
        assert!(exit.work_removed);
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn disconnected_peer_without_progress_limit_still_obeys_the_owned_wall_limit() {
        for send in [false, true] {
            let directory = tempfile::tempdir().unwrap();
            let (mut session, peer, _) =
                controlled_peer_with_limits(directory.path(), 87, None, Duration::from_millis(25));
            drop(peer);
            let error = if send {
                session.send_continue().unwrap_err()
            } else {
                session.receive().unwrap_err()
            };
            assert!(matches!(
                error,
                SessionError::Stopped(ExitReason::WallLimit)
            ));
            let exit = session.kill().unwrap();
            assert!(exit.leftovers.is_empty());
            assert!(exit.work_removed);
        }
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn empty_and_malformed_live_control_packets_remain_protocol_errors() {
        for frame in [Vec::new(), vec![1]] {
            let directory = tempfile::tempdir().unwrap();
            let (mut session, peer, _) =
                controlled_peer(directory.path(), 87, Duration::from_secs(2));
            let (release, hold) = std::sync::mpsc::channel();
            let responder = std::thread::spawn(move || {
                let mut packet = [0; CONTROL_LEN];
                assert_eq!(bridge::receive(&peer, &mut packet).unwrap(), CONTROL_LEN);
                bridge::send(&peer, &frame).unwrap();
                hold.recv().unwrap();
            });
            assert!(matches!(
                session.capture(Capture::default()),
                Err(SessionError::Protocol(_))
            ));
            assert!(session.guest.stopped().unwrap().is_none());
            release.send(()).unwrap();
            responder.join().unwrap();
            let exit = session.kill().unwrap();
            assert!(exit.leftovers.is_empty());
            assert!(exit.work_removed);
        }
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn disconnected_sends_preserve_child_status_without_parsing_error_text() {
        for (status, expected) in [
            (0, ExitReason::Exited(0)),
            (86, ExitReason::GuestPanic),
            (87, ExitReason::HostFailure),
        ] {
            for operation in 0..6 {
                let directory = tempfile::tempdir().unwrap();
                let (mut session, peer, release) =
                    controlled_peer(directory.path(), status, Duration::from_secs(2));
                drop(peer);
                std::fs::write(release, []).unwrap();
                let error = match operation {
                    0 => session.send_control(CAPTURE, 0, true),
                    1 => session.send_continue(),
                    other => session.transport_result(Err(io::Error::from(
                        [
                            io::ErrorKind::ConnectionReset,
                            io::ErrorKind::ConnectionAborted,
                            io::ErrorKind::NotConnected,
                            io::ErrorKind::UnexpectedEof,
                        ][other - 2],
                    ))),
                }
                .unwrap_err();
                assert!(
                    matches!(error, SessionError::Stopped(reason) if reason == expected),
                    "operation={operation}, status={status}: {error}"
                );
                let exit = session.kill().unwrap();
                assert!(exit.leftovers.is_empty());
                assert!(exit.work_removed);
            }
        }
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn restore_boot_wait_obeys_the_progress_limit() {
        let checkpoints = Checkpoints::new();
        let saved = checkpoint(snapshot(&checkpoints, None, &[(0, 1)]), 7, Some(120));
        let directory = tempfile::tempdir().unwrap();
        let mut launch = Launch::new(directory.path().to_path_buf());
        launch.bridge = Some(crate::bridge::Bridge::new(7));
        launch.wall_limit = Duration::MAX;
        let mut command = Command::new("/bin/sh");
        command.args(["-c", "sleep 30"]).process_group(0);
        let limit = Duration::from_millis(25);
        let error = match Session::start_with_guard(
            command,
            launch.work_directory().unwrap(),
            &launch,
            &checkpoints,
            Some(&saved),
            Some(limit),
            HostGuard::TestFixture,
        ) {
            Ok(_) => panic!("a restore-mode guest sent no request"),
            Err(error) => error,
        };
        assert!(matches!(
            error,
            SessionError::Boot { error, .. } if matches!(*error, SessionError::Hung(elapsed) if elapsed == limit)
        ));
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn import_bounds_the_private_image_before_storing_pages() {
        let checkpoints = Checkpoints::new();
        let base = checkpoint(snapshot(&checkpoints, None, &[(0, 1)]), 5, Some(120));
        let canonical = base.sidecar().unwrap();
        let impossible = crate::memory::IMAGE_BYTES as u64 + 1;
        let before = checkpoints.stats().unwrap().snapshots;
        let base_digest = base.digest().unwrap();
        for image_bytes in [impossible, u64::MAX] {
            let mut sidecar = canonical.clone();
            sidecar[SIDECAR_MAGIC.len()..SIDECAR_MAGIC.len() + 8]
                .copy_from_slice(&image_bytes.to_le_bytes());
            assert!(matches!(
                checkpoints.import(&base, &base, &[], &sidecar, &nominal_factory()),
                Err(SessionError::Memory(MemoryError::ImageTooLarge(bytes))) if bytes == image_bytes
            ));
            assert!(matches!(
                checkpoints.import_full(&base, &[], &sidecar, &nominal_factory()),
                Err(SessionError::Memory(MemoryError::ImageTooLarge(bytes))) if bytes == image_bytes
            ));
            assert_eq!(checkpoints.stats().unwrap().snapshots, before);
            assert_eq!(base.digest().unwrap(), base_digest);
        }

        let mut boundary = canonical;
        boundary[SIDECAR_MAGIC.len()..SIDECAR_MAGIC.len() + 8]
            .copy_from_slice(&(crate::memory::IMAGE_BYTES as u64).to_le_bytes());
        let imported = checkpoints
            .import(&base, &base, &[], &boundary, &nominal_factory())
            .unwrap();
        assert_eq!(imported.bytes().unwrap(), crate::memory::IMAGE_BYTES as u64);
        let imported_full = checkpoints
            .import_full(&base, &[], &boundary, &nominal_factory())
            .unwrap();
        assert_eq!(
            imported_full.bytes().unwrap(),
            crate::memory::IMAGE_BYTES as u64
        );
        assert_eq!(checkpoints.stats().unwrap().snapshots, before + 2);
    }

    #[test]
    #[cfg(target_os = "linux")]
    #[cfg_attr(miri, ignore)]
    fn process_exit_after_poll_timeout_is_a_closed_terminal_bridge() {
        struct ReleaseTerminalPoll;
        impl Drop for ReleaseTerminalPoll {
            fn drop(&mut self) {
                TEST_HOLD_TERMINAL_POLL.store(false, Ordering::Release);
                TEST_TERMINAL_POLL_PID.store(0, Ordering::Release);
            }
        }

        let parent = tempfile::tempdir().unwrap();
        let release = parent.path().join("release");
        let mut launch = Launch::new(parent.path().to_path_buf());
        launch.bridge = Some(bridge::Bridge::new(7));
        launch.wall_limit = Duration::from_secs(5);
        let mut command = Command::new("/bin/sh");
        command
            .args([
                "-c",
                &format!(
                    "while [ ! -e {} ]; do sleep 0.001; done; exit 0",
                    release.display()
                ),
            ])
            .process_group(0);
        let checkpoints = Checkpoints::new();
        let work = launch.work_directory().unwrap();
        let mut session = Session::start_with_guard(
            command,
            work,
            &launch,
            &checkpoints,
            None,
            None,
            HostGuard::TestFixture,
        )
        .unwrap();
        let pid = session.guest.pid();
        TEST_TERMINAL_POLL_READY.store(false, Ordering::Release);
        TEST_HOLD_TERMINAL_POLL.store(true, Ordering::Release);
        TEST_TERMINAL_POLL_PID.store(pid, Ordering::Release);
        let _release = ReleaseTerminalPoll;
        let controller = std::thread::spawn(move || {
            let _release = ReleaseTerminalPoll;
            let deadline = now() + Duration::from_secs(5);
            while !TEST_TERMINAL_POLL_READY.load(Ordering::Acquire) {
                assert!(now() < deadline, "session did not reach the poll timeout");
                std::thread::yield_now();
            }
            std::fs::write(release, []).unwrap();
            loop {
                let zombie = std::fs::read_to_string(format!("/proc/{pid}/stat"))
                    .ok()
                    .and_then(|status| {
                        status
                            .rsplit_once(") ")
                            .map(|(_, fields)| fields.starts_with('Z'))
                    })
                    .unwrap_or(false);
                if zombie {
                    break;
                }
                assert!(now() < deadline, "guest did not exit");
                std::thread::yield_now();
            }
            TEST_HOLD_TERMINAL_POLL.store(false, Ordering::Release);
        });
        let stop = session.run_until(1).unwrap();
        controller.join().unwrap();
        assert_eq!(stop, Stop::Closed);
        assert!(session.events().is_empty());
        session.kill().unwrap();
    }

    #[test]
    #[cfg(target_os = "linux")]
    #[cfg_attr(miri, ignore)]
    fn bridge_eof_precedes_delayed_console_limit_publication() {
        struct ReleaseReader;
        impl Drop for ReleaseReader {
            fn drop(&mut self) {
                crate::launch::TEST_HOLD_TERMINAL_CONSOLE.store(false, Ordering::Release);
                crate::launch::TEST_TERMINAL_CONSOLE_PID.store(0, Ordering::Release);
                crate::launch::TEST_EXIT_FINISH_PID.store(0, Ordering::Release);
            }
        }

        let parent = tempfile::tempdir().unwrap();
        let release = parent.path().join("release");
        let mut launch = Launch::new(parent.path().to_path_buf());
        launch.bridge = Some(bridge::Bridge::new(7));
        launch.console_limit_bytes = 8;
        launch.console_tail_bytes = 64;
        launch.wall_limit = Duration::from_secs(5);
        let mut command = Command::new("/bin/sh");
        command
            .args([
                "-c",
                &format!(
                    "while [ ! -e {} ]; do sleep 0.001; done; printf abcdefghijklmnop; exit 0",
                    release.display()
                ),
            ])
            .process_group(0);
        let checkpoints = Checkpoints::new();
        let work = launch.work_directory().unwrap();
        let mut session = Session::start_with_guard(
            command,
            work,
            &launch,
            &checkpoints,
            None,
            None,
            HostGuard::TestFixture,
        )
        .unwrap();
        let pid = session.guest.pid();
        crate::launch::TEST_TERMINAL_CONSOLE_READY.store(false, Ordering::Release);
        crate::launch::TEST_HOLD_TERMINAL_CONSOLE.store(true, Ordering::Release);
        crate::launch::TEST_TERMINAL_CONSOLE_PID.store(pid, Ordering::Release);
        crate::launch::TEST_EXIT_FINISH_READY.store(false, Ordering::Release);
        crate::launch::TEST_EXIT_FINISH_PID.store(pid, Ordering::Release);
        let _release = ReleaseReader;
        std::fs::write(release, []).unwrap();
        let deadline = now() + Duration::from_secs(5);
        loop {
            let reader_ready = crate::launch::TEST_TERMINAL_CONSOLE_READY.load(Ordering::Acquire);
            let zombie = std::fs::read_to_string(format!("/proc/{pid}/stat"))
                .ok()
                .and_then(|status| {
                    status
                        .rsplit_once(") ")
                        .map(|(_, fields)| fields.starts_with('Z'))
                })
                .unwrap_or(false);
            if reader_ready && zombie {
                break;
            }
            assert!(
                now() < deadline,
                "guest did not exit with console reader held"
            );
            std::thread::yield_now();
        }
        let mut socket = [rustix::event::PollFd::new(
            &session.socket,
            rustix::event::PollFlags::IN,
        )];
        assert_eq!(
            rustix::event::poll(&mut socket, Some(&rustix::event::Timespec::default())).unwrap(),
            1
        );
        assert!(session.console_tail().is_empty());
        assert_eq!(session.run_until(1).unwrap(), Stop::Closed);
        let release_reader = std::thread::spawn(|| {
            let deadline = now() + Duration::from_secs(5);
            while !crate::launch::TEST_EXIT_FINISH_READY.load(Ordering::Acquire) {
                if now() >= deadline {
                    crate::launch::TEST_HOLD_TERMINAL_CONSOLE.store(false, Ordering::Release);
                    panic!("guest did not enter finish with Exited(0)");
                }
                std::thread::yield_now();
            }
            crate::launch::TEST_HOLD_TERMINAL_CONSOLE.store(false, Ordering::Release);
        });
        let exit = session.run().unwrap();
        release_reader.join().unwrap();
        assert_eq!(exit.reason, ExitReason::ConsoleLimit);
        assert_eq!(exit.console_bytes, 16);
        assert_eq!(exit.console, b"abcdefghijklmnop");
        assert!(exit.events.is_empty());
        assert!(exit.leftovers.is_empty());
        assert!(exit.work_removed);
        assert!(exit.bridge_failure.is_none());
        assert_eq!(
            crate::bridge::event_hash(&exit.events),
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn pending_deadline_does_not_answer_the_held_event() {
        use std::os::unix::process::CommandExt;

        if std::env::var_os("HARMONY_UML_DEADLINE_CHILD").is_some() {
            use hypercall_proto::{ServiceId, encode_request};

            // SAFETY: the launcher's bridge setup passes the guest socket at fd 3.
            let socket = unsafe { OwnedFd::from_raw_fd(3) };
            for moment in [100_u64, 200] {
                let mut request = vec![0_u8; STAMP_LEN + MAX_FRAME];
                request[..STAMP_LEN].copy_from_slice(&moment.to_le_bytes());
                let length = encode_request(
                    ServiceId::Event,
                    1,
                    7,
                    b"\x00\x00\x00\x00{}",
                    &mut request[STAMP_LEN..],
                )
                .unwrap();
                bridge::send(&socket, &request[..STAMP_LEN + length]).unwrap();
                let mut response = vec![0_u8; MAX_FRAME];
                bridge::receive(&socket, &mut response).unwrap();
            }
            return;
        }

        let parent = tempfile::tempdir().unwrap();
        let mut launch = Launch::new(parent.path().to_path_buf());
        launch.bridge = Some(crate::bridge::Bridge::new(7));
        launch.wall_limit = Duration::from_secs(5);
        let work = launch.work_directory().unwrap();
        let mut command = Command::new("/bin/sh");
        command
            .arg("-c")
            .arg("exec \"$0\" --exact session::tests::pending_deadline_does_not_answer_the_held_event --nocapture")
            .arg(std::env::current_exe().unwrap())
            .env("HARMONY_UML_DEADLINE_CHILD", "1")
            .process_group(0);
        let checkpoints = Checkpoints::new();
        let mut session = Session::start_with_guard(
            command,
            work,
            &launch,
            &checkpoints,
            None,
            None,
            HostGuard::TestFixture,
        )
        .unwrap();
        let first = session.run_until(0).unwrap();
        let zero_hash = session.bridge_state_digest().unwrap();
        assert!(matches!(
            session.state_hash(),
            Err(SessionError::StateHashUnavailable)
        ));
        let zero_events = session.events().len();
        let second = session.run_until(100).unwrap();
        let second_hash = session.bridge_state_digest().unwrap();
        let second_events = session.events().len();
        let continued = session.run_until(150).unwrap();
        let continued_hash = session.bridge_state_digest().unwrap();
        let continued_events = session.events().len();
        session.kill().unwrap();

        assert_eq!(first, Stop::Deadline(100));
        assert_eq!(zero_events, 0);
        assert_eq!(second, Stop::Deadline(100));
        assert_eq!(second_events, 0);
        assert_eq!(second_hash, zero_hash);
        assert_eq!(continued, Stop::Deadline(200));
        assert_eq!(continued_events, 1);
        assert_ne!(continued_hash, zero_hash);
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn a_custom_service_pauses_the_socket_until_a_matching_answer_is_recorded() {
        use std::os::fd::AsFd;

        use hypercall_proto::{ServiceId, Status, decode, encode_request};

        if let Some(marker) = std::env::var_os("HARMONY_UML_DECISION_MARKER") {
            let socket = std::io::stdin().as_fd().try_clone_to_owned().unwrap();
            let mut payload = 19_u16.to_le_bytes().to_vec();
            payload.extend(7_u64.to_le_bytes());
            payload.extend(b"choose");
            let mut request = vec![0_u8; STAMP_LEN + MAX_FRAME];
            request[..STAMP_LEN].copy_from_slice(&100_u64.to_le_bytes());
            let length =
                encode_request(ServiceId::Sdk, 3, 1, &payload, &mut request[STAMP_LEN..]).unwrap();
            bridge::send(&socket, &request[..STAMP_LEN + length]).unwrap();
            std::thread::sleep(Duration::from_millis(25));
            let mut waiting = [rustix::event::PollFd::new(
                &socket,
                rustix::event::PollFlags::IN,
            )];
            assert_eq!(
                rustix::event::poll(&mut waiting, Some(&rustix::event::Timespec::default()))
                    .unwrap(),
                0
            );
            std::fs::write(marker, []).unwrap();
            let mut response = vec![0; MAX_FRAME];
            let length = bridge::receive(&socket, &mut response).unwrap();
            let (header, body) = decode(&response[..length]).unwrap();
            assert_eq!(header.status, Status::Ok as u16);
            assert_eq!(body, &[1, 42]);
            request[..STAMP_LEN].copy_from_slice(&400_u64.to_le_bytes());
            let length = encode_request(
                ServiceId::Event,
                1,
                2,
                b"\x00\x00\x00\x00{}",
                &mut request[STAMP_LEN..],
            )
            .unwrap();
            bridge::send(&socket, &request[..STAMP_LEN + length]).unwrap();
            bridge::receive(&socket, &mut response).unwrap();
            return;
        }

        let parent = tempfile::tempdir().unwrap();
        let marker = parent.path().join("decision-held");
        let mut launch = Launch::new(parent.path().to_path_buf());
        launch.bridge = Some(crate::bridge::Bridge::new(7));
        launch.wall_limit = Duration::from_secs(5);
        let work = launch.work_directory().unwrap();
        let mut command = Command::new("/bin/sh");
        command
            .arg("-c")
            .arg("exec 0<&3; exec \"$0\" --exact session::tests::a_custom_service_pauses_the_socket_until_a_matching_answer_is_recorded --nocapture")
            .arg(std::env::current_exe().unwrap())
            .env("HARMONY_UML_DECISION_MARKER", &marker)
            .process_group(0);
        let checkpoints = Checkpoints::new();
        let mut session = Session::start_with_guard(
            command,
            work,
            &launch,
            &checkpoints,
            None,
            None,
            HostGuard::TestFixture,
        )
        .unwrap();
        session
            .branch(7, Box::new(WaitingHandler), Vec::new(), None)
            .unwrap();
        let stop = session.run_until(300).unwrap();
        assert!(matches!(
            stop,
            Stop::Decision { moment: 100, ref question }
                if question.service() == 19 && question.request_id() == 7 && question.payload() == b"choose"
        ));
        assert!(session.paused());
        let deadline = now() + Duration::from_secs(5);
        while !marker.exists() {
            assert!(now() < deadline, "guest did not verify the held socket");
            std::thread::sleep(Duration::from_millis(1));
        }
        let before = session.bridge_state_digest().unwrap();
        let answer = environment::channel::Answer::Data(vec![42]).encode();
        assert!(matches!(
            session.resolve_and_run(300, 100, 19, 8, &answer),
            Err(SessionError::BadResolution(_))
        ));
        assert_eq!(session.bridge_state_digest().unwrap(), before);
        assert_eq!(
            session.resolve_and_run(300, 100, 19, 7, &answer).unwrap(),
            Stop::Deadline(400)
        );
        session.kill().unwrap();
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn imported_held_service_decision_replays_the_same_answer_and_state() {
        use hypercall_proto::{ServiceId, Status, decode, encode_request};

        let checkpoints = Checkpoints::new();
        let mut services = Services::new(7);
        services
            .branch(7, Box::new(WaitingHandler), Vec::new(), None)
            .unwrap();
        let mut payload = 19_u16.to_le_bytes().to_vec();
        payload.extend(7_u64.to_le_bytes());
        payload.extend(b"choose");
        let mut request = vec![0; STAMP_LEN + MAX_FRAME];
        request[..STAMP_LEN].copy_from_slice(&100_u64.to_le_bytes());
        let length =
            encode_request(ServiceId::Sdk, 3, 1, &payload, &mut request[STAMP_LEN..]).unwrap();
        request.truncate(STAMP_LEN + length);
        let mut response = [0; MAX_FRAME];
        assert!(matches!(
            services.exchange(&request, &mut response).unwrap().signal,
            Some(Signal::Decision(_))
        ));
        let held = Checkpoint {
            memory: snapshot(&checkpoints, None, &[(0, 1)]),
            services,
            request,
        };
        let factory: ServiceFactory = std::sync::Arc::new(|config| {
            if config.identity != b"waiting-handler" || !config.configuration.is_empty() {
                return Err(environment::channel::ChannelError::Malformed);
            }
            Ok(Box::new(WaitingHandler))
        });
        let imported = checkpoints
            .import(&held, &held, &[], &held.sidecar().unwrap(), &factory)
            .unwrap();
        assert_eq!(imported.digest().unwrap(), held.digest().unwrap());
        let answer = environment::channel::Answer::Data(vec![42]).encode();
        let (original_services, original_reply) = held
            .services
            .prepare_resolution(&held.request, 100, 19, 7, &answer)
            .unwrap();
        let (replayed_services, replayed_reply) = imported
            .services
            .prepare_resolution(&imported.request, 100, 19, 7, &answer)
            .unwrap();
        assert_eq!(replayed_reply, original_reply);
        assert_eq!(
            replayed_services.encode().unwrap(),
            original_services.encode().unwrap()
        );
        let (header, body) = decode(&replayed_reply).unwrap();
        assert_eq!(header.status, Status::Ok as u16);
        assert_eq!(body, &[1, 42]);
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn import_rejects_a_different_physical_memory_size_before_storing_pages() {
        let publisher = Checkpoints::new();
        let source = checkpoint(snapshot(&publisher, None, &[(0, 1)]), 5, Some(120));
        let sidecar = source.sidecar().unwrap();

        let destination = Checkpoints::new();
        let mut held = destination.pages(PHYSMEM_BYTES + PAGE_SIZE).unwrap();
        let root = held.root;
        let mut builder = held.store.derive(root).unwrap();
        builder.write_page(0, &[1; PAGE_SIZE]).unwrap();
        let id = builder.seal(image_state(24));
        drop(held);
        let near = checkpoint(destination.adopt(id), 5, Some(120));
        assert_ne!(source.digest().unwrap(), near.digest().unwrap());
        let before = destination.stats().unwrap();
        let digest = near.digest().unwrap();

        for full in [false, true] {
            let result = if full {
                destination.import_full(&near, &[], &sidecar, &nominal_factory())
            } else {
                destination.import(&near, &near, &[], &sidecar, &nominal_factory())
            };
            assert!(matches!(
                result,
                Err(SessionError::Memory(MemoryError::ImportedMemorySize { got, expected }))
                    if got == PHYSMEM_BYTES as u64
                        && expected == (PHYSMEM_BYTES + PAGE_SIZE) as u64
            ));
            assert_eq!(destination.stats().unwrap(), before);
            assert_eq!(near.digest().unwrap(), digest);
        }
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn unexpected_pages_lists_unreported_physical_writes() {
        let checkpoints = Checkpoints::new();
        let first = IMAGE_PAGES;
        let stored = snapshot(
            &checkpoints,
            None,
            &[(first, 1), (first + 1, 2), (first + 2, 3)],
        );
        let held = checkpoints.held().unwrap();
        let mut bytes = vec![0_u8; (IMAGE_PAGES as usize) * PAGE_SIZE + PHYSMEM_BYTES];
        for (gfn, fill) in [
            (first, 1_u8),
            (first + 1, 9),
            (first + 2, 4),
            (first + 3, 5),
        ] {
            let at = gfn as usize * PAGE_SIZE;
            bytes[at..at + PAGE_SIZE].fill(fill);
        }
        let missed = unexpected_pages(
            &held,
            stored.id(),
            vec![first, first + 1, first + 2, first + 3],
            &[first + 2],
            &bytes,
        )
        .unwrap();
        assert_eq!(missed, vec![1, 3]);
        assert!(
            unexpected_pages(&held, stored.id(), vec![first], &[], &bytes)
                .unwrap()
                .is_empty()
        );
    }

    #[test]
    fn complete_root_restores_over_a_different_setup_and_removes_stale_pages() {
        fn checkpoint(store: &Checkpoints, values: &[(u64, u8)]) -> Checkpoint {
            let mut pages = store.pages(4 * PAGE_SIZE).unwrap();
            let root = pages.root;
            let mut builder = pages.store.derive(root).unwrap();
            for &(page, value) in values {
                builder.write_page(page, &[value; PAGE_SIZE]).unwrap();
            }
            let id = builder.seal(crate::memory::image_state(4096));
            drop(pages);
            Checkpoint {
                memory: store.adopt(id),
                services: Services::new(7),
                request: 0_u64.to_le_bytes().to_vec(),
            }
        }
        let first = Checkpoints::new();
        let target = checkpoint(&first, &[(0, 17), (2, 29)]);
        let rows = first
            .full(&target, |pages| {
                pages
                    .iter()
                    .map(|&(gfn, hash, data)| (gfn, *hash, Box::new(*data)))
                    .collect::<Vec<_>>()
            })
            .unwrap();
        let rows = rows
            .iter()
            .map(|(gfn, hash, data)| (*gfn, hash, &**data))
            .collect::<Vec<_>>();
        let second = Checkpoints::new();
        let near = checkpoint(&second, &[(0, 3), (1, 99)]);
        let restored = second
            .import_full(
                &near,
                &rows,
                &target.sidecar().unwrap(),
                &environment::input_spec::nominal_factory(),
            )
            .unwrap();
        assert_eq!(restored.digest().unwrap(), target.digest().unwrap());
        drop(restored);
        assert!(second.zero().is_ok());
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn control_messages_carry_the_image_descriptor() {
        let (host, guest) = bridge::socket_pair().unwrap();
        let image = crate::memory::memfd(c"harmony-uml-test").unwrap();
        let message = [7_u8; CONTROL_LEN];
        send_with_fd(&host, &message, &image).unwrap();

        let mut received = [0_u8; CONTROL_LEN];
        let mut control = [0_u8; 64];
        let mut iov = libc::iovec {
            iov_base: received.as_mut_ptr().cast(),
            iov_len: received.len(),
        };
        // SAFETY: an all-zero msghdr is a valid empty header.
        let mut header: libc::msghdr = unsafe { std::mem::zeroed() };
        header.msg_iov = &mut iov;
        header.msg_iovlen = 1;
        header.msg_control = control.as_mut_ptr().cast();
        header.msg_controllen = control.len() as _;
        // SAFETY: `header` points at `iov`, `received` and `control`, which
        // stay live for the call.
        let length = unsafe { libc::recvmsg(guest.as_raw_fd(), &mut header, 0) };
        assert_eq!(length, CONTROL_LEN as isize);
        assert_eq!(received, message);
        // SAFETY: recvmsg filled `control`, so the first header and its data
        // lie inside it.
        let passed = unsafe {
            let cmsg = libc::CMSG_FIRSTHDR(&header);
            assert_eq!((*cmsg).cmsg_type, libc::SCM_RIGHTS);
            OwnedFd::from_raw_fd(libc::CMSG_DATA(cmsg).cast::<i32>().read_unaligned())
        };
        let mut first = std::mem::MaybeUninit::<libc::stat>::zeroed();
        let mut second = std::mem::MaybeUninit::<libc::stat>::zeroed();
        // SAFETY: both buffers are live and writable, and both descriptors are
        // open.
        let (first, second) = unsafe {
            assert_eq!(libc::fstat(image.as_raw_fd(), first.as_mut_ptr()), 0);
            assert_eq!(libc::fstat(passed.as_raw_fd(), second.as_mut_ptr()), 0);
            (first.assume_init(), second.assume_init())
        };
        assert_eq!((first.st_dev, first.st_ino), (second.st_dev, second.st_ino));
    }
}

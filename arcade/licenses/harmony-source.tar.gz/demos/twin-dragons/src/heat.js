// SPDX-License-Identifier: AGPL-3.0-or-later
import { MOTION_STRIDE, NO_ROOM } from "./swarm.js";

export const CELL_SIZE = 32;
export const cellRow = (y) => Math.floor((y - 8) / CELL_SIZE);
export const cellTop = (row) => row * CELL_SIZE + 8;
export const cellKey = (o) =>
  `${o.level}:${Math.floor(o.x / CELL_SIZE)}:${cellRow(o.y)}`;
export class Heatmap {
  constructor() {
    this.cells = new Map();
    this.elapsed = 0;
    this.runningSince = 0;
  }
  clock(now) {
    return (
      this.elapsed +
      (this.runningSince === null ? 0 : Math.max(0, now - this.runningSince))
    );
  }
  setRunning(running, now) {
    this.elapsed = this.clock(now);
    this.runningSince = running ? now : null;
  }
  retain(point, now) {
    const key = cellKey(point.observation);
    let cell = this.cells.get(key);
    if (!cell) {
      cell = {
        key,
        level: point.observation.level,
        x: Math.floor(point.observation.x / 32),
        y: cellRow(point.observation.y),
        heat: 0,
        time: this.clock(now),
        visits: 0,
        ids: [],
        routes: new Map(),
      };
      this.cells.set(key, cell);
    }
    if (point.retained !== null && !cell.ids.includes(point.retained)) {
      if (!cell.routes.has(point.retained))
        cell.routes.set(point.retained, cell.routes.size + 1);
      cell.ids.unshift(point.retained);
      cell.ids = cell.ids.slice(0, 12);
    }
    return cell;
  }
  visit(point, now) {
    const cell = this.retain(point, now);
    cell.heat = this.value(cell, now) + 1;
    cell.time = this.clock(now);
    cell.visits++;
    return cell;
  }
  visitMotion(trails, maps, now) {
    for (const samples of trails) {
      const visited = new Set();
      for (let i = 0; i < samples.length; i += MOTION_STRIDE) {
        const level = samples[i + 1], map = maps.get(level);
        if (level === NO_ROOM || !map || samples[i + 2] >= map.width) continue;
        const x = samples[i + 2] + 8, y = samples[i + 3] + 8;
        if (x >= map.width || y >= map.height) continue;
        const key = (level * 4096 + Math.floor(x / CELL_SIZE)) * 64 + cellRow(y);
        if (visited.has(key)) continue;
        visited.add(key);
        this.visit({ observation: { level, x, y }, retained: null }, now);
      }
    }
  }
  value(cell, now) {
    return (
      cell.heat * Math.pow(0.5, Math.max(0, this.clock(now) - cell.time) / 6000)
    );
  }
  color(cell, now) {
    const value = this.value(cell, now);
    const v = Math.min(1, value / 22),
      stops = [
        [64, 124, 181],
        [74, 212, 132],
        [249, 174, 65],
        [245, 89, 62],
      ],
      scaled = v * 3,
      i = Math.min(2, Math.floor(scaled)),
      f = scaled - i;
    return stops[i].map((x, j) => Math.round(x + (stops[i + 1][j] - x) * f));
  }
}
export function routeIds(cell, selectedId) {
  const ids = [...(cell?.ids || [])];
  if (cell?.routes?.has(selectedId) && !ids.includes(selectedId))
    ids.push(selectedId);
  return ids.sort((a, b) => cell.routes.get(a) - cell.routes.get(b));
}
export function validateTape(tape) {
  if (
    !tape ||
    tape.format !== "harmony-twin-dragons-browser-v1" ||
    tape.rom_sha256 !==
      "7b64267068caab5379b833336e836d6de49c7d37cc5a4341b83d07cbccf0ef73" ||
    tape.core_revision !== "26bb785c9deddb66a17717b21bb4e328f03ade32" ||
    !/^[0-9a-f]{64}$/.test(tape.endpoint_sha256 || "") ||
    !Array.isArray(tape.actions) ||
    tape.actions.length > 10000 ||
    !Number.isInteger(tape.boot_level ?? 0) ||
    (tape.boot_level ?? 0) < 0 || (tape.boot_level ?? 0) >= 3
  )
    throw new Error("Unsupported Twin Dragons history");
  let frames = 0;
  for (const a of tape.actions) {
    if (
      !Number.isInteger(a.buttons) ||
      a.buttons < 0 ||
      a.buttons > 255 ||
      a.buttons & 12 ||
      (a.buttons & 48) === 48 ||
      (a.buttons & 192) === 192 ||
      !Number.isInteger(a.frames) ||
      a.frames < 1 ||
      a.frames > 120
    )
      throw new Error("Invalid controller action");
    frames += a.frames;
  }
  if (frames > 200000) throw new Error("History too long");
  return frames;
}

// SPDX-License-Identifier: AGPL-3.0-or-later

pub const GIC_MAX_INTID: u32 = 1019;

pub const SGI_PPI_COUNT: u32 = 32;

pub(crate) const BITMAP_WORDS: usize = 32;

pub(crate) const CONFIG_WORDS: usize = 64;

pub(crate) const PRIORITY_BYTES: usize = 1020;

pub const GICD_FRAME_SIZE: u64 = 0x1_0000;

pub const GICR_FRAME_SIZE: u64 = 0x2_0000;

pub const CNTV_CTL_ENABLE: u64 = 1;

pub const CNTV_CTL_IMASK: u64 = 1 << 1;

pub const GIC_STATE_VERSION: u32 = 9;

#[derive(Clone, PartialEq, Eq, Debug)]
pub struct GicState {
    pub version: u32,
    pub impl_spis: u32,
    pub timer_hz: u64,
    pub timer_intid: u32,
    pub gicd_ctlr: u32,
    pub gicr_propbaser: u64,
    pub gicr_pendbaser: u64,
    pub group: [u32; BITMAP_WORDS],
    pub enable: [u32; BITMAP_WORDS],
    pub pending: [u32; BITMAP_WORDS],
    pub active: [u32; BITMAP_WORDS],
    pub line_level: [u32; BITMAP_WORDS],
    pub config: [u32; CONFIG_WORDS],
    pub priority: [u8; PRIORITY_BYTES],
    pub pmr: u8,
    pub bpr0: u8,
    pub bpr1: u8,
    pub ctlr: u64,
    pub igrpen0: bool,
    pub igrpen1: bool,
    pub ap0r: [u32; 4],
    pub ap1r: [u32; 4],
    pub cntv_ctl: u64,
    pub cntv_cval: u64,
    pub timer_fired: bool,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cntv_ctl_bits_match_the_architecture() {
        assert_eq!(CNTV_CTL_ENABLE, 0x1, "CNTV_CTL.ENABLE is bit 0");
        assert_eq!(CNTV_CTL_IMASK, 0x2, "CNTV_CTL.IMASK is bit 1");
    }
}

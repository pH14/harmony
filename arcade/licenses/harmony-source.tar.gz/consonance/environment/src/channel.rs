// SPDX-License-Identifier: AGPL-3.0-or-later

use std::{
    any::Any,
    collections::BTreeMap,
    fmt,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
};

use sha2::{Digest, Sha256};
use thiserror::Error;

use crate::{Moment, shared_map::SharedMap};

pub const MAX_CHANNEL_BYTES: usize = 1 << 20;

const SNAPSHOT_MAGIC: u32 = u32::from_le_bytes(*b"EVC1");
const SNAPSHOT_VERSION: u16 = 4;
const COVERAGE_SCHEDULE_VERSION: u16 = 1;
pub const MAX_RECORDED_STATE_BYTES: usize = 8 * MAX_CHANNEL_BYTES;

pub const SERVICE_ENTROPY: u16 = 1;
pub const SERVICE_PAYLOAD: u16 = 2;
pub const SERVICE_SCHEDULER: u16 = 3;
pub const SERVICE_COVERAGE_QUANTUM: u16 = 4;
pub const DEFAULT_COVERAGE_QUANTUM: u64 = 1024;

pub const MAX_LOCAL_SERVICES: usize = 32;

pub fn validate_local_services(services: &[u16]) -> Result<(), ChannelError> {
    if services.len() > MAX_LOCAL_SERVICES {
        return Err(ChannelError::TooLarge);
    }
    if services.iter().any(|id| *id <= SERVICE_COVERAGE_QUANTUM)
        || services.windows(2).any(|pair| pair[0] >= pair[1])
    {
        return Err(ChannelError::Malformed);
    }
    Ok(())
}

pub fn decode_local_services(bytes: &[u8]) -> Result<Vec<u16>, ChannelError> {
    if !bytes.len().is_multiple_of(2) || bytes.len() > MAX_LOCAL_SERVICES * 2 {
        return Err(ChannelError::Malformed);
    }
    let services: Vec<_> = bytes
        .chunks_exact(2)
        .map(|pair| u16::from_le_bytes([pair[0], pair[1]]))
        .collect();
    validate_local_services(&services)?;
    Ok(services)
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CoverageSchedule {
    default_quantum: u64,
    windows: Vec<(u64, u64, u64)>,
}

impl CoverageSchedule {
    pub fn new(default_quantum: u64, windows: Vec<(u64, u64, u64)>) -> Result<Self, ChannelError> {
        if default_quantum == 0 {
            return Err(ChannelError::Malformed);
        }
        if windows.len() > (MAX_CHANNEL_BYTES - 14) / 24 {
            return Err(ChannelError::TooLarge);
        }
        let mut previous_end = None;
        for &(start, end, quantum) in &windows {
            if start >= end || quantum == 0 || previous_end.is_some_and(|prev| prev > start) {
                return Err(ChannelError::Malformed);
            }
            previous_end = Some(end);
        }
        Ok(Self {
            default_quantum,
            windows,
        })
    }

    pub fn quantum_at(&self, moment: Moment) -> u64 {
        let index = self
            .windows
            .partition_point(|(start, _, _)| *start <= moment);
        self.windows
            .get(index.saturating_sub(1))
            .filter(|(start, end, _)| *start <= moment && moment < *end)
            .map_or(self.default_quantum, |(_, _, quantum)| *quantum)
    }

    pub fn encode(&self) -> Vec<u8> {
        let mut out = Vec::with_capacity(14 + self.windows.len() * 24);
        put_u16(&mut out, COVERAGE_SCHEDULE_VERSION);
        put_u64(&mut out, self.default_quantum);
        put_len(&mut out, self.windows.len());
        for &(start, end, quantum) in &self.windows {
            put_u64(&mut out, start);
            put_u64(&mut out, end);
            put_u64(&mut out, quantum);
        }
        out
    }

    pub fn decode(bytes: &[u8]) -> Result<Self, ChannelError> {
        if bytes.len() > MAX_CHANNEL_BYTES {
            return Err(ChannelError::TooLarge);
        }
        let mut reader = Reader::new(bytes);
        if reader.u16()? != COVERAGE_SCHEDULE_VERSION {
            return Err(ChannelError::Malformed);
        }
        let default_quantum = reader.u64()?;
        let count = reader.count(24)?;
        let mut windows = Vec::with_capacity(count);
        for _ in 0..count {
            windows.push((reader.u64()?, reader.u64()?, reader.u64()?));
        }
        reader.finish()?;
        Self::new(default_quantum, windows)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Question {
    request_id: u64,
    service: u16,
    payload: Vec<u8>,
}

impl Question {
    pub fn new(service: u16, payload: Vec<u8>) -> Result<Self, ChannelError> {
        Self::with_request_id(0, service, payload)
    }

    pub fn with_request_id(
        request_id: u64,
        service: u16,
        payload: Vec<u8>,
    ) -> Result<Self, ChannelError> {
        check_len(payload.len())?;
        Ok(Self {
            request_id,
            service,
            payload,
        })
    }

    pub fn entropy(bytes: u32) -> Result<Self, ChannelError> {
        Self::new(SERVICE_ENTROPY, bytes.to_le_bytes().to_vec())
    }

    pub fn scheduler(ready: u32) -> Result<Self, ChannelError> {
        Self::new(SERVICE_SCHEDULER, ready.to_le_bytes().to_vec())
    }

    #[must_use]
    pub fn request_id(&self) -> u64 {
        self.request_id
    }

    #[must_use]
    pub fn service(&self) -> u16 {
        self.service
    }

    #[must_use]
    pub fn payload(&self) -> &[u8] {
        &self.payload
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Answer {
    Nominal,
    Data(Vec<u8>),
}

impl Answer {
    pub fn data(payload: Vec<u8>) -> Result<Self, ChannelError> {
        check_len(payload.len())?;
        Ok(Self::Data(payload))
    }

    pub fn encode(&self) -> Vec<u8> {
        match self {
            Self::Nominal => vec![0],
            Self::Data(bytes) => {
                let mut out = vec![1];
                out.extend(bytes);
                out
            }
        }
    }
    pub fn decode(bytes: &[u8]) -> Result<Self, ChannelError> {
        match bytes {
            [0] => Ok(Self::Nominal),
            [1, payload @ ..] if payload.len() <= MAX_CHANNEL_BYTES => Self::data(payload.to_vec()),
            _ => Err(ChannelError::Malformed),
        }
    }

    #[must_use]
    pub fn payload(&self) -> Option<&[u8]> {
        match self {
            Self::Nominal => None,
            Self::Data(payload) => Some(payload),
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ServiceResponse {
    Answered(Answer),
    External,
}

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub enum Effect {
    WriteMemory { gpa: u64, bytes: Vec<u8> },
    XorMemory { gpa: u64, bytes: Vec<u8> },
}

impl Effect {
    pub fn write_memory(gpa: u64, bytes: Vec<u8>) -> Result<Self, ChannelError> {
        check_len(bytes.len())?;
        Ok(Self::WriteMemory { gpa, bytes })
    }

    pub fn xor_memory(gpa: u64, bytes: Vec<u8>) -> Result<Self, ChannelError> {
        check_len(bytes.len())?;
        Ok(Self::XorMemory { gpa, bytes })
    }

    pub fn encode(&self) -> Vec<u8> {
        let mut out = Vec::new();
        self.encode_into(&mut out);
        out
    }

    #[inline]
    pub(crate) fn encode_into(&self, out: &mut Vec<u8>) {
        match self {
            Self::WriteMemory { gpa, bytes } => {
                out.push(1);
                put_u64(out, *gpa);
                put_bytes(out, bytes);
            }
            Self::XorMemory { gpa, bytes } => {
                out.push(3);
                put_u64(out, *gpa);
                put_bytes(out, bytes);
            }
        }
    }

    pub fn decode(bytes: &[u8]) -> Result<Self, ChannelError> {
        let mut reader = Reader::new(bytes);
        let effect = match reader.u8()? {
            1 => Self::write_memory(reader.u64()?, reader.bytes()?.to_vec())?,
            3 => Self::xor_memory(reader.u64()?, reader.bytes()?.to_vec())?,
            _ => return Err(ChannelError::Malformed),
        };
        reader.finish()?;
        Ok(effect)
    }
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct EffectSchedule {
    effects: BTreeMap<Moment, Vec<Effect>>,
}

impl EffectSchedule {
    pub fn insert(&mut self, moment: Moment, effect: Effect) {
        let effects = self.effects.entry(moment).or_default();
        effects.push(effect);
        effects.sort();
        effects.dedup();
    }

    #[must_use]
    pub fn at(&self, moment: Moment) -> &[Effect] {
        self.effects.get(&moment).map_or(&[], Vec::as_slice)
    }

    pub fn iter(&self) -> impl Iterator<Item = (Moment, &[Effect])> {
        self.effects
            .iter()
            .map(|(moment, effects)| (*moment, effects.as_slice()))
    }
}

#[derive(Clone, Debug, Eq, Error, PartialEq)]
pub enum ChannelError {
    #[error("channel payload exceeds the bounded maximum")]
    TooLarge,
    #[error("malformed channel state")]
    Malformed,
    #[error("request identity was reused with different payload bytes")]
    RequestIdentityMismatch,
    #[error("service handler state was rejected: {0}")]
    Handler(String),
    #[error("service handler changed outside its transactional copy; channel is poisoned")]
    Poisoned,
}

pub trait ServiceHandler: Send + Any {
    fn identity(&self) -> &[u8];

    fn configuration(&self) -> &[u8];

    fn local_services(&self) -> &[u16] {
        &[]
    }

    fn respond(
        &mut self,
        moment: Moment,
        question: &Question,
    ) -> Result<ServiceResponse, ChannelError>;

    fn snapshot_state(&self) -> Result<Vec<u8>, ChannelError>;

    fn restore_state(&mut self, state: &[u8]) -> Result<(), ChannelError>;

    fn reseed(&mut self, _seed: u64) {}

    fn clone_box(&self) -> Box<dyn ServiceHandler>;
}

impl ServiceHandler for Box<dyn ServiceHandler> {
    fn local_services(&self) -> &[u16] {
        (**self).local_services()
    }
    fn identity(&self) -> &[u8] {
        (**self).identity()
    }

    fn configuration(&self) -> &[u8] {
        (**self).configuration()
    }

    fn respond(
        &mut self,
        moment: Moment,
        question: &Question,
    ) -> Result<ServiceResponse, ChannelError> {
        (**self).respond(moment, question)
    }

    fn snapshot_state(&self) -> Result<Vec<u8>, ChannelError> {
        (**self).snapshot_state()
    }

    fn restore_state(&mut self, state: &[u8]) -> Result<(), ChannelError> {
        (**self).restore_state(state)
    }

    fn reseed(&mut self, seed: u64) {
        (**self).reseed(seed);
    }

    fn clone_box(&self) -> Box<dyn ServiceHandler> {
        (**self).clone_box()
    }
}

impl Clone for Box<dyn ServiceHandler> {
    fn clone(&self) -> Self {
        self.clone_box()
    }
}

pub trait ServiceHandlerFactory {
    type Handler: ServiceHandler;

    fn build(&self, identity: &[u8], configuration: &[u8]) -> Result<Self::Handler, ChannelError>;
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HandlerSnapshot {
    local_services: Vec<u16>,
    identity: Vec<u8>,
    configuration: Vec<u8>,
    state: Vec<u8>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HandlerFingerprint([u8; 32]);

fn capture_handler_fingerprint(
    handler: &dyn ServiceHandler,
) -> Result<HandlerFingerprint, ChannelError> {
    let mut hasher = Sha256::new();
    hasher.update(b"consonance-handler-fingerprint-v2\0");
    for bytes in [handler.identity(), handler.configuration()] {
        hasher.update(
            u64::try_from(bytes.len())
                .map_err(|_| ChannelError::TooLarge)?
                .to_le_bytes(),
        );
        hasher.update(bytes);
    }
    let policy = handler.local_services();
    validate_local_services(policy)?;
    hasher.update((policy.len() as u64).to_le_bytes());
    for id in policy {
        hasher.update(id.to_le_bytes());
    }
    let state = handler.snapshot_state()?;
    hasher.update(
        u64::try_from(state.len())
            .map_err(|_| ChannelError::TooLarge)?
            .to_le_bytes(),
    );
    hasher.update(&state);
    Ok(HandlerFingerprint(hasher.finalize().into()))
}

fn check_handler_contract(
    handler: &dyn ServiceHandler,
    identity: &[u8],
    configuration: &[u8],
    local_services: &[u16],
) -> Result<(), ChannelError> {
    validate_local_services(handler.local_services())?;
    if handler.identity() != identity
        || handler.configuration() != configuration
        || handler.local_services() != local_services
    {
        return Err(ChannelError::Handler(
            "handler identity or configuration differs from the snapshot".to_owned(),
        ));
    }
    Ok(())
}

fn check_handler_state(handler: &dyn ServiceHandler, state: &[u8]) -> Result<(), ChannelError> {
    if handler.snapshot_state()? != state {
        return Err(ChannelError::Handler(
            "handler state differs from the snapshot after restore".to_owned(),
        ));
    }
    Ok(())
}

impl HandlerSnapshot {
    pub fn capture(handler: &dyn ServiceHandler) -> Result<Self, ChannelError> {
        validate_local_services(handler.local_services())?;
        let local_services = handler.local_services().to_vec();
        let identity = handler.identity().to_vec();
        let configuration = handler.configuration().to_vec();
        check_len(identity.len())?;
        check_len(configuration.len())?;
        let state = handler.snapshot_state()?;
        check_len(state.len())?;
        Ok(Self {
            local_services,
            identity,
            configuration,
            state,
        })
    }

    pub fn restore<F: ServiceHandlerFactory>(
        &self,
        factory: &F,
    ) -> Result<F::Handler, ChannelError> {
        let mut handler = factory.build(&self.identity, &self.configuration)?;
        check_handler_contract(
            &handler,
            &self.identity,
            &self.configuration,
            &self.local_services,
        )?;
        handler.restore_state(&self.state)?;
        check_handler_contract(
            &handler,
            &self.identity,
            &self.configuration,
            &self.local_services,
        )?;
        check_handler_state(&handler, &self.state)?;
        Ok(handler)
    }

    #[must_use]
    pub fn identity(&self) -> &[u8] {
        &self.identity
    }

    #[must_use]
    pub fn configuration(&self) -> &[u8] {
        &self.configuration
    }

    #[must_use]
    pub fn local_services(&self) -> &[u16] {
        &self.local_services
    }

    pub fn state(&self) -> &[u8] {
        &self.state
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RecordedState {
    stream_state: u64,
    moment: Moment,
    overrides: Overrides,
    payloads: Option<Vec<Vec<u8>>>,
    coverage_schedule: Option<CoverageSchedule>,
    handler: HandlerSnapshot,
}

impl RecordedState {
    pub fn answers(&self) -> impl Iterator<Item = ((Moment, u16, u64), &Answer)> {
        self.overrides
            .iter()
            .map(|(key, record)| ((key.moment, key.service, key.request_id), &record.answer))
    }

    pub fn request_bindings(&self) -> impl Iterator<Item = ((Moment, u16, u64), [u8; 32])> + '_ {
        self.overrides.iter().filter_map(|(key, record)| {
            record
                .request_sha256
                .map(|digest| ((key.moment, key.service, key.request_id), digest))
        })
    }

    pub fn capture<H: ServiceHandler>(environment: &RecordedEnv<H>) -> Result<Self, ChannelError> {
        environment.ensure_healthy()?;
        if environment.overrides.oversized != 0 {
            return Err(ChannelError::TooLarge);
        }
        let state = Self {
            stream_state: environment.stream_state,
            moment: environment.moment,
            overrides: environment.overrides.clone(),
            payloads: environment.remaining_payloads(),
            coverage_schedule: environment.coverage_schedule.as_deref().cloned(),
            handler: HandlerSnapshot::capture(&environment.handler)?,
        };
        if state.encoded_len() > MAX_RECORDED_STATE_BYTES {
            return Err(ChannelError::TooLarge);
        }
        environment.ensure_healthy()?;
        Ok(state)
    }

    fn encoded_len(&self) -> usize {
        let mut size = 44usize.saturating_add(self.overrides.encoded_bytes);
        if let Some(entries) = &self.payloads {
            size = size.saturating_add(4);
            for entry in entries {
                size = size.saturating_add(4).saturating_add(entry.len());
            }
        }
        if let Some(schedule) = &self.coverage_schedule {
            size = size
                .saturating_add(4)
                .saturating_add(schedule.encode().len());
        }
        size.saturating_add(self.handler.identity.len())
            .saturating_add(self.handler.configuration.len())
            .saturating_add(self.handler.local_services.len() * 2)
            .saturating_add(self.handler.state.len())
    }

    pub fn encode(&self) -> Vec<u8> {
        let mut out = Vec::new();
        self.encode_into(&mut out);
        out
    }

    pub fn encode_into(&self, out: &mut Vec<u8>) {
        put_u32(out, SNAPSHOT_MAGIC);
        put_u16(out, SNAPSHOT_VERSION);
        put_u64(out, self.stream_state);
        put_u64(out, self.moment);
        put_len(out, self.overrides.len());
        for (key, record) in self.overrides.iter() {
            put_u64(out, key.moment);
            put_u16(out, key.service);
            put_u64(out, key.request_id);
            put_recorded_answer(out, record);
        }
        match &self.payloads {
            None => out.push(0),
            Some(entries) => {
                out.push(1);
                put_len(out, entries.len());
                for entry in entries {
                    put_bytes(out, entry);
                }
            }
        }
        match &self.coverage_schedule {
            None => out.push(0),
            Some(schedule) => {
                out.push(1);
                put_bytes(out, &schedule.encode());
            }
        }
        put_bytes(out, &self.handler.identity);
        put_bytes(out, &self.handler.configuration);
        let policy: Vec<_> = self
            .handler
            .local_services
            .iter()
            .flat_map(|id| id.to_le_bytes())
            .collect();
        put_bytes(out, &policy);
        put_bytes(out, &self.handler.state);
    }

    #[must_use]
    pub fn remaining_payloads(&self) -> Option<Vec<Vec<u8>>> {
        self.payloads.clone()
    }

    #[must_use]
    pub fn handler(&self) -> &HandlerSnapshot {
        &self.handler
    }

    pub fn decode(bytes: &[u8]) -> Result<Self, ChannelError> {
        if bytes.len() > MAX_RECORDED_STATE_BYTES {
            return Err(ChannelError::TooLarge);
        }
        let mut reader = Reader::new(bytes);
        if reader.u32()? != SNAPSHOT_MAGIC || reader.u16()? != SNAPSHOT_VERSION {
            return Err(ChannelError::Malformed);
        }
        let stream_state = reader.u64()?;
        let moment = reader.u64()?;
        let override_count = reader.count(19)?;
        let mut overrides = Overrides::default();
        let mut previous = None;
        for _ in 0..override_count {
            let key = DecisionKey {
                moment: reader.u64()?,
                service: reader.u16()?,
                request_id: reader.u64()?,
            };
            if previous.is_some_and(|previous| previous >= key) {
                return Err(ChannelError::Malformed);
            }
            previous = Some(key);
            overrides.insert(key, read_recorded_answer(&mut reader)?);
        }
        let payloads = match reader.u8()? {
            0 => None,
            1 => {
                let count = reader.count(4)?;
                let mut entries = Vec::with_capacity(count);
                for _ in 0..count {
                    entries.push(reader.bytes()?.to_vec());
                }
                Some(entries)
            }
            _ => return Err(ChannelError::Malformed),
        };
        let coverage_schedule = match reader.u8()? {
            0 => None,
            1 => Some(CoverageSchedule::decode(reader.bytes()?)?),
            _ => return Err(ChannelError::Malformed),
        };
        let handler = HandlerSnapshot {
            identity: reader.bytes()?.to_vec(),
            configuration: reader.bytes()?.to_vec(),
            local_services: decode_local_services(reader.bytes()?)?,
            state: reader.bytes()?.to_vec(),
        };
        reader.finish()?;
        Ok(Self {
            stream_state,
            moment,
            overrides,
            payloads,
            coverage_schedule,
            handler,
        })
    }

    pub fn restore_into<H: ServiceHandler + Clone>(
        &self,
        environment: &mut RecordedEnv<H>,
    ) -> Result<(), ChannelError> {
        environment.ensure_healthy()?;
        check_handler_contract(
            &environment.handler,
            &self.handler.identity,
            &self.handler.configuration,
            &self.handler.local_services,
        )?;
        let before = HandlerSnapshot::capture(&environment.handler)?;
        let mut handler = environment.checked_handler_clone()?;
        let restored = (|| {
            handler.restore_state(&self.handler.state)?;
            check_handler_contract(
                &handler,
                &self.handler.identity,
                &self.handler.configuration,
                &self.handler.local_services,
            )?;
            check_handler_state(&handler, &self.handler.state)
        })();
        environment.verify_handler_unchanged(&before)?;
        restored?;
        environment.handler = handler;
        environment.stream_state = self.stream_state;
        environment.moment = self.moment;
        environment.overrides = self.overrides.clone();
        environment.restore_payloads(self.payloads.clone());
        environment.set_coverage_schedule(self.coverage_schedule.clone());
        Ok(())
    }
}

#[derive(Clone, Debug, Default)]
pub struct NominalHandler;

const NOMINAL_IDENTITY: &[u8] = b"consonance.nominal-handler.v1";

fn is_nominal_handler(handler: &dyn ServiceHandler) -> bool {
    let any = handler as &dyn Any;
    if any.is::<NominalHandler>() {
        return true;
    }
    any.downcast_ref::<Box<dyn ServiceHandler>>()
        .is_some_and(|inner| is_nominal_handler(inner.as_ref()))
}

impl ServiceHandler for NominalHandler {
    fn identity(&self) -> &[u8] {
        NOMINAL_IDENTITY
    }

    fn configuration(&self) -> &[u8] {
        &[]
    }

    fn respond(
        &mut self,
        _moment: Moment,
        _question: &Question,
    ) -> Result<ServiceResponse, ChannelError> {
        Ok(ServiceResponse::Answered(Answer::Nominal))
    }

    fn snapshot_state(&self) -> Result<Vec<u8>, ChannelError> {
        Ok(Vec::new())
    }

    fn restore_state(&mut self, state: &[u8]) -> Result<(), ChannelError> {
        if state.is_empty() {
            Ok(())
        } else {
            Err(ChannelError::Handler(
                "nominal handler has no dynamic state".to_owned(),
            ))
        }
    }

    fn clone_box(&self) -> Box<dyn ServiceHandler> {
        Box::new(self.clone())
    }
}

pub struct RecordedEnv<H: ServiceHandler> {
    stream_state: u64,
    overrides: Overrides,
    moment: Moment,
    payloads: Option<Vec<Vec<u8>>>,
    payload_cursor: usize,
    coverage_schedule: Option<Arc<CoverageSchedule>>,
    handler: H,
    poisoned: Arc<AtomicBool>,
}

impl<H> Clone for RecordedEnv<H>
where
    H: ServiceHandler + Clone,
{
    fn clone(&self) -> Self {
        let handler = self.clone_handler();
        Self {
            stream_state: self.stream_state,
            overrides: self.overrides.clone(),
            moment: self.moment,
            payloads: self.payloads.clone(),
            payload_cursor: self.payload_cursor,
            coverage_schedule: self.coverage_schedule.clone(),
            handler,
            poisoned: Arc::clone(&self.poisoned),
        }
    }
}

impl<H: ServiceHandler> fmt::Debug for RecordedEnv<H> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("RecordedEnv")
            .field("stream_state", &self.stream_state)
            .field("overrides", &self.overrides)
            .field("moment", &self.moment)
            .field("payload_cursor", &self.payload_cursor)
            .field("coverage_schedule", &self.coverage_schedule)
            .field("handler_identity", &self.handler.identity())
            .field("poisoned", &self.poisoned.load(Ordering::Acquire))
            .finish_non_exhaustive()
    }
}

impl<H: ServiceHandler> RecordedEnv<H> {
    fn clone_handler(&self) -> H
    where
        H: Clone,
    {
        let before = self.handler_fingerprint();
        let handler = self.handler.clone();
        let candidate = capture_handler_fingerprint(&handler);
        let after = self.handler_fingerprint();
        if !matches!(
            (&before, &candidate, &after),
            (Ok(before), Ok(candidate), Ok(after)) if before == candidate && before == after
        ) {
            self.poisoned.store(true, Ordering::Release);
        }
        handler
    }

    fn checked_handler_clone(&self) -> Result<H, ChannelError>
    where
        H: Clone,
    {
        self.ensure_healthy()?;
        let handler = self.clone_handler();
        self.ensure_healthy()?;
        Ok(handler)
    }

    pub fn checked_clone(&self) -> Result<Self, ChannelError>
    where
        H: Clone,
    {
        self.ensure_healthy()?;
        let candidate = self.clone();
        self.ensure_healthy()?;
        Ok(candidate)
    }

    pub fn request_bindings(&self) -> impl Iterator<Item = ((Moment, u16, u64), [u8; 32])> + '_ {
        self.overrides.iter().filter_map(|(key, record)| {
            record
                .request_sha256
                .map(|digest| ((key.moment, key.service, key.request_id), digest))
        })
    }

    pub fn new(seed: u64, handler: H) -> Self {
        let mut environment = Self {
            stream_state: normalize_seed(seed),
            overrides: Overrides::default(),
            moment: 0,
            payloads: None,
            payload_cursor: 0,
            coverage_schedule: None,
            handler,
            poisoned: Arc::new(AtomicBool::new(false)),
        };
        environment.handler.reseed(seed);
        environment
    }

    pub fn set_moment(&mut self, moment: Moment) {
        self.moment = moment;
    }

    pub fn reseed(&mut self, seed: u64) -> Result<(), ChannelError>
    where
        H: Clone,
    {
        self.ensure_healthy()?;
        let before = HandlerSnapshot::capture(&self.handler)?;
        let mut candidate = self.checked_handler_clone()?;
        candidate.reseed(seed);
        self.verify_handler_unchanged(&before)?;
        let after = HandlerSnapshot::capture(&candidate)?;
        if after.identity() != before.identity()
            || after.configuration() != before.configuration()
            || after.local_services() != before.local_services()
        {
            return Err(ChannelError::Handler(
                "handler identity or configuration changed while reseeding".to_owned(),
            ));
        }
        self.handler = candidate;
        self.stream_state = normalize_seed(seed);
        Ok(())
    }

    pub fn record(&mut self, moment: Moment, answer: Answer) {
        self.record_service_request(moment, 0, 0, answer);
    }

    pub fn record_request(&mut self, moment: Moment, request_id: u64, answer: Answer) {
        self.record_service_request(moment, 0, request_id, answer);
    }

    pub fn record_service_request(
        &mut self,
        moment: Moment,
        service: u16,
        request_id: u64,
        answer: Answer,
    ) {
        self.overrides.insert(
            DecisionKey {
                moment,
                service,
                request_id,
            },
            RecordedAnswer {
                answer,
                request_sha256: None,
            },
        );
    }

    pub fn record_bound_service_request(
        &mut self,
        moment: Moment,
        service: u16,
        request_id: u64,
        request_sha256: [u8; 32],
        answer: Answer,
    ) {
        self.overrides.insert(
            DecisionKey {
                moment,
                service,
                request_id,
            },
            RecordedAnswer {
                answer,
                request_sha256: Some(request_sha256),
            },
        );
    }

    pub fn record_question(&mut self, moment: Moment, question: &Question, answer: Answer) {
        self.record_bound_service_request(
            moment,
            question.service(),
            question.request_id(),
            Sha256::digest(question.payload()).into(),
            answer,
        );
    }

    pub fn set_payloads(&mut self, payloads: Option<Vec<Vec<u8>>>) -> Result<(), ChannelError> {
        self.ensure_healthy()?;
        if let Some(entries) = &payloads {
            for entry in entries {
                check_len(entry.len())?;
            }
        }
        self.payloads = payloads;
        self.payload_cursor = 0;
        Ok(())
    }

    pub fn set_coverage_schedule(&mut self, schedule: Option<CoverageSchedule>) {
        self.coverage_schedule = schedule.map(Arc::new);
    }

    pub fn coverage_schedule(&self) -> Option<&CoverageSchedule> {
        self.coverage_schedule.as_deref()
    }

    #[must_use]
    pub fn payload_configured(&self) -> bool {
        self.payloads.is_some()
    }

    pub fn pull_payload(&mut self, bytes: usize) -> Result<Option<Vec<u8>>, ChannelError> {
        self.ensure_healthy()?;
        check_len(bytes)?;
        let Some(entries) = self.payloads.as_ref() else {
            return Ok(None);
        };
        let Some(entry) = entries.get(self.payload_cursor) else {
            return Ok(None);
        };
        if entry.len() != bytes {
            return Err(ChannelError::Handler(
                "payload tape entry length does not match the request".to_owned(),
            ));
        }
        self.payload_cursor += 1;
        Ok(Some(entry.clone()))
    }

    pub fn decide_recorded(
        &mut self,
        question: &Question,
    ) -> Result<ServiceResponse, ChannelError> {
        if let Some(answer) = self.recorded_override(question)? {
            return Ok(ServiceResponse::Answered(answer));
        }
        if let Some(answer) = self.decide_core_supply(question)? {
            return Ok(ServiceResponse::Answered(answer));
        }
        if is_nominal_handler(&self.handler) {
            return Ok(ServiceResponse::Answered(Answer::Nominal));
        }
        Ok(ServiceResponse::External)
    }

    pub(crate) fn recorded_override(
        &mut self,
        question: &Question,
    ) -> Result<Option<Answer>, ChannelError> {
        self.ensure_healthy()?;
        let key = DecisionKey {
            moment: self.moment,
            service: question.service(),
            request_id: question.request_id(),
        };
        let Some(record) = self.overrides.get(&key) else {
            return Ok(None);
        };
        let digest: [u8; 32] = Sha256::digest(question.payload()).into();
        let (answer, binding) = (record.answer.clone(), record.request_sha256);
        match binding {
            Some(bound) if bound != digest => Err(ChannelError::RequestIdentityMismatch),
            Some(_) => Ok(Some(answer)),
            None => {
                self.overrides.insert(
                    key,
                    RecordedAnswer {
                        answer: answer.clone(),
                        request_sha256: Some(digest),
                    },
                );
                Ok(Some(answer))
            }
        }
    }

    pub fn decide(&mut self, question: &Question) -> Result<ServiceResponse, ChannelError>
    where
        H: Clone,
    {
        if let response @ ServiceResponse::Answered(_) = self.decide_recorded(question)? {
            return Ok(response);
        }
        let before = HandlerSnapshot::capture(&self.handler)?;
        let mut candidate = self.checked_handler_clone()?;
        let response = candidate.respond(self.moment, question);
        self.verify_handler_unchanged(&before)?;
        let response = response?;
        if let ServiceResponse::Answered(answer) = &response {
            if let Answer::Data(bytes) = answer {
                check_len(bytes.len())?;
            }
            if candidate.identity() != self.handler.identity()
                || candidate.configuration() != self.handler.configuration()
                || candidate.local_services() != self.handler.local_services()
            {
                return Err(ChannelError::Handler(
                    "handler identity or configuration changed while answering".to_owned(),
                ));
            }
            self.ensure_healthy()?;
            self.handler = candidate;
        }
        Ok(response)
    }

    pub fn handler(&self) -> &H {
        &self.handler
    }

    pub fn snapshot_state(&self) -> Result<RecordedState, ChannelError> {
        RecordedState::capture(self)
    }

    fn ensure_healthy(&self) -> Result<(), ChannelError> {
        if self.is_poisoned() {
            Err(ChannelError::Poisoned)
        } else {
            Ok(())
        }
    }

    pub fn is_poisoned(&self) -> bool {
        self.poisoned.load(Ordering::Acquire)
    }

    pub fn verify_handler_unchanged(&self, before: &HandlerSnapshot) -> Result<(), ChannelError> {
        if HandlerSnapshot::capture(&self.handler).as_ref() != Ok(before) {
            self.poisoned.store(true, Ordering::Release);
        }
        self.ensure_healthy()
    }

    pub fn handler_fingerprint(&self) -> Result<HandlerFingerprint, ChannelError> {
        self.ensure_healthy()?;
        let fingerprint = capture_handler_fingerprint(&self.handler)?;
        self.ensure_healthy()?;
        Ok(fingerprint)
    }

    pub fn verify_handler_fingerprint_unchanged(
        &self,
        before: &HandlerFingerprint,
    ) -> Result<(), ChannelError> {
        if self.handler_fingerprint().as_ref() != Ok(before) {
            self.poisoned.store(true, Ordering::Release);
        }
        self.ensure_healthy()
    }

    pub fn snapshot_state_with_binding_reserve(&self) -> Result<RecordedState, ChannelError> {
        let state = self.snapshot_state()?;
        let unbound = state.overrides.unbound;
        if state
            .encoded_len()
            .saturating_add(unbound.saturating_mul(Sha256::output_size()))
            > MAX_RECORDED_STATE_BYTES
        {
            return Err(ChannelError::TooLarge);
        }
        Ok(state)
    }

    pub fn remaining_payloads(&self) -> Option<Vec<Vec<u8>>> {
        self.payloads
            .as_ref()
            .map(|entries| entries[self.payload_cursor..].to_vec())
    }

    fn restore_payloads(&mut self, payloads: Option<Vec<Vec<u8>>>) {
        self.payloads = payloads;
        self.payload_cursor = 0;
    }

    fn decide_core_supply(&mut self, question: &Question) -> Result<Option<Answer>, ChannelError> {
        let service = question.service();
        if service != SERVICE_ENTROPY && service != SERVICE_SCHEDULER {
            return Ok(None);
        }
        let bytes = question.payload();
        let request = bytes
            .try_into()
            .map_err(|_| ChannelError::Malformed)
            .map(u32::from_le_bytes)?;
        match service {
            SERVICE_ENTROPY => {
                let length = usize::try_from(request).map_err(|_| ChannelError::TooLarge)?;
                check_len(length)?;
                let mut output = Vec::with_capacity(length);
                while output.len() < length {
                    output.extend_from_slice(&next_stream(&mut self.stream_state).to_le_bytes());
                }
                output.truncate(length);
                Ok(Some(Answer::Data(output)))
            }
            SERVICE_SCHEDULER => {
                if request == 0 {
                    return Err(ChannelError::Malformed);
                }
                let selected = (next_stream(&mut self.stream_state) % u64::from(request)) as u32;
                Ok(Some(Answer::Data(selected.to_le_bytes().to_vec())))
            }
            _ => unreachable!(),
        }
    }
}

impl RecordedEnv<NominalHandler> {
    pub fn nominal(seed: u64) -> Self {
        Self::new(seed, NominalHandler)
    }
}

pub fn restore_handler<F: ServiceHandlerFactory>(
    snapshot: &HandlerSnapshot,
    factory: &F,
) -> Result<F::Handler, ChannelError> {
    snapshot.restore(factory)
}

fn normalize_seed(seed: u64) -> u64 {
    if seed == 0 {
        0x9E37_79B9_7F4A_7C15
    } else {
        seed
    }
}

fn next_stream(state: &mut u64) -> u64 {
    *state ^= *state >> 12;
    *state ^= *state << 25;
    *state ^= *state >> 27;
    state.wrapping_mul(0x2545_F491_4F6C_DD1D)
}

fn check_len(len: usize) -> Result<(), ChannelError> {
    (len <= MAX_CHANNEL_BYTES)
        .then_some(())
        .ok_or(ChannelError::TooLarge)
}

fn put_u16(out: &mut Vec<u8>, value: u16) {
    out.extend_from_slice(&value.to_le_bytes());
}

fn put_u32(out: &mut Vec<u8>, value: u32) {
    out.extend_from_slice(&value.to_le_bytes());
}

fn put_u64(out: &mut Vec<u8>, value: u64) {
    out.extend_from_slice(&value.to_le_bytes());
}

fn put_len(out: &mut Vec<u8>, len: usize) {
    put_u32(out, u32::try_from(len).unwrap_or(u32::MAX));
}

fn put_bytes(out: &mut Vec<u8>, bytes: &[u8]) {
    put_len(out, bytes.len());
    out.extend_from_slice(bytes);
}

fn put_answer(out: &mut Vec<u8>, answer: &Answer) {
    match answer {
        Answer::Nominal => out.push(0),
        Answer::Data(bytes) => {
            out.push(1);
            put_bytes(out, bytes);
        }
    }
}

fn put_recorded_answer(out: &mut Vec<u8>, record: &RecordedAnswer) {
    match record.request_sha256 {
        None => put_answer(out, &record.answer),
        Some(digest) => {
            out.push(if matches!(record.answer, Answer::Nominal) {
                2
            } else {
                3
            });
            out.extend_from_slice(&digest);
            if let Answer::Data(bytes) = &record.answer {
                put_bytes(out, bytes);
            }
        }
    }
}

fn read_answer(reader: &mut Reader<'_>) -> Result<Answer, ChannelError> {
    match reader.u8()? {
        0 => Ok(Answer::Nominal),
        1 => Ok(Answer::Data(reader.bytes()?.to_vec())),
        _ => Err(ChannelError::Malformed),
    }
}

fn read_recorded_answer(reader: &mut Reader<'_>) -> Result<RecordedAnswer, ChannelError> {
    let Some(&tag) = reader.bytes.get(reader.cursor) else {
        return Err(ChannelError::Malformed);
    };
    if tag <= 1 {
        return Ok(RecordedAnswer {
            answer: read_answer(reader)?,
            request_sha256: None,
        });
    }
    reader.u8()?;
    if tag > 3 {
        return Err(ChannelError::Malformed);
    }
    let mut digest = [0; 32];
    digest.copy_from_slice(reader.take(32)?);
    let answer = if tag == 2 {
        Answer::Nominal
    } else {
        Answer::Data(reader.bytes()?.to_vec())
    };
    Ok(RecordedAnswer {
        answer,
        request_sha256: Some(digest),
    })
}

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd)]
struct DecisionKey {
    moment: Moment,
    service: u16,
    request_id: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct RecordedAnswer {
    answer: Answer,
    request_sha256: Option<[u8; 32]>,
}

impl RecordedAnswer {
    fn encoded_len(&self) -> usize {
        let binding = if self.request_sha256.is_some() { 32 } else { 0 };
        let data = match &self.answer {
            Answer::Nominal => 0,
            Answer::Data(bytes) => 4 + bytes.len(),
        };
        19 + binding + data
    }

    fn is_oversized(&self) -> bool {
        matches!(&self.answer, Answer::Data(bytes) if bytes.len() > MAX_CHANNEL_BYTES)
    }
}

#[derive(Clone, Default, Eq, PartialEq)]
struct Overrides {
    records: SharedMap<DecisionKey, RecordedAnswer>,
    encoded_bytes: usize,
    unbound: usize,
    oversized: usize,
}

impl Overrides {
    fn len(&self) -> usize {
        self.records.len()
    }

    fn get(&self, key: &DecisionKey) -> Option<&RecordedAnswer> {
        self.records.get(key)
    }

    fn iter(&self) -> crate::shared_map::Iter<'_, DecisionKey, RecordedAnswer> {
        self.records.iter()
    }

    fn insert(&mut self, key: DecisionKey, record: RecordedAnswer) {
        self.encoded_bytes += record.encoded_len();
        self.unbound += usize::from(record.request_sha256.is_none());
        self.oversized += usize::from(record.is_oversized());
        if let Some(previous) = self.records.insert(key, record) {
            self.encoded_bytes -= previous.encoded_len();
            self.unbound -= usize::from(previous.request_sha256.is_none());
            self.oversized -= usize::from(previous.is_oversized());
        }
    }
}

impl fmt::Debug for Overrides {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.records.fmt(formatter)
    }
}

struct Reader<'a> {
    bytes: &'a [u8],
    cursor: usize,
}

impl<'a> Reader<'a> {
    fn new(bytes: &'a [u8]) -> Self {
        Self { bytes, cursor: 0 }
    }

    fn take(&mut self, count: usize) -> Result<&'a [u8], ChannelError> {
        let end = self
            .cursor
            .checked_add(count)
            .ok_or(ChannelError::Malformed)?;
        let bytes = self
            .bytes
            .get(self.cursor..end)
            .ok_or(ChannelError::Malformed)?;
        self.cursor = end;
        Ok(bytes)
    }

    fn u8(&mut self) -> Result<u8, ChannelError> {
        Ok(*self.take(1)?.first().ok_or(ChannelError::Malformed)?)
    }

    fn u16(&mut self) -> Result<u16, ChannelError> {
        Ok(u16::from_le_bytes(
            self.take(2)?.try_into().unwrap_or([0; 2]),
        ))
    }

    fn u32(&mut self) -> Result<u32, ChannelError> {
        Ok(u32::from_le_bytes(
            self.take(4)?.try_into().unwrap_or([0; 4]),
        ))
    }

    fn u64(&mut self) -> Result<u64, ChannelError> {
        Ok(u64::from_le_bytes(
            self.take(8)?.try_into().unwrap_or([0; 8]),
        ))
    }

    fn len(&mut self) -> Result<usize, ChannelError> {
        let len = usize::try_from(self.u32()?).map_err(|_| ChannelError::Malformed)?;
        check_len(len)?;
        Ok(len)
    }

    fn count(&mut self, minimum_bytes: usize) -> Result<usize, ChannelError> {
        let count = self.len()?;
        if count > self.remaining() / minimum_bytes {
            return Err(ChannelError::Malformed);
        }
        Ok(count)
    }

    fn remaining(&self) -> usize {
        self.bytes.len().saturating_sub(self.cursor)
    }

    fn bytes(&mut self) -> Result<&'a [u8], ChannelError> {
        let len = self.len()?;
        self.take(len)
    }

    fn finish(self) -> Result<(), ChannelError> {
        self.cursor
            .eq(&self.bytes.len())
            .then_some(())
            .ok_or(ChannelError::Malformed)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[derive(Clone)]
    struct PolicyHandler {
        policy: Vec<u16>,
        state: u8,
        drift: bool,
    }
    impl ServiceHandler for PolicyHandler {
        fn identity(&self) -> &[u8] {
            b"policy-test"
        }
        fn configuration(&self) -> &[u8] {
            &[]
        }
        fn local_services(&self) -> &[u16] {
            &self.policy
        }
        fn respond(&mut self, _: Moment, _: &Question) -> Result<ServiceResponse, ChannelError> {
            self.state += 1;
            if self.drift {
                self.policy = vec![20];
            }
            Ok(ServiceResponse::Answered(Answer::Nominal))
        }
        fn snapshot_state(&self) -> Result<Vec<u8>, ChannelError> {
            Ok(vec![self.state])
        }
        fn restore_state(&mut self, state: &[u8]) -> Result<(), ChannelError> {
            self.state = *state.first().ok_or(ChannelError::Malformed)?;
            if self.drift && self.state == 9 {
                self.policy = vec![20];
            }
            Ok(())
        }
        fn reseed(&mut self, seed: u64) {
            if self.drift && seed == 9 {
                self.policy = vec![20];
            }
        }
        fn clone_box(&self) -> Box<dyn ServiceHandler> {
            Box::new(self.clone())
        }
    }
    struct PolicyFactory(Vec<u16>);
    impl ServiceHandlerFactory for PolicyFactory {
        type Handler = PolicyHandler;
        fn build(&self, _: &[u8], _: &[u8]) -> Result<PolicyHandler, ChannelError> {
            Ok(PolicyHandler {
                policy: self.0.clone(),
                state: 0,
                drift: false,
            })
        }
    }
    #[test]
    fn local_policy_is_bounded_canonical_and_part_of_snapshot_and_fingerprint() {
        let maximum: Vec<_> = (5..5 + MAX_LOCAL_SERVICES as u16).collect();
        validate_local_services(&maximum).unwrap();
        let bytes: Vec<_> = maximum.iter().flat_map(|id| id.to_le_bytes()).collect();
        assert_eq!(decode_local_services(&bytes).unwrap(), maximum);
        for policy in [
            vec![0],
            vec![4],
            vec![20, 19],
            vec![19, 19],
            vec![19; MAX_LOCAL_SERVICES + 1],
        ] {
            assert!(validate_local_services(&policy).is_err());
        }
        assert!(decode_local_services(&[19]).is_err());
        let handler = PolicyHandler {
            policy: vec![19, 25],
            state: 7,
            drift: false,
        };
        let snapshot = HandlerSnapshot::capture(&handler).unwrap();
        assert!(snapshot.restore(&PolicyFactory(vec![19])).is_err());
        assert_eq!(
            snapshot
                .restore(&PolicyFactory(vec![19, 25]))
                .unwrap()
                .state,
            7
        );
        let original = capture_handler_fingerprint(&handler).unwrap();
        let mut changed = handler.clone();
        changed.policy = vec![19];
        assert_ne!(original, capture_handler_fingerprint(&changed).unwrap());
        let env = RecordedEnv::new(7, handler);
        let state = env.snapshot_state().unwrap();
        assert_eq!(state.encoded_len(), state.encode().len());
        assert_eq!(RecordedState::decode(&state.encode()).unwrap(), state);
        let mut old = state.encode();
        old[4..6].copy_from_slice(&3_u16.to_le_bytes());
        assert!(RecordedState::decode(&old).is_err());
        let mut other = RecordedEnv::new(7, changed);
        let before = other.snapshot_state().unwrap();
        assert!(state.restore_into(&mut other).is_err());
        assert_eq!(other.snapshot_state().unwrap(), before);
    }
    #[test]
    fn local_policy_cannot_change_during_reseed_or_restore() {
        let mut env = RecordedEnv::new(
            7,
            PolicyHandler {
                policy: vec![19],
                state: 0,
                drift: true,
            },
        );
        let before = env.snapshot_state().unwrap();
        assert!(env.reseed(9).is_err());
        assert_eq!(env.snapshot_state().unwrap(), before);
        let source = RecordedEnv::new(
            7,
            PolicyHandler {
                policy: vec![19],
                state: 9,
                drift: false,
            },
        )
        .snapshot_state()
        .unwrap();
        assert!(source.restore_into(&mut env).is_err());
        assert_eq!(env.snapshot_state().unwrap(), before);
    }

    #[test]
    fn local_policy_cannot_change_during_handler_commit() {
        let mut env = RecordedEnv::new(
            7,
            PolicyHandler {
                policy: vec![19],
                state: 0,
                drift: true,
            },
        );
        let before = env.snapshot_state().unwrap();
        assert!(env.decide(&Question::new(19, Vec::new()).unwrap()).is_err());
        assert_eq!(env.snapshot_state().unwrap(), before);
    }

    #[test]
    fn channel_capacity_is_one_mebibyte() {
        assert_eq!(MAX_CHANNEL_BYTES, 1_048_576);
    }

    #[derive(Clone, Debug)]
    struct Handler {
        counter: u64,
    }

    impl ServiceHandler for Handler {
        fn identity(&self) -> &[u8] {
            b"test-handler-v1"
        }

        fn configuration(&self) -> &[u8] {
            b"test-config"
        }

        fn respond(
            &mut self,
            _moment: Moment,
            question: &Question,
        ) -> Result<ServiceResponse, ChannelError> {
            self.counter += 1;
            if question.service() == u16::MAX {
                return Ok(ServiceResponse::Answered(Answer::Data(vec![
                    0;
                    MAX_CHANNEL_BYTES
                        + 1
                ])));
            }
            Ok(ServiceResponse::Answered(Answer::data(
                self.counter.to_le_bytes().to_vec(),
            )?))
        }

        fn snapshot_state(&self) -> Result<Vec<u8>, ChannelError> {
            Ok(self.counter.to_le_bytes().to_vec())
        }

        fn restore_state(&mut self, state: &[u8]) -> Result<(), ChannelError> {
            if state.len() != 8 {
                self.counter = 0;
                return Err(ChannelError::Malformed);
            }
            let bytes: [u8; 8] = state.try_into().map_err(|_| ChannelError::Malformed)?;
            self.counter = u64::from_le_bytes(bytes);
            Ok(())
        }

        fn clone_box(&self) -> Box<dyn ServiceHandler> {
            Box::new(self.clone())
        }
    }

    #[derive(Clone, Debug, Eq, PartialEq)]
    struct ForwardingHandler {
        seed: u64,
        state: u8,
    }

    impl ServiceHandler for ForwardingHandler {
        fn identity(&self) -> &[u8] {
            b"forwarding-handler-v1"
        }

        fn configuration(&self) -> &[u8] {
            b"forwarding-config"
        }

        fn respond(
            &mut self,
            _moment: Moment,
            _question: &Question,
        ) -> Result<ServiceResponse, ChannelError> {
            self.state = self.state.wrapping_add(1);
            Ok(ServiceResponse::Answered(Answer::Nominal))
        }

        fn snapshot_state(&self) -> Result<Vec<u8>, ChannelError> {
            Ok(vec![self.state, self.seed as u8])
        }

        fn restore_state(&mut self, state: &[u8]) -> Result<(), ChannelError> {
            let [value, seed] = state else {
                return Err(ChannelError::Malformed);
            };
            self.state = *value;
            self.seed = u64::from(*seed);
            Ok(())
        }

        fn reseed(&mut self, seed: u64) {
            self.seed = seed;
        }

        fn clone_box(&self) -> Box<dyn ServiceHandler> {
            Box::new(self.clone())
        }
    }

    struct Factory;

    impl ServiceHandlerFactory for Factory {
        type Handler = Handler;

        fn build(
            &self,
            identity: &[u8],
            configuration: &[u8],
        ) -> Result<Self::Handler, ChannelError> {
            (identity == b"test-handler-v1" && configuration == b"test-config")
                .then_some(Handler { counter: 0 })
                .ok_or_else(|| ChannelError::Handler("wrong handler identity".to_owned()))
        }
    }

    #[derive(Clone)]
    struct ChangingContractHandler {
        identity: Vec<u8>,
        configuration: Vec<u8>,
        state: Vec<u8>,
        respond_change: Option<bool>,
        reseed_change: Option<bool>,
    }

    impl ChangingContractHandler {
        fn new(identity: u8, configuration: u8, state: [u8; 2]) -> Self {
            Self {
                identity: vec![identity],
                configuration: vec![configuration],
                state: state.to_vec(),
                respond_change: None,
                reseed_change: None,
            }
        }
    }

    impl ServiceHandler for ChangingContractHandler {
        fn identity(&self) -> &[u8] {
            &self.identity
        }

        fn configuration(&self) -> &[u8] {
            &self.configuration
        }

        fn respond(
            &mut self,
            _moment: Moment,
            question: &Question,
        ) -> Result<ServiceResponse, ChannelError> {
            if question.service() == 19 {
                match self.respond_change {
                    Some(true) => self.identity = vec![9],
                    Some(false) => self.configuration = vec![9],
                    None => {}
                }
            }
            Ok(ServiceResponse::Answered(Answer::Data(
                self.configuration.clone(),
            )))
        }

        fn snapshot_state(&self) -> Result<Vec<u8>, ChannelError> {
            Ok(self.state.clone())
        }

        fn restore_state(&mut self, state: &[u8]) -> Result<(), ChannelError> {
            let [identity, configuration] = state else {
                return Err(ChannelError::Malformed);
            };
            self.identity = vec![*identity];
            self.configuration = vec![*configuration];
            self.state = state.to_vec();
            Ok(())
        }

        fn reseed(&mut self, seed: u64) {
            if seed == 42 {
                match self.reseed_change {
                    Some(true) => self.identity = vec![9],
                    Some(false) => self.configuration = vec![9],
                    None => {}
                }
            }
        }

        fn clone_box(&self) -> Box<dyn ServiceHandler> {
            Box::new(self.clone())
        }
    }

    struct ChangingContractFactory {
        identity: u8,
        configuration: u8,
    }

    impl ServiceHandlerFactory for ChangingContractFactory {
        type Handler = ChangingContractHandler;

        fn build(
            &self,
            _identity: &[u8],
            _configuration: &[u8],
        ) -> Result<Self::Handler, ChannelError> {
            Ok(ChangingContractHandler::new(
                self.identity,
                self.configuration,
                [0, 0],
            ))
        }
    }

    #[derive(Clone)]
    struct IgnoringStateHandler(u8);

    impl ServiceHandler for IgnoringStateHandler {
        fn identity(&self) -> &[u8] {
            b"ignoring-state-handler"
        }

        fn configuration(&self) -> &[u8] {
            b"fixed"
        }

        fn respond(
            &mut self,
            _moment: Moment,
            _question: &Question,
        ) -> Result<ServiceResponse, ChannelError> {
            Ok(ServiceResponse::Answered(Answer::Data(vec![self.0])))
        }

        fn snapshot_state(&self) -> Result<Vec<u8>, ChannelError> {
            Ok(vec![self.0])
        }

        fn restore_state(&mut self, state: &[u8]) -> Result<(), ChannelError> {
            let [_] = state else {
                return Err(ChannelError::Malformed);
            };
            Ok(())
        }

        fn clone_box(&self) -> Box<dyn ServiceHandler> {
            Box::new(self.clone())
        }
    }

    struct IgnoringStateFactory(u8);

    impl ServiceHandlerFactory for IgnoringStateFactory {
        type Handler = IgnoringStateHandler;

        fn build(
            &self,
            _identity: &[u8],
            _configuration: &[u8],
        ) -> Result<Self::Handler, ChannelError> {
            Ok(IgnoringStateHandler(self.0))
        }
    }

    #[test]
    fn recorded_restore_rejects_contract_mutation_without_changing_environment() {
        let source = RecordedEnv::new(1, ChangingContractHandler::new(1, 2, [3, 4]));
        let saved = source.snapshot_state().unwrap();
        let mut target = RecordedEnv::new(9, ChangingContractHandler::new(1, 2, [1, 2]));
        let before = target.snapshot_state().unwrap().encode();
        assert!(saved.restore_into(&mut target).is_err());
        assert_eq!(target.snapshot_state().unwrap().encode(), before);
        assert_eq!(target.handler().identity(), &[1]);
        assert_eq!(target.handler().configuration(), &[2]);
        assert_eq!(
            target
                .decide(&Question::new(7, Vec::new()).unwrap())
                .unwrap(),
            ServiceResponse::Answered(Answer::Data(vec![2]))
        );
    }

    #[test]
    fn handler_snapshot_rejects_factory_contract_before_restore() {
        let snapshot =
            HandlerSnapshot::capture(&ChangingContractHandler::new(1, 2, [1, 2])).unwrap();
        for factory in [
            ChangingContractFactory {
                identity: 9,
                configuration: 2,
            },
            ChangingContractFactory {
                identity: 1,
                configuration: 9,
            },
        ] {
            assert!(snapshot.restore(&factory).is_err());
        }
        let handler = snapshot
            .restore(&ChangingContractFactory {
                identity: 1,
                configuration: 2,
            })
            .unwrap();
        assert_eq!(handler.identity(), &[1]);
        assert_eq!(handler.configuration(), &[2]);
        assert_eq!(handler.snapshot_state().unwrap(), vec![1, 2]);
    }

    #[test]
    fn handler_snapshot_rejects_contract_mutation_after_restore() {
        let snapshot =
            HandlerSnapshot::capture(&ChangingContractHandler::new(1, 2, [3, 4])).unwrap();
        assert!(
            snapshot
                .restore(&ChangingContractFactory {
                    identity: 1,
                    configuration: 2,
                })
                .is_err()
        );
    }

    #[test]
    fn recorded_restore_rejects_ignored_handler_state_without_changing_environment() {
        let source = RecordedEnv::new(1, IgnoringStateHandler(7));
        let saved = source.snapshot_state().unwrap();
        let mut target = RecordedEnv::new(9, IgnoringStateHandler(9));
        let before = target.snapshot_state().unwrap().encode();
        assert!(saved.restore_into(&mut target).is_err());
        assert_eq!(target.snapshot_state().unwrap().encode(), before);
        assert_eq!(
            target
                .decide(&Question::new(7, Vec::new()).unwrap())
                .unwrap(),
            ServiceResponse::Answered(Answer::Data(vec![9]))
        );
    }

    #[test]
    fn handler_snapshot_rejects_ignored_state_after_restore() {
        let snapshot = HandlerSnapshot::capture(&IgnoringStateHandler(7)).unwrap();
        assert!(snapshot.restore(&IgnoringStateFactory(9)).is_err());
        let handler = snapshot.restore(&IgnoringStateFactory(7)).unwrap();
        assert_eq!(handler.snapshot_state().unwrap(), snapshot.state());
    }

    #[test]
    fn opaque_handler_state_round_trips_and_factory_checks_identity() {
        let question = Question::new(7, vec![1, 2]).unwrap();
        let mut env = RecordedEnv::new(9, Handler { counter: 0 });
        assert_eq!(
            env.decide(&question).unwrap(),
            ServiceResponse::Answered(Answer::data(vec![1, 0, 0, 0, 0, 0, 0, 0]).unwrap())
        );
        let snapshot = env.snapshot_state().unwrap();
        let bytes = snapshot.encode();
        let decoded = RecordedState::decode(&bytes).unwrap();
        let mut restored = RecordedEnv::new(99, Handler { counter: 0 });
        decoded.restore_into(&mut restored).unwrap();
        assert_eq!(
            restored.decide(&question).unwrap(),
            ServiceResponse::Answered(Answer::data(vec![2, 0, 0, 0, 0, 0, 0, 0]).unwrap())
        );
        let handler = restore_handler(&decoded.handler, &Factory).unwrap();
        assert_eq!(handler.counter, 1);
    }

    #[test]
    fn a_handler_sees_the_moment_the_question_surfaced_at() {
        #[derive(Clone, Default)]
        struct MomentEcho(Vec<Moment>);

        impl ServiceHandler for MomentEcho {
            fn identity(&self) -> &[u8] {
                b"moment-echo-v1"
            }

            fn configuration(&self) -> &[u8] {
                &[]
            }

            fn respond(
                &mut self,
                moment: Moment,
                _question: &Question,
            ) -> Result<ServiceResponse, ChannelError> {
                self.0.push(moment);
                Ok(ServiceResponse::Answered(Answer::data(
                    moment.to_le_bytes().to_vec(),
                )?))
            }

            fn snapshot_state(&self) -> Result<Vec<u8>, ChannelError> {
                Ok(Vec::new())
            }

            fn restore_state(&mut self, _state: &[u8]) -> Result<(), ChannelError> {
                Ok(())
            }

            fn clone_box(&self) -> Box<dyn ServiceHandler> {
                Box::new(self.clone())
            }
        }

        let question = Question::new(7, vec![]).unwrap();
        let mut env = RecordedEnv::new(1, MomentEcho::default());
        for moment in [11, 11, 25] {
            env.set_moment(moment);
            assert_eq!(
                env.decide(&question).unwrap(),
                ServiceResponse::Answered(Answer::Data(moment.to_le_bytes().to_vec()))
            );
        }
        assert_eq!(env.handler().0, vec![11, 11, 25]);
    }

    #[test]
    fn failed_handler_restore_does_not_partially_mutate_environment() {
        let source = RecordedEnv::new(1, Handler { counter: 3 });
        let mut snapshot = source.snapshot_state().unwrap();
        snapshot.handler.state = vec![0xff];
        let mut target = RecordedEnv::new(9, Handler { counter: 8 });
        assert!(target.decide(&Question::new(7, vec![]).unwrap()).is_ok());
        let before = target.handler.counter;
        assert!(snapshot.restore_into(&mut target).is_err());
        assert_eq!(target.handler.counter, before);
    }

    #[test]
    fn malformed_effects_and_state_are_rejected() {
        assert_eq!(Effect::decode(&[9]), Err(ChannelError::Malformed));
        let xor = Effect::xor_memory(0x4000, vec![1, 2, 3]).unwrap();
        assert_eq!(Effect::decode(&xor.encode()), Ok(xor));
        assert_eq!(RecordedState::decode(b"EVC1"), Err(ChannelError::Malformed));
    }

    #[test]
    fn coverage_schedule_is_canonical_and_selects_window_boundaries() {
        let schedule = CoverageSchedule::new(1024, vec![(10, 20, 1), (30, 40, 9)]).unwrap();
        let decoded = CoverageSchedule::decode(&schedule.encode()).unwrap();
        assert_eq!(decoded, schedule);
        for (moment, expected) in [(9, 1024), (10, 1), (19, 1), (20, 1024), (30, 9), (40, 1024)] {
            assert_eq!(schedule.quantum_at(moment), expected);
        }
        for windows in [
            vec![(10, 10, 1)],
            vec![(10, 20, 0)],
            vec![(10, 20, 1), (19, 30, 2)],
            vec![(10, 20, 1), (5, 9, 2)],
        ] {
            assert_eq!(
                CoverageSchedule::new(1024, windows),
                Err(ChannelError::Malformed)
            );
        }
        assert_eq!(
            CoverageSchedule::new(0, Vec::new()),
            Err(ChannelError::Malformed)
        );
        let mut wrong_version = schedule.encode();
        wrong_version[0] += 1;
        assert_eq!(
            CoverageSchedule::decode(&wrong_version),
            Err(ChannelError::Malformed)
        );
    }

    #[test]
    fn mechanical_effect_schedule_is_canonical_and_fault_agnostic() {
        let mut schedule = EffectSchedule::default();
        let write = Effect::write_memory(0x10, vec![1]).unwrap();
        let xor = Effect::xor_memory(0x10, vec![1]).unwrap();
        schedule.insert(7, xor.clone());
        schedule.insert(7, write.clone());
        schedule.insert(7, xor.clone());
        assert_eq!(schedule.at(7), &[write, xor]);
    }

    #[test]
    fn request_identity_keeps_same_moment_overrides_distinct() {
        let mut env = RecordedEnv::new(1, Handler { counter: 0 });
        env.record_service_request(4, 7, 11, Answer::Data(vec![7]));
        env.set_moment(4);
        let first = Question::with_request_id(11, 7, vec![]).unwrap();
        let second = Question::with_request_id(12, 7, vec![]).unwrap();
        assert_eq!(
            env.decide(&first).unwrap(),
            ServiceResponse::Answered(Answer::Data(vec![7]))
        );
        assert_eq!(
            env.decide(&second).unwrap(),
            ServiceResponse::Answered(Answer::Data(vec![1, 0, 0, 0, 0, 0, 0, 0]))
        );
    }

    #[test]
    fn recorded_answer_rejects_same_identity_with_different_request_bytes() {
        let mut env = RecordedEnv::new(1, Handler { counter: 0 });
        let original = Question::with_request_id(11, 7, b"first".to_vec()).unwrap();
        env.record_question(4, &original, Answer::Data(vec![7]));
        env.set_moment(4);
        let changed = Question::with_request_id(11, 7, b"second".to_vec()).unwrap();
        assert_eq!(
            env.decide(&changed),
            Err(ChannelError::RequestIdentityMismatch)
        );
        assert_eq!(
            env.decide(&original),
            Ok(ServiceResponse::Answered(Answer::Data(vec![7])))
        );
        let restored_state =
            RecordedState::decode(&env.snapshot_state().unwrap().encode()).unwrap();
        let mut restored = RecordedEnv::new(1, Handler { counter: 0 });
        restored_state.restore_into(&mut restored).unwrap();
        assert_eq!(
            restored.decide(&changed),
            Err(ChannelError::RequestIdentityMismatch)
        );
    }

    #[test]
    fn aggregate_snapshot_limit_matches_decoder_for_responses_and_payloads() {
        let mut env = RecordedEnv::nominal(17);
        for id in 0..7 {
            env.record_request(id, id, Answer::Data(vec![1; MAX_CHANNEL_BYTES]));
        }
        let state = env.snapshot_state().unwrap();
        let bytes = state.encode();
        assert_eq!(state.encoded_len(), bytes.len());
        assert_eq!(RecordedState::decode(&bytes).unwrap(), state);
        env.record_request(7, 7, Answer::Data(vec![1; MAX_CHANNEL_BYTES]));
        assert_eq!(env.snapshot_state(), Err(ChannelError::TooLarge));

        let mut env = RecordedEnv::nominal(17);
        env.set_payloads(Some(vec![vec![1; MAX_CHANNEL_BYTES]; 7]))
            .unwrap();
        let state = env.snapshot_state().unwrap();
        assert_eq!(state.encoded_len(), state.encode().len());
        assert_eq!(RecordedState::decode(&state.encode()).unwrap(), state);
        env.set_payloads(Some(vec![vec![1; MAX_CHANNEL_BYTES]; 8]))
            .unwrap();
        assert_eq!(env.snapshot_state(), Err(ChannelError::TooLarge));
    }

    #[test]
    fn snapshot_aggregate_boundary_includes_all_framing_bytes() {
        let mut env = RecordedEnv::nominal(17);
        env.set_payloads(Some(vec![Vec::new(); 8])).unwrap();
        let overhead = env.snapshot_state().unwrap().encode().len();
        let mut entries = vec![vec![0; MAX_CHANNEL_BYTES]; 7];
        entries.push(vec![0; MAX_CHANNEL_BYTES - overhead]);
        env.set_payloads(Some(entries.clone())).unwrap();
        let state = env.snapshot_state().unwrap();
        assert_eq!(state.encode().len(), MAX_RECORDED_STATE_BYTES);
        assert_eq!(RecordedState::decode(&state.encode()).unwrap(), state);
        entries.last_mut().unwrap().push(0);
        env.set_payloads(Some(entries)).unwrap();
        assert_eq!(env.snapshot_state(), Err(ChannelError::TooLarge));
    }

    #[test]
    fn snapshot_reserves_capacity_for_first_use_answer_binding() {
        let mut env = RecordedEnv::nominal(17);
        env.record_service_request(7, 19, 77, Answer::Nominal);
        env.set_payloads(Some(vec![Vec::new(); 8])).unwrap();
        let overhead = env.snapshot_state().unwrap().encoded_len();
        let payload_bytes = MAX_RECORDED_STATE_BYTES - 31 - overhead;
        let mut entries = vec![vec![0; payload_bytes / 8]; 8];
        entries[0].extend(vec![0; payload_bytes % 8]);
        env.set_payloads(Some(entries.clone())).unwrap();
        assert_eq!(
            env.snapshot_state().unwrap().encoded_len(),
            MAX_RECORDED_STATE_BYTES - 31
        );
        assert_eq!(
            env.snapshot_state_with_binding_reserve(),
            Err(ChannelError::TooLarge)
        );
        entries[0].pop();
        env.set_payloads(Some(entries)).unwrap();
        assert_eq!(
            env.snapshot_state_with_binding_reserve()
                .unwrap()
                .encoded_len(),
            MAX_RECORDED_STATE_BYTES - 32
        );
        env.set_moment(7);
        let question = Question::with_request_id(77, 19, b"choose".to_vec()).unwrap();
        assert_eq!(
            env.decide(&question),
            Ok(ServiceResponse::Answered(Answer::Nominal))
        );
        assert_eq!(
            env.snapshot_state().unwrap().encoded_len(),
            MAX_RECORDED_STATE_BYTES
        );
    }

    #[test]
    fn invalid_handler_answer_does_not_commit_handler_state() {
        let mut env = RecordedEnv::new(17, Handler { counter: 0 });
        let question = Question::new(u16::MAX, vec![]).unwrap();
        assert!(env.decide(&question).is_err());
        assert_eq!(env.handler().counter, 0);
    }

    #[test]
    fn answered_request_rejects_handler_contract_drift_without_committing() {
        for change_identity in [true, false] {
            let mut handler = ChangingContractHandler::new(1, 2, [3, 4]);
            handler.respond_change = Some(change_identity);
            let mut env = RecordedEnv::new(17, handler);
            let before = env.snapshot_state().unwrap().encode();
            assert!(matches!(
                env.decide(&Question::new(19, Vec::new()).unwrap()),
                Err(ChannelError::Handler(_))
            ));
            assert_eq!(env.snapshot_state().unwrap().encode(), before);
            assert_eq!(env.handler().identity(), &[1]);
            assert_eq!(env.handler().configuration(), &[2]);
            assert_eq!(
                env.decide(&Question::new(20, Vec::new()).unwrap()),
                Ok(ServiceResponse::Answered(Answer::Data(vec![2])))
            );
        }
    }

    #[test]
    fn core_supply_is_deterministic_and_snapshot_restores_overrides() {
        let mut env = RecordedEnv::nominal(17);
        let question = Question::entropy(9).unwrap();
        let expected = env.decide(&question).unwrap();
        env.record_question(3, &question, Answer::Data(vec![42]));
        env.set_moment(3);
        let snapshot = env.snapshot_state().unwrap();
        let decoded = RecordedState::decode(&snapshot.encode()).unwrap();
        let mut restored = RecordedEnv::nominal(99);
        decoded.restore_into(&mut restored).unwrap();
        assert_eq!(
            restored.decide(&question),
            Ok(ServiceResponse::Answered(Answer::Data(vec![42])))
        );

        let mut replay = RecordedEnv::nominal(17);
        assert_eq!(replay.decide(&question), Ok(expected));
    }

    #[test]
    fn snapshot_size_tracks_replaced_and_bound_answers_across_clones() {
        let mut env = RecordedEnv::nominal(5);
        let mut held = Vec::new();
        for step in 0..3_000_u64 {
            let moment = step % 700;
            let answer = if step % 3 == 0 {
                Answer::Nominal
            } else {
                Answer::Data(vec![step as u8; (step % 11) as usize])
            };
            if step % 2 == 0 {
                env.record_service_request(moment, 7, step % 5, answer);
            } else {
                let question =
                    Question::with_request_id(step % 5, 7, step.to_le_bytes().to_vec()).unwrap();
                env.record_question(moment, &question, answer);
            }
            if step % 9 == 0 {
                let question = Question::with_request_id(step % 5, 7, vec![1]).unwrap();
                env.set_moment(moment);
                let _ = env.recorded_override(&question);
            }
            if step % 101 == 0 {
                held.push(env.checked_clone().unwrap());
            }
        }
        for candidate in held.iter().chain([&env]) {
            let state = candidate.snapshot_state().unwrap();
            let bytes = state.encode();
            assert_eq!(state.encoded_len(), bytes.len());
            assert_eq!(
                state.overrides.unbound,
                state.answers().count() - state.request_bindings().count()
            );
            let decoded = RecordedState::decode(&bytes).unwrap();
            assert_eq!(decoded, state);
            assert_eq!(decoded.encoded_len(), bytes.len());
            assert_eq!(decoded.overrides.unbound, state.overrides.unbound);
        }
        env.record(1, Answer::Data(vec![0; MAX_CHANNEL_BYTES + 1]));
        assert_eq!(env.snapshot_state(), Err(ChannelError::TooLarge));
        env.record(1, Answer::Nominal);
        assert!(env.snapshot_state().is_ok());
    }

    #[test]
    fn question_and_answer_codecs_cover_accessors_and_limits() {
        let question = Question::with_request_id(23, 41, vec![1, 2]).unwrap();
        assert_eq!(question.request_id(), 23);
        assert_eq!(question.service(), 41);
        assert_eq!(question.payload(), &[1, 2]);
        assert_eq!(
            Question::new(41, vec![0; MAX_CHANNEL_BYTES])
                .unwrap()
                .payload()
                .len(),
            MAX_CHANNEL_BYTES
        );
        assert_eq!(
            Question::new(41, vec![0; MAX_CHANNEL_BYTES + 1]),
            Err(ChannelError::TooLarge)
        );

        let nominal = Answer::Nominal;
        assert_eq!(nominal.encode(), vec![0]);
        assert_eq!(nominal.payload(), None);
        assert_eq!(Answer::decode(&[0]), Ok(nominal.clone()));
        assert_eq!(Answer::decode(&[2]), Err(ChannelError::Malformed));

        let data = Answer::data(vec![3, 4]).unwrap();
        assert_eq!(data.encode(), vec![1, 3, 4]);
        assert_eq!(data.payload(), Some(&[3, 4][..]));
        assert_eq!(Answer::decode(&data.encode()), Ok(data));
        assert_eq!(
            Answer::decode(&[1; MAX_CHANNEL_BYTES + 2]),
            Err(ChannelError::Malformed)
        );
        assert_eq!(
            Answer::data(vec![0; MAX_CHANNEL_BYTES])
                .unwrap()
                .payload()
                .unwrap()
                .len(),
            MAX_CHANNEL_BYTES
        );
        assert_eq!(
            Answer::data(vec![0; MAX_CHANNEL_BYTES + 1]),
            Err(ChannelError::TooLarge)
        );
    }

    #[test]
    fn effects_and_schedule_round_trip_all_variants() {
        let effects = [
            Effect::write_memory(0x1000, vec![1, 2]).unwrap(),
            Effect::xor_memory(0x2000, vec![3, 4]).unwrap(),
            Effect::write_memory(0x3000, vec![5]).unwrap(),
        ];
        for effect in &effects {
            assert_eq!(Effect::decode(&effect.encode()), Ok(effect.clone()));
        }
        assert_eq!(
            Effect::write_memory(0, vec![0; MAX_CHANNEL_BYTES + 1]),
            Err(ChannelError::TooLarge)
        );
        assert_eq!(
            Effect::xor_memory(0, vec![0; MAX_CHANNEL_BYTES + 1]),
            Err(ChannelError::TooLarge)
        );
        let mut schedule = EffectSchedule::default();
        schedule.insert(9, effects[2].clone());
        schedule.insert(3, effects[0].clone());
        schedule.insert(9, effects[1].clone());
        assert_eq!(
            schedule.iter().collect::<Vec<_>>(),
            vec![
                (3, &[effects[0].clone()][..]),
                (9, &[effects[2].clone(), effects[1].clone()][..])
            ]
        );
    }

    #[test]
    fn boxed_handlers_and_handler_snapshot_forward_every_operation() {
        let mut boxed: Box<dyn ServiceHandler> = Box::new(ForwardingHandler { seed: 1, state: 2 });
        assert_eq!(boxed.identity(), b"forwarding-handler-v1");
        assert_eq!(boxed.configuration(), b"forwarding-config");
        assert_eq!(boxed.snapshot_state().unwrap(), vec![2, 1]);
        boxed.reseed(9);
        assert_eq!(boxed.snapshot_state().unwrap(), vec![2, 9]);
        boxed.restore_state(&[7, 8]).unwrap();
        assert_eq!(boxed.snapshot_state().unwrap(), vec![7, 8]);
        let cloned = boxed.clone_box();
        assert_eq!(cloned.snapshot_state().unwrap(), vec![7, 8]);

        let snapshot = HandlerSnapshot::capture(&*boxed).unwrap();
        assert_eq!(snapshot.identity(), b"forwarding-handler-v1");
        assert_eq!(snapshot.configuration(), b"forwarding-config");
        assert_eq!(snapshot.state(), &[7, 8]);
    }

    #[test]
    fn recorded_state_exposes_answers_and_remaining_payloads() {
        let mut env = RecordedEnv::nominal(3);
        env.record_service_request(4, 8, 12, Answer::Data(vec![5]));
        env.set_payloads(Some(vec![vec![1], vec![2]])).unwrap();
        assert!(env.payload_configured());
        assert_eq!(env.pull_payload(1).unwrap(), Some(vec![1]));
        let state = env.snapshot_state().unwrap();
        assert_eq!(state.remaining_payloads(), Some(vec![vec![2]]));
        assert_eq!(
            state.answers().collect::<Vec<_>>(),
            vec![((4, 8, 12), &Answer::Data(vec![5]))]
        );

        let mut restored = RecordedEnv::nominal(99);
        state.restore_into(&mut restored).unwrap();
        assert_eq!(restored.remaining_payloads(), Some(vec![vec![2]]));
        restored.set_moment(4);
        let question = Question::with_request_id(12, 8, vec![]).unwrap();
        assert_eq!(
            restored.decide(&question),
            Ok(ServiceResponse::Answered(Answer::Data(vec![5])))
        );
    }

    #[test]
    fn recorded_encoding_appends_without_changing_existing_bytes() {
        let mut env = RecordedEnv::new(31, ForwardingHandler { seed: 7, state: 9 });
        env.record_service_request(4, 8, 12, Answer::Data(vec![5, 6]));
        env.record_service_request(7, 8, 13, Answer::Nominal);
        for payloads in [None, Some(vec![]), Some(vec![vec![], vec![1, 2, 3]])] {
            env.set_payloads(payloads).unwrap();
            let state = env.snapshot_state().unwrap();
            let encoded = state.encode();
            let mut out = b"existing-prefix".to_vec();
            let start = out.len();
            state.encode_into(&mut out);
            assert_eq!(&out[..start], b"existing-prefix");
            assert_eq!(&out[start..], encoded.as_slice());
            assert_eq!(RecordedState::decode(&out[start..]).unwrap(), state);
            let end = out.len();
            state.encode_into(&mut out);
            assert_eq!(&out[end..], encoded.as_slice());
            assert_eq!(&out[start..end], encoded.as_slice());
        }
    }

    #[test]
    fn payload_tape_is_bounded_exact_and_transactional() {
        let mut absent = RecordedEnv::nominal(1);
        assert!(!absent.payload_configured());
        assert_eq!(absent.pull_payload(1).unwrap(), None);
        assert_eq!(
            absent.pull_payload(MAX_CHANNEL_BYTES + 1),
            Err(ChannelError::TooLarge)
        );

        let mut env = RecordedEnv::nominal(1);
        env.set_payloads(Some(vec![vec![9], vec![8, 7]])).unwrap();
        assert!(matches!(env.pull_payload(2), Err(ChannelError::Handler(_))));
        assert_eq!(env.pull_payload(1).unwrap(), Some(vec![9]));
        assert_eq!(env.pull_payload(2).unwrap(), Some(vec![8, 7]));
        assert_eq!(env.pull_payload(0).unwrap(), None);
        assert_eq!(env.remaining_payloads(), Some(vec![]));
        env.set_payloads(None).unwrap();
        assert!(!env.payload_configured());
        assert_eq!(
            env.set_payloads(Some(vec![vec![0; MAX_CHANNEL_BYTES + 1]])),
            Err(ChannelError::TooLarge)
        );
    }

    #[test]
    fn records_and_reseeds_change_the_selected_decision_stream() {
        let mut env = RecordedEnv::new(1, Handler { counter: 0 });
        env.record(4, Answer::Data(vec![3]));
        env.record_request(4, 9, Answer::Data(vec![4]));
        env.set_moment(4);
        assert_eq!(
            env.decide(&Question::new(0, vec![]).unwrap()),
            Ok(ServiceResponse::Answered(Answer::Data(vec![3])))
        );
        assert_eq!(
            env.decide(&Question::with_request_id(9, 0, vec![]).unwrap()),
            Ok(ServiceResponse::Answered(Answer::Data(vec![4])))
        );

        let mut seeded = RecordedEnv::nominal(1);
        let first = seeded.decide(&Question::entropy(8).unwrap()).unwrap();
        assert_eq!(
            first,
            ServiceResponse::Answered(Answer::Data(5180492295206395165u64.to_le_bytes().to_vec()))
        );
        seeded.reseed(2).unwrap();
        let second = seeded.decide(&Question::entropy(8).unwrap()).unwrap();
        assert_eq!(
            second,
            ServiceResponse::Answered(Answer::Data(10360984590412790330u64.to_le_bytes().to_vec()))
        );
    }

    #[test]
    fn core_supply_validates_services_and_stream_boundaries() {
        let mut env = RecordedEnv::nominal(1);
        assert_eq!(
            env.decide(&Question::scheduler(7).unwrap()),
            Ok(ServiceResponse::Answered(Answer::Data(
                5u32.to_le_bytes().to_vec()
            )))
        );
        assert_eq!(
            env.decide(&Question::scheduler(0).unwrap()),
            Err(ChannelError::Malformed)
        );
        assert_eq!(
            env.decide(&Question::new(SERVICE_SCHEDULER, vec![1]).unwrap()),
            Err(ChannelError::Malformed)
        );

        let mut stream = RecordedEnv::nominal(1);
        let _ = stream.decide(&Question::entropy(9).unwrap()).unwrap();
        let next = stream.decide(&Question::entropy(1).unwrap()).unwrap();
        assert_eq!(next, ServiceResponse::Answered(Answer::Data(vec![0x57])));

        let mut exact_stream = RecordedEnv::nominal(1);
        let _ = exact_stream.decide(&Question::entropy(8).unwrap()).unwrap();
        let next = exact_stream.decide(&Question::entropy(1).unwrap()).unwrap();
        assert_eq!(next, ServiceResponse::Answered(Answer::Data(vec![0x1d])));

        let mut xor_stream = RecordedEnv::nominal(0x1234_5678_9abc_def0);
        assert_eq!(
            xor_stream.decide(&Question::entropy(8).unwrap()),
            Ok(ServiceResponse::Answered(Answer::Data(
                13257192714554721081u64.to_le_bytes().to_vec()
            )))
        );

        let mut handler = RecordedEnv::new(1, Handler { counter: 0 });
        let response = handler.decide(&Question::new(99, vec![]).unwrap()).unwrap();
        assert_eq!(
            response,
            ServiceResponse::Answered(Answer::Data(vec![1, 0, 0, 0, 0, 0, 0, 0]))
        );
    }

    #[test]
    fn reader_and_snapshot_decoders_enforce_canonical_boundaries() {
        let mut exact = Reader::new(&[1, 0, 0, 0, 0, 0]);
        assert_eq!(exact.count(1).unwrap(), 1);
        let mut too_many = Reader::new(&[2, 0, 0, 0, 0]);
        assert_eq!(too_many.count(1), Err(ChannelError::Malformed));
        let mut exact_width = Reader::new(&[2, 0, 0, 0, 0, 0, 0, 0, 0]);
        assert_eq!(exact_width.count(2).unwrap(), 2);
        let mut wrong_width = Reader::new(&[3, 0, 0, 0, 0, 0, 0, 0, 0]);
        assert_eq!(wrong_width.count(2), Err(ChannelError::Malformed));
        assert_eq!(Reader::new(&[]).finish(), Ok(()));
        assert_eq!(Reader::new(&[0]).finish(), Err(ChannelError::Malformed));
        assert_eq!(read_answer(&mut Reader::new(&[0])), Ok(Answer::Nominal));
        assert_eq!(
            read_answer(&mut Reader::new(&[1, 1, 0, 0, 0, 9])),
            Ok(Answer::Data(vec![9]))
        );
        assert_eq!(
            read_answer(&mut Reader::new(&[9])),
            Err(ChannelError::Malformed)
        );

        assert_ne!(
            RecordedState::decode(&vec![0; MAX_RECORDED_STATE_BYTES]),
            Err(ChannelError::TooLarge)
        );
        assert_eq!(
            RecordedState::decode(&vec![0; MAX_RECORDED_STATE_BYTES + 1]),
            Err(ChannelError::TooLarge)
        );
    }

    #[test]
    fn restore_requires_both_handler_identity_and_configuration() {
        let state = RecordedEnv::new(1, ForwardingHandler { seed: 1, state: 2 })
            .snapshot_state()
            .unwrap();
        let mut wrong_identity = state.clone();
        wrong_identity.handler.identity = b"other".to_vec();
        let mut target = RecordedEnv::new(2, ForwardingHandler { seed: 2, state: 3 });
        assert!(wrong_identity.restore_into(&mut target).is_err());
        let mut wrong_config = state;
        wrong_config.handler.configuration = b"other".to_vec();
        assert!(wrong_config.restore_into(&mut target).is_err());
    }

    #[test]
    fn nominal_handler_contract_is_stable_and_stateless() {
        let handler = NominalHandler;
        assert_eq!(handler.identity(), b"consonance.nominal-handler.v1");
        assert_eq!(handler.configuration(), b"");
        assert_eq!(handler.snapshot_state(), Ok(Vec::new()));
        let mut restored = NominalHandler;
        assert_eq!(restored.restore_state(&[]), Ok(()));
        assert_eq!(
            restored.restore_state(&[1]),
            Err(ChannelError::Handler(
                "nominal handler has no dynamic state".to_owned()
            ))
        );
    }

    #[test]
    fn debug_output_contains_recorded_environment_fields() {
        let env = RecordedEnv::nominal(7);
        let debug = format!("{env:?}");
        assert!(debug.contains("stream_state"));
        assert!(debug.contains("handler_identity"));
    }

    #[derive(Clone, Copy)]
    enum SharedResponse {
        External,
        Answered,
        InvalidAnswer,
        Failure,
    }

    #[derive(Clone)]
    struct SharedStateHandler {
        state: std::sync::Arc<std::sync::atomic::AtomicU8>,
        response: SharedResponse,
        reseed_changes_state: bool,
        clone_changes_state: bool,
    }

    impl SharedStateHandler {
        fn new(value: u8, response: SharedResponse) -> Self {
            Self {
                state: std::sync::Arc::new(std::sync::atomic::AtomicU8::new(value)),
                response,
                reseed_changes_state: false,
                clone_changes_state: false,
            }
        }
    }

    impl ServiceHandler for SharedStateHandler {
        fn identity(&self) -> &[u8] {
            b"shared-state-handler"
        }

        fn configuration(&self) -> &[u8] {
            b""
        }

        fn respond(
            &mut self,
            _moment: Moment,
            _question: &Question,
        ) -> Result<ServiceResponse, ChannelError> {
            self.state.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            match self.response {
                SharedResponse::External => Ok(ServiceResponse::External),
                SharedResponse::Answered => Ok(ServiceResponse::Answered(Answer::Nominal)),
                SharedResponse::InvalidAnswer => Ok(ServiceResponse::Answered(Answer::Data(vec![
                        0;
                        MAX_CHANNEL_BYTES
                            + 1
                    ]))),
                SharedResponse::Failure => Err(ChannelError::Malformed),
            }
        }

        fn snapshot_state(&self) -> Result<Vec<u8>, ChannelError> {
            Ok(vec![self.state.load(std::sync::atomic::Ordering::SeqCst)])
        }

        fn restore_state(&mut self, state: &[u8]) -> Result<(), ChannelError> {
            let [value] = state else {
                return Err(ChannelError::Malformed);
            };
            self.state
                .store(*value, std::sync::atomic::Ordering::SeqCst);
            Ok(())
        }

        fn reseed(&mut self, _seed: u64) {
            if self.reseed_changes_state {
                self.state.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            }
        }

        fn clone_box(&self) -> Box<dyn ServiceHandler> {
            if self.clone_changes_state {
                self.state.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
            }
            Box::new(self.clone())
        }
    }

    struct DivergingCloneHandler(u8);

    impl ServiceHandler for DivergingCloneHandler {
        fn identity(&self) -> &[u8] {
            b"diverging-clone-handler"
        }

        fn configuration(&self) -> &[u8] {
            b""
        }

        fn respond(&mut self, _: Moment, _: &Question) -> Result<ServiceResponse, ChannelError> {
            Ok(ServiceResponse::Answered(Answer::Data(vec![self.0])))
        }

        fn snapshot_state(&self) -> Result<Vec<u8>, ChannelError> {
            Ok(vec![self.0])
        }

        fn restore_state(&mut self, state: &[u8]) -> Result<(), ChannelError> {
            let [value] = state else {
                return Err(ChannelError::Malformed);
            };
            self.0 = *value;
            Ok(())
        }

        fn clone_box(&self) -> Box<dyn ServiceHandler> {
            Box::new(Self(self.0 + 1))
        }
    }

    #[test]
    fn deciding_with_a_divergent_handler_clone_poisoned() {
        let mut env = RecordedEnv::new(
            1,
            Box::new(DivergingCloneHandler(0)) as Box<dyn ServiceHandler>,
        );
        assert!(env.snapshot_state().is_ok());
        assert_eq!(
            env.decide(&Question::new(7, vec![]).unwrap()),
            Err(ChannelError::Poisoned)
        );
        assert_eq!(env.snapshot_state(), Err(ChannelError::Poisoned));
    }

    #[test]
    fn reseeding_with_a_divergent_handler_clone_poisoned() {
        let mut env = RecordedEnv::new(
            1,
            Box::new(DivergingCloneHandler(0)) as Box<dyn ServiceHandler>,
        );
        assert!(env.snapshot_state().is_ok());
        assert_eq!(env.reseed(2), Err(ChannelError::Poisoned));
        assert_eq!(env.snapshot_state(), Err(ChannelError::Poisoned));
    }

    #[test]
    fn restoring_with_a_divergent_handler_clone_poisoned() {
        let source = RecordedEnv::new(
            1,
            Box::new(DivergingCloneHandler(0)) as Box<dyn ServiceHandler>,
        );
        let snapshot = source.snapshot_state().unwrap();
        let mut target = RecordedEnv::new(
            1,
            Box::new(DivergingCloneHandler(0)) as Box<dyn ServiceHandler>,
        );
        assert_eq!(
            snapshot.restore_into(&mut target),
            Err(ChannelError::Poisoned)
        );
        assert_eq!(target.snapshot_state(), Err(ChannelError::Poisoned));
    }

    #[test]
    fn cloning_a_recorded_environment_poisoned_if_it_changes_the_live_handler() {
        let mut handler = SharedStateHandler::new(0, SharedResponse::External);
        handler.clone_changes_state = true;
        let env = RecordedEnv::new(1, Box::new(handler) as Box<dyn ServiceHandler>);
        assert!(env.snapshot_state().is_ok());
        let cloned = env.clone();
        assert_eq!(env.snapshot_state(), Err(ChannelError::Poisoned));
        assert_eq!(cloned.snapshot_state(), Err(ChannelError::Poisoned));
    }

    #[test]
    fn shared_handler_mutation_cannot_certify_an_external_request() {
        for response in [
            SharedResponse::External,
            SharedResponse::Answered,
            SharedResponse::InvalidAnswer,
            SharedResponse::Failure,
        ] {
            let mut env = RecordedEnv::new(1, SharedStateHandler::new(0, response));
            assert!(env.snapshot_state().is_ok());
            let question = Question::new(7, vec![]).unwrap();
            assert_eq!(env.decide(&question), Err(ChannelError::Poisoned));
            assert_eq!(env.decide(&question), Err(ChannelError::Poisoned));
            assert_eq!(env.snapshot_state(), Err(ChannelError::Poisoned));
            assert_eq!(env.pull_payload(1), Err(ChannelError::Poisoned));
        }
    }

    #[test]
    fn shared_handler_mutation_poison_reaches_transaction_parent() {
        let handler = SharedStateHandler::new(0, SharedResponse::External);
        let env = RecordedEnv::new(1, handler);
        let mut candidate = env.clone();
        candidate.set_moment(0);
        assert_eq!(
            candidate.decide(&Question::new(7, Vec::new()).unwrap()),
            Err(ChannelError::Poisoned)
        );
        assert_eq!(env.snapshot_state(), Err(ChannelError::Poisoned));
    }

    #[test]
    fn shared_handler_restore_poison_reaches_transaction_parent() {
        let source = RecordedEnv::new(1, SharedStateHandler::new(1, SharedResponse::External));
        let state = source.snapshot_state().unwrap();
        let mut target = RecordedEnv::new(1, SharedStateHandler::new(0, SharedResponse::External));
        let parent = target.clone();
        assert_eq!(state.restore_into(&mut target), Err(ChannelError::Poisoned));
        assert_eq!(parent.snapshot_state(), Err(ChannelError::Poisoned));
    }

    #[test]
    fn shared_handler_reseed_cannot_silently_change_parent_snapshot() {
        let mut handler = SharedStateHandler::new(0, SharedResponse::External);
        handler.reseed_changes_state = true;
        let parent = RecordedEnv::new(1, handler);
        let mut branch = parent.clone();
        assert!(parent.snapshot_state().is_ok());
        assert_eq!(branch.reseed(2), Err(ChannelError::Poisoned));
        assert_eq!(parent.snapshot_state(), Err(ChannelError::Poisoned));
    }

    #[test]
    fn reseed_rejects_handler_contract_drift_without_committing() {
        for change_identity in [true, false] {
            let mut handler = ChangingContractHandler::new(1, 2, [3, 4]);
            handler.reseed_change = Some(change_identity);
            let mut env = RecordedEnv::new(1, handler);
            let before = env.snapshot_state().unwrap().encode();
            assert!(matches!(env.reseed(42), Err(ChannelError::Handler(_))));
            assert_eq!(env.snapshot_state().unwrap().encode(), before);
        }
    }
}

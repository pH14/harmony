<!-- SPDX-License-Identifier: AGPL-3.0-or-later -->

# vmm-backend

`vmm-backend` owns the substrate boundary below `vmm-core`. The `Backend`
trait maps guest memory, runs a vCPU, exposes normalized exits, completes
read/write operations, injects events, and saves/restores vCPU state. It is
generic over an architecture type, so the upper VMM does not name KVM, HVF, or
an ISA-specific exit enum.

`Backend::physical_telemetry` exposes runtime physical-entry accounting separately
from normalized `ExitCounts`. `PhysicalTelemetry` uses fixed platform and purpose
slots, with raw reason buckets 0 through 63 and one `other` bucket. Its measured
boundary records attempts, successful OS returns, interrupted calls, other OS
errors and host elapsed time; it does not append normalized events or enter vCPU
state. Sites with no attempts are omitted from exported counters. The generic
mock backend has no OS entries; its explicit test setter supplies only fixture
data for aggregation tests.

Counters use `backend.<platform>.<purpose>.<leaf>`, where platform is `kvm_x86`,
`kvm_arm64` or `hvf_arm64`, purpose is `guest`, `completion` or `maintenance`,
and leaves are `entries`, `returns`, `interruptions`, `errors` and `run_ns`.
`raw_exit.<reason>.count` counts successful OS returns before backend decoding or
internal handling, including consumed interrupts, PSCI calls and tracked writes.
Reason numbers retain their platform ABI meanings. These are OS entry API
attempts and returns, not proof of hardware guest entry or guest instruction
counts. Normalized exit totals and EventHistory counts need not equal them.

KVM `EINTR` attempts have interruption counts and no successful-return/reason
charge. Other failed syscalls have error counts. The arm64 raw syscall boundary
preserves the locked kvm-ioctls 0.25.0 interpretation of `-1` with `EFAULT` or
`EHWPOISON` and `KVM_EXIT_MEMORY_FAULT`: normal backend handling still receives
that condition, while telemetry counts an OS error, never a successful return.
The syscall records errno before any clock read or decoder work. The safe
`VcpuFd::get_kvm_run` accessor supplies the reason after a completed call;
ordinary errors never read stale exit data. The memory-fault errno pair is the
explicit exception permitted by the KVM ABI and pinned against Linux constants.

Staged KVM completion calls are distinct from guest calls. Snapshot preparation
with immediate exit is maintenance unless it consumes a staged completion, in
which case it is completion. HVF translation-flush guest stubs are maintenance.
HVF canceled exits are successful raw returns with reason zero, even when the
backend rejects them; nonzero HVF API status is an OS error. HVF does not invent
an errno-style interruption count. Checks that reject before an OS call do not
count as entry attempts. Semantic exit counter reset does not reset physical
work. FakeKvm scripts the same boundary counts for portable tests; its counts
and timing are fixture evidence, not measurements of a hypervisor.

Hot entry accounting uses fixed arrays without strings or allocations. Each
entry reads the host clock at entry and completion; `run_ns` includes the OS call
and immediate classification/readback. Timers have platform-dependent overhead
and resolution, and overlap VMM guest/service timing rather than adding another
independent elapsed interval. Counters and their 5040-byte runtime storage never
enter snapshots, identity commitments, virtual clocks or retention policy.

## Narrow x86 observations

`Backend::read_x86_regs` reads only general registers, including RIP and RFLAGS.
`read_x86_cpuid_state` reads only the CR4 and XCR0 inputs to dynamic CPUID
resolution. Neither method falls back to a full CPU save: unsupported backends
return `Unsupported`. Boxed backends forward the exact result. The x86 mock
reads its live scripted state; KVM retains affinity and backend-health checks,
uses GET_REGS or guarded GET_SREGS2 plus GET_XCRS, and does not retire a staged
completion, prepare a snapshot, enter the guest, or capture XSAVE/MSRs/nested
state. The guarded SREGS2 read retains the existing AMD PAE refusal.

These observations are valid during exit servicing, including while an MSR
answer is pending, and are not sealable snapshot records. Callers still use the
complete save/prepare/validate path for publication, restore and state hashes.
The existing native MSR completion test compares both narrow observations with
the complete architectural record before and after completion, checks unchanged
physical entry totals, and requires the unanswered MSR to remain pending.

## Implementations

- `MockBackend` and `MockArm64Backend` provide scripted, deterministic
  backends for portable tests behind the `mock` feature.
- `KvmBackend` is the stock Linux x86-64 KVM implementation.
- `Arm64KvmBackend` and `HvfBackend` implement the arm64 KVM and macOS
  Hypervisor.framework paths where their platform APIs are available.

An x86 KVM entry failure retains the hardware failure reason and CPU reported by
`KVM_EXIT_FAIL_ENTRY`. The structured error reaches the caller and workload
failure trace, distinguishing invalid guest state from other entry failures.
KVM retains both `KVM_GET_SUPPORTED_CPUID` and `KVM_GET_EMULATED_CPUID`
inventories at construction. Either ioctl failure rejects construction. Before
ordinary policy installation or nested initialization begins mutation, every
requested capability bit must be supplied by one of those inventories or by an
explicit caller declaration in `CpuidModel.emulated_features`. This declaration
is admission metadata; it does not change the CPUID bytes installed in KVM.
An absent leaf/subleaf supplies zero capability. A failed preflight preserves
the previous CPUID, MSR filter, architectural state, and backend usability.
Unsupported features produce `CpuidUnavailable` with leaf, subleaf, register,
requested bits, and available bits; the requested model is never intersected
with the host inventory.

The backend classifies capability words rather than embedding a guest profile:

| CPUID words | Admission rule |
| --- | --- |
| `1:ECX/EDX` | Require KVM capability bits; OSXSAVE (`ECX[27]`) is KVM runtime state derived from CR4 |
| `6:EAX/ECX/EDX` | Require KVM capability bits or explicit userspace declarations |
| `7.0:EBX/ECX/EDX`, `7.N:EAX/EBX/ECX/EDX` for N > 0 | Require KVM capability bits or explicit userspace declarations; `7.0:EBX[6,13]` are inverse x87 absence flags |
| `80000001:ECX/EDX`, `80000007:EDX`, `80000008:EBX`, `8000000a:EDX` | Require KVM capability bits or explicit userspace declarations; includes VMX/SVM requests |
| `D.0:EAX/EDX`, `D.1:EAX/ECX/EDX` | Require supported XSAVE state/features; software declarations cannot supply them |
| Nonzero `D.N` components, N >= 2 | Require exact supported size, standard offset, and component flags |
| Vendor/signature, brand, cache descriptors, topology, frequency and address-width fields | Descriptive model values, not host feature masks |
| Unclassified nonzero leaves | Refused until their fields receive a disposition |

Indexed feature leaves 7 and D must carry KVM's significant-index flag;
non-indexed feature leaves must use index zero. This prevents one entry from
aliasing unchecked subleaves. Nonzero PMU and hypervisor capability leaves are
unsupported rather than treated as CPU identity.

KVM's [x87 errata](https://docs.kernel.org/virt/kvm/x86/errata.html) recommend
always setting `FDP_EXCPTN_ONLY` and `ZERO_FCS_FDS` in guest CPUID. These are
inverse absence flags, not required native instruction capabilities; they do
not require the host's matching bit. This classification does not bypass XSAVE
state or component-layout admission.

Userspace declarations must be subsets of advertised bits in known feature
words, cannot repeat a leaf/subleaf, and cannot exempt XSAVE or its state/layout
requirements. The caller owns the declared emulation implementation. KVM's
emulated inventory handles instruction fallbacks such as MOVBE without
requiring native MOVBE; efficiently virtualized features are already present
in its supported inventory. No raw-host subset test replaces those APIs.

The live `missing_cpuid_features_reject_before_policy_mutation` test removes
each required bit from synthetic inventories on a real configured vCPU and
requires unchanged CPUID, snapshot state, filter, and a healthy backend.
`missing_nested_cpuid_feature_rejects_before_mutation` exercises the nested
entry path. `production_cpuid_is_preserved_by_native_capability_admission`
runs the actual VMM contract and compares ten guest CPUID queries against its
fixed values and documented runtime fields. These run in the CPU State CI job.

KVM policy installation changes the live CPUID before installing the VM-wide
MSR filter. If either write fails, the vCPU is retired: a failed filter can
leave new CPUID with the previous filter, which must not be captured or run as
one coherent policy. The live `rejected_msr_filter_retires_partly_reconfigured_vcpu`
test changes a CPUID leaf, makes KVM reject a zero-length filter range, and
requires subsequent capture and policy installation to refuse the vCPU.

Before the first policy is installed, `KvmBackend::nested_capabilities` selects
KVM-supported VMX or SVM. `initialize_nested` checks `KVM_CAP_NESTED_STATE` and
installs the requested vendor's CPUID model. VMX reads the declared capability
MSRs and sets IA32_FEATURE_CONTROL; SVM uses its supported CPUID capability leaf
and retains VM_CR and VM_HSAVE_PA through the native MSR filter and snapshot
MSR block. Partial MSR operations fail. The VMM's named nested-host policy binds
vendor and every exposed capability into contract identity.
Once nested initialization starts changing CPUID, an invalid VMX capability MSR,
rejected feature-control write, or later validation error retires the vCPU. The
live `rejected_vmx_capability_read_retires_partly_initialized_vcpu` test forces
an invalid MSR index after the CPUID write and requires capture and policy
installation to refuse the partly initialized backend. It reports an explicit
skip when a host has no VMX support; the test also requires KVM to reject reads
of the invalid MSR.

Nested state is captured in a capability-sized initialized buffer. The complete
returned payload is retained with the inactive VMCS12 metadata normalization
described below. SVM uses KVM's format 1 and retains its GIF flag unchanged.
Outside L2 guest mode, SVM returns the 128-byte header; its VMCB is in guest RAM,
and EFER.SVME and the host-save MSR remain architectural state. Raw observations
can include an active L2 payload, but publication and restore require L1 outside
guest mode without a pending nested entry. The validator rejects unknown flags,
malformed vendor layouts and cross-vendor restore before mutation. Ordinary
backends neither capture nor accept nested state.

With a userspace LAPIC, KVM delivers a `KVM_INTERRUPT` vector to L2 whenever
L1 is in nested guest mode. KVM also reports an open interrupt window while
L1's VMLAUNCH, VMRESUME or VMRUN is still pending, even though L1 had
interrupts disabled. Before queuing a vector, the backend reads the nested
state's guest-mode flag. In guest mode the vector stays pending and the window
request is cleared, so a later exit from L1 outside guest mode delivers it.
That delay has no fixed bound. KVM marks a `KVM_INTERRUPT` vector as already
injected, so it re-injects the vector into L2 and never turns it into an exit
to L1. A window request kept in guest mode would arm interrupt-window exiting
in the L2 control state, and an L2 with interrupts enabled would then exit
before every instruction.

X86 restore uses the host Linux 7.1
[KVM selftest](https://github.com/torvalds/linux/blob/v7.1/tools/testing/selftests/kvm/lib/x86/processor.c)
dependency order: special
registers, MSRs, XCRs, XSAVE, MP state, debug registers, general registers,
events, then nested state. Event restoration follows general registers because
KVM_SET_REGS clears the exception queue. The selftest's earlier event write
loses pending #PF and #GP under the enabled exception-payload API; the existing
live exception-payload and serviced-MSR regressions exercise that difference.
EFER, FS base, and GS base occur in both the special-register record and the
stateful MSR block. Restore rejects mismatched copies during preflight, before
retiring a staged write completion or changing KVM state; otherwise the later
MSR write silently replaces the special-register value. Coherent copies remain
restorable and read back with the same values.
SYSENTER CS is a 32-bit VMCS field, while SYSENTER ESP and EIP are virtual
addresses. KVM can accept wider values through `KVM_SET_MSRS` but return a
truncated or sign-extended value on the next save. Restore preflight rejects a
nonzero upper half of CS and noncanonical ESP or EIP values before changing
the vCPU. KVM canonicalizes ESP and EIP at its host LA57 capability width,
independent of the guest CPUID width. SVM also discards their upper halves for
AMD-compatible guests. To cover older kernels, preflight requires 32-bit
values on SVM unless the guest advertises the GenuineIntel vendor.
CR8 holds a four-bit task-priority value. KVM also accepts larger values in
`KVM_SET_SREGS2` but reads them back changed, so restore rejects those values
during preflight.
RFLAGS bit 1 is fixed at one, while bits 3, 5, 15, and 22 through 63 are
reserved. KVM accepts a cleared bit 1 through `KVM_SET_REGS` and reads it
back set. It also accepts reserved bits but rejects guest entry with them set.
Restore preflight rejects both cases before applying any vCPU state.
The VM flag is valid only for virtual-8086 execution in protected mode; KVM
accepts it in real or long mode but fails the next guest entry. Preflight
rejects those mode combinations before restore.
CR4.PCIDE requires IA-32e paging: CR0.PG, CR4.PAE, and EFER.LMA must all be
set. KVM accepts PCIDE without that mode in `KVM_SET_SREGS2`, then fails the
next VM entry before the guest executes. Restore rejects the combination
during preflight; a valid long-mode PCIDE state remains restorable.
Segment type and DPL fields have four-bit and two-bit encodings. KVM accepts
larger values through `KVM_SET_SREGS2` and silently truncates them on the next
save. Restore checks all eight segments before applying any vCPU state.
The present, DB, S, L, G, AVL, and unusable flags are one-bit fields and receive
the same preflight check; KVM otherwise accepts larger values and reads them
back changed.
A segment with the present flag clear must be marked unusable. An unusable
segment keeps only its base and selector; its other fields are zero. KVM
normalizes other combinations during save, so restore checks this shape first.
The XSAVE header's reserved bytes 528 through 575 must be zero. KVM rejects a
nonzero byte at `KVM_SET_XSAVE` after earlier restore writes, so preflight
checks that range before changing the vCPU.
KVM restore also requires standard XSAVE layout, state bits from its supported
CPUID mask, and no reserved MXCSR bits. These inputs likewise fail at
`KVM_SET_XSAVE` after earlier writes, so preflight checks them first. The pure
XSAVE image helper can retain a compacted image for non-KVM callers; the KVM
restore path rejects it because its ioctl accepts standard layout only.
The vCPU event validity flags sent to KVM must match the flags KVM reports
for the VM. The restore adapter always adds the payload-valid bit. Without it,
KVM drops a pending exception and its payload; a typed snapshot may omit that
selector while retaining the same event state. Preflight compares the
effective KVM write mask before any state write.
Event preflight also requires zero software-interrupt and SIPI fields that KVM
never reports, an interrupt shadow using only the STI and MOV-SS bits, at most
two pending NMIs, and canonical one-bit event fields. It also rejects a triple
fault when the VM lacks that event capability. KVM otherwise accepts some of
these values and changes them on the next save.
KVM clears an exception payload marker when no exception is pending and ignores
an inside-NMI marker outside SMM. This backend uses a userspace LAPIC, so KVM
cannot retain a latched INIT event either. Preflight rejects those event forms
before any restore write and accepts KVM-captured canonical events.
A nested-host restore first installs the vendor's inactive nested state.
The live vCPU may be in L2 or in VMX operation, and KVM leaves nested
operation by loading VMCS12 host state or switching to VMCB01. Doing that
first keeps it from overwriting the restored registers, and lets a snapshot
taken before VMXON clear CR4.VMXE. On SVM the backend then clears EFER.SVME
before writing the saved EFER. Leaving nested operation keeps the host's VMCB02
and the last VMCB12 address, and the host reloads L2 segment, descriptor-table
and debug state from VMCB12 only when L1 marks it dirty. Restored guest RAM
rolls VMCB12 back while L1's clean bits stay set, so without that reset L2
would resume with values from after the snapshot. Clearing SVME frees VMCB02.
The complete nested payload is installed after all architectural state. Invalid format, size, mode flags, or contract
presence fails preflight before any restore ioctl. So does a VMXON or VMCS12
address beyond the guest's physical address width, which KVM derives from
CPUID leaf 0x80000008 and rejects only after the architectural state is written.

`Backend::drain_dirty_pages` returns the guest pages written since the last
drain, so snapshots copy and restores reload only those pages. The KVM backends
read the kernel's dirty log. `HvfBackend` maps guest RAM without write
permission. A guest write then exits as a data abort inside RAM, and the
backend records its 16 KiB page, grants write access with `hv_vm_protect`, and
reruns the store without surfacing an exit. A drain removes write access again
and reports each recorded page as four 4 KiB guest pages. Hypervisor.framework
reports these aborts with a translation fault status, so the backend treats any
lower-EL abort inside mapped RAM as a tracked write.

Nested-host dirty drains capture and validate the current nested payload before
clearing dirty bits, then remove and reinstall each outer RAM slot at the same
address and size before reloading the unchanged nested state. Outer restore also
reloads those slots after restoring RAM and before installing CPU state. This
invalidates cached nested mappings, including shadow pages that can survive
a nested-state reload, and starts a fresh dirty bitmap after consuming the old
one. The stopped vCPU never enters between slot removal and replacement.
Without that invalidation, incremental capture can omit L2 writes and restored
L2 execution can read stale translations despite exact outer RAM restoration.
The inner process and VM remain allocated. Ordinary guests use the kernel
bitmap directly. Portable tests and Miri cover payload and mapping preservation,
preflight before mutation, operation order and stopping on errors. The live
matrix checks all RAM bytes, while recorded search exercises longer histories.
Any error during an x86 KVM dirty drain, including a nested-state read or
validation failure, poisons that backend. A later slot failure may leave earlier
dirty bits cleared, so retrying cannot recover the complete page set. Errors
during any x86 CPU-state restore mutation also poison the backend.
Further entry, preparation, capture and restore fail; a deleted slot cannot
be reused after an incomplete reload. Portable fault injection exercises each
slot-removal/replacement error and the final nested-state installation boundary.

On AMD-compatible KVM with NPT, full capture after a guest has entered 32-bit
PAE paging has changed the guest's cached PDPTR continuation. The guard applies
to AMD-compatible KVM regardless of NPT mode. Both snapshot
preparation and direct vCPU capture inspect the returned SREGS2 paging mode.
If that mode is active after guest entry, they report `AmdPaeSnapshotUnsafe`
and poison the backend. SREGS2 inspection cannot certify that hidden state is
unchanged, so the source vCPU cannot be resumed or reused for restore. No CPU record
or snapshot is published. A failed AMD SREGS2 read after guest entry likewise
retires the vCPU because the current paging mode is unknown. An unentered entry
template remains readable, and a successful restore starts a new entry epoch.
Intel and non-PAE captures retain
their normal behavior. The underlying AMD continuation discrepancy remains
tracked in [#314](https://github.com/pH14/harmony/issues/314).

AMD-compatible KVM also cannot safely restore CPU state into a vCPU that has
already attempted ordinary guest entry. A 64-bit XRSTOR-to-init continuation
produced guest XSAVE bytes with `XSTATE_BV=0` after reused restore, where the
uninterrupted and fresh-restored guest wrote `XSTATE_BV=2`, although the captured
KVM CPU records matched. Restore validation rejects that reused vCPU before any
backend or guest-memory mutation. An unentered vCPU remains restorable; the
control server falls back to a fresh VM when an in-place restore is refused.
Portable import checks the snapshot's structural compatibility separately from
this current-vCPU reuse rule. Importing a valid artifact after AMD guest entry
does not restore the entered vCPU; replay still requires a fresh backend.
Intel reuse remains supported. The underlying AMD behavior is tracked in
[#307](https://github.com/pH14/harmony/issues/307).

Backends install a guest-visible CPU policy before the first run. Read-style
exits require the matching completion response. The x86 KVM backend completes
PIO reads and MSR callbacks eagerly with an immediate-exit entry. A PIO write
leaves its completion staged and already acknowledged: `run()` accepts it
without a `finish_exit` call and the next real `KVM_RUN` retires it as a side
effect, so a write that never precedes a state read costs no extra entry at
all. `save`, `prepare_snapshot`, `restore`, and `retire_pending_completion`
retire an acknowledged write with one immediate-exit entry before they read or
replace the vCPU, so a restore never leaves an in-kernel completion to land on
the restored registers. The acknowledgement is derived from the decoded exit at
every decode site, so a device access surfaced by that drain is unacknowledged
like any other MMIO exit. An MMIO exit stays unacknowledged until
`finish_exit`, so `run()`, `prepare_snapshot`, and `restore` reject it with
`PendingCompletion` and no guest entry, and `save` reads the vCPU as it stands;
`finish_exit` completes the MMIO callback and returns any further device access
required by the same instruction. Callers service these continuations until `finish_exit` returns
`None` before exposing a stopped execution. No completion entry executes the
successor instruction or injects an interrupt. An MSR fault queues its
exception without executing the handler. An unexpected completion-only entry
or ioctl error retires the backend before it can retry the uncertain completion
or publish a snapshot; expected immediate-exit interruption and a decoded
device continuation leave the backend usable. An unsupported exit after guest
entry also retires the backend. The live
`rejected_rep_input_retires_uncounted_guest_progress` test executes a guest
write before KVM returns a multi-byte REP input exit that this backend cannot
decode; the exit count stays zero, and capture, restore, and re-entry all
refuse that uncounted progress.
The live serviced-exit regressions require exact CPU state at the stopped
completion boundary. After guest continuation, they compare logical XSAVE
presence alongside every CPU field; the MMIO and MSR cases also compare guest
RAM bytewise. KVM can change raw presence bits for init-valued x87/SSE
components on entry without changing their state.

KVM construction enables the exception-payload API so pending exceptions remain
distinct from injected ones and restores replace the complete exception record.
Snapshots retain general registers verbatim, including `RFLAGS.RF`: that flag
suppresses the next instruction breakpoint and can change the continuation.
The live resume-flag test compares original, saved, and cold execution against
an RF-cleared control that must enter the guest debug handler.

Exit counters include continuation accesses exactly once. Virtual-time policy,
device models, snapshot formats, and entropy live above this crate.

ARM64 snapshot capture rejects a pending exit or staged completion before it
reads the vCPU. Completed MMIO reads and MMIO writes remain capturable;
placeholder ARM64 sysreg exits remain uncapturable while their completion is
pending. The ARM64 KVM backend leaves an MMIO write, or a read once its data is
supplied, for the next `KVM_RUN` to complete, so each access costs one entry.
`save` completes it with one immediate-exit entry; `restore` first validates
the requested state, then completes it before writing the restored state. A
rejected restore therefore leaves an owed access untouched, while captured
registers are past the access and a valid restore never leaves a completion to
land on the restored registers. The backend counts and times those entries
and reports the totals through `Backend::store_completions`, since they are
host cost the exit table cannot see. An unexpected completion failure retires
the vCPU because the kernel entry may already have advanced guest state.
HVF rejects a restore with PSTATE bits above bit 31 before changing registers:
its CPSR setter accepts those bits but discards them on the next capture.
Its FPCR and FPSR setters likewise discard bits above bit 31, so restore
preflight rejects those values before changing the vCPU.

`Backend::read_irq_mask` optionally reads the CPU's architectural IRQ mask
without capturing a complete snapshot. `Some(true)` means the mask is set;
`None` means the caller must obtain it from full state. This query does not
enter the guest, acknowledge an IRQ, or test the interrupt controller's pending
state. Errors propagate rather than falling back to another read. HVF reads
`PSTATE.I` through one CPSR access. ARM KVM completes any owed MMIO access and
then reads PSTATE through one register ioctl instead of capturing the GIC and
the rest of the vCPU. Both reject pending completions before the read. Other
backends currently return `None`.
The boxed backend forwards the query so live sessions use the same path.

`Backend::read_arm64_gic_idle_state` reads only the in-kernel GIC fields needed
to decide whether a selected PPI can wake an idle ARM guest: distributor Group
1 enable, that PPI's group, enable, active, and priority fields, and the CPU
interface's mask, Group 1 enable, binary point, control, and active-priority
registers. ARM KVM uses this read after settling an owed MMIO access. It does
not capture a vCPU or scan SPI routes. Snapshot capture continues to reject
pending or asserted SPIs and nonzero SPI routes, while idle can still inspect
the clockevent PPI in those guest states. The boxed backend forwards the
targeted read, the ARM mock projects its held GIC state, and HVF and x86
backends return no in-kernel GIC state.

The ignored HVF `irq_mask_polling_matches_full_capture` comparison alternates
full capture and direct reads in one binary, both alone and after each exit of
a synthetic guest loop. It checks every guest output, RAM, exit counts, and
modeled CPU state except the host-driven virtual counter. Run it with:

```sh
cargo test --release -p vmm-backend --test hvf_smoke irq_mask_polling_matches_full_capture -- --ignored --nocapture
```

It reports local timings without a timing assertion. This isolates polling
cost; it does not measure whole-workload throughput or snapshot performance.

Both Linux KVM backends expose a cancellation latch for the session watchdog.
The watchdog interrupts a blocked KVM run with a signal and sets the latch;
the backend refuses subsequent guest entry after cancellation.

The `contract-tests` feature exposes the shared backend contract exam, and the
`mock` feature enables portable fixtures:

```sh
cargo test -p vmm-backend --features mock,contract-tests
cargo clippy -p vmm-backend --all-targets -- -D warnings
```

`tests/contract_kvm.rs` runs the same exam against stock KVM. The CPU State job
in `Checks / Consonance` runs it on the hosted runner's KVM.

KVM restoration invalidates cached guest translations before resuming a reused
VM. The restore sequence writes a transient CR0 write-protection value and then
the exact saved special registers, without entering the guest between writes.
This forces KVM to reset its MMU context after the caller replaces page-table
memory while retaining the same paging registers. Linux performs this reset
conditionally in [`__set_sregs2`](https://github.com/torvalds/linux/blob/v6.12/arch/x86/kvm/x86.c#L11986). Synthetic tests check the
write sequence and error handling; KVM integration coverage exercises restored
continuations across a branching snapshot tree.

HVF restoration invalidates the guest's stage-1 translations before it writes
the restored vCPU state. Hypervisor.framework exposes no TLB call, so the
backend maps a private page above the guest's regions holding
`tlbi vmalle1is; ic ialluis; dsb ish; isb; hvc #0` and runs it with the MMU off. Without it
a restore rewinds guest RAM and registers while the hardware keeps translations
the abandoned execution installed, and the guest reads the wrong physical page
through an address the restored page tables map elsewhere. That reads as
narrow, register-shaped corruption in an arbitrary guest process rather than as
a fault. The `ic ialluis` covers code the abandoned execution wrote and ran on
a page whose bytes the restore then left alone because they already matched
the snapshot. Host writes to guest RAM go through
`Backend::invalidate_instruction_cache`, which HVF clips to the host ranges it
mapped. Stage 2 never changes across a restore and needs no maintenance: the
host allocation behind guest RAM keeps its address.
The flush accepts its HVC exit only when the vCPU PC equals the instruction
after the private stub. An HVC in a guest exception vector can otherwise make
an aborted stub look complete; restore must refuse and retire the backend.

A watchdog cancellation requested before the stub's guest entry is consumed by
that entry and retires no instruction, so the stub entry is retried once. The
cancellation latch outlives the exit and `run` still refuses the guest.

An error after HVF guest entry retires the backend. The vCPU may have executed
instructions before `hv_vcpu_run` or exit decoding failed, while no exit was
reported or counted. A pre-entry watchdog cancellation leaves the backend
capturable, but a post-entry error refuses later guest entry, preparation,
capture, and restore. The live failure-injection test executes a guest register
write before returning an injected post-run error and checks that the uncounted
state cannot be published.

The guest's virtual counter runs off the host counter and neither backend can
trap a guest read of it, so a restore that left the counter alone handed the
guest every tick of host time spent between the snapshot and the restore. Both
arm64 backends record the counter the guest was reading at the snapshot and put
it back on restore: HVF derives a CNTVOFF_EL2 from the host counter and ARM KVM
writes KVM_REG_ARM_TIMER_CNT. The counter keeps advancing with host time while
the guest runs, so a save taken after a restore reports a later value than the
one restored, and it stays out of the state hash and the divergence components
for that reason.

The owned ARM guest cannot program its architected virtual timer controls.
Both backends set `CNTV_CTL_EL0` to zero before guest entry and reject an
enabled timer during capture or restore. This keeps a restored checkpoint from
arming a host-time interrupt outside the Harmony clockevent path.
ARM KVM also exposes the guest physical timer. A guest can change
`CNTP_CVAL_EL0` while `CNTP_CTL_EL0` is disabled, or arm the timer and receive
PPI 30. Neither register belongs to the portable vCPU record. ARM KVM therefore
admits capture only when both physical-timer registers equal the fresh-vCPU
zero baseline, and clears both before guest entry and restore. KVM owns the
virtual-timer PPI 20 and physical-timer PPI 30: it accepts a userspace line
write for either one but clears that line before the guest can accept it, so
the backend refuses external injection of both timer-owned PPIs. The
live `guest_physical_timer_state_refuses_capture_and_legacy_restore` check
observes a programmed timer's guest control value of `0x5` against a fresh
guest's `0x0`, then verifies capture and old-record restore refusal. It also
checks a disabled timer with a nonzero compare value. KVM can leave PPI 20 or
30 asserted after the timer controls return to zero at a shutdown exit.
Capture also refuses a pending or active bit on either timer-owned PPI, and
restore rejects a record containing any of those three delivery states. The live
`guest_timer_owned_ppi_line_refuses_terminal_cut_capture_and_restore` check
exercises the asserted PPI 30 shutdown cut and confirms an external PPI 29
remains admitted.

ARM KVM also exposes a guest-writable `DISR_EL1` value. It is absent from the
portable vCPU record: a guest-written `0x1234` survived uninterrupted execution
but read back as zero after a cold restore. Capture now refuses a nonzero
`DISR_EL1`, and policy installation and restore clear it to the fresh-vCPU zero
baseline. Arm GIC state version 7 rejects older snapshots that lacked proof of
both the physical-timer and `DISR_EL1` boundaries. The live
`guest_disr_state_refuses_capture_and_legacy_restore` check covers capture
refusal, version-6 restore refusal, and a clean restore into a reused vCPU.

Apple HVF also exposes guest-writable `ACTLR_EL1`, including the EnTSO memory
ordering control. It is absent from the portable vCPU record: a guest-written
value of `0x2` survived uninterrupted execution but read back as zero after a
fresh restore. HVF refuses capture while `ACTLR_EL1` is nonzero, and policy
installation and restore clear it to the fresh-vCPU zero baseline. Backend
creation probes ACTLR read/write and refuses a host without that capability;
Apple documents the register API from macOS 15. The live
`guest_actlr_state_refuses_capture_and_clean_restore_resets_it` test checks
capture refusal and clean reused and fresh restores.

HVF also allows EL1 guests to write and read all ten pointer-authentication key
halves even when the advertised feature ID disables pointer authentication.
Those keys are absent from the portable vCPU record. On the measured host, each
guest-written key read back as `0x1234` without restore and zero after cold
restore. HVF now refuses capture if any key half is nonzero, and policy
installation and restore clear all ten keys to the fresh-vCPU zero baseline.
Backend creation probes read/write access to each key and refuses a host that
cannot establish this boundary. Arm portable records first used wire version 10
to reject older snapshots that lacked proof of the ACTLR and key capture checks.
The live `guest_pauth_keys_refuse_capture_and_clean_restore_resets_them` test
covers all ten keys, capture refusal, and clean reused, fresh, and policy
restores.

## ARM register inventory admission

`Arm64Kvm::register_list` enumerates the initialized vCPU with
[`KVM_GET_REG_LIST`](https://docs.kernel.org/virt/kvm/api.html#kvm-get-reg-list).
Enumeration failure, duplicate IDs, an unclassified ID, or a missing captured
slot refuses policy installation before any write. Capture and restore repeat
admission. This is a bounded inventory of the registers KVM actually lists for
Harmony's PSCI-only, AArch64, non-SVE/non-PAuth vCPU initialization; it is not an
assertion about every architectural register or arbitrary future KVM features.
The measured Linux 6.18 ARM KVM inventory has 257 entries:

| Disposition | Entries | State and enforcement |
| --- | ---: | --- |
| Captured | 159 | 37 AArch64 core slots, 34 SIMD/FP slots, the 19 `SYSREGS` fields, 66 debug slots, and three virtual-timer slots |
| Fixed zero | 22 | ACTLR, DISR, physical timer control/compare; 14 reserved ID slots; four optional firmware bitmaps |
| OS lock | 1 | OSLK must be clear at capture; restore clears it; read-only feature bits enter identity |
| Immutable identity | 62 | Other listed CPU ID/cache registers and 14 demultiplexed CCSIDR selectors |
| Firmware configuration | 4 | PSCI version and three SMCCC workaround values enter identity |
| Excluded AArch32 | 8 | Four banked SPSRs, DBGVCR32, DACR32, IFSR32 and FPEXC32; capture and restore admit only AArch64 EL0/EL1 modes in both PSTATE and SPSR_EL1 |
| Excluded physical counter | 1 | Native CNTPCT is external host time, outside the cooperative virtual-time interface; it is not replayed |

The AArch32 exclusion also depends on the actual vCPU initialization, not just
cut-time PSTATE checks. `vcpu_init_features` enables exactly PSCI, leaving
`KVM_ARM_VCPU_EL1_32BIT` and nested EL2 disabled. KVM fixes EL1 to AArch64 via
[HCR_EL2.RW](https://github.com/torvalds/linux/blob/v6.18/arch/arm64/include/asm/kvm_emulate.h).
Guest EL1 cannot change that hypervisor control. A transient AArch32 EL0
execution cannot read or write privileged AArch32 banked SPSRs or those four
EL2 views of EL1-only registers. Its shared GPR/SIMD state is captured normally;
an AArch32 cut itself remains unsupported. In particular, KVM
[skips FPEXC32 save/restore for AArch64 EL1](https://github.com/torvalds/linux/blob/v6.18/arch/arm64/kvm/hyp/include/hyp/switch.h),
and Arm specifies that its enable bit applies only when EL1 is not AArch64.
These controls prevent later AArch32 EL0 execution from observing omitted
privileged banked state; masking the advertised ID alone would not suffice.

The native physical counter exclusion is an explicit limit, not a claim that
all EL1 timing instructions trap or that arbitrary counter-reading guests are
deterministic. Standard libraries remain supported through the owned Linux
clock interface. KVM register IDs must be interpreted as ABI identifiers:
legacy virtual timer CVAL and counter IDs use encodings `0xdf02` and `0xdf1a`,
respectively, rather than their architectural system-register names. The
[Linux v6.18 register implementation](https://github.com/torvalds/linux/blob/v6.18/arch/arm64/kvm/sys_regs.c)
provides the mapping, reserved-ID behavior, ACTLR access behavior, and immutable
cache configuration used by this table.

`sha2` hashes sorted IDs, dispositions, immutable values, firmware values and
read-only OS-lock bits into `Arm64Caps::register_identity`; captured values are
already owned by the snapshot. A changed schema or native value changes the
runtime contract. Capture refuses unexpected identity drift; restore verifies
the target identity before mutation. Restore resets the four transient fixed
registers and OSLK, so a dirty detour does not itself prevent a clean restore.
A failed register read or write propagates. This digest owns small admission
metadata; the backend still does not hash guest RAM or the full machine.
The core includes it in snapshot, imported-artifact and cache identity.

HVF has no equivalent register-enumeration API. Its boundary is the public SDK
configuration and state APIs, with an explicitly created and released vCPU
configuration passed to the actual vCPU creation. Its fingerprint includes all
14 documented configuration feature fields, both eight-entry CCSIDR arrays,
and maximum guest streaming vector length when SME is present. This conservatively
binds native configuration even where the guest policy masks a feature. HVF
captures the modeled core, SIMD/FP, system/debug, virtual-timer and interrupt
state; its userspace GIC and PSCI are modeled by the core. Native configuration
with non-streaming SVE is unsupported because the record has no non-streaming
predicate or extended vector storage. Physical timer APIs
require `hv_gic_create`, and EL2 APIs require an EL2-enabled VM configuration;
this backend enables neither. Those SDK fields are not silently read as zero.
Direct REVIDR, CLIDR, AIDR, OSLSR and DISR reads are unavailable on the measured
HVF host; cache geometry comes from the actual configuration API instead.

HVF fixes ACTLR, SCXTNUM_EL0/EL1, TPIDR2_EL0, SMPRI_EL1 and SMCR_EL1 at zero,
in addition to the ten pointer-authentication key halves. Creation verifies
read/write/reset; capture refuses nonzero state; policy and restore reset it.
SME capture requires PSTATE.SM=0 and PSTATE.ZA=0, independently of masked ID
registers. Restore clears both before restoring Q registers and FPSR. Apple's
[XNU SME documentation](https://github.com/apple-oss-distributions/xnu/blob/main/doc/arm/sme.md)
states that enabling ZA clears ZA/ZT0; the HVF state setter clears streaming
Z/P state on mode transitions. Inactive extended storage therefore cannot
carry a prior detour into the next activation. This does not admit active
streaming vectors, predicates, ZA or ZT0 into the portable record.

SME APIs are resolved at runtime, avoiding a loader failure on older macOS.
Only explicit `HV_UNSUPPORTED` means absent SME when the APIs exist. If all
three SME symbols are absent, admission additionally requires a successful,
exact integer-zero native `hw.optional.arm.FEAT_SME` read and zero SME in the
unmodified configuration's PFR1. Arm's
[hardware feature detection guide](https://learn.arm.com/learning-paths/laptops-and-desktops/kleidicv-on-mac/build-1/)
defines this native zero as SME unavailable. Missing, malformed or failed reads,
partial symbols, and nonzero native features refuse admission. This older
preflight hashes 12 feature fields rather than 14; schemas do not compare
equal. That preflight does not establish older-runtime admission: actual
fixed-register access remains mandatory, including fields introduced in macOS
15.2, and a framework rejecting those accesses refuses creation. The existing
core baseline also requires ZFR0/SMFR0 register APIs introduced in macOS 15.2.
Neither older-runtime admission nor active-SME hardware has been qualified by
the current macOS 26.6 non-SME host receipt.

The registered native inventory tests print each KVM disposition and exercise
native identity drift, ACTLR reset, all six HVF fixed-register detours and the
SME state boundary. An explicit `SME_ACTIVE_TEST=UNSUPPORTED` receipt is absence
evidence only, not an active-SME pass. Portable controls cover unknown/missing/
duplicate/failed enumeration before mutation, identity/schema differences,
fixed-state detours, unsupported execution modes and imported hash rejection.

ARM KVM handles `OSLAR_EL1` writes and `OSLSR_EL1` reads internally, bypassing
userspace's unlock-only dispatcher rule. The portable debug record admits only
an unlocked OS lock: capture reads `OSLSR_EL1` and refuses `OSLK` (bit 1), while
policy installation and restore clear OSLK through KVM's writable `OSLSR_EL1`
register API, preserving its required read-only feature bits. Failed reads or writes propagate as backend errors. Read-only
OSLSR feature bits are excluded from the lock check. ARM GIC state version 9
rejects older KVM snapshots that lacked this admission proof. The live
`guest_os_lock_refuses_capture_and_clean_restore_unlocks` fixture sets the lock
from guest EL1, checks readback at a completed MMIO boundary, verifies that
capture refusal preserves the locked continuation, and checks unlocked
capture-and-continue, fresh restore, reused restore after a locked detour, and
policy reset. Removing the capture check or restore reset must fail this test.
This synthetic guest qualifies the boundary; it does not establish a failure in
an ordinary shipped application.

The debug-register inventory for this boundary is:

| Register or field | Disposition | ARM KVM enforcement |
| --- | --- | --- |
| `DBGBVRn_EL1`, `DBGBCRn_EL1`, `DBGWVRn_EL1`, `DBGWCRn_EL1` | Captured | All 16 slots read and restored through one-register ioctls |
| `MDCCINT_EL1.RX/TX`, `MDSCR_EL1` | Captured | Read and restored; reserved MDCCINT bits rejected |
| `OSLSR_EL1.OSLK` | Fixed unlocked | Capture refuses a lock; restore and policy clear it |
| `OSLAR_EL1` | Emulated write alias | KVM changes OSLSR; checked at capture rather than relying on an exit |
| Other `OSLSR_EL1` fields | Excluded feature description | Read-only KVM feature bits do not represent the OS lock |
| Debug exception/register-access trap requests | Unsupported | Restore preflight rejects either enabled request |

Both ARM KVM and HVF capture and restore guest-writable `MDCCINT_EL1.RX` and
`MDCCINT_EL1.TX` as part of the debug state. A guest write to RX survives normal
execution on HVF but was lost after a cold snapshot restore, so Arm portable
records now use wire version 11 and reject older records that omitted this
register. Both backends and the codec reject nonzero reserved bits. The ignored
`arm64_hvf_mdccint` hardware test compares guest readback without restore and
after a fresh VMM restore.

ARM KVM refuses restore after the first attempted guest entry. Updating
translation registers through `KVM_SET_ONE_REG` does not establish a guest TLB
or instruction-cache maintenance boundary. A fixed-CPU, fixed-ASID witness with
an empty dirty bitmap reproduced a stale translation after an abandoned branch;
dirty-log clearing can incidentally hide that failure. The refusal occurs in
restore preflight before register writes or the control server's RAM changes.
The control server falls back to a fresh VM. Portable import checks the saved
state independently of whether the current VM has already run, so importing a
snapshot for fresh replay remains supported. Reconfiguring policy never clears
the used-vCPU latch. This costs fresh-VM creation on ARM KVM replay until an
explicit in-place maintenance mechanism is qualified.

The live `arm64_restore_translation` regression warms the abandoned mapping,
drains its page-table writes, confirms a subsequent empty dirty bitmap, checks
that refusal preserves registers and RAM and permits continuation, and compares
fresh restore with guest-issued invalidation. The shared register suite reports
when ARM KVM requires this fresh fallback; HVF continues to exercise in-place
restore with its explicit maintenance path.

ARM KVM and HVF expose pure restore-shape checks through the `Backend` trait,
so portable snapshot import rejects their known invalid vCPU records before
guest RAM or backend state is changed.
ARM KVM and HVF reject later guest entry, preparation, capture, restore and
state observation if a restore operation fails after preflight: a partially
changed vCPU must not be reused as a coherent replay state. HVF includes its
private translation-flush guest entry in that failure boundary. Shape rejection
before the write sequence leaves the backend usable. The ignored live HVF
`failed_translation_flush_retires_mutated_vcpu` test injects a failure after the
flush has staged registers and checks the refusal; it also checks that an
invalid restore shape leaves the backend usable.

`HvfBackend::set_policy` reads HVF's own value of each `ID_AA64*` feature
register and validates the complete policy before writing any register. A
rejected policy leaves the prior guest identity intact; a failed HVF write
retires the vCPU because the prior identity may be partly replaced. The live
`rejected_policy_preserves_live_identity` and
`failed_policy_write_retires_mutated_vcpu` tests exercise both boundaries.
HVF also retires the vCPU if servicing a trapped system-register fault fails
after it begins writing the exception registers. Retrying from a partly changed
PSTATE would take a different exception path and replace the original SPSR.
The live `failed_fault_completion_retires_partly_changed_vcpu` test forces that
late failure and checks that the backend refuses a retry and capture.

Policy validation returns `BackendError::IdRegisterAboveHost` when any 4-bit field asks for
more than that host value. The guest sizes its use of the hardware from these
fields, and Hypervisor.framework accepts any value written to them. ARM KVM
makes the same check inside `KVM_SET_ONE_REG`. Fields compare as unsigned
levels, except the signed fields `PFR0.FP`, `PFR0.AdvSIMD`, `DFR0.DoubleLock`,
`MMFR0.TGran64` and `MMFR0.TGran4`, where all ones means absent. `PFR0.GIC` is
not compared because the VMM implements the GIC system registers by trapping
them. The stage-2 and EL2 fields `MMFR0.TGran*_2`, `MMFR1.VMIDBits`,
`MMFR1.VH`, `MMFR2.FWB` and `MMFR2.EVT` are not compared because the guest runs
at EL1 and never uses them.

Arm KVM also retires the vCPU when policy installation fails after it starts
writing PSCI, firmware, ID-register or GIC state. A later rejection can leave
the previous live policy only partly replaced. The fake-KVM
`failed_policy_write_retires_partly_reconfigured_vcpu` test injects failure
after the first ID-register write and requires later capture and guest entry to
refuse that vCPU.

`Arm64Caps::asid_bits` reports the ASID width each backend's host fixes for the
guest. Hypervisor.framework implements 8-bit ASIDs, so HVF reports 8 bits. ARM
KVM leaves `MMFR0.ASIDBits` out of its writable ID register mask and fails
`KVM_SET_ONE_REG` with `EINVAL` for any value other than the host's, so
`LiveKvm::new` reads the vCPU's `ID_AA64MMFR0_EL1` after `KVM_ARM_VCPU_INIT` and
reports that width.

HVF answers `SMCCC_ARCH_FEATURES(ARCH_WORKAROUND_1/2/3)` as `1/-1/0`.
ARM KVM's responses to these three queries depend on the host's Spectre-v2,
Spectre-v4, and BHB states even when optional firmware bitmaps are disabled.
After applying the guest ID-register policy, ARM KVM reads its three firmware
workaround pseudo-registers and exposes their measured levels as backend
capabilities. HVF exposes the equivalent fixed levels `2/0/1`. Hosts with other
levels can boot, but the VMM binds those levels into snapshot compatibility and
state identity so different firmware answers cannot share a replay state. The
shared `arm64_sysreg_snapshot` hardware test executes all three queries in a
guest and compares their responses with the exposed levels on both hosts. The
owned arm64 Linux guest treats workaround 2's `-2` as unaffected by Spectre-v4
but `-1` as vulnerable; its frozen CPU identity has no SSBS feature, so this
answer controls retained mitigation state.

ARM KVM handles PSCI 1.0 HVCs in-kernel. HVF implements its own single-vCPU
PSCI handler. Their guest-visible answers differ: for example,
`PSCI_FEATURES(CPU_SUSPEND)` returns `0` on KVM and `-1` on HVF, and
`AFFINITY_INFO` for CPU 0 returns `0` on KVM and `-7` on HVF. Both backends
expose an explicit PSCI profile capability. The shared
`arm64_sysreg_snapshot` hardware test checks each profile against live guest
HVC results. This profile is a replay compatibility boundary, not a claim that
the two PSCI implementations have equal behavior.

ARM KVM captures and restores the GIC CPU interface through the VGIC device
registers: priority mask, both binary point registers, `ICC_CTLR_EL1`, both
group enables, and every available Group-0 and Group-1 active-priority register.
The number of active-priority registers follows the host's `PriBits` field.
KVM cannot expose all active-priority slots when the host reports eight
priority bits, so policy setup rejects that host before guest execution.
Restore checks the immutable `ICC_CTLR_EL1` fields before changing vCPU state;
those fields also enter the runtime contract. Full vCPU capture rejects
`ICC_CTLR_EL1.CBPR=1`, because KVM does not expose the independent Group-1
binary point hidden by that mode. This also makes run-end capture and state
hashing fail closed if a guest sets CBPR. The ignored
`guest_gic_cpu_interface_survives_fresh_restore` ARM KVM test exercises guest
writes, cold restore, and this fail-closed boundary.
The VGIC record also retains distributor SPI trigger configuration. Restore
checks the immutable redistributor SGI/PPI configuration before changing vCPU
state, then writes SPI configuration before the remaining distributor state.
Policy setup programs KVM's initially edge-triggered SPIs to the common level
baseline before first guest entry and verifies the device accepted the writes.
The fixed SGI/PPI configuration is edge/level, respectively, on the measured
ARM KVM host and in the userspace model.
The ignored `guest_gic_spi_trigger_survives_fresh_restore` ARM KVM test compares
guest readback of that baseline and of a programmed edge after uninterrupted
execution and cold restore.
KVM also retains guest writes to the redistributor `GICR_PROPBASER` and
`GICR_PENDBASER` even when no ITS is present. ARM GIC state version 8 records
both 64-bit values, and ARM device blobs include them in replay identity. KVM
canonicalizes an initially zero `GICR_PROPBASER` to `0x180` when userspace
writes it, so backend creation writes both fresh redistributor bases before
first guest entry. Restore checks reserved bits and KVM's canonical
shareability and cacheability fields before changing vCPU state, then writes
both halves and requires exact readback. KVM rewrites outer-shareable,
noncacheable inner, and noncanonical outer-cacheable values on write; imported
records containing those values are rejected before mutation. The ignored
`guest_gicr_bases_survive_restore_with_fresh_fallback` test compares guest MMIO
readback after uninterrupted execution, restore with fresh fallback, and a cold restore.
ARM KVM selects VGIC `GICD_IIDR` implementation revision 2 before configuring
the device and requires exact readback. KVM revisions 2 and 3 return different
guest-visible `GICR_CTLR` values on the same host, so accepting the host's
default revision would make guest behavior depend on its kernel version. The
full configured `GICD_IIDR` and `GICD_TYPER2` values enter backend capabilities
and the runtime contract; the latter includes any host-dependent
`nASSGIcap` bit. A bounded msr1 guest probe read `GICR_CTLR=0` under revision
2 and `0x6` under revision 3 while `ICC_CTLR_EL1` remained `0x8400`.
On GICv4.1 hosts with direct SGIs, `GICD_CTLR.nASSGIreq` can hold guest-writable
state. The record represents only distributor Group-1 enable, so capture refuses
bit 8 and any other distributor-control bits outside the fixed and represented
set. Imported records with unrepresented bits are rejected before device
mutation. A fake-KVM regression exercises the fail-closed boundary.
The single-vCPU machine supports SPI routing only to affinity zero. The
userspace GIC rejects a nonzero `GICD_IROUTER` write. KVM can execute that
write inside its in-kernel VGIC, so capture reads both 32-bit KVM device-attribute
words of every implemented SPI's 64-bit route and refuses a snapshot if either
word is nonzero. Restore clears
and verifies all SPI routes, including on a reused target that previously ran
a guest with a nonzero route. The ignored
`guest_nonzero_spi_route_rejects_capture_and_zero_route_restores` test checks
guest readback, refusal, reused-target reset, and cold restore.
KVM's VGIC can retain a pending SPI outside its vCPU delivery queue after a
guest routes the SPI away, pends it, and routes it back. The same captured VGIC
registers can then report different `ICC_HPPIR1_EL1` results. KVM capture and
state hashing therefore refuse any pending SPI or asserted SPI input line, and
restore rejects such a KVM GIC record before changing the target. The userspace
GIC retains its own pending-SPI state. The ignored
`routed_away_pending_spi_refuses_capture_and_restore` ARM KVM test compares the
two live routing histories and verifies both refusal paths.
ARM KVM restore reconstructs the one asserted external PPI input from the saved
VGIC line level. The next clockevent ACK or DISARM can then lower that line
through `KVM_IRQ_LINE`, while restored interrupt-acceptance observations remain
transient. Capture refuses multiple asserted PPIs or any asserted SGI input,
and restore rejects those records before changing the target because the
backend controls one external interrupt line at a time. The public VMM
clockevent regression saves an asserted PPI, restores it into a cold VM, and
acknowledges it through the ARM MMIO dispatch path.
Changing an asserted KVM interrupt line deasserts the old input before it
asserts the new one. A failure on the second write retires the backend because
the VGIC line level has already changed; capturing at that point would publish
a half-applied interrupt switch. The fake-KVM
`failed_irq_line_switch_refuses_capture_after_partial_transition` test forces
that sequence and checks that capture refuses it.
IRQ requests outside the configured 96-interrupt VGIC are rejected before any
line changes, leaving the backend usable.

ARM KVM retires when `KVM_RUN` fails or the subsequent interrupt-acceptance
observation or exit decode fails: guest execution may have advanced, but the
exit was not reported or accounted. The fake-KVM
`failed_guest_entry_refuses_capture_after_unreported_guest_progress` test models
a run error after guest progress; `failed_post_run_irq_observation_refuses_lost_exit_capture`
forces a VGIC read failure after a consumed MMIO exit. Both require capture to
refuse the lost-exit state.

Both ARM backends capture and restore `CONTEXTIDR_EL1`, `AMAIR_EL1`,
`PAR_EL1`, `CSSELR_EL1`, `AFSR0_EL1`, and `AFSR1_EL1` alongside the
translation, exception, and thread registers. The shared
`arm64_sysreg_snapshot` hardware test compares uninterrupted execution, capture
without restore, restore after a detour, and restore into a fresh VM. It
requires the detour to change guest readback across an exit for CONTEXTIDR, PAR,
and CSSELR. AMAIR and auxiliary fault status can be fixed or lose writes across
an exit on a particular host; those cases are reported as unobservable rather
than evidence of register restoration. Portable tests independently check all
six fields through the KVM register table, codec, and VMM identity. The aligned
guest-memory fixture also runs under Miri through the mock backend.

ARM KVM saves the guest's system registers as the guest left them and never
normalizes a value the guest wrote. TCR_EL1.AS selects 8-bit or 16-bit ASIDs, and
while the identity baseline advertised 16-bit, clearing it left the guest kernel
issuing ASIDs the hardware no longer distinguished and processes shared TLB
entries. For SCTLR_EL1 and TCR_EL1, `KVM_SET_ONE_REG` and `KVM_GET_ONE_REG`
read and write the saved vCPU context rather than the architectural register, so
a restore cannot tell from those calls whether the host implements a field the
saved value uses. Restoring onto a host that lacks such a feature can therefore
resume the guest with that field reading zero; the feature identity registers
carry their own admission check, and these two do not. ARM KVM does no
stage-1 translation invalidation on restore either; whether it needs the
maintenance HVF needs is unmeasured, and an Arm KVM host is where that is
settled.

## Live HVF tests

`tests/hvf_smoke.rs` runs small hand-assembled guests on Hypervisor.framework.
It checks that a restore drops guest translations cached before it, that a
restore puts the guest counter back, that saving and restoring between steps or
branching from a snapshot does not change what the guest computes, that every
vCPU state class reads back after a restore, that restore rejects timer states
HVF cannot hold, and that `set_policy` checks every policy against the host's
ID fields and rejects a field above the host. The tests are ignored because
hosted runners have no hypervisor. The pre-push hook runs them on Apple
silicon, from `HOST_TESTS` in `scripts/ci_contract.py`. To run them directly:

```sh
cargo test -p vmm-backend --test hvf_smoke -- --ignored
```

The repository's cargo runner for `aarch64-apple-darwin`,
`scripts/macos-hvf-runner.sh`, signs each binary with `hvf.entitlements.plist`
before it runs, so these tests and a `cargo run` of the CLI need no manual
`codesign` step.

## Preparing x86 KVM snapshot boundaries

`Backend::prepare_snapshot` reconciles backend execution state before a logical
boundary is published. The default implementation is inert. KVM uses a guarded
`KVM_RUN` with `immediate_exit`. When a completion is already staged (a PIO
write left pending by the lazy path above), that same guarded entry retires it
first, so preparation and completion share one `KVM_RUN` instead of two. It
still refuses a pending read/MSR value awaiting an explicit completion and an
already-queued completion exit, and requires `EINTR` from the entry it does
run, clearing its immediate-exit request on success or error. It mirrors CR8
from the current CPU state into the shared run page before entry; restore also
synchronizes that field, preventing a stale run page from replacing restored
CR8. This path does not inject queued interrupts or count a guest exit.

The immediate-exit operation does not guarantee stable XSAVE presence bits,
either across repeated preparation or subsequent guest entry. Backend snapshots
retain the complete raw bitmap. The core layer projects only validated init
x87/SSE restoration metadata. The reproduced AMD failure and its contract are documented under
[Published XSAVE identity check](../vmm-core/README.md#published-xsave-identity-check). `save()`
retires an acknowledged write completion with the same guarded entry before it
reads and is otherwise a read; callers prepare a boundary explicitly after
restoring RAM and CPU state or servicing an exit. Pending CPU events remain present; a
staged write completion with no value left to supply is a different condition
and preparation consumes it as part of its own guarded entry, but a pending
read/MSR response awaiting an explicit value is not consumed and still fails
preparation closed. KVM restore retires an acknowledged write completion with
that guarded entry first and rejects pending read/MSR responses, unacknowledged
staged completions and queued completion exits before any CPU ioctl or state
mutation, since committing a stale exit's completion after restore would apply
it to the wrong instruction. A rejected restore leaves completion and interrupt
state intact. Raw backend save remains
available during exit servicing for CPUID resolution and tracing; it is not
itself a sealable snapshot boundary. Snapshot publication must enforce the
completion boundary at the VMM layer. KVM may refresh shared run-page output metadata.
The tentative supported execution requirement is a single host core type for all
related boots, forks, and restores. On hybrid Intel Linux hosts, launch the worker
under `taskset -c <pool>` or a cpuset containing only P-cores or only E-cores.
Choose the same pool type for every process participating in a snapshot lineage.
The backend validates the creating thread's affinity against Linux's
`cpu_core/cpus` and `cpu_atom/cpus` masks, rejecting mixed or uncovered masks
when exposed. It retains the exact admitted affinity and checks the calling
thread's current mask before guest entries, staged completion, CPU capture and
restore, policy installation, and dirty-page drain. A changed mask refuses
those operations before they mutate KVM state. It does not choose a pool or
change caller affinity. Preserve affinity for the backend lifetime and prevent
concurrent external changes. CPU topology is read at admission; CPU hotplug or
topology remapping requires stopping and requalifying the worker.
If both topology masks are unavailable but Intel's hybrid CPUID bit is set,
backend creation refuses the host. A namespace that hides these files on the
measured Core Ultra 9 285HX otherwise admitted the same divergent P-to-E
restore. Hosts that hide both topology and the hybrid CPUID indication,
including nested VMs, require operator qualification of the underlying
scheduling placement; absent signals do not prove homogeneity. Raw KVM CPU
snapshots carry the admitted P-core or E-core class, and restore refuses a
different or missing class before changing the vCPU.
Snapshot validation also rechecks the current thread affinity, including when
the VMM reuses a previously captured CPU record. The portable x86 VMM contract
binds the same class, so import into the other class is refused before restore.
On hosts without these topology masks or a hybrid CPUID indication the class
is unreported and no hardware homogeneity can be inferred. Compatibility
across different physical hosts, steppings, and feature sets still requires
separate qualification.

On the measured Core Ultra 9 285HX, six P-core captures restored on an E-core
were previously accepted but produced different guest-written XSAVE and RAM
after identical continuation. Same-class P-core controls matched. The class
guard refuses those cross-class restores rather than certifying their output.

On the measured Core Ultra 9 285HX, preparation on a P-core retained presence `2`,
while moving the same vCPU to an E-core changed it to `3` with no guest instruction.
Within each CPUID-verified core-type pool, 15,600 complete-state comparisons passed
across seeds `0`, `2`, and `3`, including repeated restores. Fixed-core guest XSAVE
and full-VMM continuation tests passed on both types. This supports the tentative
restriction; it is not a universal hardware or extended-state qualification.

## XSAVE entry differential

`snapshot_entry_restores_match_uninterrupted_execution` compares independently
prepared initial states, repeated capture, capture-and-continue, cold restore,
and restore into a vCPU dirtied by another continuation. It covers presence
seeds 0/2/3 and XCR0 3/7 with HLT, XSAVE, and XRSTOR-to-init followed by XSAVE.
Every endpoint comparison includes the complete modeled CPU state, raw restore
presence, RAM (including guest-written XSAVE bytes), and exit counts. A changed
RBX and nonzero XMM0 are the negative control; the XSAVE case must also distinguish
the guest output itself. `XSAVE_ENTRY_REPORT_DIR` must name a fresh directory;
raw KVM XSAVE images, state dumps, RAM, and each comparison result are retained.
The matrix continues through comparison failures to report all seed/mode cases.
It does not assume raw presence stays constant across actual guest execution.

The additional `snapshot_entry_debug_reentry_preserves_guest_observation`
diagnostic inserts a hardware execution breakpoint between guest XRSTOR-to-init
and XSAVE. It retains the stopped and resumed state and compares the complete
endpoint, including guest RAM, with uninterrupted execution. This intervention
is not yet qualified as equivalent to arbitrary host interruption. The hardware
check runs both this diagnostic and the entry/restore differential on one fixed
allowed CPU, alongside the original unrestricted differential, to distinguish
placement effects without replacing first-failure evidence.

The current same-core-type restriction is insufficient for every XSAVE sequence:
a fixed P-core debug-entry witness changes the guest-written header, and hosted
AMD reuse can change that header despite equal final modeled CPU state. Snapshot
consistency remains under investigation; preparation is not a proven universal
fixed point.

`XSAVE_ENTRY_LONG_MODE` selects a separate fixed-CPU control with identity-mapped
64-bit code and XSAVE64/XRSTOR64, matching the shipped Linux execution mode.
The original entry fixtures use real mode, so their failures alone do not
establish that the same instruction sequence diverges in 64-bit mode. Both
sets retain full CPU and RAM comparisons; the mode is recorded in CI evidence.

## Synthetic guest XSAVE canonicalization

The ignored Linux x86 test
`kvm_sys::xsave_diagnostic::canonical::snapshot_guest_canonicalization_preserves_complete_endpoints`
executes `xsave_canonical_guest.S` in long mode with XCR0=7. It requires AVX and
XSAVEC support and a fresh `XSAVE_CANONICAL_REPORT_DIR`; set
`XSAVE_ENTRY_LONG_MODE=1`, and run on one fixed
CPU. This is a test fixture, not a kernel or admission-policy change.

`snapshot_canonical_entry_restores_match_uninterrupted_execution` also applies
the same canonicalizer after the raw entry fixture's XSAVE, preserving its
capture, poison, cold restore and reused restore sequence. It covers XCR0=3/7,
each raw seed and both XSAVE-only and XRSTOR-then-XSAVE programs, with and without
prefaulting in required CI. It uses `XSAVE_ENTRY_REPORT_DIR` and long mode. Full
RAM, CPU state and exit counts remain byte-exact; a separate RAM poison keeps
the negative control observable after the canonicalizer clears scratch GPRs.
The original unmodified raw-entry diagnostic remains a distinct control.

Every execution first fills all 832 owned save bytes with a nonzero pattern,
then resets registers and selects init, SSE-active, AVX-active, or MXCSR-only
state. Standard XSAVE64 and compacted XSAVEC64 each have a raw control and a
guest canonicalizer. The canonicalizer materializes absent component init data,
clears presence for init payloads, fixes owned reserved/padding bytes, and records
an explicit format header. MXCSR is saved separately with STMXCSR: SSE presence
cannot determine its value, and compacted init saves may leave its slot unwritten.
Only the three enabled components are supported; for this fixed mask the AVX
payload offset is 576 in both layouts.

Both full-memory cold/reused restores and hardware-breakpoint interventions
compare complete RAM and modeled state only at the final HLT. Interventions
before save, after save, and inside canonicalization are not snapshot comparison
points. A register-value poison must change guest RAM, and every canonical
reference buffer is checked against an independently constructed expected image.
Raw controls report their RAM divergence count without requiring Intel hosts to
reproduce AMD tracking behavior. A zero raw count is not a reproduced negative
control on that host. Reports retain endpoint RAM, modeled state, raw
KVM_GET_XSAVE2, expected images, guest bytes, and breakpoint offsets. Broader host
qualification remains separate from this synthetic test.

The `XSAVE_ENTRY_PREFAULT=1` control populates the entire fixture RAM through
`KVM_PRE_FAULT_MEMORY` after vCPU configuration and host writes that
materialize every RAM page (avoiding shared zero-page CoW), without executing guest
instructions. This full-RAM oracle disables dirty logging before mapping in
prefault mode, because write-protected dirty-log mappings still fault on the
first XSAVE write. Production memory policy and the original control remain
unchanged. It retries partial progress and interruptions. Missing capability
or unsupported vCPU mode fails explicitly with `XSAVE_PREFAULT_UNSUPPORTED`;
that result does not qualify the fixture. Leaving the variable unset preserves
the unfaulted control. The ioctl creates stage-2 read mappings and does not break CoW or set accessed bits, so the
paired endpoint results must establish whether the XSAVE write fault disappeared;
successful prefault completion alone does not establish that result. Bounded CI
retains the single-cohort result and all restore/debug-entry prefault cohorts.

The non-default `xsave-diagnostics` feature exposes a one-shot hardware
execution breakpoint for native guest-kernel tests. KVM verifies the debug
exit RIP, disables debug controls, and resumes through ordinary entry handling.
The debug exit remains outside modeled exit counts and virtual time; an
unexpected debug exit fails. The diagnostic stores hit addresses only on the
host and does not rewrite guest registers or RAM. Default builds omit this
interface and dispatch branch.

Host standard-XSAVE normalization treats MXCSR separately from XMM registers:
Linux's KVM UABI materializes MXCSR when either SSE or YMM is present. With
SSE absent and YMM present, XMM bytes normalize to init while nondefault MXCSR
is preserved. The original restore bitmap remains separately bound. This does
not assert that raw guest XSAVE buffers with both bits absent are returned
unchanged by the host UABI.

KVM rejects a YMM-present/SSE-absent image with non-init MXCSR when publishing
a snapshot or before restoring the vCPU. Ordinary register reads and guest
execution remain available. A host using compacted restore can retain
MXCSR=0x3f80 in its KVM UABI buffer while guest entry
initializes live MXCSR to 0x1f80. A host using standard XRSTOR may restore that
state locally, but the snapshot would not be portable to a compacted host. The
ignored `ymm_without_sse_noninit_mxcsr_restore_rejects_atomically` regression checks
that admission boundary on a live KVM vCPU. It requires AVX. Images with init
MXCSR or SSE presence remain admissible.

`natural_avx_mxcsr_survives_capture_and_restore` requires long mode. The guest
sets nonzero YMM upper lanes with zero XMM lanes, loads MXCSR=0x3f80, and stops
at completed port I/O before capture. Both continued and cold-restored STMXCSR
results must equal 0x3f80. The observed raw presence bitmap is retained rather
than asserted to exclude SSE on every host.

The rejected imported-case observation is consistent with a compacted host restore:
[Intel SDM volume 1, sections 13.8.2, 13.11 and 13.12](https://cdrdv2-public.intel.com/868137/325462-089-sdm-vol-1-2abcd-3abcd-4.pdf)
specifies that compacted restore initializes MXCSR when SSE presence is clear,
while standard XRSTOR loads it when YMM is requested even if SSE presence is
clear.
Compacted save includes SSE presence for nondefault MXCSR. On ms02, host boot
metadata confirms compacted FPU format; the natural test reports presence 6.
The imported presence-4 case therefore does not establish naturally occurring
register-value corruption. The precise host restore instruction was not traced.

Snapshot preparation coverage compares CPU state excluding only raw presence,
RAM, exit counts, readiness, pending events, and CR8 after each preparation.
Raw transitions are printed explicitly, and the preparation and restore guard
regressions retain their failure evidence. Production preparation is unchanged.

The canonical entry fixture requires exact equality at completed guest HLT
endpoints. Before the first instruction, exact identity comparisons are recorded
as diagnostics; setup still requires identical RAM, canonical CPU data, exit
counts and raw XSAVE bytes except x87/SSE presence bits whose canonical component
is init-valued. Active-component differences remain failures. Repeated capture
purity remains required. The XSAVE negative checks changed XMM output; the
XRSTOR negative supplies non-init MXCSR and checks the guest's saved MXCSR value,
without relying on an unrelated RAM mutation. This fixture distinction does not
change production snapshot identity or restore semantics.

The x86 raw ioctl adapters infer the libc request type so the same 32-bit KVM
request encodings compile under both glibc (unsigned long) and musl (int). This
allows the production backend to be linked into the static inner driver.

Nested capture canonicalizes inactive VMCS12 exit interrupt information. Linux
VMCS12 revision `0x11e57ed0` fixes this field at byte 816 of the VMCS payload.
When its valid bit is clear, the vector/type and error-code bytes have no active
architectural meaning and can retain a physical host interrupt vector. Capture
zeros that inactive information, and zeros an error code when its delivery bit
is clear. Valid interrupt information and all other payload bytes are preserved.
The revision and field bounds are checked before mutation; an unknown layout
fails capture. Snapshots, hashes and portable exports retain the complete
canonical payload. Dirty-log reprotection still reloads the unchanged raw
current payload. Portable tests cover inactive/valid cases, preservation of the
remaining bytes, and rejection without mutation, including under Miri.

// SPDX-License-Identifier: AGPL-3.0-or-later

use std::collections::BTreeMap;

use sha2::{Digest, Sha256};
use vmm_backend::{Backend, ExitReason};
use vtime::{IdlePlanner, TimerQueue, TimerToken, VClock, VClockConfig};

pub const PLACEHOLDER_INTERRUPT_CONTROLLER_MMIO_VNS: u64 = 1;

pub const PLACEHOLDER_SERIAL_MMIO_VNS: u64 = 1;

pub const PLACEHOLDER_PARAVIRTUAL_DEVICE_MMIO_VNS: u64 = 1;

pub const PLACEHOLDER_TRAPPED_TIME_READ_VNS: u64 = 1;

pub const PLACEHOLDER_ARCHITECTURAL_CONTROL_VNS: u64 = 1;

pub const PLACEHOLDER_EXECUTION_TICK_VNS: u64 = 1;

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum DeviceClass {
    InterruptController,
    Serial,
    Paravirtual,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct VirtualTimeTiming {
    pub interrupt_controller_mmio_vns: u64,
    pub serial_mmio_vns: u64,
    pub paravirtual_device_mmio_vns: u64,
    pub trapped_time_read_vns: u64,
    pub architectural_control_vns: u64,
    pub execution_tick_vns: u64,
}

impl Default for VirtualTimeTiming {
    fn default() -> Self {
        Self {
            interrupt_controller_mmio_vns: PLACEHOLDER_INTERRUPT_CONTROLLER_MMIO_VNS,
            serial_mmio_vns: PLACEHOLDER_SERIAL_MMIO_VNS,
            paravirtual_device_mmio_vns: PLACEHOLDER_PARAVIRTUAL_DEVICE_MMIO_VNS,
            trapped_time_read_vns: PLACEHOLDER_TRAPPED_TIME_READ_VNS,
            architectural_control_vns: PLACEHOLDER_ARCHITECTURAL_CONTROL_VNS,
            execution_tick_vns: PLACEHOLDER_EXECUTION_TICK_VNS,
        }
    }
}

impl VirtualTimeTiming {
    pub(crate) fn mmio_vns(self, class: DeviceClass) -> u64 {
        match class {
            DeviceClass::InterruptController => self.interrupt_controller_mmio_vns,
            DeviceClass::Serial => self.serial_mmio_vns,
            DeviceClass::Paravirtual => self.paravirtual_device_mmio_vns,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum NormalizedEventClass {
    Doorbell,
    DeviceMmio(DeviceClass),
    TimeRead,
    ArchitecturalControl,
    InterruptDelivery,
    Idle,
    Terminal,
}

impl NormalizedEventClass {
    pub fn label(self) -> &'static str {
        match self {
            Self::Doorbell => "doorbell",
            Self::DeviceMmio(DeviceClass::InterruptController) => "ic_mmio",
            Self::DeviceMmio(DeviceClass::Serial) => "serial_mmio",
            Self::DeviceMmio(DeviceClass::Paravirtual) => "pv_mmio",
            Self::TimeRead => "time_read",
            Self::ArchitecturalControl => "arch_control",
            Self::InterruptDelivery => "irq_delivery",
            Self::Idle => "idle",
            Self::Terminal => "terminal",
        }
    }

    fn tag(self) -> u8 {
        match self {
            Self::Doorbell => 0,
            Self::DeviceMmio(DeviceClass::InterruptController) => 1,
            Self::DeviceMmio(DeviceClass::Serial) => 2,
            Self::DeviceMmio(DeviceClass::Paravirtual) => 3,
            Self::TimeRead => 4,
            Self::Idle => 5,
            Self::Terminal => 6,
            Self::ArchitecturalControl => 7,
            Self::InterruptDelivery => 8,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum AdvanceRule {
    Doorbell(u64),
    DeviceMmio(DeviceClass),
    TimeRead,
    ArchitecturalControl,
    Idle,
    None,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ClassifiedExit {
    class: NormalizedEventClass,
    payload: Vec<u8>,
    advance: AdvanceRule,
    terminal: bool,
}

impl ClassifiedExit {
    pub fn doorbell(payload: Vec<u8>, duration_vns: u64) -> Self {
        Self {
            class: NormalizedEventClass::Doorbell,
            payload,
            advance: AdvanceRule::Doorbell(duration_vns),
            terminal: false,
        }
    }

    pub fn device_mmio(class: DeviceClass, payload: Vec<u8>) -> Self {
        Self {
            class: NormalizedEventClass::DeviceMmio(class),
            payload,
            advance: AdvanceRule::DeviceMmio(class),
            terminal: false,
        }
    }

    pub fn time_read(payload: Vec<u8>) -> Self {
        Self {
            class: NormalizedEventClass::TimeRead,
            payload,
            advance: AdvanceRule::TimeRead,
            terminal: false,
        }
    }

    pub fn architectural_control(payload: Vec<u8>) -> Self {
        Self {
            class: NormalizedEventClass::ArchitecturalControl,
            payload,
            advance: AdvanceRule::ArchitecturalControl,
            terminal: false,
        }
    }

    pub fn idle(payload: Vec<u8>) -> Self {
        Self {
            class: NormalizedEventClass::Idle,
            payload,
            advance: AdvanceRule::Idle,
            terminal: false,
        }
    }

    pub fn terminal(payload: Vec<u8>) -> Self {
        Self {
            class: NormalizedEventClass::Terminal,
            payload,
            advance: AdvanceRule::None,
            terminal: true,
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ScheduledInterrupt {
    pub deadline_vns: u64,
    pub schedule_index: u64,
    pub armed_for_event: u64,
    pub canceled_at_event: Option<u64>,
    pub interrupt_id: u32,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct InterruptDelivery {
    pub deadline_vns: u64,
    pub schedule_index: u64,
    pub interrupt_id: u32,
}

impl From<ScheduledInterrupt> for InterruptDelivery {
    fn from(value: ScheduledInterrupt) -> Self {
        Self {
            deadline_vns: value.deadline_vns,
            schedule_index: value.schedule_index,
            interrupt_id: value.interrupt_id,
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct RawEvent {
    pub event_index: u64,
    pub portable_event_index: Option<u64>,
    pub reason: ExitReason,
    pub backend_debug: String,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct NormalizedEvent {
    pub event_index: u64,
    pub class: NormalizedEventClass,
    pub payload_digest: [u8; 32],
    pub vns_after: u64,
    pub interrupts: Vec<InterruptDelivery>,
    pub state_hash: Option<[u8; 32]>,
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct NormalizedLog {
    pub events: Vec<NormalizedEvent>,
}

#[derive(Clone, Debug)]
struct PendingLiveEvent {
    raw: RawEvent,
    class: NormalizedEventClass,
    payload: Vec<u8>,
    service: Option<(u64, [u8; 32])>,
    completion: Option<Vec<u8>>,
}

#[derive(Clone, Debug, Default)]
pub struct LiveVirtualTimeTrace {
    history: control_proto::EventHistory,
    raw: Vec<RawEvent>,
    normalized: NormalizedLog,
    schedule: Vec<ScheduledInterrupt>,
    next_schedule_index: u64,
    active_clockevent_schedule: Option<u64>,
    pending: Option<PendingLiveEvent>,
    raw_event_active: bool,
    current_interrupts: Vec<InterruptDelivery>,
}

impl LiveVirtualTimeTrace {
    pub fn event_history(&self) -> control_proto::EventHistory {
        self.history
    }

    pub(crate) fn restore_event_history(&mut self, history: control_proto::EventHistory) {
        self.history = history;
    }

    pub(crate) fn retire(&mut self) -> Self {
        let history = self.history;
        let retired = std::mem::take(self);
        self.history = history;
        retired
    }

    pub fn raw_log(&self) -> &[RawEvent] {
        &self.raw
    }

    pub fn normalized_log(&self) -> &NormalizedLog {
        &self.normalized
    }

    pub fn schedule(&self) -> &[ScheduledInterrupt] {
        &self.schedule
    }

    pub fn normalized_digest(&self) -> [u8; 32] {
        let mut h = Sha256::new();
        h.update(b"consonance.live-prescriptive-log.v1\0");
        h.update(
            u64::try_from(self.normalized.events.len())
                .unwrap_or(u64::MAX)
                .to_le_bytes(),
        );
        for event in &self.normalized.events {
            h.update(event.event_index.to_le_bytes());
            h.update([event.class.tag()]);
            h.update(event.payload_digest);
            h.update(event.vns_after.to_le_bytes());
            h.update(
                u64::try_from(event.interrupts.len())
                    .unwrap_or(u64::MAX)
                    .to_le_bytes(),
            );
            for delivery in &event.interrupts {
                h.update(delivery.deadline_vns.to_le_bytes());
                h.update(delivery.schedule_index.to_le_bytes());
                h.update(delivery.interrupt_id.to_le_bytes());
            }
            match event.state_hash {
                Some(hash) => {
                    h.update([1]);
                    h.update(hash);
                }
                None => h.update([0]),
            }
        }
        h.update(
            u64::try_from(self.schedule.len())
                .unwrap_or(u64::MAX)
                .to_le_bytes(),
        );
        for scheduled in &self.schedule {
            h.update(scheduled.deadline_vns.to_le_bytes());
            h.update(scheduled.schedule_index.to_le_bytes());
            h.update(scheduled.armed_for_event.to_le_bytes());
            match scheduled.canceled_at_event {
                Some(event) => {
                    h.update([1]);
                    h.update(event.to_le_bytes());
                }
                None => h.update([0]),
            }
            h.update(scheduled.interrupt_id.to_le_bytes());
        }
        h.finalize().into()
    }

    pub(crate) fn begin(
        &mut self,
        reason: ExitReason,
        backend_debug: String,
        class: NormalizedEventClass,
        payload: Vec<u8>,
    ) -> Result<(), &'static str> {
        if self.pending.is_some() || self.raw_event_active {
            return Err("virtual_time trace began a second event before finishing the first");
        }
        let event_index = u64::try_from(self.raw.len()).unwrap_or(u64::MAX);
        self.pending = Some(PendingLiveEvent {
            raw: RawEvent {
                event_index,
                portable_event_index: Some(
                    u64::try_from(self.normalized.events.len()).unwrap_or(u64::MAX),
                ),
                reason,
                backend_debug,
            },
            class,
            payload,
            service: None,
            completion: None,
        });
        self.current_interrupts.clear();
        Ok(())
    }

    pub(crate) fn current_event_index(&self) -> Result<u64, &'static str> {
        self.pending
            .as_ref()
            .map(|_| u64::try_from(self.normalized.events.len()).unwrap_or(u64::MAX))
            .ok_or("virtual_time trace operation outside an active event")
    }

    pub(crate) fn record_raw_only(
        &mut self,
        reason: ExitReason,
        backend_debug: String,
    ) -> Result<(), &'static str> {
        if self.pending.is_some() || self.raw_event_active {
            return Err("virtual_time trace recorded a raw-only exit during an active event");
        }
        self.raw.push(RawEvent {
            event_index: u64::try_from(self.raw.len()).unwrap_or(u64::MAX),
            portable_event_index: None,
            reason,
            backend_debug,
        });
        Ok(())
    }

    pub(crate) fn begin_raw(
        &mut self,
        reason: ExitReason,
        backend_debug: String,
    ) -> Result<(), &'static str> {
        self.record_raw_only(reason, backend_debug)?;
        self.raw_event_active = true;
        Ok(())
    }

    pub(crate) fn normalized_event_pending(&self) -> bool {
        self.pending.is_some()
    }

    pub(crate) fn finish_raw(&mut self) -> Result<(), &'static str> {
        if !self.raw_event_active || self.pending.is_some() || !self.current_interrupts.is_empty() {
            return Err("virtual_time raw event completion has inconsistent pending state");
        }
        self.raw_event_active = false;
        Ok(())
    }

    pub(crate) fn schedule_clockevent(
        &mut self,
        deadline_vns: u64,
        interrupt_id: u32,
    ) -> Result<(), &'static str> {
        let event = self.current_event_index()?;
        self.cancel_clockevent_at(event)?;
        let schedule_index = self.next_schedule_index;
        self.next_schedule_index = self
            .next_schedule_index
            .checked_add(1)
            .ok_or("virtual_time clockevent schedule index exhausted")?;
        self.schedule.push(ScheduledInterrupt {
            deadline_vns,
            schedule_index,
            armed_for_event: event,
            canceled_at_event: None,
            interrupt_id,
        });
        self.active_clockevent_schedule = Some(schedule_index);
        Ok(())
    }

    pub(crate) fn preflight_restore_clockevent_schedule(
        &self,
        restored_schedule: bool,
    ) -> Result<(), &'static str> {
        if self.pending.is_some() || self.raw_event_active {
            return Err("virtual_time trace restore occurred during an active event");
        }
        if let Some(schedule_index) = self.active_clockevent_schedule {
            let scheduled = self
                .schedule
                .iter()
                .find(|scheduled| scheduled.schedule_index == schedule_index)
                .ok_or("active virtual_time clockevent schedule record is missing")?;
            if scheduled.canceled_at_event.is_some() {
                return Err("active virtual_time clockevent schedule was already canceled");
            }
        }
        if restored_schedule {
            self.next_schedule_index
                .checked_add(1)
                .ok_or("virtual_time restored schedule index exhausted")?;
        }
        Ok(())
    }

    pub(crate) fn restore_clockevent_schedule(
        &mut self,
        restored: Option<(u64, u32)>,
    ) -> Result<(), &'static str> {
        self.preflight_restore_clockevent_schedule(restored.is_some())?;
        let event = u64::try_from(self.normalized.events.len()).unwrap_or(u64::MAX);
        self.cancel_clockevent_at(event)?;
        let Some((deadline_vns, interrupt_id)) = restored else {
            return Ok(());
        };
        let schedule_index = self.next_schedule_index;
        self.next_schedule_index = self
            .next_schedule_index
            .checked_add(1)
            .ok_or("virtual_time restored schedule index exhausted")?;
        self.schedule.push(ScheduledInterrupt {
            deadline_vns,
            schedule_index,
            armed_for_event: event,
            canceled_at_event: None,
            interrupt_id,
        });
        self.active_clockevent_schedule = Some(schedule_index);
        Ok(())
    }

    pub(crate) fn cancel_clockevent(&mut self) -> Result<(), &'static str> {
        let event = self.current_event_index()?;
        self.cancel_clockevent_at(event)
    }

    pub(crate) fn defer_clockevent(&mut self) -> Result<(), &'static str> {
        if self.pending.is_none() {
            return Ok(());
        }
        let event = self.current_event_index()?;
        let active = self
            .active_clockevent_schedule
            .ok_or("clockevent deferral has no active virtual_time schedule")?;
        let position = self
            .schedule
            .iter()
            .position(|scheduled| scheduled.schedule_index == active)
            .ok_or("deferred virtual_time clockevent schedule record is missing")?;
        let prior = self.schedule[position];
        if prior.canceled_at_event.is_some() {
            return Err("active virtual_time clockevent schedule was already canceled");
        }
        let armed_for_event = event
            .checked_add(1)
            .ok_or("virtual_time clockevent deferral event exhausted")?;
        let schedule_index = self.next_schedule_index;
        self.next_schedule_index = self
            .next_schedule_index
            .checked_add(1)
            .ok_or("virtual_time clockevent schedule index exhausted")?;
        self.schedule[position].canceled_at_event = Some(event);
        self.schedule.push(ScheduledInterrupt {
            deadline_vns: prior.deadline_vns,
            schedule_index,
            armed_for_event,
            canceled_at_event: None,
            interrupt_id: prior.interrupt_id,
        });
        self.active_clockevent_schedule = Some(schedule_index);
        Ok(())
    }

    fn cancel_clockevent_at(&mut self, event: u64) -> Result<(), &'static str> {
        let Some(schedule_index) = self.active_clockevent_schedule.take() else {
            return Ok(());
        };
        let scheduled = self
            .schedule
            .iter_mut()
            .find(|scheduled| scheduled.schedule_index == schedule_index)
            .ok_or("active virtual_time clockevent schedule record is missing")?;
        if scheduled.canceled_at_event.is_some() {
            return Err("active virtual_time clockevent schedule was already canceled");
        }
        scheduled.canceled_at_event = Some(event);
        Ok(())
    }

    pub(crate) fn deliver_clockevent(&mut self) -> Result<(), &'static str> {
        if self.pending.is_none() && !self.raw_event_active {
            return Err("clockevent delivery has no active normalized event");
        }
        let schedule_index = self
            .active_clockevent_schedule
            .ok_or("clockevent delivery has no active virtual_time schedule")?;
        let scheduled = *self
            .schedule
            .iter()
            .find(|scheduled| scheduled.schedule_index == schedule_index)
            .ok_or("delivered virtual_time clockevent schedule record is missing")?;
        if scheduled.canceled_at_event.is_some() {
            return Err("canceled virtual_time clockevent was delivered");
        }
        if self.pending.is_none() {
            let mut raw = self
                .raw
                .pop()
                .ok_or("interrupt delivery raw event is missing")?;
            raw.portable_event_index = Some(
                u64::try_from(self.normalized.events.len())
                    .map_err(|_| "normalized event index exhausted")?,
            );
            self.pending = Some(PendingLiveEvent {
                raw,
                class: NormalizedEventClass::InterruptDelivery,
                payload: Vec::new(),
                service: None,
                completion: None,
            });
        }
        self.active_clockevent_schedule = None;
        self.current_interrupts.push(scheduled.into());
        Ok(())
    }

    pub(crate) fn record_completion(&mut self, result: &[u8]) -> Result<(), &'static str> {
        let Some(pending) = self.pending.as_mut() else {
            return Ok(());
        };
        if pending.completion.is_some() {
            return Err("duplicate guest completion for normalized event");
        }
        pending.completion = Some(result.to_vec());
        Ok(())
    }

    pub(crate) fn preflight_service_completion(&self) -> Result<(), &'static str> {
        let records = match &self.pending {
            Some(pending)
                if pending.class == NormalizedEventClass::Doorbell && pending.service.is_none() =>
            {
                2
            }
            Some(_) => return Err("service completion has inconsistent active event"),
            None if self.raw_event_active => {
                return Err("service completion during raw-only event");
            }
            None => 1,
        };
        self.history
            .count
            .checked_add(records)
            .ok_or("event history count overflow")?;
        Ok(())
    }

    pub(crate) fn complete_service(
        &mut self,
        moment: u64,
        exchange: [u8; 32],
    ) -> Result<(), &'static str> {
        self.preflight_service_completion()?;
        if let Some(pending) = self.pending.as_mut() {
            pending.service = Some((moment, exchange));
        } else {
            self.append_service(moment, exchange)?;
        }
        Ok(())
    }

    fn append_service(&mut self, moment: u64, exchange: [u8; 32]) -> Result<(), &'static str> {
        let count = self
            .history
            .count
            .checked_add(1)
            .ok_or("event history count overflow")?;
        let mut digest = Sha256::new();
        digest.update(b"consonance.ordered-event-history.v3\0");
        digest.update(self.history.digest);
        digest.update(count.to_le_bytes());
        digest.update([1]);
        digest.update(moment.to_le_bytes());
        digest.update(exchange);
        self.history = control_proto::EventHistory {
            count,
            digest: digest.finalize().into(),
        };
        Ok(())
    }

    pub(crate) fn finish(
        &mut self,
        vns_after: u64,
        state_hash: Option<[u8; 32]>,
    ) -> Result<(), &'static str> {
        let records = 1 + u64::from(
            self.pending
                .as_ref()
                .is_some_and(|pending| pending.service.is_some()),
        );
        self.history
            .count
            .checked_add(records)
            .ok_or("event history count overflow")?;
        let pending = self
            .pending
            .take()
            .ok_or("virtual_time trace finished with no active event")?;
        let service = pending.service;
        self.raw_event_active = false;
        self.raw.push(pending.raw);
        let event = NormalizedEvent {
            event_index: u64::try_from(self.normalized.events.len()).unwrap_or(u64::MAX),
            class: pending.class,
            payload_digest: digest_completed_payload(
                pending.class,
                &pending.payload,
                pending.completion.as_deref(),
            ),
            vns_after,
            interrupts: std::mem::take(&mut self.current_interrupts),
            state_hash,
        };
        let count = self
            .history
            .count
            .checked_add(1)
            .ok_or("event history count overflow")?;
        let mut digest = Sha256::new();
        digest.update(b"consonance.ordered-event-history.v3\0");
        digest.update(self.history.digest);
        digest.update(count.to_le_bytes());
        digest.update([0]);
        digest.update([event.class.tag()]);
        digest.update(event.payload_digest);
        digest.update(event.vns_after.to_le_bytes());
        digest.update((event.interrupts.len() as u64).to_le_bytes());
        for delivery in &event.interrupts {
            digest.update(delivery.deadline_vns.to_le_bytes());
            digest.update(delivery.interrupt_id.to_le_bytes());
        }
        self.history = control_proto::EventHistory {
            count,
            digest: digest.finalize().into(),
        };
        self.normalized.events.push(event);
        if let Some((moment, exchange)) = service {
            self.append_service(moment, exchange)?;
        }
        Ok(())
    }

    pub(crate) fn checkpoint_last(&mut self, state_hash: [u8; 32]) -> Result<(), &'static str> {
        let last = self
            .normalized
            .events
            .last_mut()
            .ok_or("cannot checkpoint an empty virtual_time trace")?;
        last.state_hash = Some(state_hash);
        Ok(())
    }

    pub(crate) fn checkpoint_at(
        &mut self,
        event_index: u64,
        state_hash: [u8; 32],
    ) -> Result<(), &'static str> {
        let index = usize::try_from(event_index)
            .map_err(|_| "deferred virtual_time checkpoint index does not fit usize")?;
        let event = self
            .normalized
            .events
            .get_mut(index)
            .ok_or("deferred virtual_time checkpoint event does not exist")?;
        if event.event_index != event_index {
            return Err("deferred virtual_time checkpoint ordinal mismatch");
        }
        if event.state_hash.is_some() {
            return Err("deferred virtual_time checkpoint would overwrite an existing hash");
        }
        event.state_hash = Some(state_hash);
        Ok(())
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct VirtualTimeCheckpoint {
    pub vns: u64,
    pub pending_interrupts: u64,
    pub event_index: u64,
}

#[derive(Debug, thiserror::Error)]
pub enum VirtualTimeError {
    #[error(transparent)]
    Backend(#[from] vmm_backend::BackendError),
    #[error(transparent)]
    Clock(#[from] vtime::VtimeError),
    #[error("checkpoint interval must be at least one event")]
    ZeroCheckpointInterval,
    #[error("idle exit has no scheduled interrupt deadline")]
    IdleWithoutDeadline,
    #[error("{counter} index exhausted")]
    IndexExhausted { counter: &'static str },
    #[error("cannot run after a terminal event")]
    AlreadyTerminal,
    #[error("timer queue returned unknown token {token}")]
    UnknownTimerToken { token: u64 },
    #[error("exit classification failed: {0}")]
    Classification(String),
}

pub struct VirtualTimeRunLoop<B: Backend> {
    backend: B,
    timing: VirtualTimeTiming,
    clock: VClock,
    idle: IdlePlanner,
    timers: TimerQueue,
    pending: BTreeMap<TimerToken, ScheduledInterrupt>,
    schedule: Vec<ScheduledInterrupt>,
    raw: Vec<RawEvent>,
    normalized: NormalizedLog,
    checkpoint_every: u64,
    next_event_index: u64,
    next_schedule_index: u64,
    terminal: bool,
}

impl<B: Backend> VirtualTimeRunLoop<B> {
    pub fn new(
        backend: B,
        clock_config: VClockConfig,
        timing: VirtualTimeTiming,
        checkpoint_every: u64,
    ) -> Result<Self, VirtualTimeError> {
        if checkpoint_every == 0 {
            return Err(VirtualTimeError::ZeroCheckpointInterval);
        }
        Ok(Self {
            backend,
            timing,
            clock: VClock::new(clock_config)?,
            idle: IdlePlanner::new(),
            timers: TimerQueue::new(),
            pending: BTreeMap::new(),
            schedule: Vec::new(),
            raw: Vec::new(),
            normalized: NormalizedLog::default(),
            checkpoint_every,
            next_event_index: 0,
            next_schedule_index: 0,
            terminal: false,
        })
    }

    pub fn vns(&self) -> u64 {
        self.clock.vns()
    }

    pub fn backend(&self) -> &B {
        &self.backend
    }

    pub fn raw_log(&self) -> &[RawEvent] {
        &self.raw
    }

    pub fn normalized_log(&self) -> &NormalizedLog {
        &self.normalized
    }

    pub fn schedule(&self) -> &[ScheduledInterrupt] {
        &self.schedule
    }

    pub fn schedule_interrupt(
        &mut self,
        deadline_vns: u64,
        interrupt_id: u32,
    ) -> Result<ScheduledInterrupt, VirtualTimeError> {
        let schedule_index = self.next_schedule_index;
        self.next_schedule_index =
            self.next_schedule_index
                .checked_add(1)
                .ok_or(VirtualTimeError::IndexExhausted {
                    counter: "schedule",
                })?;
        let scheduled = ScheduledInterrupt {
            deadline_vns,
            schedule_index,
            armed_for_event: self.next_event_index,
            canceled_at_event: None,
            interrupt_id,
        };
        let token = TimerToken(schedule_index);
        self.timers.schedule_oneshot(deadline_vns, token);
        self.pending.insert(token, scheduled);
        self.schedule.push(scheduled);
        Ok(scheduled)
    }

    pub fn run_backend_once<C, D, H>(
        &mut self,
        classify: C,
        mut deliver: D,
        hash: H,
    ) -> Result<&NormalizedEvent, VirtualTimeError>
    where
        C: FnOnce(&mut B, &vmm_backend::Exit<B::A>) -> Result<ClassifiedExit, VirtualTimeError>,
        D: FnMut(&mut B, InterruptDelivery) -> Result<(), VirtualTimeError>,
        H: FnOnce(&mut B, VirtualTimeCheckpoint) -> [u8; 32],
        B::A: std::fmt::Debug,
    {
        if self.terminal {
            return Err(VirtualTimeError::AlreadyTerminal);
        }
        let exit = self.backend.run()?;
        let reason = exit.reason();
        let backend_debug = format!("{exit:?}");
        let classified = classify(&mut self.backend, &exit)?;
        self.record(reason, backend_debug, classified, &mut deliver, hash)
    }

    fn record<D, H>(
        &mut self,
        reason: ExitReason,
        backend_debug: String,
        classified: ClassifiedExit,
        deliver: &mut D,
        hash: H,
    ) -> Result<&NormalizedEvent, VirtualTimeError>
    where
        D: FnMut(&mut B, InterruptDelivery) -> Result<(), VirtualTimeError>,
        H: FnOnce(&mut B, VirtualTimeCheckpoint) -> [u8; 32],
    {
        let event_index = self.next_event_index;
        self.next_event_index = self
            .next_event_index
            .checked_add(1)
            .ok_or(VirtualTimeError::IndexExhausted { counter: "event" })?;

        let now = self.vns();
        let advance_vns = match classified.advance {
            AdvanceRule::Doorbell(duration_vns) => duration_vns,
            AdvanceRule::DeviceMmio(class) => self.timing.mmio_vns(class),
            AdvanceRule::TimeRead => self.timing.trapped_time_read_vns,
            AdvanceRule::ArchitecturalControl => self.timing.architectural_control_vns,
            AdvanceRule::Idle => {
                let (deadline, _) = self
                    .timers
                    .peek_next()
                    .ok_or(VirtualTimeError::IdleWithoutDeadline)?;
                self.idle.plan(now, deadline).advance_vns
            }
            AdvanceRule::None => 0,
        };
        self.clock.advance(advance_vns);
        let vns_after = self.vns();

        let mut interrupts = Vec::new();
        for (_, token) in self.timers.pop_due(vns_after) {
            let scheduled = self
                .pending
                .remove(&token)
                .ok_or(VirtualTimeError::UnknownTimerToken { token: token.0 })?;
            let delivery = scheduled.into();
            deliver(&mut self.backend, delivery)?;
            interrupts.push(delivery);
        }

        let checkpoint_due = (event_index + 1).is_multiple_of(self.checkpoint_every);
        let checkpoint = VirtualTimeCheckpoint {
            vns: vns_after,
            pending_interrupts: u64::try_from(self.pending.len()).unwrap_or(u64::MAX),
            event_index,
        };
        let state_hash =
            (checkpoint_due || classified.terminal).then(|| hash(&mut self.backend, checkpoint));

        self.raw.push(RawEvent {
            event_index,
            portable_event_index: Some(event_index),
            reason,
            backend_debug,
        });
        self.normalized.events.push(NormalizedEvent {
            event_index,
            class: classified.class,
            payload_digest: digest_payload(classified.class, &classified.payload),
            vns_after,
            interrupts,
            state_hash,
        });
        self.terminal = classified.terminal;
        self.normalized
            .events
            .last()
            .ok_or(VirtualTimeError::Classification(
                "normalized event append produced no event".to_string(),
            ))
    }
}

fn digest_completed_payload(
    class: NormalizedEventClass,
    request: &[u8],
    completion: Option<&[u8]>,
) -> [u8; 32] {
    let request = digest_payload(class, request);
    let Some(completion) = completion else {
        return request;
    };
    let mut digest = Sha256::new();
    digest.update(b"consonance.completed-event.v1\0");
    digest.update(request);
    digest.update((completion.len() as u64).to_le_bytes());
    digest.update(completion);
    digest.finalize().into()
}

pub(crate) fn digest_payload(class: NormalizedEventClass, payload: &[u8]) -> [u8; 32] {
    let mut hasher = Sha256::new();
    hasher.update(b"consonance.prescriptive-event.v1\0");
    hasher.update([class.tag()]);
    hasher.update(
        u64::try_from(payload.len())
            .unwrap_or(u64::MAX)
            .to_le_bytes(),
    );
    hasher.update(payload);
    hasher.finalize().into()
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum LogField {
    Length,
    EventIndex,
    Class,
    PayloadDigest,
    VnsAfter,
    Interrupts,
    StateHash,
}

#[derive(Clone, Debug, PartialEq, Eq, thiserror::Error)]
#[error("normalized logs diverged at event {event_index} in {field:?}")]
pub struct LogDivergence {
    pub event_index: u64,
    pub field: LogField,
}

pub fn compare_normalized_logs(
    left: &NormalizedLog,
    right: &NormalizedLog,
) -> Result<(), LogDivergence> {
    for (offset, (a, b)) in left.events.iter().zip(&right.events).enumerate() {
        let event_index = u64::try_from(offset).unwrap_or(u64::MAX);
        let field = if a.event_index != b.event_index {
            Some(LogField::EventIndex)
        } else if a.class != b.class {
            Some(LogField::Class)
        } else if a.payload_digest != b.payload_digest {
            Some(LogField::PayloadDigest)
        } else if a.vns_after != b.vns_after {
            Some(LogField::VnsAfter)
        } else if a.interrupts != b.interrupts {
            Some(LogField::Interrupts)
        } else if a.state_hash != b.state_hash {
            Some(LogField::StateHash)
        } else {
            None
        };
        if let Some(field) = field {
            return Err(LogDivergence { event_index, field });
        }
    }
    if left.events.len() != right.events.len() {
        return Err(LogDivergence {
            event_index: u64::try_from(left.events.len().min(right.events.len()))
                .unwrap_or(u64::MAX),
            field: LogField::Length,
        });
    }
    Ok(())
}

#[derive(Clone, Debug, PartialEq, Eq, thiserror::Error)]
pub enum PlacementViolation {
    #[error("normalized log event index {actual} appeared at position {position}")]
    BadEventIndex { position: u64, actual: u64 },
    #[error("normalized log V-time moved backwards at event {event_index}: {before} -> {after}")]
    VtimeRegressed {
        event_index: u64,
        before: u64,
        after: u64,
    },
    #[error("interrupt placement differs at event {event_index}")]
    WrongDelivery {
        event_index: u64,
        expected: Vec<InterruptDelivery>,
        actual: Vec<InterruptDelivery>,
    },
    #[error("scheduled interrupt {schedule_index} at {deadline_vns} vns was not delivered")]
    Undelivered {
        schedule_index: u64,
        deadline_vns: u64,
    },
}

pub fn check_delivery_placement(
    schedule: &[ScheduledInterrupt],
    log: &NormalizedLog,
) -> Result<(), PlacementViolation> {
    let mut ordered = schedule.to_vec();
    ordered.sort_by_key(|s| (s.deadline_vns, s.schedule_index));
    let mut delivered = vec![false; ordered.len()];
    let mut previous_vns = 0u64;

    for (position, event) in log.events.iter().enumerate() {
        let position_u64 = u64::try_from(position).unwrap_or(u64::MAX);
        if event.event_index != position_u64 {
            return Err(PlacementViolation::BadEventIndex {
                position: position_u64,
                actual: event.event_index,
            });
        }
        if event.vns_after < previous_vns {
            return Err(PlacementViolation::VtimeRegressed {
                event_index: event.event_index,
                before: previous_vns,
                after: event.vns_after,
            });
        }
        previous_vns = event.vns_after;

        let due_indices: Vec<_> = ordered
            .iter()
            .enumerate()
            .filter_map(|(index, scheduled)| {
                (!delivered[index]
                    && scheduled.armed_for_event <= event.event_index
                    && scheduled
                        .canceled_at_event
                        .is_none_or(|canceled| canceled > event.event_index)
                    && scheduled.deadline_vns <= event.vns_after)
                    .then_some(index)
            })
            .collect();
        let expected: Vec<_> = due_indices
            .iter()
            .map(|index| InterruptDelivery::from(ordered[*index]))
            .collect();
        if event.interrupts != expected {
            return Err(PlacementViolation::WrongDelivery {
                event_index: event.event_index,
                expected,
                actual: event.interrupts.clone(),
            });
        }
        for index in due_indices {
            delivered[index] = true;
        }
    }

    if let Some(last) = log.events.last()
        && let Some((_, missing)) = ordered.iter().enumerate().find(|(index, scheduled)| {
            !delivered[*index]
                && scheduled.canceled_at_event.is_none()
                && scheduled.armed_for_event <= last.event_index
                && scheduled.deadline_vns <= last.vns_after
        })
    {
        return Err(PlacementViolation::Undelivered {
            schedule_index: missing.schedule_index,
            deadline_vns: missing.deadline_vns,
        });
    }
    Ok(())
}

#[cfg(test)]
mod live_trace_tests {
    use super::*;

    #[test]
    fn calibration_labels_are_the_frozen_fit_script_vocabulary() {
        for (class, label) in [
            (NormalizedEventClass::Doorbell, "doorbell"),
            (
                NormalizedEventClass::DeviceMmio(DeviceClass::InterruptController),
                "ic_mmio",
            ),
            (
                NormalizedEventClass::DeviceMmio(DeviceClass::Serial),
                "serial_mmio",
            ),
            (
                NormalizedEventClass::DeviceMmio(DeviceClass::Paravirtual),
                "pv_mmio",
            ),
            (NormalizedEventClass::TimeRead, "time_read"),
            (NormalizedEventClass::ArchitecturalControl, "arch_control"),
            (NormalizedEventClass::InterruptDelivery, "irq_delivery"),
            (NormalizedEventClass::Idle, "idle"),
            (NormalizedEventClass::Terminal, "terminal"),
        ] {
            assert_eq!(class.label(), label);
        }
    }

    #[test]
    fn frozen_v1_empty_serial_payload_digest_is_stable() {
        assert_eq!(
            digest_payload(NormalizedEventClass::DeviceMmio(DeviceClass::Serial), &[],),
            [
                0x63, 0xa3, 0x23, 0x2e, 0xe8, 0xd6, 0x98, 0xd8, 0xfd, 0xd4, 0xd5, 0x38, 0x73, 0xef,
                0x9a, 0xeb, 0x02, 0x0f, 0x90, 0x52, 0x1a, 0xa8, 0x53, 0xb4, 0x8f, 0xb4, 0x36, 0x93,
                0xd9, 0xf0, 0x2d, 0x49,
            ],
        );
    }

    #[test]
    fn raw_only_exit_does_not_consume_a_portable_ordinal() {
        let mut trace = LiveVirtualTimeTrace::default();
        trace
            .record_raw_only(ExitReason::Mmio, "private GIC MMIO".to_string())
            .unwrap();
        trace
            .begin(
                ExitReason::Mmio,
                "portable serial MMIO".to_string(),
                NormalizedEventClass::DeviceMmio(DeviceClass::Serial),
                vec![1],
            )
            .unwrap();

        assert_eq!(trace.current_event_index().unwrap(), 0);
        trace.finish(2, None).unwrap();
        assert_eq!(trace.raw.len(), 2);
        assert_eq!(trace.raw[0].event_index, 0);
        assert_eq!(trace.raw[0].portable_event_index, None);
        assert_eq!(trace.raw[1].event_index, 1);
        assert_eq!(trace.raw[1].portable_event_index, Some(0));
        assert_eq!(trace.normalized.events.len(), 1);
        assert_eq!(trace.normalized.events[0].event_index, 0);
        assert_eq!(trace.raw_log().len(), 2);
        assert_ne!(trace.normalized_digest(), [0; 32]);
        assert_ne!(trace.normalized_digest(), [1; 32]);
        trace.checkpoint_last([9; 32]).unwrap();
        assert_eq!(trace.normalized.events[0].state_hash, Some([9; 32]));

        let mut empty = LiveVirtualTimeTrace::default();
        assert!(empty.checkpoint_last([1; 32]).is_err());
    }

    #[test]
    fn replacement_and_disarm_are_recorded_as_cancellations() {
        let mut trace = LiveVirtualTimeTrace::default();
        trace
            .begin(
                ExitReason::Mmio,
                "Mmio".to_string(),
                NormalizedEventClass::DeviceMmio(DeviceClass::Paravirtual),
                vec![1],
            )
            .unwrap();
        trace.schedule_clockevent(10, 20).unwrap();
        trace.schedule_clockevent(20, 20).unwrap();
        trace.finish(1, None).unwrap();

        trace
            .begin(
                ExitReason::Mmio,
                "Mmio".to_string(),
                NormalizedEventClass::DeviceMmio(DeviceClass::Paravirtual),
                vec![2],
            )
            .unwrap();
        trace.cancel_clockevent().unwrap();
        trace.finish(2, None).unwrap();

        assert_eq!(trace.schedule.len(), 2);
        assert_eq!(trace.schedule[0].canceled_at_event, Some(0));
        assert_eq!(trace.schedule[1].canceled_at_event, Some(1));
        check_delivery_placement(trace.schedule(), trace.normalized_log()).unwrap();
    }

    #[test]
    fn live_delivery_is_bound_to_the_active_schedule() {
        let mut trace = LiveVirtualTimeTrace::default();
        trace
            .begin(
                ExitReason::Mmio,
                "Mmio".to_string(),
                NormalizedEventClass::DeviceMmio(DeviceClass::Paravirtual),
                vec![3],
            )
            .unwrap();
        trace.schedule_clockevent(4, 20).unwrap();
        trace.finish(1, None).unwrap();
        trace
            .begin(
                ExitReason::Mmio,
                "Mmio".to_string(),
                NormalizedEventClass::DeviceMmio(DeviceClass::Serial),
                vec![4],
            )
            .unwrap();
        trace.deliver_clockevent().unwrap();
        trace.finish(4, None).unwrap();

        check_delivery_placement(trace.schedule(), trace.normalized_log()).unwrap();
        assert_eq!(trace.normalized.events[1].interrupts.len(), 1);
    }

    #[test]
    fn restored_timer_seeds_the_new_trace_segment_before_delivery() {
        let mut trace = LiveVirtualTimeTrace::default();
        trace.restore_clockevent_schedule(Some((4, 20))).unwrap();
        trace
            .begin(
                ExitReason::Mmio,
                "first restored exit".to_string(),
                NormalizedEventClass::DeviceMmio(DeviceClass::Serial),
                vec![5],
            )
            .unwrap();
        trace.deliver_clockevent().unwrap();
        trace.finish(4, None).unwrap();

        check_delivery_placement(trace.schedule(), trace.normalized_log()).unwrap();
        assert_eq!(trace.schedule.len(), 1);
        assert_eq!(trace.schedule[0].armed_for_event, 0);
        assert_eq!(trace.normalized.events[0].interrupts.len(), 1);
    }

    #[test]
    fn restore_preflight_preserves_trace_on_invalid_schedule_state() {
        let mut trace = LiveVirtualTimeTrace::default();
        trace.restore_clockevent_schedule(Some((4, 20))).unwrap();

        trace.active_clockevent_schedule = Some(99);
        assert_eq!(
            trace.restore_clockevent_schedule(None),
            Err("active virtual_time clockevent schedule record is missing")
        );
        assert_eq!(trace.active_clockevent_schedule, Some(99));

        trace.active_clockevent_schedule = Some(0);
        trace.schedule[0].canceled_at_event = Some(0);
        assert_eq!(
            trace.restore_clockevent_schedule(None),
            Err("active virtual_time clockevent schedule was already canceled")
        );
        assert_eq!(trace.active_clockevent_schedule, Some(0));

        trace.schedule[0].canceled_at_event = None;
        trace.next_schedule_index = u64::MAX;
        assert_eq!(
            trace.restore_clockevent_schedule(Some((8, 21))),
            Err("virtual_time restored schedule index exhausted")
        );
        assert_eq!(trace.active_clockevent_schedule, Some(0));
        assert_eq!(trace.schedule[0].canceled_at_event, None);
        trace.restore_clockevent_schedule(None).unwrap();
        assert_eq!(trace.active_clockevent_schedule, None);
        assert_eq!(trace.schedule[0].canceled_at_event, Some(0));
    }

    #[test]
    fn masked_due_epochs_are_explicit_and_late_delivery_still_fails() {
        let mut trace = LiveVirtualTimeTrace::default();
        trace
            .begin(
                ExitReason::Mmio,
                "program".to_string(),
                NormalizedEventClass::DeviceMmio(DeviceClass::Paravirtual),
                vec![1],
            )
            .unwrap();
        trace.schedule_clockevent(4, 27).unwrap();
        trace.finish(1, None).unwrap();

        trace
            .begin(
                ExitReason::Mmio,
                "masked".to_string(),
                NormalizedEventClass::DeviceMmio(DeviceClass::Paravirtual),
                vec![2],
            )
            .unwrap();
        trace.defer_clockevent().unwrap();
        trace.finish(4, None).unwrap();

        trace
            .begin(
                ExitReason::Mmio,
                "unmask-fence".to_string(),
                NormalizedEventClass::DeviceMmio(DeviceClass::Paravirtual),
                vec![3],
            )
            .unwrap();
        trace.deliver_clockevent().unwrap();
        trace.finish(5, None).unwrap();
        trace
            .begin(
                ExitReason::Mmio,
                "next".to_string(),
                NormalizedEventClass::DeviceMmio(DeviceClass::Paravirtual),
                vec![4],
            )
            .unwrap();
        trace.finish(6, None).unwrap();

        assert_eq!(trace.schedule.len(), 2);
        assert_eq!(trace.schedule[0].canceled_at_event, Some(1));
        assert_eq!(trace.schedule[1].armed_for_event, 2);
        assert_eq!(trace.schedule[1].deadline_vns, 4);
        check_delivery_placement(trace.schedule(), trace.normalized_log()).unwrap();

        let mut early = trace.normalized_log().clone();
        let delivery = early.events[2].interrupts.remove(0);
        early.events[1].interrupts.push(delivery);
        assert!(matches!(
            check_delivery_placement(trace.schedule(), &early),
            Err(PlacementViolation::WrongDelivery { event_index: 1, .. })
        ));

        let mut late = trace.normalized_log().clone();
        let delivery = late.events[2].interrupts.remove(0);
        late.events[3].interrupts.push(delivery);
        assert!(matches!(
            check_delivery_placement(trace.schedule(), &late),
            Err(PlacementViolation::WrongDelivery { event_index: 2, .. })
        ));
    }

    #[test]
    fn finite_prefix_permits_only_deadlines_beyond_its_final_vtime() {
        let event = NormalizedEvent {
            event_index: 0,
            class: NormalizedEventClass::Terminal,
            payload_digest: [0; 32],
            vns_after: 9,
            interrupts: Vec::new(),
            state_hash: None,
        };
        let schedule = [ScheduledInterrupt {
            deadline_vns: 10,
            schedule_index: 0,
            armed_for_event: 0,
            canceled_at_event: None,
            interrupt_id: 20,
        }];
        let prefix = NormalizedLog {
            events: vec![event.clone()],
        };
        check_delivery_placement(&schedule, &prefix).unwrap();

        let due = NormalizedLog {
            events: vec![NormalizedEvent {
                vns_after: 10,
                ..event
            }],
        };
        assert!(matches!(
            check_delivery_placement(&schedule, &due),
            Err(PlacementViolation::WrongDelivery { event_index: 0, .. })
        ));

        let future_epoch = [ScheduledInterrupt {
            deadline_vns: 0,
            armed_for_event: 1,
            ..schedule[0]
        }];
        assert_eq!(check_delivery_placement(&future_epoch, &prefix), Ok(()));
    }

    #[test]
    fn service_completion_order_is_defer_and_retirement_neutral() {
        let begin = |trace: &mut LiveVirtualTimeTrace| {
            trace
                .begin(
                    ExitReason::Mmio,
                    "doorbell".into(),
                    NormalizedEventClass::Doorbell,
                    vec![28],
                )
                .unwrap();
        };
        let mut inline = LiveVirtualTimeTrace::default();
        begin(&mut inline);
        inline.complete_service(17, [9; 32]).unwrap();
        assert_eq!(inline.event_history().count, 0);
        assert!(inline.complete_service(17, [9; 32]).is_err());
        inline.finish(17, None).unwrap();
        assert_eq!(inline.event_history().count, 2);
        assert_eq!(inline.normalized_log().events.len(), 1);
        let mut deferred = LiveVirtualTimeTrace::default();
        begin(&mut deferred);
        deferred.finish(17, None).unwrap();
        let prefix = deferred.event_history();
        deferred.checkpoint_last([7; 32]).unwrap();
        deferred.retire();
        assert_eq!(deferred.event_history(), prefix);
        deferred.complete_service(17, [9; 32]).unwrap();
        assert_eq!(deferred.event_history(), inline.event_history());
        let mut different = LiveVirtualTimeTrace::default();
        different.restore_event_history(prefix);
        different.complete_service(17, [8; 32]).unwrap();
        assert_eq!(
            different.event_history().count,
            inline.event_history().count
        );
        assert_ne!(different.event_history(), inline.event_history());
        let mut later = LiveVirtualTimeTrace::default();
        later.restore_event_history(prefix);
        later.complete_service(18, [9; 32]).unwrap();
        assert_ne!(later.event_history(), inline.event_history());
    }

    #[test]
    fn completed_event_separates_request_result_and_missing_completion() {
        let class = NormalizedEventClass::ArchitecturalControl;
        let no_result = digest_completed_payload(class, &[1, 2], None);
        let read = digest_completed_payload(class, &[1, 2], Some(&[0, 3]));
        let fault = digest_completed_payload(class, &[1, 2], Some(&[1]));
        assert_ne!(no_result, read);
        assert_ne!(read, fault);
        assert_ne!(
            read,
            digest_completed_payload(class, &[1], Some(&[2, 0, 3]))
        );
        let mut trace = LiveVirtualTimeTrace::default();
        trace
            .begin(ExitReason::Mmio, String::new(), class, vec![1, 2])
            .unwrap();
        trace.record_completion(&[0, 3]).unwrap();
        assert!(trace.record_completion(&[0, 4]).is_err());
        trace.finish(7, None).unwrap();
        assert_eq!(trace.normalized_log().events[0].payload_digest, read);
    }

    #[test]
    fn service_completion_reserves_both_records_before_queuing() {
        let mut trace = LiveVirtualTimeTrace::default();
        let history = control_proto::EventHistory {
            count: u64::MAX - 1,
            digest: [5; 32],
        };
        trace.restore_event_history(history);
        trace
            .begin(
                ExitReason::Mmio,
                String::new(),
                NormalizedEventClass::Doorbell,
                Vec::new(),
            )
            .unwrap();
        assert_eq!(
            trace.complete_service(17, [9; 32]),
            Err("event history count overflow")
        );
        assert_eq!(trace.event_history(), history);
        trace.finish(17, None).unwrap();
        assert_eq!(trace.event_history().count, u64::MAX);
        assert_eq!(
            trace.complete_service(17, [9; 32]),
            Err("event history count overflow")
        );
        assert_eq!(trace.event_history().count, u64::MAX);
    }

    #[test]
    fn ordered_history_is_capture_and_retirement_neutral() {
        let event = |trace: &mut LiveVirtualTimeTrace, payload, at| {
            trace
                .begin(
                    ExitReason::Mmio,
                    "diagnostic".into(),
                    NormalizedEventClass::DeviceMmio(DeviceClass::Serial),
                    vec![payload],
                )
                .unwrap();
            trace.finish(at, None).unwrap();
        };
        let mut uninterrupted = LiveVirtualTimeTrace::default();
        event(&mut uninterrupted, 1, 10);
        event(&mut uninterrupted, 2, 20);
        let mut segmented = LiveVirtualTimeTrace::default();
        event(&mut segmented, 1, 10);
        let before = segmented.event_history();
        segmented.checkpoint_last([7; 32]).unwrap();
        assert_eq!(segmented.event_history(), before);
        let retired = segmented.retire();
        assert_eq!(retired.event_history(), before);
        assert_eq!(segmented.event_history(), before);
        event(&mut segmented, 2, 20);
        assert_eq!(segmented.event_history(), uninterrupted.event_history());
        let mut changed = LiveVirtualTimeTrace::default();
        event(&mut changed, 9, 10);
        event(&mut changed, 2, 20);
        assert_eq!(
            changed.event_history().count,
            uninterrupted.event_history().count
        );
        assert_eq!(
            changed.normalized_log().events.last().unwrap().vns_after,
            20
        );
        assert_ne!(changed.event_history(), uninterrupted.event_history());
        let mut reordered = LiveVirtualTimeTrace::default();
        event(&mut reordered, 2, 10);
        event(&mut reordered, 1, 20);
        assert_ne!(reordered.event_history(), uninterrupted.event_history());
        let mut restored = LiveVirtualTimeTrace::default();
        restored.restore_event_history(before);
        event(&mut restored, 2, 20);
        assert_eq!(restored.event_history(), uninterrupted.event_history());
    }

    #[test]
    fn ordered_history_binds_interrupt_association_and_order_without_local_schedule_ids() {
        let run = |deliveries: Vec<InterruptDelivery>, later: bool| {
            let mut trace = LiveVirtualTimeTrace::default();
            for ordinal in 0..2 {
                trace
                    .begin(
                        ExitReason::Idle,
                        "idle".into(),
                        NormalizedEventClass::Idle,
                        vec![],
                    )
                    .unwrap();
                if (ordinal == 1) == later {
                    trace.current_interrupts = deliveries.clone();
                }
                trace.finish(ordinal + 10, None).unwrap();
            }
            trace.event_history()
        };
        let a = InterruptDelivery {
            deadline_vns: 5,
            schedule_index: 0,
            interrupt_id: 32,
        };
        let b = InterruptDelivery {
            deadline_vns: 5,
            schedule_index: 1,
            interrupt_id: 33,
        };
        let baseline = run(vec![a, b], false);
        assert_eq!(
            baseline,
            run(
                vec![
                    InterruptDelivery {
                        schedule_index: 91,
                        ..a
                    },
                    InterruptDelivery {
                        schedule_index: 92,
                        ..b
                    }
                ],
                false
            )
        );
        assert_ne!(baseline, run(vec![b, a], false));
        assert_ne!(baseline, run(vec![a, b], true));
        assert_ne!(
            baseline,
            run(
                vec![
                    InterruptDelivery {
                        deadline_vns: 6,
                        ..a
                    },
                    b
                ],
                false
            )
        );
        let mut trace = LiveVirtualTimeTrace::default();
        trace.restore_event_history(control_proto::EventHistory {
            count: u64::MAX,
            digest: [4; 32],
        });
        trace
            .begin(
                ExitReason::Idle,
                "idle".into(),
                NormalizedEventClass::Idle,
                vec![],
            )
            .unwrap();
        assert_eq!(trace.finish(1, None), Err("event history count overflow"));
    }

    #[test]
    fn delivery_outside_a_normalized_event_cannot_disappear_from_history() {
        let mut trace = LiveVirtualTimeTrace::default();
        trace.restore_clockevent_schedule(Some((10, 32))).unwrap();
        let before = trace.clone();
        assert_eq!(
            trace.deliver_clockevent(),
            Err("clockevent delivery has no active normalized event")
        );
        assert_eq!(trace.event_history(), before.event_history());
        assert_eq!(trace.schedule, before.schedule);
        assert_eq!(
            trace.active_clockevent_schedule,
            before.active_clockevent_schedule
        );
        trace
            .begin(
                ExitReason::Idle,
                "idle".into(),
                NormalizedEventClass::Idle,
                vec![],
            )
            .unwrap();
        trace.deliver_clockevent().unwrap();
        trace.finish(10, None).unwrap();
        assert_eq!(trace.normalized_log().events[0].interrupts.len(), 1);
    }

    #[test]
    fn only_semantic_delivery_promotes_a_raw_exit_to_a_normalized_event() {
        let mut trace = LiveVirtualTimeTrace::default();
        trace.restore_clockevent_schedule(Some((10, 32))).unwrap();
        trace.begin_raw(ExitReason::Sysreg, "raw".into()).unwrap();
        assert!(trace.preflight_restore_clockevent_schedule(false).is_err());
        trace.finish_raw().unwrap();
        assert_eq!(trace.event_history().count, 0);
        trace
            .begin_raw(ExitReason::Mmio, "GIC read".into())
            .unwrap();
        trace.deliver_clockevent().unwrap();
        trace.finish(10, None).unwrap();
        assert_eq!(trace.event_history().count, 1);
        assert_eq!(trace.raw_log().len(), 2);
        assert_eq!(trace.raw_log()[0].portable_event_index, None);
        assert_eq!(trace.raw_log()[1].portable_event_index, Some(0));
        let event = &trace.normalized_log().events[0];
        assert_eq!(event.class, NormalizedEventClass::InterruptDelivery);
        assert_eq!(event.vns_after, 10);
        assert_eq!(event.interrupts.len(), 1);
        check_delivery_placement(trace.schedule(), trace.normalized_log()).unwrap();
    }
}

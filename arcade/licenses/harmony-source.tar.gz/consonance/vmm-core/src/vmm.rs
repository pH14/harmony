// SPDX-License-Identifier: AGPL-3.0-or-later

use hypercall_proto::{
    MAX_PAYLOAD, SeededEntropy, Service, ServiceId, Status, decode, encode_error, encode_response,
};
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, BTreeSet};
use vm_state::SnapshotRecords;
use vmm_backend::{Arch, Backend, CommonExit, Exit};
use vtime::{IdlePlanner, VClock, VClockConfig};

use crate::engine_state::EngineState;
use crate::snapshot::SnapshotError;
use crate::vendor::Vendor;
use crate::virtual_time::LiveVirtualTimeTrace;

use environment::{
    channel,
    input_spec::ServiceConfig,
    sdk::{self, CoverageOutcome, EventClass, ServiceOutcome},
};

use crate::sdk_telemetry::{Attribution, Callback, Kind, SdkDispatchTelemetry};

pub type VcpuOf<B> = <<B as Backend>::A as Arch>::VcpuState;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum HostOperationSite {
    ControlBefore,
    ControlAfter,
    SdkResponse,
}

pub type HostOperationGuard =
    std::sync::Arc<dyn Fn(HostOperationSite) -> Result<(), String> + Send + Sync>;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TerminalReason {
    DebugExit { code: u8 },
    Idle,
    Shutdown,
    SdkStop,
}

const REQ_GPA: usize = 0x0000_E000;
const RESP_GPA: usize = 0x0000_F000;
const HC_PAGE: usize = 4096;
const DOORBELL_MAP_GPA: usize = 0x0000_C000;
const DOORBELL_MAP_LEN: usize = 4 * HC_PAGE;

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SdkStop {
    Quiescent,
    Assertion {
        id: u32,
        data: Vec<u8>,
    },
    Decision {
        moment: u64,
        seq: u32,
        question: channel::Question,
    },
    CoverageDecision {
        moment: u64,
        seq: u32,
        question: channel::Question,
        ready: u32,
    },
    DeferredDoorbell {
        moment: u64,
        requested_len: u32,
        request: Vec<u8>,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
enum SdkEventAction {
    Stop(SdkStop),
    DeferSnapshot,
    Capture,
    Malformed,
}

#[derive(Debug, thiserror::Error)]
pub enum VmmError {
    #[error("backend error: {0}")]
    Backend(#[from] vmm_backend::BackendError),
    #[error("vendor boot error: {0}")]
    VendorBoot(#[source] Box<dyn std::error::Error + Send + Sync + 'static>),
    #[error("contract violation: {0}")]
    ContractViolation(String),
    #[error("v-time error: {0}")]
    Vtime(#[from] vtime::VtimeError),
    #[error("snapshot error")]
    Snapshot(#[from] crate::snapshot::SnapshotError),
    #[error("service channel error")]
    Channel(#[from] channel::ChannelError),
}

impl VmmError {
    pub fn vendor_boot<E>(err: E) -> Self
    where
        E: std::error::Error + Send + Sync + 'static,
    {
        VmmError::VendorBoot(Box::new(err))
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Step {
    Continued,
    Terminal(TerminalReason),
    SdkStop,
}

struct ExitProgress<A: Arch> {
    step: Step,
    continuation: Option<Exit<A>>,
}

pub struct RunResult {
    pub reason: TerminalReason,
    pub sdk_stop: Option<SdkStop>,
    pub serial: Vec<u8>,
    pub exit_counts: vmm_backend::ExitCounts,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CheckpointHashPreimage {
    pub event_index: u64,
    pub state_hash: [u8; 32],
    pub state_blob_suffix: Vec<u8>,
    pub memory_digest: [u8; 32],
    pub memory_length: usize,
}

type StateHashPreimage = ([u8; 32], Vec<u8>, [u8; 32]);

pub enum RamBacking {
    Owned(GuestRam),
    Snapshot(snapshot_store::Mapping),
}

impl RamBacking {
    pub fn len(&self) -> usize {
        match self {
            RamBacking::Owned(ram) => ram.len(),
            RamBacking::Snapshot(map) => map.len(),
        }
    }

    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    pub fn as_bytes(&self) -> &[u8] {
        match self {
            RamBacking::Owned(ram) => ram.as_bytes(),
            RamBacking::Snapshot(map) => map.as_slice(),
        }
    }

    pub fn as_mut_bytes(&mut self) -> &mut [u8] {
        match self {
            RamBacking::Owned(ram) => ram.as_mut_bytes(),
            RamBacking::Snapshot(map) => map.as_mut_slice(),
        }
    }
}

fn extend_written(written: &mut Vec<(usize, usize)>, offset: usize, len: usize) {
    match written.last_mut() {
        Some(last) if last.0 + last.1 == offset => last.1 += len,
        _ => written.push((offset, len)),
    }
}

fn valid_guest_ram_len(len: usize, page_size: usize) -> bool {
    len != 0 && len.is_multiple_of(page_size)
}

pub struct GuestRam {
    #[cfg(not(miri))]
    inner: memmap2::MmapMut,
    #[cfg(miri)]
    inner: Vec<u8>,
}

impl GuestRam {
    pub fn new(len: usize) -> Result<Self, VmmError> {
        if len == 0 || !len.is_multiple_of(4096) {
            return Err(VmmError::Backend(vmm_backend::BackendError::Memory(
                "guest RAM length must be a non-zero multiple of 4 KiB",
            )));
        }
        #[cfg(not(miri))]
        let inner = memmap2::MmapMut::map_anon(len)
            .map_err(|e| VmmError::Backend(vmm_backend::BackendError::Io(e)))?;
        #[cfg(miri)]
        let inner = vec![0u8; len];
        Ok(Self { inner })
    }

    pub fn len(&self) -> usize {
        self.inner.len()
    }

    pub fn is_empty(&self) -> bool {
        self.inner.is_empty()
    }

    pub fn as_bytes(&self) -> &[u8] {
        &self.inner
    }

    pub fn as_mut_bytes(&mut self) -> &mut [u8] {
        &mut self.inner
    }
}

pub struct VtimeWiring {
    pub(crate) cfg: VClockConfig,
    pub(crate) clock: VClock,
    pub(crate) entropy: SeededEntropy,
    pub(crate) guest_clock_offset: u64,
}

impl VtimeWiring {
    pub fn new_virtual_time(cfg: VClockConfig, seed: u64) -> Result<VtimeWiring, VmmError> {
        Ok(VtimeWiring {
            cfg,
            clock: VClock::new(cfg)?,
            entropy: SeededEntropy::new(seed),
            guest_clock_offset: 0,
        })
    }

    pub fn advance_virtual_time(&mut self, vns_delta: u64) {
        self.clock.advance(vns_delta);
    }

    pub fn virtual_time_vns(&self) -> u64 {
        self.clock.vns()
    }

    #[cfg(any(all(target_os = "linux", target_arch = "x86_64"), test))]
    pub(crate) fn next_entropy_word(&mut self) -> Result<u64, VmmError> {
        let mut buf = [0u8; 8];
        let (status, got) = self.entropy.handle(1, &8u32.to_le_bytes(), &mut buf);
        if (status, got) != (Status::Ok, buf.len()) {
            return Err(VmmError::ContractViolation(format!(
                "seeded entropy draw failed (status {status:?}, got {got} of 8 bytes)"
            )));
        }
        Ok(u64::from_le_bytes(buf))
    }

    pub(crate) fn draw_entropy(&mut self, req: &[u8], resp: &mut [u8]) -> (Status, usize) {
        self.entropy.handle(1, req, resp)
    }

    pub(crate) fn guest_clock(&self) -> u64 {
        self.clock
            .guest_ticks()
            .wrapping_add(self.guest_clock_offset)
    }
}

#[derive(Clone, PartialEq, Eq, Debug)]
pub struct VtimeSnapshot {
    pub vns: u64,
    pub guest_clock_offset: u64,
    pub entropy: Vec<u8>,
}

const EVENT_TRACE_CAP: usize = 4096;

pub const PVCLOCK_REFRESH_TRACE_CAP: usize = EVENT_TRACE_CAP;

#[derive(Clone, Copy, PartialEq, Eq)]
enum StampKind {
    Refresh,
    Canonical,
}

fn synchronous_checkpoint_due(checkpoint: bool, deferred: bool) -> bool {
    checkpoint && !deferred
}

enum IdleAction {
    Terminal,
    DeliverPending,
    JumpToDeadline { vns: u64, control_wake: bool },
}

pub(crate) struct SdkChannel {
    env: channel::RecordedEnv<Box<dyn channel::ServiceHandler>>,
    events: Vec<(u64, u32, Vec<u8>)>,
    coverage_thresholds: BTreeMap<u32, u64>,
    coverage: Vec<(u64, u32, u64, u32, u32)>,
    pending_stop: Option<SdkStop>,
    pending_snapshot: bool,
}

pub(crate) struct LocalServiceAnswer {
    answer: channel::Answer,
    moment: u64,
    question: channel::Question,
    environment: channel::RecordedEnv<Box<dyn channel::ServiceHandler>>,
}

impl LocalServiceAnswer {
    pub(crate) fn answer(&self) -> &channel::Answer {
        &self.answer
    }
}

pub(crate) struct PvclockChannel {
    gpa: Option<u64>,
    armed: bool,
    refreshes: Vec<(u64, u64)>,
}

#[derive(Clone, Debug)]
pub struct SdkSnapshot {
    pub(crate) recorded: channel::RecordedState,
    pub(crate) events: Vec<(u64, u32, Vec<u8>)>,
    pub(crate) pending_snapshot: bool,
    pub(crate) pending_stop: Option<SdkStop>,
    pub(crate) coverage_thresholds: BTreeMap<u32, u64>,
}

impl SdkSnapshot {
    pub(crate) fn remaining_payloads(&self) -> Option<Vec<Vec<u8>>> {
        self.recorded.remaining_payloads()
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PvclockSnapshot {
    pub(crate) gpa: Option<u64>,
    pub(crate) registrable: bool,
    pub(crate) armed: bool,
}

pub struct Vmm<B: Backend>
where
    B::A: Vendor,
{
    pub(crate) backend: B,
    pub(crate) ram: RamBacking,
    pub(crate) ram_base_gpa: u64,
    pub(crate) doorbell_pages: Option<GuestRam>,
    pub(crate) devices: <B::A as Vendor>::Devices,
    pub(crate) host_dirty: std::collections::BTreeSet<u64>,
    pub(crate) host_dirty_wholesale: bool,
    page_digests: crate::state_digest::PageDigests,
    pub(crate) report_stream: Vec<u32>,
    pub(crate) idle_landings: Vec<u64>,
    pub(crate) terminal: Option<TerminalReason>,
    pub(crate) saved_state: Option<VcpuOf<B>>,
    pub(crate) vtime: Option<VtimeWiring>,
    pub(crate) virtual_time_progress: std::sync::Arc<std::sync::atomic::AtomicU64>,
    pub(crate) virtual_time_trace: Option<LiveVirtualTimeTrace>,
    pub(crate) doorbell_exits: u64,
    sdk_dispatch_telemetry: std::cell::RefCell<SdkDispatchTelemetry>,
    exit_telemetry: crate::host_telemetry::ExitTelemetry,
    hash_telemetry: std::cell::Cell<crate::host_telemetry::HashTelemetry>,
    pub(crate) deferred_virtual_time_checkpoints: bool,
    virtual_time_checkpoint_events: BTreeSet<u64>,
    pub(crate) completion_staged: bool,
    pub(crate) require_long_mode: bool,
    snapshot_ready: bool,
    pub(crate) sdk_snapshot_reentry_required: bool,
    pub(crate) snapshot_hashing: bool,
    checkpoint_hash_preimage_armed: bool,
    checkpoint_hash_preimage: Option<CheckpointHashPreimage>,
    pub(crate) idle_wake_vns: Option<u64>,
    run_deadline_vns: Option<u64>,
    pending_coverage_callbacks: u64,
    pub(crate) last_step_control_idle_landing_vns: Option<u64>,
    pub(crate) sdk: Option<SdkChannel>,
    pub(crate) pvclock: Option<PvclockChannel>,
    host_operation_guard: Option<HostOperationGuard>,
}

enum RestoreValidation {
    CurrentBackend,
    ImportedArtifact,
}

struct RestorePreparation<B: Backend>
where
    B::A: Vendor,
{
    engine_state: EngineState,
    vcpu: VcpuOf<B>,
    clock_offset: u64,
    vendor: <B::A as Vendor>::RestorePrep,
    vtime: Option<(VClockConfig, VClock, SeededEntropy)>,
}

impl<B: Backend> Vmm<B>
where
    B::A: Vendor,
{
    pub fn new(backend: B, guest_ram: GuestRam) -> Self {
        Self::with_backing(backend, RamBacking::Owned(guest_ram))
    }

    pub fn vcpu_record(&mut self) -> Result<VcpuOf<B>, VmmError> {
        Ok(self.backend.save()?)
    }

    #[cfg(test)]
    pub(crate) fn backend(&self) -> &B {
        &self.backend
    }

    pub(crate) fn backend_mut(&mut self) -> &mut B {
        &mut self.backend
    }

    pub(crate) fn devices(&self) -> &<B::A as Vendor>::Devices {
        &self.devices
    }

    pub fn with_backing(backend: B, ram: RamBacking) -> Self {
        Self {
            backend,
            page_digests: crate::state_digest::PageDigests::new(ram.len()),
            ram,
            ram_base_gpa: 0,
            doorbell_pages: None,
            devices: <B::A as Vendor>::new_devices(),
            host_dirty: std::collections::BTreeSet::new(),
            host_dirty_wholesale: false,
            report_stream: Vec::new(),
            idle_landings: Vec::new(),
            terminal: None,
            saved_state: None,
            vtime: None,
            virtual_time_progress: std::sync::Arc::new(std::sync::atomic::AtomicU64::new(0)),
            virtual_time_trace: None,
            doorbell_exits: 0,
            sdk_dispatch_telemetry: std::cell::RefCell::default(),
            exit_telemetry: crate::host_telemetry::ExitTelemetry::default(),
            hash_telemetry: std::cell::Cell::default(),
            deferred_virtual_time_checkpoints: false,
            virtual_time_checkpoint_events: BTreeSet::new(),
            completion_staged: false,
            require_long_mode: false,
            snapshot_ready: true,
            sdk_snapshot_reentry_required: false,
            snapshot_hashing: false,
            checkpoint_hash_preimage_armed: false,
            checkpoint_hash_preimage: None,
            idle_wake_vns: None,
            run_deadline_vns: None,
            pending_coverage_callbacks: 0,
            last_step_control_idle_landing_vns: None,
            sdk: None,
            pvclock: None,
            host_operation_guard: None,
        }
    }

    pub fn set_host_operation_guard(&mut self, guard: HostOperationGuard) {
        self.host_operation_guard = Some(guard);
    }

    fn check_host_operation_guard(&self, site: HostOperationSite) -> Result<(), VmmError> {
        if let Some(guard) = &self.host_operation_guard {
            guard(site).map_err(VmmError::ContractViolation)?;
        }
        Ok(())
    }

    pub fn sdk_dispatch_telemetry(&self) -> SdkDispatchTelemetry {
        self.sdk_dispatch_telemetry.borrow().clone()
    }

    fn measure_sdk_guard(&self, site: HostOperationSite) -> (Result<(), VmmError>, Callback) {
        #[allow(clippy::disallowed_methods)]
        let started = std::time::Instant::now();
        self.measure_sdk_guard_using(site, || {
            u64::try_from(started.elapsed().as_nanos()).unwrap_or(u64::MAX)
        })
    }

    fn measure_sdk_guard_using(
        &self,
        site: HostOperationSite,
        elapsed: impl FnOnce() -> u64,
    ) -> (Result<(), VmmError>, Callback) {
        let result = self.check_host_operation_guard(site);
        let work = Callback::measured(
            self.host_operation_guard.is_some(),
            result.is_err(),
            elapsed(),
        );
        (result, work)
    }

    pub fn wire_vtime(&mut self, wiring: VtimeWiring) -> &mut Self {
        self.virtual_time_progress.store(
            wiring.virtual_time_vns(),
            std::sync::atomic::Ordering::Release,
        );
        self.virtual_time_trace = Some(LiveVirtualTimeTrace::default());
        self.virtual_time_checkpoint_events.clear();
        self.vtime = Some(wiring);
        self
    }

    pub fn virtual_time_trace(&self) -> Option<&LiveVirtualTimeTrace> {
        self.virtual_time_trace.as_ref()
    }

    pub fn event_history(&self) -> Option<control_proto::EventHistory> {
        self.virtual_time_trace
            .as_ref()
            .map(LiveVirtualTimeTrace::event_history)
    }

    pub(crate) fn restore_event_history(
        &mut self,
        history: control_proto::EventHistory,
    ) -> Result<(), VmmError> {
        self.virtual_time_trace
            .as_mut()
            .ok_or_else(|| {
                VmmError::ContractViolation("event history requires V-time wiring".into())
            })?
            .restore_event_history(history);
        Ok(())
    }

    pub(crate) fn take_virtual_time_trace(&mut self) -> Option<LiveVirtualTimeTrace> {
        self.virtual_time_checkpoint_events.clear();
        self.virtual_time_trace
            .as_mut()
            .map(LiveVirtualTimeTrace::retire)
    }

    pub fn defer_virtual_time_checkpoint_hashes(&mut self) -> Result<(), VmmError> {
        let trace = self.virtual_time_trace.as_ref().ok_or_else(|| {
            VmmError::ContractViolation(
                "deferred checkpoint hashing without virtual_time trace".to_string(),
            )
        })?;
        if !trace.raw_log().is_empty() || !trace.normalized_log().events.is_empty() {
            return Err(VmmError::ContractViolation(
                "deferred checkpoint hashing enabled after the trace started".to_string(),
            ));
        }
        self.deferred_virtual_time_checkpoints = true;
        Ok(())
    }

    #[must_use]
    pub fn virtual_time_checkpoint_due(&self, event_index: u64) -> bool {
        self.virtual_time_checkpoint_events.contains(&event_index)
    }

    pub fn checkpoint_virtual_time_trace_at(
        &mut self,
        event_index: u64,
        state_hash: [u8; 32],
    ) -> Result<(), VmmError> {
        if !self.deferred_virtual_time_checkpoints {
            return Err(VmmError::ContractViolation(
                "deferred checkpoint installed while synchronous hashing is active".to_string(),
            ));
        }
        if !self.virtual_time_checkpoint_due(event_index) {
            return Err(VmmError::ContractViolation(format!(
                "deferred checkpoint event {event_index} is not a completed checkpoint boundary"
            )));
        }
        self.virtual_time_trace
            .as_mut()
            .ok_or_else(|| {
                VmmError::ContractViolation(
                    "deferred checkpoint installed without virtual_time trace".to_string(),
                )
            })?
            .checkpoint_at(event_index, state_hash)
            .map_err(|message| VmmError::ContractViolation(message.to_string()))
    }

    pub fn checkpoint_virtual_time_trace(&mut self) -> Result<(), VmmError> {
        let hash = self
            .state_hash_preimage(crate::host_telemetry::HashSite::Checkpoint)?
            .0;
        self.virtual_time_trace
            .as_mut()
            .ok_or_else(|| {
                VmmError::ContractViolation(
                    "virtual_time trace checkpoint without virtual_time V-time".to_string(),
                )
            })?
            .checkpoint_last(hash)
            .map_err(|message| VmmError::ContractViolation(message.to_string()))
    }

    pub(crate) fn trace_arm_clockevent_schedule(
        &mut self,
        deadline_ticks: u64,
        interrupt_id: u32,
    ) -> Result<(), VmmError> {
        let deadline_vns = self.guest_clock_deadline_vns(deadline_ticks)?;
        self.trace_clockevent_schedule_vns(deadline_vns, interrupt_id)
    }

    pub(crate) fn trace_clockevent_schedule_vns(
        &mut self,
        deadline_vns: u64,
        interrupt_id: u32,
    ) -> Result<(), VmmError> {
        let Some(trace) = self.virtual_time_trace.as_mut() else {
            return Ok(());
        };
        trace
            .schedule_clockevent(deadline_vns, interrupt_id)
            .map_err(|message| VmmError::ContractViolation(message.to_string()))
    }

    pub(crate) fn guest_clock_deadline_vns(&self, deadline_ticks: u64) -> Result<u64, VmmError> {
        let vt = self.vtime.as_ref().ok_or_else(|| {
            VmmError::ContractViolation(
                "virtual_time clockevent schedule without V-time wiring".to_string(),
            )
        })?;
        if vt.guest_clock_offset != 0 {
            return Err(VmmError::ContractViolation(
                "virtual_time clockevent schedule with nonzero guest-clock offset".to_string(),
            ));
        }
        let ticks = deadline_ticks.saturating_sub(vt.cfg.guest_base);
        let numerator = u128::from(ticks) * 1_000_000_000_u128;
        let hz = u128::from(vt.cfg.guest_hz);
        if hz == 0 {
            return Err(VmmError::ContractViolation(
                "virtual_time clockevent schedule with zero guest frequency".to_string(),
            ));
        }
        let deadline_vns = numerator
            .saturating_add(hz - 1)
            .checked_div(hz)
            .unwrap_or(u128::MAX)
            .min(u128::from(u64::MAX)) as u64;
        Ok(deadline_vns)
    }

    pub(crate) fn trace_clockevent_cancel(&mut self) -> Result<(), VmmError> {
        let Some(trace) = self.virtual_time_trace.as_mut() else {
            return Ok(());
        };
        trace
            .cancel_clockevent()
            .map_err(|message| VmmError::ContractViolation(message.to_string()))
    }

    pub(crate) fn trace_arm_clockevent_defer(&mut self) -> Result<(), VmmError> {
        let Some(trace) = self.virtual_time_trace.as_mut() else {
            return Ok(());
        };
        trace
            .defer_clockevent()
            .map_err(|message| VmmError::ContractViolation(message.to_string()))
    }

    pub(crate) fn trace_clockevent_delivery(&mut self) -> Result<(), VmmError> {
        let Some(trace) = self.virtual_time_trace.as_mut() else {
            return Ok(());
        };
        trace
            .deliver_clockevent()
            .map_err(|message| VmmError::ContractViolation(message.to_string()))
    }

    pub(crate) fn advance_virtual_time_vtime(&mut self, delta_vns: u64) -> Result<(), VmmError> {
        let Some(vt) = self.vtime.as_mut() else {
            return Err(VmmError::ContractViolation(
                "virtual_time exit advancement without V-time wiring".to_string(),
            ));
        };
        vt.advance_virtual_time(delta_vns);
        self.virtual_time_progress
            .store(vt.virtual_time_vns(), std::sync::atomic::Ordering::Release);
        Ok(())
    }

    pub fn vtime_wired(&self) -> bool {
        self.vtime.is_some()
    }

    pub(crate) fn virtual_time_vtime_enabled(&self) -> bool {
        self.vtime.is_some()
    }

    pub(crate) fn map_doorbell_pages(&mut self) -> Result<(), VmmError> {
        let mut pages = GuestRam::new(DOORBELL_MAP_LEN)?;
        // SAFETY: `pages` is moved into `self.doorbell_pages` below; its backing
        // is pinned (an mmap/Vec that does not move when `self` moves) and lives
        // for the backend's lifetime because `self` owns it, and the run loop
        // holds `&mut self` so it is never aliased mid-run — the `map_memory`
        // contract, exactly as the main RAM mapping upholds it.
        unsafe {
            self.backend.map_memory(
                vmm_backend::Gpa(DOORBELL_MAP_GPA as u64),
                pages.as_mut_bytes(),
            )?;
        }
        self.doorbell_pages = Some(pages);
        Ok(())
    }

    pub fn wire_snapshot_hashing(&mut self) -> &mut Self {
        self.snapshot_hashing = true;
        self
    }

    pub fn snapshot_hashing_wired(&self) -> bool {
        self.snapshot_hashing
    }

    pub fn arm_checkpoint_hash_preimage(&mut self) -> &mut Self {
        self.checkpoint_hash_preimage_armed = true;
        self.checkpoint_hash_preimage = None;
        self
    }

    pub fn take_checkpoint_hash_preimage(&mut self) -> Option<CheckpointHashPreimage> {
        self.checkpoint_hash_preimage.take()
    }

    pub fn has_pending_guest_interrupt(&mut self) -> Result<bool, VmmError> {
        <B::A as Vendor>::has_pending_guest_interrupt(self)
    }

    pub fn guest_memory(&self) -> &[u8] {
        self.ram.as_bytes()
    }

    pub fn ram_backing_is_snapshot(&self) -> bool {
        matches!(self.ram, RamBacking::Snapshot(_))
    }

    pub fn write_guest_pages(&mut self, pages: &[(u64, [u8; 4096])]) -> Result<(), VmmError> {
        self.write_guest_page_iter(pages.iter().map(|(gfn, page)| (*gfn, page)))
    }

    pub(crate) fn write_guest_hashed_page_refs(
        &mut self,
        pages: &[(u64, &[u8; 32], &[u8; 4096])],
    ) -> Result<(), VmmError> {
        self.write_guest_page_iter(pages.iter().map(|&(gfn, _, page)| (gfn, page)))?;
        self.note_page_digests(pages.iter().map(|&(gfn, hash, _)| (gfn, *hash)));
        Ok(())
    }

    #[cfg(test)]
    pub(crate) fn forget_page_digests(&mut self) {
        self.page_digests.mark_all();
    }

    pub(crate) fn note_page_digests(&mut self, pages: impl IntoIterator<Item = (u64, [u8; 32])>) {
        for (page, digest) in pages {
            self.page_digests.set(page, digest);
        }
    }

    fn write_guest_page_iter<'a>(
        &mut self,
        pages: impl ExactSizeIterator<Item = (u64, &'a [u8; 4096])>,
    ) -> Result<(), VmmError> {
        const PAGE_SIZE: usize = 4096;
        const PAGE_SIZE_U64: u64 = PAGE_SIZE as u64;

        if pages.len() == 0 {
            return Ok(());
        }
        let ram_len = self.ram.len();
        if !valid_guest_ram_len(ram_len, PAGE_SIZE) {
            return Err(VmmError::ContractViolation(format!(
                "write_guest_pages: guest RAM length {ram_len} is not a non-zero multiple of {PAGE_SIZE}"
            )));
        }
        if !self.ram_base_gpa.is_multiple_of(PAGE_SIZE_U64) {
            return Err(VmmError::ContractViolation(format!(
                "write_guest_pages: main RAM base GPA {:#x} is not page-aligned",
                self.ram_base_gpa
            )));
        }

        let mut validated = Vec::with_capacity(pages.len());
        for (gfn, page) in pages {
            let gfn_usize = usize::try_from(gfn).map_err(|_| {
                VmmError::ContractViolation(format!(
                    "write_guest_pages: GFN {gfn} does not fit the host address space"
                ))
            })?;
            let offset = gfn_usize.checked_mul(PAGE_SIZE).ok_or_else(|| {
                VmmError::ContractViolation(format!(
                    "write_guest_pages: GFN {gfn} page offset overflows the host address space"
                ))
            })?;
            let end = offset.checked_add(PAGE_SIZE).ok_or_else(|| {
                VmmError::ContractViolation(format!(
                    "write_guest_pages: GFN {gfn} page end overflows the host address space"
                ))
            })?;
            if end > ram_len {
                return Err(VmmError::ContractViolation(format!(
                    "write_guest_pages: GFN {gfn} is outside guest RAM ({}) pages",
                    ram_len / PAGE_SIZE
                )));
            }
            let offset_u64 = u64::try_from(offset).map_err(|_| {
                VmmError::ContractViolation(format!(
                    "write_guest_pages: GFN {gfn} page offset does not fit a GPA"
                ))
            })?;
            let gpa = self.ram_base_gpa.checked_add(offset_u64).ok_or_else(|| {
                VmmError::ContractViolation(format!(
                    "write_guest_pages: GFN {gfn} GPA overflows the guest address space"
                ))
            })?;
            if gpa.checked_add(PAGE_SIZE_U64).is_none() {
                return Err(VmmError::ContractViolation(format!(
                    "write_guest_pages: GFN {gfn} has an invalid GPA range"
                )));
            }
            validated.push((offset, end, page));
        }
        validated.sort_unstable_by_key(|&(offset, _, _)| offset);
        if let Some(pair) = validated.windows(2).find(|pair| pair[0].0 == pair[1].0) {
            return Err(VmmError::ContractViolation(format!(
                "write_guest_pages: duplicate GFN {}",
                pair[0].0 / PAGE_SIZE
            )));
        }

        let ram = self.ram.as_mut_bytes();
        let base = ram.as_mut_ptr() as usize;
        let mut written = Vec::new();
        for &(offset, end, page) in &validated {
            ram[offset..end].copy_from_slice(page);
            extend_written(&mut written, offset, PAGE_SIZE);
        }
        for &(offset, len) in &written {
            self.page_digests.mark_range(offset, len);
        }
        self.invalidate_written_instructions(base, &written);
        self.host_dirty_wholesale = true;
        Ok(())
    }

    pub(crate) fn retire_pending_completion(&mut self) -> Result<(), VmmError> {
        if !self.completion_staged {
            return Ok(());
        }
        self.backend.retire_pending_completion()?;
        self.completion_staged = false;
        self.sdk_snapshot_reentry_required = false;
        Ok(())
    }

    pub fn inject_serial_input(&mut self, bytes: &[u8]) {
        <B::A as Vendor>::inject_serial_input(&mut self.devices, bytes);
    }

    pub fn serial_output(&self) -> &[u8] {
        <B::A as Vendor>::serial_capture(&self.devices)
    }

    pub fn inspect_vcpu(&mut self) -> Result<VcpuOf<B>, VmmError> {
        self.current_vcpu()
    }

    pub fn has_inflight_event_injection(&mut self) -> Result<bool, VmmError> {
        Ok(<B::A as Vendor>::vcpu_has_inflight_injection(
            &self.current_vcpu()?,
        ))
    }

    pub fn has_active_event_injection(&mut self) -> Result<bool, VmmError> {
        Ok(<B::A as Vendor>::vcpu_has_active_injection(
            &self.current_vcpu()?,
        ))
    }

    pub fn restore_guest_memory(&mut self, image: &[u8]) -> Result<(), VmmError> {
        const PAGE_SIZE: usize = 4096;
        let ram = self.ram.as_mut_bytes();
        if image.len() != ram.len() {
            return Err(VmmError::ContractViolation(format!(
                "restore_guest_memory: image is {} bytes, guest RAM is {} bytes",
                image.len(),
                ram.len()
            )));
        }
        let base = ram.as_mut_ptr() as usize;
        let mut written: Vec<(usize, usize)> = Vec::new();
        for (index, (target, source)) in ram
            .chunks_mut(PAGE_SIZE)
            .zip(image.chunks(PAGE_SIZE))
            .enumerate()
        {
            if target == source {
                continue;
            }
            target.copy_from_slice(source);
            extend_written(&mut written, index * PAGE_SIZE, source.len());
        }
        for &(offset, len) in &written {
            self.page_digests.mark_range(offset, len);
        }
        self.invalidate_written_instructions(base, &written);
        self.host_dirty_wholesale = true;
        Ok(())
    }

    fn invalidate_written_instructions(&mut self, base: usize, written: &[(usize, usize)]) {
        for &(offset, len) in written {
            self.backend
                .invalidate_instruction_cache(base + offset, len);
        }
    }

    pub fn save_vtime(&self) -> Result<Option<VtimeSnapshot>, VmmError> {
        match &self.vtime {
            None => Ok(None),
            Some(vt) => Ok(Some(VtimeSnapshot {
                vns: vt.clock.vns(),
                guest_clock_offset: vt.guest_clock_offset,
                entropy: vt.entropy.save_state(),
            })),
        }
    }

    pub fn effective_vns(&self) -> Option<u64> {
        self.vtime.as_ref().map(|vt| vt.clock.vns())
    }

    pub fn virtual_time_progress(&self) -> Option<std::sync::Arc<std::sync::atomic::AtomicU64>> {
        self.vtime
            .as_ref()
            .map(|_| std::sync::Arc::clone(&self.virtual_time_progress))
    }

    pub fn restore_vtime(&mut self, snap: &VtimeSnapshot) -> Result<(), VmmError> {
        <B::A as Vendor>::validate_vtime_clock_offset(snap.guest_clock_offset)?;
        let (clock, cfg, entropy) = {
            let vt = self.vtime.as_ref().ok_or_else(|| {
                VmmError::ContractViolation(
                    "restore_vtime called but V-time is not wired".to_string(),
                )
            })?;
            let mut cfg = vt.cfg;
            cfg.vns_base = snap.vns;
            let clock = VClock::new(cfg)?;
            let mut entropy = vt.entropy.clone();
            entropy.restore_state(&snap.entropy).map_err(|e| {
                VmmError::ContractViolation(format!("entropy snapshot rejected on restore: {e:?}"))
            })?;
            (clock, cfg, entropy)
        };
        let vt = self.vtime.as_mut().ok_or_else(|| {
            VmmError::ContractViolation("restore_vtime called but V-time is not wired".to_string())
        })?;
        vt.clock = clock;
        vt.cfg = cfg;
        vt.entropy = entropy;
        vt.guest_clock_offset = snap.guest_clock_offset;
        self.virtual_time_progress
            .store(snap.vns, std::sync::atomic::Ordering::Release);
        if self
            .pvclock
            .as_ref()
            .is_some_and(|pv| pv.gpa.is_some() && pv.armed)
        {
            self.pvclock_stamp(StampKind::Refresh)?;
        }
        Ok(())
    }

    pub fn prepare_snapshot(&mut self) -> Result<(), VmmError> {
        self.snapshot_ready = false;
        self.backend.prepare_snapshot()?;
        self.saved_state = None;
        self.snapshot_ready = true;
        Ok(())
    }

    fn ensure_snapshot_ready(&mut self) -> Result<(), VmmError> {
        if !self.snapshot_ready {
            self.prepare_snapshot()?;
        }
        Ok(())
    }

    pub fn save_vm_state(&mut self) -> Result<<B::A as Vendor>::Snapshot, VmmError> {
        self.capture_vm_state().map(|(snapshot, _)| snapshot)
    }

    pub(crate) fn capture_vm_state(
        &mut self,
    ) -> Result<(<B::A as Vendor>::Snapshot, VcpuOf<B>), VmmError> {
        self.ensure_snapshot_ready()?;
        let vcpu = match &self.saved_state {
            Some(s) => s.clone(),
            None => self.backend.save()?,
        };
        self.backend.validate_snapshot_state(&vcpu)?;
        <B::A as Vendor>::check_sealable_vcpu(&vcpu)?;
        self.check_guest_mode(&vcpu)?;
        let snapshot = self.build_snapshot_state(&vcpu)?;
        if self.doorbell_pages.is_some()
            && <B::A as Vendor>::project_snapshot_hash_parts(&snapshot)?
                .doorbell
                .is_none()
        {
            return Err(VmmError::ContractViolation(
                "save_vm_state: mapped doorbell pages are absent from the VM state".into(),
            ));
        }
        Ok((snapshot, vcpu))
    }

    fn check_guest_mode(&self, vcpu: &VcpuOf<B>) -> Result<(), VmmError> {
        if self.require_long_mode {
            <B::A as Vendor>::check_long_mode_vcpu(vcpu)?;
        }
        Ok(())
    }

    fn engine_state(&self) -> crate::engine_state::EngineState {
        crate::engine_state::EngineState {
            terminal: self.terminal,
            sdk_snapshot_reentry_required: self.sdk_snapshot_reentry_required,
        }
    }

    fn build_snapshot_state(
        &self,
        vcpu: &VcpuOf<B>,
    ) -> Result<<B::A as Vendor>::Snapshot, VmmError> {
        let mut state = <B::A as Vendor>::build_vm_state(self, vcpu);
        state.set_engine_state(self.engine_state().encode()?);
        Ok(state)
    }

    fn prepare_restore_vm_state(
        &self,
        s: &<B::A as Vendor>::Snapshot,
        validation: RestoreValidation,
    ) -> Result<RestorePreparation<B>, VmmError> {
        let engine_state = EngineState::decode(s.engine_state())?;
        if *s.timers() != vm_state::TimerQueueState::default() {
            return Err(VmmError::ContractViolation(
                "restore_vm_state: snapshot carries a non-empty timer queue, but vmm-core has no \
                 TimerQueue to apply it — restoring would silently drop it. (A vmm-core snapshot \
                 always seals an empty timer queue; the fabric timer rides the device blob.)"
                    .to_string(),
            ));
        }
        let (vcpu, clock_offset, prep) = <B::A as Vendor>::validate_restore(self, s)?;
        self.check_guest_mode(&vcpu)?;
        let backend_validation = match validation {
            RestoreValidation::CurrentBackend => self.backend.validate_restore_state(&vcpu),
            RestoreValidation::ImportedArtifact => self.backend.validate_import_state(&vcpu),
        };
        backend_validation.map_err(|error| {
            VmmError::ContractViolation(format!(
                "restore_vm_state: backend rejected snapshot shape: {error}"
            ))
        })?;
        let svt = s.vtime();
        let vtime_commit = match self.vtime.as_ref() {
            Some(vt) => {
                if svt.guest_hz != vt.cfg.guest_hz || svt.guest_base != vt.cfg.guest_base {
                    return Err(VmmError::ContractViolation(
                        "restore_vm_state: V-time clock mismatch (the snapshot's guest_hz/\
                         guest_base differ from this VM's wired clock)."
                            .to_string(),
                    ));
                }
                let mut cfg = vt.cfg;
                cfg.vns_base = svt.snapshot_vns;
                let clock = VClock::new(cfg)?;
                let mut entropy = vt.entropy.clone();
                entropy.restore_state(s.entropy_bytes()).map_err(|e| {
                    VmmError::ContractViolation(format!(
                        "entropy snapshot rejected on restore: {e:?}"
                    ))
                })?;
                Some((cfg, clock, entropy))
            }
            None => {
                let is_unwired_sentinel = svt.guest_hz == 0
                    && svt.guest_base == 0
                    && svt.snapshot_vns == 0
                    && s.entropy_bytes().is_empty();
                if !is_unwired_sentinel {
                    return Err(VmmError::ContractViolation(
                        "restore_vm_state: snapshot carries live V-time/entropy state but this VM \
                         has no V-time wired — restore into a VM composed like the snapshot source."
                            .to_string(),
                    ));
                }
                None
            }
        };
        Ok(RestorePreparation {
            engine_state,
            vcpu,
            clock_offset,
            vendor: prep,
            vtime: vtime_commit,
        })
    }

    fn checked_restore_preparation(
        &self,
        s: &<B::A as Vendor>::Snapshot,
    ) -> Result<RestorePreparation<B>, VmmError> {
        if self.completion_staged {
            return Err(VmmError::ContractViolation(
                "restore_vm_state into a backend with a staged completion: the VM just serviced a \
                 read/MSR/CPUID exit whose completion is pending in kvm_run and is not \
                 cleared by restore — it would commit the old exit on the next run. Complete and \
                 retire the old exit first, or use a freshly-booted VM."
                    .to_string(),
            ));
        }
        let preparation = self.prepare_restore_vm_state(s, RestoreValidation::CurrentBackend)?;
        if let Some(trace) = self.virtual_time_trace.as_ref() {
            trace
                .preflight_restore_clockevent_schedule(
                    <B::A as Vendor>::restored_clockevent_trace_schedule_present(
                        self,
                        &preparation.vendor,
                    ),
                )
                .map_err(|message| {
                    VmmError::Backend(vmm_backend::BackendError::Internal(message))
                })?;
        }
        Ok(preparation)
    }

    pub(crate) fn validate_restore_vm_state(
        &self,
        s: &<B::A as Vendor>::Snapshot,
    ) -> Result<(), VmmError> {
        self.checked_restore_preparation(s).map(|_| ())
    }

    pub fn restore_vm_state(&mut self, s: &<B::A as Vendor>::Snapshot) -> Result<(), VmmError> {
        let RestorePreparation {
            engine_state,
            vcpu,
            clock_offset,
            vendor,
            vtime,
        } = self.checked_restore_preparation(s)?;
        self.snapshot_ready = false;
        self.backend.restore(&vcpu)?;
        if let Some((cfg, clock, entropy)) = vtime {
            let vt = self.vtime.as_mut().expect("vtime_commit implies wired");
            vt.cfg = cfg;
            vt.clock = clock;
            vt.entropy = entropy;
            vt.guest_clock_offset = clock_offset;
        }
        <B::A as Vendor>::commit_restore(self, vendor);
        let restored_clockevent = <B::A as Vendor>::clockevent_trace_schedule(self);
        if let Some(trace) = self.virtual_time_trace.as_mut() {
            trace
                .restore_clockevent_schedule(restored_clockevent)
                .map_err(|message| {
                    VmmError::Backend(vmm_backend::BackendError::Internal(message))
                })?;
        }
        self.terminal = engine_state.terminal;
        self.saved_state = None;
        self.completion_staged = false;
        self.sdk_snapshot_reentry_required = engine_state.sdk_snapshot_reentry_required;
        self.snapshot_ready = true;
        if let Some(vt) = self.vtime.as_ref() {
            self.virtual_time_progress
                .store(vt.virtual_time_vns(), std::sync::atomic::Ordering::Release);
        }
        Ok(())
    }

    pub fn restore_snapshot(
        &mut self,
        memory: &[u8],
        vm_state: &<B::A as Vendor>::Snapshot,
    ) -> Result<(), VmmError> {
        if memory.len() != self.ram.len() {
            return Err(VmmError::ContractViolation(format!(
                "restore_snapshot: image is {} bytes, guest RAM is {} bytes",
                memory.len(),
                self.ram.len()
            )));
        }
        self.restore_vm_state(vm_state)?;
        self.restore_guest_memory(memory)?;
        self.prepare_snapshot()?;
        Ok(())
    }

    pub fn reseed_entropy(&mut self, seed: u64) -> Result<(), VmmError> {
        let Some(vt) = self.vtime.as_mut() else {
            return Err(VmmError::ContractViolation(
                "reseed_entropy: the seeded-entropy path is not wired, so there is no stream to fork for a branch."
                    .to_owned(),
            ));
        };

        vt.entropy = SeededEntropy::new(seed);
        Ok(())
    }

    pub fn step(&mut self) -> Result<Step, VmmError> {
        self.step_until(None)
    }

    pub(crate) fn step_until(&mut self, deadline_vns: Option<u64>) -> Result<Step, VmmError> {
        self.run_deadline_vns = deadline_vns;
        let result = self.step_inner();
        self.run_deadline_vns = None;
        result
    }

    fn step_inner(&mut self) -> Result<Step, VmmError> {
        self.last_step_control_idle_landing_vns = None;
        if self.pending_service_question().is_some() {
            return Ok(Step::SdkStop);
        }
        if let Some((moment, requested_len, request)) = self.pending_deferred_doorbell() {
            if self
                .run_deadline_vns
                .is_some_and(|deadline| moment >= deadline)
            {
                return Ok(Step::SdkStop);
            }
            self.sdk
                .as_mut()
                .expect("deferred doorbell has SDK")
                .pending_stop = None;
            let step = self.finish_doorbell(moment, requested_len, &request)?;
            self.pvclock_refresh()?;
            <B::A as Vendor>::post_exit(self)?;
            if self.pending_coverage_callbacks != 0 {
                self.charge_coverage_callbacks();
                self.pvclock_refresh()?;
            }
            return Ok(step);
        }
        if let Some(reason) = self.terminal {
            return Ok(Step::Terminal(reason));
        }
        <B::A as Vendor>::service_pending_irqs(self)?;
        self.snapshot_ready = false;
        #[allow(clippy::disallowed_methods)]
        let entered = std::time::Instant::now();
        let mut exit = self.backend.run()?;
        self.exit_telemetry
            .guest_runs
            .add(entered.elapsed().as_nanos());
        self.sdk_snapshot_reentry_required = false;
        let mut stop = Step::Continued;
        let mut checkpoint_due = false;
        loop {
            let (site, write) = exit.site();
            let site = crate::host_telemetry::ExitSite {
                reason: exit.reason(),
                site,
                write,
            };
            #[allow(clippy::disallowed_methods)]
            let serviced = std::time::Instant::now();
            let ExitProgress { step, continuation } =
                self.service_exit(exit, &mut checkpoint_due)?;
            self.exit_telemetry
                .exits
                .entry(site)
                .or_default()
                .add(serviced.elapsed().as_nanos());
            if step != Step::Continued {
                stop = step;
            }
            match continuation {
                Some(next) => exit = next,
                None => return Ok(stop),
            }
        }
    }

    pub(crate) fn record_guest_completion(&mut self, result: &[u8]) -> Result<(), VmmError> {
        if let Some(trace) = self.virtual_time_trace.as_mut() {
            trace
                .record_completion(result)
                .map_err(|message| VmmError::ContractViolation(message.into()))?;
        }
        Ok(())
    }

    pub(crate) fn complete_guest_read(&mut self, value: u64) -> Result<(), VmmError> {
        self.backend.complete_read(value)?;
        let mut result = [0; 9];
        result[1..].copy_from_slice(&value.to_le_bytes());
        self.record_guest_completion(&result)
    }

    pub(crate) fn complete_guest_fault(&mut self) -> Result<(), VmmError> {
        self.backend.complete_fault()?;
        self.record_guest_completion(&[1])
    }

    fn service_exit(
        &mut self,
        exit: Exit<B::A>,
        checkpoint_due: &mut bool,
    ) -> Result<ExitProgress<B::A>, VmmError> {
        if <B::A as Vendor>::is_doorbell_exit(&exit) {
            self.doorbell_exits = self.doorbell_exits.saturating_add(1);
        }
        let trace_started = if let Some(trace) = self.virtual_time_trace.as_mut() {
            if let Some((class, payload)) = <B::A as Vendor>::normalize_virtual_time_exit(&exit) {
                let reason = exit.reason();
                let backend_debug = format!("{reason:?}");
                trace
                    .begin(reason, backend_debug, class, payload)
                    .map_err(|message| VmmError::ContractViolation(message.to_string()))?;
                true
            } else {
                let reason = exit.reason();
                let backend_debug = format!("{reason:?}");
                trace
                    .begin_raw(reason, backend_debug)
                    .map_err(|message| VmmError::ContractViolation(message.to_string()))?;
                true
            }
        } else {
            false
        };
        self.completion_staged = exit.stages_completion();
        <B::A as Vendor>::complete_irq_delivery(self);
        let step = match exit {
            Exit::Common(CommonExit::Idle) => self.on_idle(),
            Exit::Common(CommonExit::Shutdown) => Ok(self.terminate(TerminalReason::Shutdown)),
            Exit::Common(CommonExit::Mmio { gpa, size, write }) => {
                <B::A as Vendor>::dispatch_mmio(self, gpa, size, write)
            }
            Exit::Common(CommonExit::Hypercall(_)) => Err(VmmError::ContractViolation(
                "unmodeled hypercall-instruction exit (host handler is a later phase; the \
                 cooperating-guest channel rides the doorbell)"
                    .to_string(),
            )),
            Exit::Arch(e) => <B::A as Vendor>::dispatch_arch(self, e),
        }?;
        self.pvclock_refresh()?;
        <B::A as Vendor>::post_exit(self)?;
        let next = <B::A as Vendor>::finish_exit(self)?;
        if trace_started
            && self
                .virtual_time_trace
                .as_ref()
                .is_some_and(LiveVirtualTimeTrace::normalized_event_pending)
        {
            let event_index = self
                .virtual_time_trace
                .as_ref()
                .expect("trace was started")
                .current_event_index()
                .map_err(|message| VmmError::ContractViolation(message.to_string()))?;
            *checkpoint_due |= (event_index + 1).is_multiple_of(256);
            if *checkpoint_due && next.is_none() {
                self.virtual_time_checkpoint_events.insert(event_index);
            }
            let state_hash = if synchronous_checkpoint_due(
                *checkpoint_due && next.is_none(),
                self.deferred_virtual_time_checkpoints,
            ) {
                let (hash, suffix, memory_digest) =
                    self.state_hash_preimage(crate::host_telemetry::HashSite::Checkpoint)?;
                if self.checkpoint_hash_preimage_armed {
                    self.checkpoint_hash_preimage = Some(CheckpointHashPreimage {
                        event_index,
                        state_hash: hash,
                        state_blob_suffix: suffix,
                        memory_digest,
                        memory_length: self.ram.as_bytes().len(),
                    });
                }
                Some(hash)
            } else {
                None
            };
            let vns_after = self
                .vtime
                .as_ref()
                .ok_or_else(|| {
                    VmmError::ContractViolation(
                        "virtual_time trace completed without V-time wiring".to_string(),
                    )
                })?
                .virtual_time_vns();
            self.virtual_time_trace
                .as_mut()
                .expect("trace was started")
                .finish(vns_after, state_hash)
                .map_err(|message| VmmError::ContractViolation(message.to_string()))?;
        } else if trace_started {
            self.virtual_time_trace
                .as_mut()
                .expect("raw trace was started")
                .finish_raw()
                .map_err(|message| VmmError::ContractViolation(message.to_string()))?;
        }
        if self.pending_coverage_callbacks != 0 {
            self.charge_coverage_callbacks();
            self.pvclock_refresh()?;
        }
        Ok(ExitProgress {
            step,
            continuation: next,
        })
    }

    pub fn run(&mut self) -> Result<RunResult, VmmError> {
        let reason = loop {
            match self.step()? {
                Step::Terminal(r) => break r,
                Step::SdkStop => break TerminalReason::SdkStop,
                Step::Continued => {}
            }
        };
        let sdk_stop = if reason == TerminalReason::SdkStop {
            self.take_sdk_stop()
        } else {
            None
        };
        if reason == TerminalReason::SdkStop {
            self.saved_state = None;
        } else {
            self.saved_state = Some(self.backend.save()?);
        }
        Ok(RunResult {
            reason,
            sdk_stop,
            serial: <B::A as Vendor>::serial_capture(&self.devices).to_vec(),
            exit_counts: self.backend.exit_counts(),
        })
    }

    pub fn state_blob(&mut self) -> Result<Vec<u8>, VmmError> {
        let mut out = Vec::new();
        put_chunk(&mut out, b"MEM\0", self.ram.as_bytes());
        out.extend_from_slice(&self.state_blob_suffix()?);
        Ok(out)
    }

    pub(crate) fn state_blob_suffix(&mut self) -> Result<Vec<u8>, VmmError> {
        self.ensure_snapshot_ready()?;
        let vcpu = match &self.saved_state {
            Some(state) => state.clone(),
            None => self.backend.save()?,
        };
        self.state_blob_suffix_from_vcpu(&vcpu, None)
    }

    pub(crate) fn state_blob_suffix_from_vcpu(
        &self,
        vcpu: &VcpuOf<B>,
        sdk_recorded: Option<&channel::RecordedState>,
    ) -> Result<Vec<u8>, VmmError> {
        let mut out = Vec::new();
        let vcpu = <B::A as Vendor>::logical_identity_vcpu(vcpu)?;
        if let Some(db) = &self.doorbell_pages {
            put_chunk(&mut out, b"DOOR", db.as_bytes());
        }
        put_chunk(
            &mut out,
            b"VCPU",
            &<B::A as Vendor>::encode_vcpu_chunk(&vcpu),
        );
        put_chunk(
            &mut out,
            b"SERL",
            <B::A as Vendor>::serial_capture(&self.devices),
        );
        put_chunk(&mut out, b"DEV\0", &self.encode_device_terminal());
        if let Some(vt) = &self.vtime {
            put_chunk(&mut out, b"VTIM", &encode_vtime(vt));
        }
        <B::A as Vendor>::hash_device_chunks(&vcpu, &self.devices, &mut out);
        if let Some(contract) = <B::A as Vendor>::contract_identity_hash(self) {
            put_chunk(&mut out, b"CNTR", &contract);
        }
        if let Some(sdk) = &self.sdk {
            append_sdk_channel(&mut out, sdk, sdk_recorded)?;
        }
        if let Some(pv) = &self.pvclock {
            let mut bytes = 1_u64.to_le_bytes().to_vec();
            match pv.gpa {
                Some(gpa) => {
                    bytes.push(1);
                    bytes.extend_from_slice(&gpa.to_le_bytes());
                }
                None => bytes.push(0),
            }
            bytes.push(u8::from(self.pvclock_available()));
            bytes.push(u8::from(pv.armed));
            put_chunk(&mut out, b"PVCK", &bytes);
        }
        if self.sdk_snapshot_reentry_required {
            put_chunk(&mut out, b"SDRE", &[1]);
        }
        if self.snapshot_hashing {
            let snapshot = self.build_snapshot_state(&vcpu)?;
            let bytes = <<B::A as Vendor>::Snapshot as SnapshotRecords>::encode_for_hash(&snapshot)
                .map_err(SnapshotError::from)?;
            put_chunk(&mut out, b"VMST", &bytes);
        }
        Ok(out)
    }

    pub(crate) fn project_state_blob_suffix_from_snapshot(
        &self,
        snapshot: &<B::A as Vendor>::Snapshot,
        sdk: &SdkSnapshot,
    ) -> Result<Vec<u8>, VmmError> {
        let prepared =
            self.prepare_restore_vm_state(snapshot, RestoreValidation::ImportedArtifact)?;
        let parts = <B::A as Vendor>::project_snapshot_hash_parts(snapshot)?;
        if self.doorbell_pages.is_some() != parts.doorbell.is_some() {
            return Err(VmmError::ContractViolation(
                "restore_vm_state: mapped doorbell pages have no matching snapshot state".into(),
            ));
        }
        let vcpu = <B::A as Vendor>::logical_identity_vcpu(&prepared.vcpu)?;
        let mut out = Vec::new();
        if let Some(doorbell) = parts.doorbell {
            put_chunk(&mut out, b"DOOR", &doorbell);
        }
        put_chunk(
            &mut out,
            b"VCPU",
            &<B::A as Vendor>::encode_vcpu_chunk(&vcpu),
        );
        put_chunk(&mut out, b"SERL", &parts.serial);
        let mut device = parts.device;
        append_terminal(&mut device, prepared.engine_state.terminal);
        put_chunk(&mut out, b"DEV\0", &device);
        if self.vtime.is_some() {
            put_chunk(
                &mut out,
                b"VTIM",
                &encode_vtime_parts(
                    snapshot.vtime().guest_hz,
                    snapshot.vtime().guest_base,
                    parts.clock_offset,
                    snapshot.vtime().snapshot_vns,
                    snapshot.entropy_bytes(),
                ),
            );
        }
        out.extend_from_slice(&parts.vendor_chunks);
        if let Some(contract) = <B::A as Vendor>::contract_identity_hash(self) {
            put_chunk(&mut out, b"CNTR", &contract);
        }
        append_sdk_snapshot(&mut out, sdk);
        if let Some(pvclock) = parts.pvclock {
            let mut bytes = 1_u64.to_le_bytes().to_vec();
            match pvclock.gpa {
                Some(gpa) => {
                    bytes.push(1);
                    bytes.extend_from_slice(&gpa.to_le_bytes());
                }
                None => bytes.push(0),
            }
            bytes.push(u8::from(pvclock.registrable));
            bytes.push(u8::from(pvclock.armed));
            put_chunk(&mut out, b"PVCK", &bytes);
        }
        if prepared.engine_state.sdk_snapshot_reentry_required {
            put_chunk(&mut out, b"SDRE", &[1]);
        }
        if self.snapshot_hashing {
            let mut logical_snapshot = snapshot.clone();
            <B::A as Vendor>::project_logical_snapshot(&mut logical_snapshot, &vcpu);
            let bytes =
                <<B::A as Vendor>::Snapshot as SnapshotRecords>::encode_for_hash(&logical_snapshot)
                    .map_err(SnapshotError::from)?;
            put_chunk(&mut out, b"VMST", &bytes);
        }
        Ok(out)
    }

    fn encode_device_terminal(&self) -> Vec<u8> {
        let mut v = <B::A as Vendor>::encode_device_state(&self.devices);
        append_terminal(&mut v, self.terminal);
        v
    }

    pub fn state_hash(&mut self) -> Result<[u8; 32], VmmError> {
        self.state_hash_preimage(crate::host_telemetry::HashSite::WholeRequest)
            .map(|(hash, _, _)| hash)
    }

    pub(crate) fn hash_telemetry(&self) -> crate::host_telemetry::HashTelemetry {
        self.hash_telemetry.get()
    }

    fn state_hash_preimage(
        &mut self,
        site: crate::host_telemetry::HashSite,
    ) -> Result<StateHashPreimage, VmmError> {
        let mut work = crate::host_telemetry::HashWork::new();
        let result = (|| {
            let memory_digest = self.memory_digest(&mut work)?;
            let suffix = self.state_blob_suffix()?;
            let hash = crate::state_digest::state_hash(&memory_digest, &suffix, &mut work);
            Ok((hash, suffix, memory_digest))
        })();
        work.finish(&self.hash_telemetry, site, result.is_err());
        result
    }

    pub fn state_components(&mut self) -> Result<Vec<(&'static str, [u8; 32])>, VmmError> {
        fn dig(bytes: &[u8]) -> [u8; 32] {
            let mut h = Sha256::new();
            h.update(bytes);
            h.finalize().into()
        }
        let vcpu = self.current_vcpu()?;
        let mut out: Vec<(&'static str, [u8; 32])> = Vec::new();

        let ram = self.ram.as_bytes();
        let region = |lo: usize, hi: usize| {
            let (lo, hi) = (lo.min(ram.len()), hi.min(ram.len()));
            dig(&ram[lo..hi])
        };
        out.push(("RAM:0..64K", region(0, 0x1_0000)));
        out.push(("RAM:64K..1M", region(0x1_0000, 0x10_0000)));
        out.push(("RAM:1M..2M", region(0x10_0000, 0x20_0000)));
        out.push(("RAM:2M..16M", region(0x20_0000, 0x100_0000)));
        out.push(("RAM:16M..", region(0x100_0000, ram.len())));
        if let Some(db) = &self.doorbell_pages {
            out.push(("doorbell", dig(db.as_bytes())));
        }

        <B::A as Vendor>::vcpu_components(&vcpu, &mut out);

        out.push((
            "serial",
            dig(<B::A as Vendor>::serial_capture(&self.devices)),
        ));
        out.push(("dev", dig(&self.encode_device_terminal())));
        <B::A as Vendor>::device_components(&vcpu, &self.devices, &mut out);
        if let Some(contract) = <B::A as Vendor>::contract_identity_hash(self) {
            out.push(("contract", contract));
        }
        if let Some(vt) = &self.vtime {
            let mut cfg = 1_u64.to_le_bytes().to_vec();
            for x in [vt.cfg.guest_hz, vt.cfg.guest_base, vt.guest_clock_offset] {
                cfg.extend_from_slice(&x.to_le_bytes());
            }
            out.push(("vtim:cfg", dig(&cfg)));
            out.push(("vtim:eff-vns", dig(&vt.clock.vns().to_le_bytes())));
            out.push(("vtim:entropy", dig(&vt.entropy.save_state())));
        }
        Ok(out)
    }

    pub fn report_stream(&self) -> &[u32] {
        &self.report_stream
    }

    pub fn idle_landings(&self) -> &[u64] {
        &self.idle_landings
    }

    #[cfg(feature = "xsave-diagnostics")]
    pub fn diagnostic_breakpoint(&mut self, rip: u64) -> Result<(), VmmError> {
        self.backend
            .diagnostic_breakpoint(rip)
            .map_err(VmmError::from)
    }

    #[cfg(feature = "xsave-diagnostics")]
    pub fn diagnostic_debug_hits(&self) -> Vec<u64> {
        self.backend.diagnostic_debug_hits()
    }

    pub fn serial(&self) -> &[u8] {
        <B::A as Vendor>::serial_capture(&self.devices)
    }

    pub fn exit_counts(&self) -> vmm_backend::ExitCounts {
        self.backend.exit_counts()
    }

    pub fn cancellation_flag(&self) -> Option<std::sync::Arc<std::sync::atomic::AtomicBool>> {
        self.backend.cancellation_flag()
    }

    pub fn doorbell_exits(&self) -> u64 {
        self.doorbell_exits
    }

    pub(crate) fn physical_telemetry(&self) -> vmm_backend::PhysicalTelemetry {
        self.backend.physical_telemetry()
    }

    pub fn exit_telemetry(&self) -> crate::host_telemetry::ExitTelemetry {
        let mut telemetry = self.exit_telemetry.clone();
        telemetry.store_completions = self.backend.store_completions();
        telemetry
    }

    pub fn terminal_reason(&self) -> Option<TerminalReason> {
        self.terminal
    }

    pub fn observable_digest(&self) -> [u8; 32] {
        let report_stream = &self.report_stream;
        let serial = <B::A as Vendor>::serial_capture(&self.devices);
        let mut hasher = sha2::Sha256::new();
        hasher.update(b"OBSV");
        hasher.update((report_stream.len() as u64).to_le_bytes());
        for v in report_stream {
            hasher.update(v.to_le_bytes());
        }
        hasher.update((serial.len() as u64).to_le_bytes());
        hasher.update(serial);
        hasher.finalize().into()
    }

    pub(crate) fn terminate(&mut self, reason: TerminalReason) -> Step {
        self.terminal = Some(reason);
        Step::Terminal(reason)
    }

    pub fn enable_sdk(
        &mut self,
        env: channel::RecordedEnv<Box<dyn channel::ServiceHandler>>,
        _config: &ServiceConfig,
    ) -> &mut Self {
        self.sdk = Some(SdkChannel {
            env,
            events: Vec::new(),
            coverage_thresholds: BTreeMap::new(),
            coverage: Vec::new(),
            pending_stop: None,
            pending_snapshot: false,
        });
        self
    }

    #[cfg(test)]
    pub(crate) fn sdk_is_enabled(&self) -> bool {
        self.sdk.is_some()
    }

    pub fn enable_pvclock(&mut self) -> &mut Self {
        self.pvclock = Some(PvclockChannel {
            gpa: None,
            armed: false,
            refreshes: Vec::new(),
        });
        self
    }

    pub fn pvclock_offered(&self) -> bool {
        self.pvclock.is_some()
    }

    fn pvclock_available(&self) -> bool {
        self.pvclock.is_some() && self.vtime.is_some()
    }

    fn doorbell_service_offered(&self, service: u16) -> bool {
        match service {
            s if s == ServiceId::Event as u16 => self.sdk.is_some(),
            s if s == ServiceId::Sdk as u16 => self.sdk.is_some(),
            s if s == ServiceId::Entropy as u16 => self.sdk.is_some(),
            s if s == ServiceId::Payload as u16 => self
                .sdk
                .as_ref()
                .is_some_and(|sdk| sdk.env.payload_configured()),
            s if s == ServiceId::Pvclock as u16 => self.pvclock_available(),
            _ => false,
        }
    }

    pub fn pvclock_registration(&self) -> Option<u64> {
        self.pvclock.as_ref().and_then(|pv| pv.gpa)
    }

    pub fn pvclock_snapshot(&self) -> Option<PvclockSnapshot> {
        let registrable = self.pvclock_available();
        self.pvclock.as_ref().map(|pv| PvclockSnapshot {
            gpa: pv.gpa,
            registrable,
            armed: pv.armed,
        })
    }

    pub(crate) fn pvclock_validate_restore(
        &self,
        rec: Option<&PvclockSnapshot>,
    ) -> Result<(), VmmError> {
        match (rec, self.pvclock.as_ref()) {
            (None, None) => Ok(()),
            (None, Some(_)) => Err(VmmError::ContractViolation(
                "restore_vm_state: this VM offers the pvclock page but the snapshot's VM did \
                 not — a guest registering here would fork the timeline off the sealed one; \
                 restore into a VM composed like the snapshot source."
                    .to_string(),
            )),
            (Some(snapshot), None) => Err(VmmError::ContractViolation(format!(
                "restore_vm_state: snapshot carries a pvclock channel (registration \
                 {:#x?}) but this VM was composed without enable_pvclock — \
                 restore into a VM composed like the snapshot source.",
                snapshot.gpa
            ))),
            (Some(snapshot), Some(_pv)) => {
                if snapshot.armed && snapshot.gpa.is_none() {
                    return Err(VmmError::ContractViolation(
                        "restore_vm_state: pvclock record is armed without a registered page"
                            .to_string(),
                    ));
                }
                if snapshot.gpa.is_some() && !snapshot.registrable {
                    return Err(VmmError::ContractViolation(
                        "restore_vm_state: pvclock record has a registration but is marked non-registrable"
                            .to_string(),
                    ));
                }
                if snapshot.registrable != self.pvclock_available() {
                    return Err(VmmError::ContractViolation(format!(
                        "restore_vm_state: pvclock registration capability mismatch (the \
                         snapshot's VM {} register a clock page; this VM {}) — the restored \
                         guest's next registration would take a different branch than the \
                         sealed timeline's. Restore into a VM composed like the snapshot \
                         source (V-time wired, deterministic virtual-time clock).",
                        if snapshot.registrable {
                            "could"
                        } else {
                            "could NOT"
                        },
                        if self.pvclock_available() {
                            "can"
                        } else {
                            "can NOT"
                        }
                    )));
                }
                if let Some(gpa) = snapshot.gpa {
                    self.pvclock_validate_gpa(gpa).map_err(|reason| {
                        VmmError::ContractViolation(format!(
                            "restore_vm_state: snapshot pvclock page GPA {gpa:#x} does not \
                             validate on this VM ({reason}) — restore into a VM composed like \
                             the snapshot source."
                        ))
                    })?;
                }
                Ok(())
            }
        }
    }

    pub(crate) fn pvclock_commit_restore(&mut self, rec: Option<&PvclockSnapshot>) {
        if let Some(pv) = self.pvclock.as_mut() {
            let (gpa, armed) = rec.map_or((None, false), |snapshot| (snapshot.gpa, snapshot.armed));
            pv.armed = armed;
            pv.gpa = gpa;
            pv.refreshes.clear();
        }
    }

    pub fn pvclock_clear_refreshes(&mut self) {
        if let Some(pv) = self.pvclock.as_mut() {
            pv.refreshes.clear();
        }
    }

    pub fn pvclock_refreshes(&self) -> &[(u64, u64)] {
        self.pvclock
            .as_ref()
            .map(|pv| pv.refreshes.as_slice())
            .unwrap_or(&[])
    }

    pub fn pvclock_page(&self) -> Option<&[u8]> {
        let off = self.ram_offset_of(self.pvclock_registration()?)?;
        self.ram
            .as_bytes()
            .get(off..off + vtime::pvclock::PVCLOCK_PAGE_LEN)
    }

    pub fn pvclock_check_oracle(&self) -> Result<(), VmmError> {
        let Some(page) = self.pvclock_page() else {
            return Ok(());
        };
        let vt = self.vtime.as_ref().ok_or_else(|| {
            VmmError::ContractViolation(
                "pvclock page registered but V-time is not wired — registration requires the \
                 determinism path, so this is unreachable state"
                    .to_string(),
            )
        })?;
        let want_vns = vt.clock.vns();
        let want_gc = vt.guest_clock();
        let want_hz = vt.cfg.guest_hz;
        let Some(f) = vtime::pvclock::read(page) else {
            return Err(VmmError::ContractViolation(
                "pvclock page is not a stable ABI-v1 frame (odd seq or foreign abi_version) at a \
                 host-quiescent read — the stamp protocol never leaves the page mid-update"
                    .to_string(),
            ));
        };
        if (f.vns, f.guest_clock, f.guest_clock_hz) != (want_vns, want_gc, want_hz) {
            return Err(VmmError::ContractViolation(format!(
                "pvclock page diverges from the RDTSC-trap oracle: page \
                 (vns {}, guest_clock {}, hz {}) vs oracle (vns {want_vns}, guest_clock \
                 {want_gc}, hz {want_hz})",
                f.vns, f.guest_clock, f.guest_clock_hz
            )));
        }
        if f.flags != vtime::pvclock::PVCLOCK_FLAGS_V1 {
            return Err(VmmError::ContractViolation(format!(
                "pvclock page flags {:#x} != the ABI-v1 MATERIALIZED|EXIT_COUNT_DERIVED word {:#x} — a \
                 placeholder or corrupted page, never a real exit-count-derived stamp",
                f.flags,
                vtime::pvclock::PVCLOCK_FLAGS_V1
            )));
        }
        Ok(())
    }

    fn pvclock_validate_gpa(&self, gpa: u64) -> Result<(), &'static str> {
        let page_len = vtime::pvclock::PVCLOCK_PAGE_LEN as u64;
        if !gpa.is_multiple_of(page_len) {
            return Err("not page-aligned");
        }
        let off = self.ram_offset_of(gpa).ok_or("below the guest RAM base")? as u64;
        let end = off.checked_add(page_len).ok_or("address overflow")?;
        if end > self.ram.as_bytes().len() as u64 {
            return Err("past the end of guest RAM");
        }
        if gpa == REQ_GPA as u64 || gpa == RESP_GPA as u64 {
            return Err("overlaps a doorbell frame page");
        }
        for &(hole, hole_len) in <B::A as Vendor>::mmio_holes() {
            let hole_end = hole.saturating_add(hole_len);
            if gpa < hole_end && hole < end {
                return Err("overlaps a device-MMIO hole (not backed as guest RAM)");
            }
        }
        Ok(())
    }

    pub(crate) fn pvclock_registration_status(&self, gpa: u64) -> (Status, Option<u32>) {
        if !self.pvclock_available() {
            return (Status::UnknownService, None);
        }
        if self.pvclock_registration().is_some() {
            return (Status::BadRequest, None);
        }
        if self.pvclock_validate_gpa(gpa).is_err() {
            return (Status::OutOfRange, None);
        }
        (Status::Ok, Some(vtime::pvclock::PVCLOCK_ABI_VERSION))
    }

    pub(crate) fn pvclock_register(&mut self, gpa: u64) -> (Status, Option<u32>) {
        let result = self.pvclock_registration_status(gpa);
        if result.0 != Status::Ok {
            return result;
        }
        let pv = self.pvclock.as_mut().expect("checked above");
        pv.gpa = Some(gpa);
        result
    }

    fn pvclock_stamp(&mut self, kind: StampKind) -> Result<(), VmmError> {
        let Some(pv) = self.pvclock.as_ref() else {
            return Ok(());
        };
        let Some(gpa) = pv.gpa else {
            return Ok(());
        };
        let Some(vt) = self.vtime.as_ref() else {
            return Err(VmmError::ContractViolation(
                "pvclock page registered but V-time is not wired".to_string(),
            ));
        };
        let vns = vt.clock.vns();
        let gc = vt.guest_clock();
        let hz = vt.cfg.guest_hz;
        let off = self.ram_offset_of(gpa);
        let ram = self.ram.as_mut_bytes();
        let Some(page) = off.and_then(|o| ram.get_mut(o..o + vtime::pvclock::PVCLOCK_PAGE_LEN))
        else {
            return Err(VmmError::ContractViolation(format!(
                "pvclock page {gpa:#x} no longer inside guest RAM — registration validated it, so \
                 the RAM backing changed underneath the channel"
            )));
        };
        let changed = match kind {
            StampKind::Refresh => vtime::pvclock::stamp(page, vns, gc, hz),
            StampKind::Canonical => vtime::pvclock::stamp_canonical(page, vns, gc, hz),
        };
        if !changed {
            return Ok(());
        }
        let readback = vtime::pvclock::read(page);
        if readback.map(|f| (f.vns, f.guest_clock, f.guest_clock_hz)) != Some((vns, gc, hz)) {
            return Err(VmmError::ContractViolation(format!(
                "pvclock stamp read-back mismatch: wrote (vns {vns}, \
                 guest_clock {gc}, hz {hz}) but the page decodes to {readback:?}"
            )));
        }
        self.mark_host_dirty(gpa, vtime::pvclock::PVCLOCK_PAGE_LEN as u64);
        if kind == StampKind::Refresh {
            let pv = self.pvclock.as_mut().expect("checked above");
            if pv.refreshes.len() < EVENT_TRACE_CAP {
                pv.refreshes.push((vns, gc));
            }
        }
        Ok(())
    }

    pub(crate) fn pvclock_set_irq_pending(&mut self, pending: bool) -> Result<(), VmmError> {
        let Some(gpa) = self
            .pvclock
            .as_ref()
            .filter(|pv| pv.armed)
            .and_then(|pv| pv.gpa)
        else {
            return Ok(());
        };
        let off = self.ram_offset_of(gpa);
        let ram = self.ram.as_mut_bytes();
        let Some(page) = off.and_then(|o| ram.get_mut(o..o + vtime::pvclock::PVCLOCK_PAGE_LEN))
        else {
            return Err(VmmError::ContractViolation(format!(
                "pvclock page {gpa:#x} no longer inside guest RAM"
            )));
        };
        if vtime::pvclock::set_irq_pending(page, pending) {
            self.mark_host_dirty(gpa, vtime::pvclock::PVCLOCK_PAGE_LEN as u64);
        }
        Ok(())
    }

    fn pvclock_refresh(&mut self) -> Result<(), VmmError> {
        let Some(pv) = self.pvclock.as_ref() else {
            return Ok(());
        };
        if pv.gpa.is_none() {
            return Ok(());
        }
        if !pv.armed {
            self.pvclock.as_mut().expect("checked above").armed = true;
            return self.pvclock_stamp(StampKind::Canonical);
        }
        self.pvclock_stamp(StampKind::Refresh)
    }

    pub fn sdk_snapshot(&self) -> Result<Option<SdkSnapshot>, channel::ChannelError> {
        self.sdk
            .as_ref()
            .map(|s| {
                Ok(SdkSnapshot {
                    recorded: s.env.snapshot_state()?,
                    events: s.events.clone(),
                    pending_snapshot: s.pending_snapshot,
                    pending_stop: s.pending_stop.clone(),
                    coverage_thresholds: s.coverage_thresholds.clone(),
                })
            })
            .transpose()
    }

    pub(crate) fn sdk_handler_fingerprint(
        &self,
    ) -> Result<Option<channel::HandlerFingerprint>, channel::ChannelError> {
        match self.sdk.as_ref() {
            None => Ok(None),
            Some(sdk) if sdk.env.is_poisoned() => Ok(None),
            Some(sdk) => sdk.env.handler_fingerprint().map(Some),
        }
    }

    pub(crate) fn verify_sdk_handler_unchanged(
        &self,
        before: &channel::HandlerFingerprint,
    ) -> Result<(), channel::ChannelError> {
        self.sdk
            .as_ref()
            .ok_or(channel::ChannelError::Poisoned)?
            .env
            .verify_handler_fingerprint_unchanged(before)
    }

    pub(crate) fn prepare_local_service_answer(
        &self,
    ) -> Result<Option<LocalServiceAnswer>, channel::ChannelError> {
        let Some(sdk) = &self.sdk else {
            return Ok(None);
        };
        let Some(SdkStop::Decision {
            moment, question, ..
        }) = &sdk.pending_stop
        else {
            return Ok(None);
        };
        channel::validate_local_services(sdk.env.handler().local_services())?;
        if sdk
            .env
            .handler()
            .local_services()
            .binary_search(&question.service())
            .is_err()
        {
            return Ok(None);
        }
        let before = sdk.env.handler_fingerprint()?;
        let mut environment = sdk.env.checked_clone()?;
        environment.set_moment(*moment);
        let response = environment.decide(question);
        let after = environment.handler_fingerprint();
        sdk.env.verify_handler_fingerprint_unchanged(&before)?;
        let response = response?;
        let channel::ServiceResponse::Answered(answer) = response else {
            return Ok(None);
        };
        if after? != before {
            return Err(channel::ChannelError::Handler(
                "local service answers must not change captured handler state".into(),
            ));
        }
        Ok(Some(LocalServiceAnswer {
            answer,
            moment: *moment,
            question: question.clone(),
            environment,
        }))
    }

    pub(crate) fn sdk_snapshot_after_answer(
        &self,
        moment: u64,
        question: &channel::Question,
        answer: &channel::Answer,
        local: Option<&LocalServiceAnswer>,
    ) -> Result<(), channel::ChannelError> {
        if let Some(sdk) = &self.sdk {
            let mut projected = if let Some(local) = local {
                if local.moment != moment || local.question != *question || local.answer != *answer
                {
                    return Err(channel::ChannelError::Malformed);
                }
                local.environment.checked_clone()?
            } else {
                sdk.env.checked_clone()?
            };
            projected.record_question(moment, question, answer.clone());
            projected.snapshot_state_with_binding_reserve()?;
            if let Some(SdkStop::CoverageDecision { ready, .. }) = &sdk.pending_stop {
                let observed = <[u8; 8]>::try_from(question.payload())
                    .map(u64::from_le_bytes)
                    .map_err(|_| channel::ChannelError::Malformed)?;
                let thread = u32::try_from(question.request_id())
                    .map_err(|_| channel::ChannelError::Malformed)?;
                let mut thresholds = sdk.coverage_thresholds.clone();
                if !matches!(
                    sdk::decide_coverage(
                        &mut projected,
                        &mut thresholds,
                        moment,
                        thread,
                        observed,
                        *ready,
                        None,
                    ),
                    Ok(CoverageOutcome::Answered(_))
                ) {
                    return Err(channel::ChannelError::Malformed);
                }
            }
        }
        Ok(())
    }

    pub fn sdk_restore(&mut self, snap: &SdkSnapshot) -> Result<(), channel::ChannelError> {
        if let Some(s) = self.sdk.as_mut() {
            snap.recorded.restore_into(&mut s.env)?;
            s.events = snap.events.clone();
            s.pending_snapshot = snap.pending_snapshot;
            s.pending_stop = snap.pending_stop.clone();
            s.coverage_thresholds = snap.coverage_thresholds.clone();
        }
        Ok(())
    }

    pub fn sdk_restore_events(&mut self, snap: &SdkSnapshot) {
        if let Some(s) = self.sdk.as_mut() {
            s.events = snap.events.clone();
            s.pending_snapshot = snap.pending_snapshot;
            s.pending_stop = snap.pending_stop.clone();
            s.coverage_thresholds = snap.coverage_thresholds.clone();
        }
    }

    pub fn sdk_events(&self) -> &[(u64, u32, Vec<u8>)] {
        self.sdk
            .as_ref()
            .map(|s| s.events.as_slice())
            .unwrap_or(&[])
    }

    pub fn take_sdk_stop(&mut self) -> Option<SdkStop> {
        self.sdk.as_mut().and_then(|s| {
            if matches!(
                s.pending_stop,
                Some(
                    SdkStop::Decision { .. }
                        | SdkStop::CoverageDecision { .. }
                        | SdkStop::DeferredDoorbell { .. }
                )
            ) {
                s.pending_stop.clone()
            } else {
                s.pending_stop.take()
            }
        })
    }

    fn pending_deferred_doorbell(&self) -> Option<(u64, u32, Vec<u8>)> {
        match self.sdk.as_ref()?.pending_stop.as_ref()? {
            SdkStop::DeferredDoorbell {
                moment,
                requested_len,
                request,
            } => Some((*moment, *requested_len, request.clone())),
            _ => None,
        }
    }

    pub(crate) fn pending_sdk_stop_moment(&self) -> Option<u64> {
        match self.sdk.as_ref()?.pending_stop.as_ref()? {
            SdkStop::Decision { moment, .. }
            | SdkStop::CoverageDecision { moment, .. }
            | SdkStop::DeferredDoorbell { moment, .. } => Some(*moment),
            _ => None,
        }
    }

    pub fn pending_service_question(&self) -> Option<(u64, &channel::Question)> {
        match self.sdk.as_ref()?.pending_stop.as_ref()? {
            SdkStop::Decision {
                moment, question, ..
            }
            | SdkStop::CoverageDecision {
                moment, question, ..
            } => Some((*moment, question)),
            _ => None,
        }
    }

    pub fn sdk_request_bindings(&self) -> Vec<((u64, u16, u64), [u8; 32])> {
        self.sdk
            .as_ref()
            .map(|sdk| sdk.env.request_bindings().collect())
            .unwrap_or_default()
    }

    fn write_service_response(
        &mut self,
        moment: u64,
        request: &[u8],
        opcode: u16,
        seq: u32,
        status: Status,
        payload: &[u8],
    ) -> Result<(), VmmError> {
        let mut response = [0; HC_PAGE];
        let len = encode_response(ServiceId::Sdk, opcode, seq, status, payload, &mut response)
            .map_err(|_| VmmError::ContractViolation("service answer cannot be encoded".into()))?;
        self.complete_doorbell(
            moment,
            request.len() as u32,
            request,
            &response[..len],
            Attribution::kind(match opcode {
                2 => Kind::Coverage,
                3 => Kind::Service,
                _ => Kind::ResponseUnknown,
            }),
        )
    }

    pub(crate) fn resolve_service_binding_mismatch(&mut self) -> Result<(), VmmError> {
        let sdk = self
            .sdk
            .as_ref()
            .ok_or(channel::ChannelError::RequestIdentityMismatch)?;
        let Some(SdkStop::Decision {
            moment,
            seq,
            question,
        }) = &sdk.pending_stop
        else {
            return Err(channel::ChannelError::RequestIdentityMismatch.into());
        };
        let before = sdk.env.handler_fingerprint()?;
        let mut probe = sdk.env.checked_clone()?;
        probe.set_moment(*moment);
        let decision = probe.decide_recorded(question);
        sdk.env.verify_handler_fingerprint_unchanged(&before)?;
        if !matches!(
            decision,
            Err(channel::ChannelError::RequestIdentityMismatch)
        ) {
            return Err(channel::ChannelError::RequestIdentityMismatch.into());
        }
        let request = crate::service_transcript::pending_request(
            sdk.pending_stop
                .as_ref()
                .expect("validated pending SDK request"),
        )
        .ok_or_else(|| {
            VmmError::ContractViolation("pending service request cannot be encoded".into())
        })?;
        let moment = *moment;
        let seq = *seq;
        self.write_service_response(moment, &request, 3, seq, Status::BadRequest, &[])?;
        self.sdk
            .as_mut()
            .expect("validated pending SDK request")
            .pending_stop = None;
        Ok(())
    }

    pub(crate) fn resolve_service_answer(
        &mut self,
        answer: channel::Answer,
        local: Option<LocalServiceAnswer>,
    ) -> Result<(u64, channel::Question), VmmError> {
        let stop = self
            .sdk
            .as_ref()
            .and_then(|sdk| sdk.pending_stop.clone())
            .ok_or_else(|| VmmError::ContractViolation("no service request is pending".into()))?;
        let request = crate::service_transcript::pending_request(&stop).ok_or_else(|| {
            VmmError::ContractViolation("pending service request cannot be encoded".into())
        })?;
        let (moment, seq, question, opcode, payload, coverage_commit) = match stop {
            SdkStop::Decision {
                moment,
                seq,
                question,
            } => {
                let payload = sdk::answer_bytes(&answer).ok_or_else(|| {
                    VmmError::ContractViolation("service answer exceeds the doorbell frame".into())
                })?;
                (moment, seq, question, 3, payload, None)
            }
            SdkStop::CoverageDecision {
                moment,
                seq,
                question,
                ready,
            } => {
                let thread = u32::try_from(question.request_id())
                    .map_err(|_| VmmError::ContractViolation("invalid coverage thread".into()))?;
                let observed = <[u8; 8]>::try_from(question.payload())
                    .map(u64::from_le_bytes)
                    .map_err(|_| {
                        VmmError::ContractViolation("invalid coverage observation".into())
                    })?;
                let sdk = self
                    .sdk
                    .as_ref()
                    .expect("pending request requires SDK channel");
                let mut env = sdk.env.checked_clone()?;
                env.record_question(moment, &question, answer.clone());
                let mut thresholds = sdk.coverage_thresholds.clone();
                let until_deadline = self.coverage_callbacks_until_timer();
                let CoverageOutcome::Answered(coverage) = sdk::decide_coverage(
                    &mut env,
                    &mut thresholds,
                    moment,
                    thread,
                    observed,
                    ready,
                    until_deadline,
                )
                .map_err(|_| VmmError::ContractViolation("invalid coverage answer".into()))?
                else {
                    return Err(VmmError::ContractViolation(
                        "unresolved coverage answer".into(),
                    ));
                };
                (
                    moment,
                    seq,
                    question,
                    2,
                    coverage.encode().to_vec(),
                    Some((env, thresholds, coverage)),
                )
            }
            _ => {
                return Err(VmmError::ContractViolation(
                    "no service request is pending".into(),
                ));
            }
        };
        if let Some(local) = &local
            && (local.moment != moment
                || local.question != question
                || local.answer != answer
                || opcode != 3)
        {
            return Err(VmmError::ContractViolation(
                "prepared service question differs".into(),
            ));
        }
        let callbacks = coverage_commit
            .as_ref()
            .map_or(0, |(_, _, coverage)| coverage.next - coverage.observed);
        self.write_service_response(moment, &request, opcode, seq, Status::Ok, &payload)?;
        let sdk = self
            .sdk
            .as_mut()
            .expect("pending request requires SDK channel");
        if let Some((env, thresholds, coverage)) = coverage_commit {
            sdk.env = env;
            sdk.coverage_thresholds = thresholds;
            sdk.coverage.push((
                moment,
                coverage.thread,
                coverage.observed,
                coverage.ready,
                coverage.selected,
            ));
        } else {
            if let Some(local) = local {
                sdk.env = local.environment;
            }
            sdk.env.record_question(moment, &question, answer);
        }
        sdk.pending_stop = None;
        if callbacks != 0 {
            self.pending_coverage_callbacks = callbacks;
            self.charge_coverage_callbacks();
            self.pvclock_refresh()?;
        }
        Ok((moment, question))
    }

    pub fn sdk_coverage(&self) -> &[(u64, u32, u64, u32, u32)] {
        self.sdk
            .as_ref()
            .map(|s| s.coverage.as_slice())
            .unwrap_or(&[])
    }

    pub(crate) fn service_doorbell(&mut self, req_len: u32) -> Result<Step, VmmError> {
        let moment = self.effective_vns().unwrap_or(0);
        let req = if req_len as usize > HC_PAGE {
            Vec::new()
        } else {
            self.guest_slice(REQ_GPA as u64, req_len as usize)
                .map(<[u8]>::to_vec)
                .ok_or_else(|| {
                    self.sdk_dispatch_telemetry.borrow_mut().request(Attribution::kind(Kind::Unreadable), false);
                    VmmError::ContractViolation(format!(
                        "doorbell request page {REQ_GPA:#x}+{req_len} is not backed — x86 keeps the \
                         transport ABI pages in the GPA-0 RAM; an arm64 boot must map them (a dedicated \
                         low-GPA memslot; RAM is high)"
                    ))
                })?
        };
        let at_run_deadline = self
            .run_deadline_vns
            .is_some_and(|deadline| moment >= deadline);
        let sdk_decision = at_run_deadline
            && decode(&req).ok().is_some_and(|(header, payload)| {
                if !header.is_request() || header.service != ServiceId::Sdk as u16 {
                    return false;
                }
                let Some(sdk) = self.sdk.as_ref() else {
                    return false;
                };
                match header.opcode {
                    3 => sdk::service_question(payload).is_ok(),
                    2 => sdk::coverage_request(payload).is_ok_and(|(thread, observed, ready)| {
                        sdk::coverage_question(&sdk.coverage_thresholds, thread, observed, ready)
                            .is_ok()
                    }),
                    _ => false,
                }
            });
        self.sdk_dispatch_telemetry.borrow_mut().request(
            if req_len as usize > HC_PAGE {
                Attribution::kind(Kind::Unreadable)
            } else {
                Attribution::request(&req)
            },
            at_run_deadline && !sdk_decision,
        );
        if at_run_deadline && !sdk_decision {
            let sdk = self.sdk.as_mut().ok_or_else(|| {
                VmmError::ContractViolation(
                    "control deadline deferral requires an SDK channel".to_owned(),
                )
            })?;
            sdk.pending_stop = Some(SdkStop::DeferredDoorbell {
                moment,
                requested_len: req_len,
                request: req,
            });
            return Ok(Step::SdkStop);
        }
        self.finish_doorbell(moment, req_len, &req)
    }

    fn finish_doorbell(&mut self, moment: u64, req_len: u32, req: &[u8]) -> Result<Step, VmmError> {
        let mut resp = [0_u8; HC_PAGE];
        let (resp_len, stop) = if req_len as usize > HC_PAGE {
            (
                encode_response(ServiceId::Event, 1, 0, Status::BadRequest, &[], &mut resp)
                    .unwrap_or(0),
                None,
            )
        } else {
            self.dispatch_doorbell(moment, req, &mut resp)
        };
        self.complete_doorbell(
            moment,
            req_len,
            req,
            &resp[..resp_len],
            if req_len as usize > HC_PAGE {
                Attribution::kind(Kind::Unreadable)
            } else {
                Attribution::request(req)
            },
        )?;
        match stop {
            Some(s) => {
                if let Some(sdk) = self.sdk.as_mut() {
                    sdk.pending_stop = Some(s);
                }
                Ok(Step::SdkStop)
            }
            None => Ok(Step::Continued),
        }
    }

    pub(crate) fn ram_offset_of(&self, gpa: u64) -> Option<usize> {
        usize::try_from(gpa.checked_sub(self.ram_base_gpa)?).ok()
    }

    pub(crate) fn guest_slice(&self, gpa: u64, len: usize) -> Option<&[u8]> {
        if let Some(off) = self.ram_offset_of(gpa) {
            return self.ram.as_bytes().get(off..off.checked_add(len)?);
        }
        let db = self.doorbell_pages.as_ref()?;
        let off = usize::try_from(gpa.checked_sub(DOORBELL_MAP_GPA as u64)?).ok()?;
        db.as_bytes().get(off..off.checked_add(len)?)
    }

    pub(crate) fn guest_slice_mut(&mut self, gpa: u64, len: usize) -> Option<&mut [u8]> {
        if let Some(off) = self.ram_offset_of(gpa) {
            let end = off.checked_add(len)?;
            return self.ram.as_mut_bytes().get_mut(off..end);
        }
        let db = self.doorbell_pages.as_mut()?;
        let off = usize::try_from(gpa.checked_sub(DOORBELL_MAP_GPA as u64)?).ok()?;
        let end = off.checked_add(len)?;
        db.as_mut_bytes().get_mut(off..end)
    }

    fn complete_doorbell(
        &mut self,
        moment: u64,
        requested_len: u32,
        request: &[u8],
        response: &[u8],
        attribution: Attribution,
    ) -> Result<(), VmmError> {
        if response.is_empty() {
            return self.write_attributed_response(response, attribution);
        }
        if let Some(trace) = self.virtual_time_trace.as_ref() {
            trace
                .preflight_service_completion()
                .map_err(|message| VmmError::ContractViolation(message.into()))?;
        }
        let exchange = crate::service_transcript::exchange_digest(requested_len, request, response);
        self.write_attributed_response(response, attribution)?;
        if let Some(trace) = self.virtual_time_trace.as_mut() {
            trace
                .complete_service(moment, exchange)
                .map_err(|message| VmmError::ContractViolation(message.into()))?;
        }
        Ok(())
    }

    #[cfg(test)]
    pub(crate) fn write_doorbell_response(&mut self, resp: &[u8]) -> Result<(), VmmError> {
        self.write_attributed_response(resp, Attribution::kind(Kind::ResponseUnknown))
    }

    fn write_attributed_response(
        &mut self,
        resp: &[u8],
        attribution: Attribution,
    ) -> Result<(), VmmError> {
        let (checked, callback) = self.measure_sdk_guard(HostOperationSite::SdkResponse);
        self.sdk_dispatch_telemetry
            .borrow_mut()
            .response(attribution, callback);
        checked?;
        let Some(dst) = self.guest_slice_mut(RESP_GPA as u64, resp.len()) else {
            return Err(VmmError::ContractViolation(format!(
                "doorbell response page {RESP_GPA:#x}+{} is not backed",
                resp.len()
            )));
        };
        dst.copy_from_slice(resp);
        self.mark_host_dirty(RESP_GPA as u64, resp.len() as u64);
        Ok(())
    }

    fn dispatch_doorbell(
        &mut self,
        moment: u64,
        req: &[u8],
        resp: &mut [u8],
    ) -> (usize, Option<SdkStop>) {
        let Ok((header, payload)) = decode(req) else {
            let n =
                encode_response(ServiceId::Event, 1, 0, Status::BadRequest, &[], resp).unwrap_or(0);
            return (n, None);
        };
        if !header.is_request() {
            let n = encode_error(
                header.service,
                header.opcode,
                header.seq,
                Status::BadRequest,
                resp,
            );
            return (n, None);
        }
        let at_run_deadline = self
            .run_deadline_vns
            .is_some_and(|deadline| moment >= deadline);
        if header.service == ServiceId::Pvclock as u16 {
            if !self.pvclock_available() {
                let n = encode_error(
                    header.service,
                    header.opcode,
                    header.seq,
                    Status::UnknownService,
                    resp,
                );
                return (n, None);
            }
            if header.opcode != 1 {
                let n = encode_error(
                    header.service,
                    header.opcode,
                    header.seq,
                    Status::UnknownOpcode,
                    resp,
                );
                return (n, None);
            }
            if payload.len() != 8 {
                let n = encode_response(
                    ServiceId::Pvclock,
                    1,
                    header.seq,
                    Status::BadRequest,
                    &[],
                    resp,
                )
                .unwrap_or(0);
                return (n, None);
            }
            let mut gpa_bytes = [0_u8; 8];
            gpa_bytes.copy_from_slice(payload);
            let (status, abi) = self.pvclock_register(u64::from_le_bytes(gpa_bytes));
            let body = abi.map(u32::to_le_bytes);
            let n = encode_response(
                ServiceId::Pvclock,
                1,
                header.seq,
                status,
                body.as_ref().map(<[u8; 4]>::as_slice).unwrap_or(&[]),
                resp,
            )
            .unwrap_or(0);
            return (n, None);
        }
        if header.service == ServiceId::Payload as u16 {
            if !self.doorbell_service_offered(header.service) {
                let n = encode_error(
                    header.service,
                    header.opcode,
                    header.seq,
                    Status::UnknownService,
                    resp,
                );
                return (n, None);
            }
            if header.opcode != 1 {
                let n = encode_error(
                    header.service,
                    header.opcode,
                    header.seq,
                    Status::UnknownOpcode,
                    resp,
                );
                return (n, None);
            }
            let sdk = self
                .sdk
                .as_mut()
                .expect("payload availability requires SDK");
            return match sdk::pull_payload(&mut sdk.env, payload) {
                Ok(Some(entry)) => (
                    encode_response(ServiceId::Payload, 1, header.seq, Status::Ok, &entry, resp)
                        .unwrap_or(0),
                    None,
                ),
                Ok(None) => (
                    encode_response(
                        ServiceId::Payload,
                        1,
                        header.seq,
                        Status::OutOfRange,
                        &[],
                        resp,
                    )
                    .unwrap_or(0),
                    Some(SdkStop::Quiescent),
                ),
                Err(status) => (
                    encode_response(ServiceId::Payload, 1, header.seq, status, &[], resp)
                        .unwrap_or(0),
                    None,
                ),
            };
        }
        if header.service == ServiceId::Event as u16 && header.opcode == 1 {
            if self.sdk.is_none() {
                let n = encode_response(
                    ServiceId::Event,
                    1,
                    header.seq,
                    Status::UnknownService,
                    &[],
                    resp,
                )
                .unwrap_or(0);
                return (n, None);
            }
            if payload.len() < 4 {
                let n = encode_response(
                    ServiceId::Event,
                    1,
                    header.seq,
                    Status::BadRequest,
                    &[],
                    resp,
                )
                .unwrap_or(0);
                return (n, None);
            }
            let id = u32::from_le_bytes([payload[0], payload[1], payload[2], payload[3]]);
            let data = &payload[4..];
            if id == hypercall_proto::observation::EVENT_ID
                && hypercall_proto::observation::Descriptor::decode(data)
                    .ok()
                    .is_none_or(|region| {
                        region.len != 0
                            && self
                                .guest_slice(region.address, region.len as usize)
                                .is_none()
                    })
            {
                let n = encode_response(
                    ServiceId::Event,
                    1,
                    header.seq,
                    Status::BadRequest,
                    &[],
                    resp,
                )
                .unwrap_or(0);
                return (n, None);
            }
            let (stop, defer) = match Self::classify_sdk_event(id, data) {
                SdkEventAction::Malformed => {
                    let n = encode_response(
                        ServiceId::Event,
                        1,
                        header.seq,
                        Status::BadRequest,
                        &[],
                        resp,
                    )
                    .unwrap_or(0);
                    return (n, None);
                }
                SdkEventAction::Stop(s) => (Some(s), false),
                SdkEventAction::DeferSnapshot => (None, true),
                SdkEventAction::Capture => (None, false),
            };
            if let Some(sdk) = self.sdk.as_mut() {
                sdk.events.push((moment, id, data.to_vec()));
                if defer {
                    sdk.pending_snapshot = true;
                }
            }
            if defer {
                self.sdk_snapshot_reentry_required = true;
            }
            let n = encode_response(ServiceId::Event, 1, header.seq, Status::Ok, &[], resp)
                .unwrap_or(0);
            return (n, stop);
        }
        if header.service == ServiceId::Sdk as u16 && header.opcode == 3 {
            let Some(sdk) = self.sdk.as_mut() else {
                return (
                    encode_error(
                        header.service,
                        header.opcode,
                        header.seq,
                        Status::UnknownService,
                        resp,
                    ),
                    None,
                );
            };
            if at_run_deadline {
                return match sdk::service_question(payload) {
                    Ok(question) => (
                        0,
                        Some(SdkStop::Decision {
                            moment,
                            seq: header.seq,
                            question,
                        }),
                    ),
                    Err(status) => (
                        encode_error(header.service, header.opcode, header.seq, status, resp),
                        None,
                    ),
                };
            }
            return match sdk::decide_service(&mut sdk.env, moment, payload) {
                Ok(ServiceOutcome::Answered(bytes)) => (
                    encode_response(ServiceId::Sdk, 3, header.seq, Status::Ok, &bytes, resp)
                        .unwrap_or(0),
                    None,
                ),
                Ok(ServiceOutcome::External(question)) => (
                    0,
                    Some(SdkStop::Decision {
                        moment,
                        seq: header.seq,
                        question,
                    }),
                ),
                Err(status) => (
                    encode_error(header.service, header.opcode, header.seq, status, resp),
                    None,
                ),
            };
        }
        if header.service == ServiceId::Sdk as u16 && header.opcode == 2 {
            if self.sdk.is_none() {
                let n = encode_response(
                    ServiceId::Sdk,
                    2,
                    header.seq,
                    Status::UnknownService,
                    &[],
                    resp,
                )
                .unwrap_or(0);
                return (n, None);
            }
            let (thread, observed, ready) = match sdk::coverage_request(payload) {
                Ok(request) => request,
                Err(status) => {
                    let n = encode_response(ServiceId::Sdk, 2, header.seq, status, &[], resp)
                        .unwrap_or(0);
                    return (n, None);
                }
            };
            if at_run_deadline {
                let sdk = self.sdk.as_ref().expect("SDK presence checked above");
                return match sdk::coverage_question(
                    &sdk.coverage_thresholds,
                    thread,
                    observed,
                    ready,
                ) {
                    Ok(question) => (
                        0,
                        Some(SdkStop::CoverageDecision {
                            moment,
                            seq: header.seq,
                            question,
                            ready,
                        }),
                    ),
                    Err(status) => (
                        encode_error(header.service, header.opcode, header.seq, status, resp),
                        None,
                    ),
                };
            }
            match self.decide_coverage(moment, thread, observed, ready) {
                Ok(CoverageOutcome::Answered(coverage)) => {
                    self.pending_coverage_callbacks = coverage.next - coverage.observed;
                    let n = encode_response(
                        ServiceId::Sdk,
                        2,
                        header.seq,
                        Status::Ok,
                        &coverage.encode(),
                        resp,
                    )
                    .unwrap_or(0);
                    return (n, None);
                }
                Ok(CoverageOutcome::External(question)) => {
                    return (
                        0,
                        Some(SdkStop::CoverageDecision {
                            moment,
                            seq: header.seq,
                            question,
                            ready,
                        }),
                    );
                }
                Err(status) => {
                    let n = encode_response(ServiceId::Sdk, 2, header.seq, status, &[], resp)
                        .unwrap_or(0);
                    return (n, None);
                }
            }
        }
        if header.service == ServiceId::Entropy as u16 && header.opcode == 1 {
            if self.sdk.is_none() {
                let n = encode_response(
                    ServiceId::Entropy,
                    1,
                    header.seq,
                    Status::UnknownService,
                    &[],
                    resp,
                )
                .unwrap_or(0);
                return (n, None);
            }
            let mut buf = [0_u8; MAX_PAYLOAD];
            let (status, got) = match self.vtime.as_mut() {
                Some(vt) => vt.draw_entropy(payload, &mut buf),
                None => (Status::BadRequest, 0),
            };
            let m = encode_response(ServiceId::Entropy, 1, header.seq, status, &buf[..got], resp)
                .unwrap_or(0);
            return (m, None);
        }
        let known = matches!(
            header.service,
            s if s == ServiceId::Event as u16
                || s == ServiceId::Sdk as u16
                || s == ServiceId::Entropy as u16
                || s == ServiceId::Pvclock as u16
                || s == ServiceId::Payload as u16
        );
        if known && self.doorbell_service_offered(header.service) {
            let n = encode_error(
                header.service,
                header.opcode,
                header.seq,
                Status::UnknownOpcode,
                resp,
            );
            (n, None)
        } else {
            let n = encode_error(
                header.service,
                header.opcode,
                header.seq,
                Status::UnknownService,
                resp,
            );
            (n, None)
        }
    }

    fn classify_sdk_event(id: u32, data: &[u8]) -> SdkEventAction {
        match sdk::classify_event(id, data) {
            EventClass::Violation { id, data } => {
                SdkEventAction::Stop(SdkStop::Assertion { id, data })
            }
            EventClass::SnapshotPoint => SdkEventAction::DeferSnapshot,
            EventClass::Recorded => SdkEventAction::Capture,
            EventClass::Malformed => SdkEventAction::Malformed,
        }
    }

    pub fn take_snapshot_point(&mut self) -> bool {
        if !self.sdk_snapshot_reentry_required
            && let Some(sdk) = self.sdk.as_mut()
            && sdk.pending_stop.is_none()
            && sdk.pending_snapshot
        {
            sdk.pending_snapshot = false;
            return true;
        }
        false
    }

    fn coverage_callbacks_until_timer(&self) -> Option<u64> {
        let now = self.vtime.as_ref()?.virtual_time_vns();
        let deadline = <B::A as Vendor>::next_timer_deadline_vns(self)?;
        let cost = B::A::coverage_callback_vns();
        (cost > 0).then(|| deadline.saturating_sub(now).div_ceil(cost))
    }

    fn charge_coverage_callbacks(&mut self) {
        let callbacks = std::mem::take(&mut self.pending_coverage_callbacks);
        if let Some(vt) = self.vtime.as_mut() {
            vt.advance_virtual_time(callbacks.saturating_mul(B::A::coverage_callback_vns()));
            self.virtual_time_progress
                .store(vt.virtual_time_vns(), std::sync::atomic::Ordering::Release);
        }
    }

    fn decide_coverage(
        &mut self,
        moment: u64,
        thread: u32,
        observed: u64,
        ready: u32,
    ) -> Result<CoverageOutcome, Status> {
        let until_deadline = self.coverage_callbacks_until_timer();
        let Some(sdk) = self.sdk.as_mut() else {
            return Err(Status::UnknownService);
        };
        let coverage = sdk::decide_coverage(
            &mut sdk.env,
            &mut sdk.coverage_thresholds,
            moment,
            thread,
            observed,
            ready,
            until_deadline,
        )?;
        if let CoverageOutcome::Answered(answer) = &coverage {
            sdk.coverage
                .push((moment, thread, observed, ready, answer.selected));
        }
        Ok(coverage)
    }

    pub(crate) fn now_vns(&self) -> Result<u64, VmmError> {
        match &self.vtime {
            Some(vt) => Ok(vt.clock.vns()),
            None => Ok(0),
        }
    }

    pub(crate) fn set_idle_wake_vns(&mut self, vns: Option<u64>) {
        self.idle_wake_vns = vns;
    }

    pub fn entropy_state(&self) -> Option<u64> {
        self.vtime.as_ref().map(|vt| {
            let bytes = vt.entropy.save_state();
            let mut buf = [0u8; 8];
            buf.copy_from_slice(&bytes[..8]);
            u64::from_le_bytes(buf)
        })
    }

    pub fn apply_effect(&mut self, effect: &channel::Effect) -> Result<(), VmmError> {
        match effect {
            channel::Effect::WriteMemory { gpa, bytes } => {
                let Some(dst) = self.guest_slice_mut(*gpa, bytes.len()) else {
                    return Err(VmmError::ContractViolation(format!(
                        "WriteMemory gpa {gpa:#x}+{} is not backed by guest RAM",
                        bytes.len()
                    )));
                };
                dst.copy_from_slice(bytes);
                let host_addr = dst.as_ptr() as usize;
                self.backend
                    .invalidate_instruction_cache(host_addr, bytes.len());
                self.mark_host_dirty(*gpa, bytes.len() as u64);
                Ok(())
            }
            channel::Effect::XorMemory { gpa, bytes } => {
                let Some(dst) = self.guest_slice_mut(*gpa, bytes.len()) else {
                    return Err(VmmError::ContractViolation(format!(
                        "XorMemory gpa {gpa:#x}+{} is not backed by guest RAM",
                        bytes.len()
                    )));
                };
                for (current, mask) in dst.iter_mut().zip(bytes) {
                    *current ^= mask;
                }
                let host_addr = dst.as_ptr() as usize;
                self.backend
                    .invalidate_instruction_cache(host_addr, bytes.len());
                self.mark_host_dirty(*gpa, bytes.len() as u64);
                Ok(())
            }
        }
    }

    pub(crate) fn mark_host_dirty(&mut self, gpa: u64, len: u64) {
        if len == 0 {
            return;
        }
        let first = gpa / 4096;
        let last = (gpa + len - 1) / 4096;
        self.host_dirty.extend(first..=last);
        self.mark_page_digests(first..=last);
    }

    fn mark_page_digests(&mut self, gfns: impl IntoIterator<Item = u64>) {
        let base = self.ram_base_gpa / 4096;
        for gfn in gfns {
            if let Some(page) = gfn.checked_sub(base) {
                self.page_digests.mark(page);
            }
        }
    }

    fn drain_backend_dirty_pages(&mut self) -> Result<Option<Vec<u64>>, VmmError> {
        match self.backend.drain_dirty_pages() {
            Ok(gfns) => {
                self.mark_page_digests(gfns.iter().copied());
                Ok(Some(gfns))
            }
            Err(vmm_backend::BackendError::Unsupported { .. }) => {
                self.page_digests.mark_all();
                Ok(None)
            }
            Err(error) => {
                self.page_digests.mark_all();
                Err(error.into())
            }
        }
    }

    pub(crate) fn memory_digest(
        &mut self,
        work: &mut crate::host_telemetry::HashWork,
    ) -> Result<[u8; 32], VmmError> {
        if let Some(gfns) = self.drain_backend_dirty_pages()? {
            self.host_dirty.extend(gfns);
        }
        Ok(self.page_digests.digest(self.ram.as_bytes(), work))
    }

    pub fn drain_dirty_pages(&mut self) -> Result<Option<Vec<u64>>, VmmError> {
        if self.host_dirty_wholesale {
            return Ok(None);
        }
        let Some(mut gfns) = self.drain_backend_dirty_pages()? else {
            return Ok(None);
        };
        gfns.extend(self.host_dirty.iter().copied());
        self.host_dirty.clear();
        let base = self.ram_base_gpa / 4096;
        let pages = (self.ram.len() / 4096) as u64;
        let mut rel: Vec<u64> = gfns
            .into_iter()
            .filter_map(|g| g.checked_sub(base).filter(|&r| r < pages))
            .collect();
        rel.sort_unstable();
        rel.dedup();
        Ok(Some(rel))
    }

    pub fn reset_dirty_tracking(&mut self) -> Result<bool, VmmError> {
        let tracked = self.drain_backend_dirty_pages()?.is_some();
        self.host_dirty.clear();
        self.host_dirty_wholesale = false;
        Ok(tracked)
    }

    pub(crate) fn on_idle(&mut self) -> Result<Step, VmmError> {
        match self.idle_action()? {
            IdleAction::DeliverPending => Ok(Step::Continued),
            IdleAction::JumpToDeadline { vns, control_wake } => self.resume_idle(vns, control_wake),
            IdleAction::Terminal => Ok(self.terminate(TerminalReason::Idle)),
        }
    }

    fn idle_action(&mut self) -> Result<IdleAction, VmmError> {
        let Some(_vt) = self.vtime.as_ref() else {
            return Ok(IdleAction::Terminal);
        };
        if !<B::A as Vendor>::guest_interruptible(self)? {
            return Ok(IdleAction::Terminal);
        }
        if <B::A as Vendor>::pending_deliverable_interrupt(self)? {
            return Ok(IdleAction::DeliverPending);
        }
        let timer = <B::A as Vendor>::deliverable_timer_deadline_vns(self)?;
        let wake = match (timer, self.idle_wake_vns) {
            (Some(timer), Some(host)) if host < timer => Some((host, true)),
            (Some(timer), _) => Some((timer, false)),
            (None, Some(host)) => Some((host, true)),
            (None, None) => None,
        };
        match wake {
            Some((vns, control_wake)) => Ok(IdleAction::JumpToDeadline { vns, control_wake }),
            None => Ok(IdleAction::Terminal),
        }
    }

    pub(crate) fn resume_idle(
        &mut self,
        deadline_vns: u64,
        control_wake: bool,
    ) -> Result<Step, VmmError> {
        let (landing, snap) = {
            let vt = self
                .vtime
                .as_ref()
                .expect("JumpToDeadline implies V-time wired");
            let now_vns = vt.clock.vns();
            let landing = IdlePlanner::new().plan(now_vns, deadline_vns).landed_vns;
            let snap = VtimeSnapshot {
                vns: landing,
                guest_clock_offset: vt.guest_clock_offset,
                entropy: vt.entropy.save_state(),
            };
            (landing, snap)
        };
        self.restore_vtime(&snap)?;
        if control_wake {
            self.last_step_control_idle_landing_vns = Some(landing);
        }
        if self.idle_landings.len() < EVENT_TRACE_CAP {
            self.idle_landings.push(landing);
        }
        Ok(Step::Continued)
    }

    pub(crate) fn current_vcpu(&mut self) -> Result<VcpuOf<B>, VmmError> {
        match &self.saved_state {
            Some(s) => Ok(s.clone()),
            None => Ok(self.backend.save()?),
        }
    }
}

#[cfg(all(target_os = "macos", target_arch = "aarch64", not(miri)))]
impl Vmm<vmm_backend::HvfBackend> {
    pub fn hvf_exit_handle(&self) -> vmm_backend::HvfExitHandle {
        self.backend.exit_handle()
    }
}

pub(crate) fn put_chunk(out: &mut Vec<u8>, tag: &[u8; 4], bytes: &[u8]) {
    out.extend_from_slice(tag);
    out.extend_from_slice(&(bytes.len() as u64).to_le_bytes());
    out.extend_from_slice(bytes);
}

fn encode_vtime(vt: &VtimeWiring) -> Vec<u8> {
    encode_vtime_parts(
        vt.cfg.guest_hz,
        vt.cfg.guest_base,
        vt.guest_clock_offset,
        vt.clock.vns(),
        &vt.entropy.save_state(),
    )
}

fn encode_vtime_parts(
    guest_hz: u64,
    guest_base: u64,
    clock_offset: u64,
    vns: u64,
    entropy: &[u8],
) -> Vec<u8> {
    let mut v = Vec::new();
    v.push(1);
    v.extend_from_slice(&1_u64.to_le_bytes());
    for x in [guest_hz, guest_base, clock_offset] {
        v.extend_from_slice(&x.to_le_bytes());
    }
    v.extend_from_slice(&vns.to_le_bytes());
    v.extend_from_slice(entropy);
    v
}

fn append_terminal(out: &mut Vec<u8>, terminal: Option<TerminalReason>) {
    match terminal {
        None => out.push(0),
        Some(TerminalReason::DebugExit { code }) => {
            out.push(1);
            out.push(code);
        }
        Some(TerminalReason::Idle) => out.push(2),
        Some(TerminalReason::Shutdown) => out.push(3),
        Some(TerminalReason::SdkStop) => {
            unreachable!("SdkStop never latches as the VM terminal")
        }
    }
}

fn append_sdk_channel(
    v: &mut Vec<u8>,
    sdk: &SdkChannel,
    recorded: Option<&channel::RecordedState>,
) -> Result<(), channel::ChannelError> {
    let captured;
    let recorded = match recorded {
        Some(state) => state,
        None => {
            captured = sdk.env.snapshot_state()?;
            &captured
        }
    };
    append_sdk_hash_channel(
        v,
        recorded,
        &sdk.events,
        sdk.pending_stop.as_ref(),
        sdk.pending_snapshot,
        &sdk.coverage_thresholds,
    );
    Ok(())
}

fn append_sdk_snapshot(v: &mut Vec<u8>, sdk: &SdkSnapshot) {
    append_sdk_hash_channel(
        v,
        &sdk.recorded,
        &sdk.events,
        sdk.pending_stop.as_ref(),
        sdk.pending_snapshot,
        &sdk.coverage_thresholds,
    );
}

fn append_sdk_hash_channel(
    v: &mut Vec<u8>,
    recorded: &channel::RecordedState,
    events: &[(u64, u32, Vec<u8>)],
    pending_stop: Option<&SdkStop>,
    pending_snapshot: bool,
    coverage_thresholds: &BTreeMap<u32, u64>,
) {
    v.extend_from_slice(b"SDK\0");
    let chunk_length = v.len();
    v.extend_from_slice(&0_u64.to_le_bytes());
    let chunk_start = v.len();
    v.extend_from_slice(&0_u64.to_le_bytes());
    let recorded_start = v.len();
    recorded.encode_into(v);
    let recorded_len = v.len() - recorded_start;
    v[chunk_start..recorded_start].copy_from_slice(&(recorded_len as u64).to_le_bytes());
    match pending_stop {
        None => v.push(0),
        Some(SdkStop::Assertion { id, data }) => {
            v.push(1);
            v.extend_from_slice(&id.to_le_bytes());
            v.extend_from_slice(&(data.len() as u32).to_le_bytes());
            v.extend_from_slice(data);
        }
        Some(SdkStop::Quiescent) => v.push(2),
        Some(SdkStop::Decision {
            moment,
            seq,
            question,
        }) => {
            v.push(3);
            v.extend_from_slice(&moment.to_le_bytes());
            v.extend_from_slice(&seq.to_le_bytes());
            v.extend_from_slice(&question.service().to_le_bytes());
            v.extend_from_slice(&question.request_id().to_le_bytes());
            v.extend_from_slice(&(question.payload().len() as u32).to_le_bytes());
            v.extend_from_slice(question.payload());
        }
        Some(SdkStop::CoverageDecision {
            moment,
            seq,
            question,
            ready,
        }) => {
            v.push(4);
            v.extend_from_slice(&moment.to_le_bytes());
            v.extend_from_slice(&seq.to_le_bytes());
            v.extend_from_slice(&question.service().to_le_bytes());
            v.extend_from_slice(&question.request_id().to_le_bytes());
            v.extend_from_slice(&(question.payload().len() as u32).to_le_bytes());
            v.extend_from_slice(question.payload());
            v.extend_from_slice(&ready.to_le_bytes());
        }
        Some(SdkStop::DeferredDoorbell {
            moment,
            requested_len,
            request,
        }) => {
            v.push(5);
            v.extend_from_slice(&moment.to_le_bytes());
            v.extend_from_slice(&requested_len.to_le_bytes());
            v.extend_from_slice(&(request.len() as u32).to_le_bytes());
            v.extend_from_slice(request);
        }
    }
    v.push(u8::from(pending_snapshot));
    if !coverage_thresholds.is_empty() {
        v.extend_from_slice(b"COVR");
        let count = u64::try_from(coverage_thresholds.len()).unwrap_or(u64::MAX);
        v.extend_from_slice(&count.to_le_bytes());
        for (thread, threshold) in coverage_thresholds {
            v.extend_from_slice(&thread.to_le_bytes());
            v.extend_from_slice(&threshold.to_le_bytes());
        }
    }
    if !events.is_empty() {
        v.extend_from_slice(b"EVTS");
        v.extend_from_slice(&(events.len() as u64).to_le_bytes());
        for (moment, local, payload) in events {
            v.extend_from_slice(&moment.to_le_bytes());
            v.extend_from_slice(&local.to_le_bytes());
            v.extend_from_slice(&(payload.len() as u64).to_le_bytes());
            v.extend_from_slice(payload);
        }
    }
    let chunk_len = v.len() - chunk_start;
    v[chunk_length..chunk_start].copy_from_slice(&(chunk_len as u64).to_le_bytes());
}

#[cfg(test)]
mod tests {

    use std::collections::VecDeque;

    use super::*;
    use crate::virtual_time::NormalizedEventClass;
    use hypercall_proto::{SDK_COVERAGE_QUANTUM, SDK_COVERAGE_REQUEST_LEN};
    use vmm_backend::{ExitReason, Gpa, VcpuState, X86, X86Caps, X86Exit, X86Policy};

    use crate::vendor::x86::devices::REPORT_PORT;
    #[cfg(feature = "msr-diagnostics")]
    use crate::vendor::x86::dispatch::MsrDir;
    use crate::vendor::x86::dispatch::{
        APIC_MMIO_BASE, COM1_IRQ_VECTOR, DOORBELL_PORT, IA32_TSC_ADJUST, IDLE_PORT, RFLAGS_IF,
        VIRTUAL_TIME_TICK_PORT, contract_vclock_config, lookup_cpuid,
    };
    use crate::vendor::x86::records as snapshot;

    mod service_transcript_tests {
        use super::*;
        include!("service_transcript_tests.rs");
    }

    const TEST_RAM: usize = if cfg!(miri) { 0x1_0000 } else { 0x2_0000 };

    mod buffered_sdk_encoding {
        use super::{SdkChannel, SdkStop, channel};
        include!("../qualification/reference-sdk-encoding.rs");

        pub(super) fn encode(sdk: &SdkChannel) -> Vec<u8> {
            encode_sdk_channel(sdk, None).unwrap()
        }
    }

    #[test]
    fn direct_sdk_encoding_preserves_framing_and_all_stop_variants() {
        let mut env = channel::RecordedEnv::new(
            31,
            Box::new(SeededService { seed: 7, calls: 11 }) as Box<dyn channel::ServiceHandler>,
        );
        env.set_payloads(Some(vec![vec![], vec![1, 2, 3]])).unwrap();
        env.record_service_request(4, 8, 12, channel::Answer::Data(vec![5, 6]));
        env.record_service_request(7, 8, 13, channel::Answer::Nominal);
        let mut sdk = SdkChannel {
            env,
            events: vec![(9, 27, vec![8, 7])],
            coverage_thresholds: BTreeMap::new(),
            coverage: vec![],
            pending_stop: None,
            pending_snapshot: false,
        };
        let recorded = sdk.env.snapshot_state().unwrap();
        for stop in [
            None,
            Some(SdkStop::Assertion {
                id: 27,
                data: vec![8, 9],
            }),
            Some(SdkStop::Quiescent),
            Some(SdkStop::Decision {
                moment: 37,
                seq: 12,
                question: channel::Question::with_request_id(91, 19, vec![1, 3, 5]).unwrap(),
            }),
            Some(SdkStop::CoverageDecision {
                moment: 37,
                seq: 12,
                question: channel::Question::with_request_id(
                    3,
                    channel::SERVICE_COVERAGE_QUANTUM,
                    1_u64.to_le_bytes().to_vec(),
                )
                .unwrap(),
                ready: 2,
            }),
            Some(SdkStop::DeferredDoorbell {
                moment: 37,
                requested_len: 3,
                request: vec![1, 2, 3],
            }),
        ] {
            sdk.pending_stop = stop;
            for pending_snapshot in [false, true] {
                sdk.pending_snapshot = pending_snapshot;
                for coverage in [BTreeMap::new(), BTreeMap::from([(3, 17), (9, 71)])] {
                    sdk.coverage_thresholds = coverage;
                    let mut expected = b"existing-prefix".to_vec();
                    put_chunk(
                        &mut expected,
                        b"SDK\0",
                        &buffered_sdk_encoding::encode(&sdk),
                    );
                    for captured in [None, Some(&recorded)] {
                        let mut actual = b"existing-prefix".to_vec();
                        append_sdk_channel(&mut actual, &sdk, captured).unwrap();
                        assert_eq!(actual, expected);
                    }
                }
            }
        }
    }

    #[test]
    fn imported_hash_projection_matches_live_x86_chunks() {
        for snapshot_hashing in [false, true] {
            let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
            vmm.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 37).unwrap());
            vmm.wire_lapic(
                lapic::Lapic::new(lapic::LapicConfig {
                    apic_id: 0,
                    timer_hz: 24_000_000,
                })
                .unwrap(),
            );
            vmm.enable_pvclock();
            enable_nominal(&mut vmm, 37);
            if snapshot_hashing {
                vmm.wire_snapshot_hashing();
            }
            vmm.devices.uart.write(0x3f8, b'x');
            vmm.devices.uart.write(0x3fb, 0x80);
            vmm.devices.uart.write(0x3f9, 0x5a);
            vmm.inject_serial_input(b"queued");
            let mut vcpu = vmm.backend.save().unwrap();
            vcpu.events = vmm_backend::VcpuEvents {
                exception_pending: 1,
                exception_nr: 14,
                exception_has_error_code: 1,
                exception_error_code: 0xcafe,
                ..Default::default()
            };
            vmm.backend.set_state(vcpu);
            vmm.sdk_snapshot_reentry_required = true;
            let sdk = vmm.sdk.as_mut().unwrap();
            sdk.events.push((39, 7, vec![4, 5, 6]));
            sdk.pending_snapshot = true;
            sdk.pending_stop = Some(SdkStop::Decision {
                moment: 41,
                seq: 2,
                question: channel::Question::with_request_id(7, 9, vec![1, 2]).unwrap(),
            });
            sdk.coverage_thresholds.insert(3, 17);
            let (snapshot, vcpu) = vmm.capture_vm_state().unwrap();
            let sdk = vmm.sdk_snapshot().unwrap().unwrap();
            let live = vmm
                .state_blob_suffix_from_vcpu(&vcpu, Some(&sdk.recorded))
                .unwrap();
            let projected = vmm
                .project_state_blob_suffix_from_snapshot(&snapshot, &sdk)
                .unwrap();
            assert_eq!(projected, live);
        }
    }

    #[test]
    fn imported_hash_projection_matches_live_arm_chunks() {
        use vmm_backend::{Arm64Policy, MockArm64Backend};

        for snapshot_hashing in [false, true] {
            let mut backend = MockArm64Backend::new();
            backend.set_policy(&Arm64Policy::default()).unwrap();
            let mut vmm = Vmm::new(backend, GuestRam::new(TEST_RAM).unwrap());
            vmm.ram_base_gpa = crate::vendor::arm64::board::RAM_BASE;
            vmm.map_doorbell_pages().unwrap();
            vmm.doorbell_pages.as_mut().unwrap().as_mut_bytes()[0] = 0x5a;
            vmm.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 37).unwrap());
            vmm.enable_pvclock();
            vmm.devices.gic = Some(crate::vendor::arm64::board::new_gic());
            vmm.devices.clockevent.deadline = Some(113);
            vmm.enable_sdk(nominal_env(37), &ServiceConfig::default());
            if snapshot_hashing {
                vmm.wire_snapshot_hashing();
            }
            vmm.devices.uart.write(0, u32::from(b'x'));
            vmm.inject_serial_input(b"queued");
            let mut vcpu = vmm.backend.save().unwrap();
            vcpu.sysregs.tpidr_el1 = 0x1234_5678;
            vcpu.vtimer.counter = 0x9abc_def0;
            vmm.backend.set_state(vcpu);
            vmm.sdk_snapshot_reentry_required = true;
            let sdk = vmm.sdk.as_mut().unwrap();
            sdk.events.push((39, 7, vec![4, 5, 6]));
            sdk.pending_snapshot = true;
            sdk.pending_stop = Some(SdkStop::Assertion {
                id: 41,
                data: vec![1, 2],
            });
            sdk.coverage_thresholds.insert(3, 17);
            let (snapshot, vcpu) = vmm.capture_vm_state().unwrap();
            let sdk = vmm.sdk_snapshot().unwrap().unwrap();
            let live = vmm
                .state_blob_suffix_from_vcpu(&vcpu, Some(&sdk.recorded))
                .unwrap();
            let projected = vmm
                .project_state_blob_suffix_from_snapshot(&snapshot, &sdk)
                .unwrap();
            assert_eq!(projected, live);
            let mut other_backend =
                MockArm64Backend::with_capabilities(vmm_backend::Capabilities {
                    name: "mock-arm64",
                    arch: vmm_backend::Arm64Caps {
                        register_identity: [0x91; 32],
                        ..vmm.backend.capabilities().arch
                    },
                });
            other_backend.set_policy(&Arm64Policy::default()).unwrap();
            let mut other = Vmm::new(other_backend, GuestRam::new(TEST_RAM).unwrap());
            let before = other.save_vm_state().unwrap();
            let ram = other.guest_memory().to_vec();
            assert!(matches!(
                other.project_state_blob_suffix_from_snapshot(&snapshot, &sdk),
                Err(VmmError::Snapshot(SnapshotError::ContractMismatch))
            ));
            assert_eq!(other.save_vm_state().unwrap(), before);
            assert_eq!(other.guest_memory(), ram);
            let mut mismatched = snapshot.clone();
            mismatched.contract_hash[0] ^= 1;
            assert!(matches!(
                vmm.project_state_blob_suffix_from_snapshot(&mismatched, &sdk),
                Err(VmmError::Snapshot(SnapshotError::ContractMismatch))
            ));
        }
    }

    #[test]
    #[cfg(feature = "msr-diagnostics")]
    fn msr_dir_renders_direction_and_exit_reason() {
        assert_eq!(MsrDir::Read.dir(), "RDMSR");
        assert_eq!(MsrDir::Write.dir(), "WRMSR");
        assert_eq!(MsrDir::Read.exit_reason(), "KVM_EXIT_X86_RDMSR");
        assert_eq!(MsrDir::Write.exit_reason(), "KVM_EXIT_X86_WRMSR");
    }

    #[test]
    fn lookup_cpuid_exact_leaf_only_and_default() {
        let l1 = lookup_cpuid(1, 0);
        assert_eq!(l1.leaf, 1);
        assert_eq!(l1.eax, 0x0009_06ec);
        assert_eq!(lookup_cpuid(4, 2).eax, 0x0000_0143);
        assert_eq!(lookup_cpuid(1, 99).eax, 0x0009_06ec);
        let d = lookup_cpuid(0xDEAD, 5);
        assert_eq!((d.leaf, d.subleaf, d.eax), (0xDEAD, 5, 0));
    }

    use vmm_backend::{Completion, CpuidModel, MockBackend, MsrFilter};

    const TEST_SERVICE_IDENTITY: &[u8] = b"vmm-test-service.v1";

    #[derive(Clone, Debug, Default)]
    struct SeededService {
        seed: u64,
        calls: u64,
    }

    impl SeededService {
        fn config() -> ServiceConfig {
            ServiceConfig {
                local_services: Vec::new(),
                identity: b"vmm-seeded-service.v1".to_vec(),
                configuration: b"seeded".to_vec(),
            }
        }
    }

    impl channel::ServiceHandler for SeededService {
        fn identity(&self) -> &[u8] {
            b"vmm-seeded-service.v1"
        }

        fn configuration(&self) -> &[u8] {
            b"seeded"
        }

        fn respond(
            &mut self,
            _moment: environment::Moment,
            _question: &channel::Question,
        ) -> Result<channel::ServiceResponse, channel::ChannelError> {
            self.calls = self.calls.saturating_add(1);
            Ok(channel::ServiceResponse::Answered(channel::Answer::Nominal))
        }

        fn snapshot_state(&self) -> Result<Vec<u8>, channel::ChannelError> {
            let mut state = Vec::with_capacity(16);
            state.extend_from_slice(&self.seed.to_le_bytes());
            state.extend_from_slice(&self.calls.to_le_bytes());
            Ok(state)
        }

        fn restore_state(&mut self, state: &[u8]) -> Result<(), channel::ChannelError> {
            let state: [u8; 16] = state
                .try_into()
                .map_err(|_| channel::ChannelError::Malformed)?;
            self.seed = u64::from_le_bytes(state[..8].try_into().unwrap());
            self.calls = u64::from_le_bytes(state[8..].try_into().unwrap());
            Ok(())
        }

        fn reseed(&mut self, seed: u64) {
            self.seed = seed;
        }

        fn clone_box(&self) -> Box<dyn channel::ServiceHandler> {
            Box::new(self.clone())
        }
    }

    #[derive(Clone, Debug, Default)]
    struct OversizedService;

    impl channel::ServiceHandler for OversizedService {
        fn identity(&self) -> &[u8] {
            TEST_SERVICE_IDENTITY
        }

        fn configuration(&self) -> &[u8] {
            b"oversized"
        }

        fn respond(
            &mut self,
            _moment: environment::Moment,
            _question: &channel::Question,
        ) -> Result<channel::ServiceResponse, channel::ChannelError> {
            Ok(channel::ServiceResponse::Answered(channel::Answer::Data(
                vec![0; MAX_PAYLOAD],
            )))
        }

        fn snapshot_state(&self) -> Result<Vec<u8>, channel::ChannelError> {
            Ok(Vec::new())
        }

        fn restore_state(&mut self, state: &[u8]) -> Result<(), channel::ChannelError> {
            if state.is_empty() {
                Ok(())
            } else {
                Err(channel::ChannelError::Malformed)
            }
        }

        fn clone_box(&self) -> Box<dyn channel::ServiceHandler> {
            Box::new(self.clone())
        }
    }

    struct MutatingCloneService(std::sync::Arc<std::sync::atomic::AtomicU8>);

    impl channel::ServiceHandler for MutatingCloneService {
        fn identity(&self) -> &[u8] {
            b"vmm-mutating-clone-service"
        }

        fn configuration(&self) -> &[u8] {
            b""
        }

        fn respond(
            &mut self,
            _: environment::Moment,
            _: &channel::Question,
        ) -> Result<channel::ServiceResponse, channel::ChannelError> {
            panic!("guest service decisions require an explicit answer")
        }

        fn snapshot_state(&self) -> Result<Vec<u8>, channel::ChannelError> {
            Ok(vec![self.0.load(std::sync::atomic::Ordering::SeqCst)])
        }

        fn restore_state(&mut self, state: &[u8]) -> Result<(), channel::ChannelError> {
            let [value] = state else {
                return Err(channel::ChannelError::Malformed);
            };
            self.0.store(*value, std::sync::atomic::Ordering::SeqCst);
            Ok(())
        }

        fn clone_box(&self) -> Box<dyn channel::ServiceHandler> {
            let _ = self.0.compare_exchange(
                0,
                1,
                std::sync::atomic::Ordering::SeqCst,
                std::sync::atomic::Ordering::SeqCst,
            );
            Box::new(Self(std::sync::Arc::clone(&self.0)))
        }
    }

    fn mutating_clone_vmm() -> (
        Vmm<MockBackend>,
        std::sync::Arc<std::sync::atomic::AtomicU8>,
    ) {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        let state = std::sync::Arc::new(std::sync::atomic::AtomicU8::new(0));
        let config = ServiceConfig {
            local_services: Vec::new(),
            identity: b"vmm-mutating-clone-service".to_vec(),
            configuration: Vec::new(),
        };
        vmm.enable_sdk(
            channel::RecordedEnv::new(
                7,
                Box::new(MutatingCloneService(std::sync::Arc::clone(&state))),
            ),
            &config,
        );
        (vmm, state)
    }

    #[test]
    fn service_answer_preflight_rejects_a_clone_that_changes_the_live_handler() {
        let (vmm, state) = mutating_clone_vmm();
        let question = channel::Question::with_request_id(77, 19, b"choose".to_vec()).unwrap();
        assert_eq!(
            vmm.sdk_snapshot_after_answer(4, &question, &channel::Answer::Nominal, None),
            Err(channel::ChannelError::Poisoned)
        );
        assert_eq!(state.load(std::sync::atomic::Ordering::SeqCst), 1);
        assert!(vmm.sdk.as_ref().unwrap().env.is_poisoned());
    }

    #[test]
    fn coverage_answer_rejects_a_clone_that_changes_the_live_handler() {
        let (mut vmm, state) = mutating_clone_vmm();
        let question = channel::Question::with_request_id(
            11,
            channel::SERVICE_COVERAGE_QUANTUM,
            1_u64.to_le_bytes().to_vec(),
        )
        .unwrap();
        vmm.sdk.as_mut().unwrap().pending_stop = Some(SdkStop::CoverageDecision {
            moment: 4,
            seq: 12,
            question,
            ready: 2,
        });
        assert!(
            vmm.resolve_service_answer(channel::Answer::Data(7_u64.to_le_bytes().to_vec()), None)
                .is_err()
        );
        assert_eq!(state.load(std::sync::atomic::Ordering::SeqCst), 1);
        assert!(vmm.sdk.as_ref().unwrap().env.is_poisoned());
        assert!(vmm.pending_service_question().is_some());
    }

    fn enable_nominal(vmm: &mut Vmm<MockBackend>, seed: u64) {
        let config = ServiceConfig::default();
        vmm.enable_sdk(
            channel::RecordedEnv::new(seed, Box::new(channel::NominalHandler)),
            &config,
        );
    }

    fn nominal_env(seed: u64) -> channel::RecordedEnv<Box<dyn channel::ServiceHandler>> {
        channel::RecordedEnv::new(seed, Box::new(channel::NominalHandler))
    }

    fn enable_oversized(vmm: &mut Vmm<MockBackend>, seed: u64) {
        let config = ServiceConfig {
            local_services: Vec::new(),
            identity: TEST_SERVICE_IDENTITY.to_vec(),
            configuration: b"oversized".to_vec(),
        };
        vmm.enable_sdk(
            channel::RecordedEnv::new(seed, Box::new(OversizedService)),
            &config,
        );
    }

    fn enable_seeded_service(vmm: &mut Vmm<MockBackend>, seed: u64) {
        let config = SeededService::config();
        vmm.enable_sdk(
            channel::RecordedEnv::new(seed, Box::new(SeededService::default())),
            &config,
        );
    }

    #[test]
    fn cancellation_flag_is_the_backend_latch() {
        let latch = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        let backend = configured_mock(Vec::new()).with_cancellation_flag(latch.clone());
        let vmm = Vmm::new(backend, GuestRam::new(0x1000).unwrap());
        let reported = vmm.cancellation_flag().expect("mock reports its latch");
        assert!(std::sync::Arc::ptr_eq(&reported, &latch));

        let unbounded = Vmm::new(configured_mock(Vec::new()), GuestRam::new(0x1000).unwrap());
        assert!(unbounded.cancellation_flag().is_none());
    }

    #[test]
    fn virtual_time_progress_tracks_wiring_advancement_and_restore() {
        let mut vmm = Vmm::new(configured_mock(Vec::new()), GuestRam::new(0x1000).unwrap());
        assert!(vmm.virtual_time_progress().is_none());
        vmm.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 1).unwrap());
        let progress = vmm.virtual_time_progress().unwrap();
        assert_eq!(progress.load(std::sync::atomic::Ordering::Acquire), 0);

        vmm.advance_virtual_time_vtime(17).unwrap();
        assert_eq!(progress.load(std::sync::atomic::Ordering::Acquire), 17);

        let mut snapshot = vmm.save_vtime().unwrap().unwrap();
        snapshot.vns = 4_096;
        vmm.restore_vtime(&snapshot).unwrap();
        assert_eq!(progress.load(std::sync::atomic::Ordering::Acquire), 4_096);
    }

    #[test]
    fn in_place_restore_resets_virtual_time_progress_before_repeated_tick() {
        let mut vmm = Vmm::new(configured_mock(Vec::new()), GuestRam::new(0x1000).unwrap());
        vmm.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 1).unwrap());
        vmm.advance_virtual_time_vtime(4_096).unwrap();
        let saved = vmm.save_vm_state().unwrap();
        let progress = vmm.virtual_time_progress().unwrap();

        vmm.advance_virtual_time_vtime(17).unwrap();
        assert_eq!(progress.load(std::sync::atomic::Ordering::Acquire), 4_113);
        let mut invalid = saved.clone();
        invalid.contract_hash = [0; 32];
        assert!(vmm.restore_vm_state(&invalid).is_err());
        assert_eq!(progress.load(std::sync::atomic::Ordering::Acquire), 4_113);

        vmm.restore_vm_state(&saved).unwrap();
        assert_eq!(vmm.effective_vns(), Some(4_096));
        assert_eq!(progress.load(std::sync::atomic::Ordering::Acquire), 4_096);
        vmm.advance_virtual_time_vtime(17).unwrap();
        assert_eq!(progress.load(std::sync::atomic::Ordering::Acquire), 4_113);
    }

    fn configured_mock(exits: Vec<Exit<X86>>) -> MockBackend {
        let mut m = MockBackend::with_exits(exits);
        m.set_policy(&X86Policy {
            cpuid: CpuidModel::default(),
            msr_filter: MsrFilter::default(),
        })
        .expect("set_policy");
        m
    }

    fn canonical_xsave_image() -> Vec<u8> {
        let mut image = vec![0; 576];
        image[0..2].copy_from_slice(&0x037Fu16.to_le_bytes());
        image[24..28].copy_from_slice(&0x1F80u32.to_le_bytes());
        image[28..32].copy_from_slice(&0x0000FFFFu32.to_le_bytes());
        image[512..520].copy_from_slice(&3u64.to_le_bytes());
        vmm_backend::arch::x86::canonicalize_xsave(&mut image);
        image
    }

    fn vtime_vmm(exits: Vec<Exit<X86>>, seed: u64) -> Vmm<MockBackend> {
        let mut vmm = Vmm::new(configured_mock(exits), GuestRam::new(0x1000).unwrap());
        vmm.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), seed).unwrap());
        vmm
    }

    #[test]
    fn read_completion_history_detects_reconverged_uart_answers() {
        let mut observations = Vec::new();
        for byte in [0x35, 0x71] {
            let mut vmm = vtime_vmm(
                vec![Exit::Arch(vmm_backend::X86Exit::Io {
                    port: 0x3f8,
                    size: 1,
                    write: None,
                })],
                37,
            );
            vmm.inject_serial_input(&[byte]);
            assert!(matches!(vmm.step().unwrap(), Step::Continued));
            assert_eq!(
                vmm.backend.completions(),
                &[Completion::Read(u64::from(byte))]
            );
            observations.push((
                vmm.state_hash().unwrap(),
                vmm.event_history().unwrap(),
                vmm.virtual_time_trace().unwrap().normalized_log().events[0].clone(),
            ));
        }
        let (left_state, left_history, left_event) = &observations[0];
        let (right_state, right_history, right_event) = &observations[1];
        assert_eq!(left_state, right_state);
        assert_eq!(left_history.count, right_history.count);
        assert_eq!(left_event.class, right_event.class);
        assert_eq!(left_event.vns_after, right_event.vns_after);
        assert_eq!(left_event.interrupts, right_event.interrupts);
        assert_ne!(left_event.payload_digest, right_event.payload_digest);
        assert_ne!(left_history.digest, right_history.digest);
    }

    #[test]
    fn read_completion_history_commits_resolved_cpuid_registers() {
        let mut observations = Vec::new();
        for cr4 in [0, 1 << 18] {
            let mut vmm = vtime_vmm(
                vec![Exit::Arch(vmm_backend::X86Exit::Cpuid {
                    leaf: 1,
                    subleaf: 0,
                })],
                37,
            );
            let mut state = vmm.backend.save().unwrap();
            state.sregs.cr4 = cr4;
            vmm.backend.set_state(state);
            vmm.step().unwrap();
            let mut state = vmm.backend.save().unwrap();
            state.sregs.cr4 = 0;
            vmm.backend.set_state(state);
            observations.push((vmm.state_hash().unwrap(), vmm.event_history().unwrap()));
        }
        assert_eq!(observations[0].0, observations[1].0);
        assert_eq!(observations[0].1.count, observations[1].1.count);
        assert_ne!(observations[0].1.digest, observations[1].1.digest);
    }

    #[test]
    fn incremental_memory_digest_sees_every_write_whichever_consumer_drains_it() {
        let mut backend = configured_mock(Vec::new());
        backend.enable_dirty_tracking();
        let mut vmm = Vmm::new(backend, GuestRam::new(8 * 4096).unwrap());
        let check = |vmm: &mut Vmm<MockBackend>| {
            let mut work = crate::host_telemetry::HashWork::new();
            assert_eq!(
                vmm.memory_digest(&mut work).unwrap(),
                crate::state_digest::memory_digest_of(vmm.guest_memory())
            );
            work.ram_bytes()
        };
        check(&mut vmm);
        vmm.ram.as_mut_bytes()[4096] = 1;
        vmm.backend.push_dirty_gfns(vec![1]);
        assert_eq!(check(&mut vmm), 4096);
        vmm.ram.as_mut_bytes()[2 * 4096] = 2;
        vmm.backend.push_dirty_gfns(vec![2]);
        assert_eq!(vmm.drain_dirty_pages().unwrap(), Some(vec![1, 2]));
        assert_eq!(check(&mut vmm), 4096);
        vmm.ram.as_mut_bytes()[3 * 4096] = 3;
        vmm.backend.push_dirty_gfns(vec![3]);
        check(&mut vmm);
        assert_eq!(vmm.drain_dirty_pages().unwrap(), Some(vec![3]));
        vmm.ram.as_mut_bytes()[4 * 4096] = 4;
        vmm.backend.push_dirty_gfns(vec![4]);
        assert!(vmm.reset_dirty_tracking().unwrap());
        assert_eq!(check(&mut vmm), 4096);
        vmm.guest_slice_mut(5 * 4096 + 9, 2)
            .unwrap()
            .copy_from_slice(&[5, 5]);
        vmm.mark_host_dirty(5 * 4096 + 9, 2);
        check(&mut vmm);
        vmm.write_guest_pages(&[(6, [6; 4096])]).unwrap();
        check(&mut vmm);
        let mut image = vmm.guest_memory().to_vec();
        image[7 * 4096] = 7;
        image[4096] = 0;
        vmm.restore_guest_memory(&image).unwrap();
        assert_eq!(check(&mut vmm), 4096);
        vmm.ram.as_mut_bytes()[0] = 8;
        vmm.backend.fail_next_dirty_drain();
        let mut work = crate::host_telemetry::HashWork::new();
        assert!(vmm.memory_digest(&mut work).is_err());
        check(&mut vmm);
        let page = [9_u8; 4096];
        let hash = *blake3::hash(&page).as_bytes();
        vmm.write_guest_hashed_page_refs(&[(2, &hash, &page)])
            .unwrap();
        assert_eq!(check(&mut vmm), 0);
        assert!(vmm.reset_dirty_tracking().unwrap());
        vmm.ram.as_mut_bytes()[3 * 4096..4 * 4096].fill(0);
        vmm.backend.push_dirty_gfns(vec![3]);
        let gfns = vmm.drain_dirty_pages().unwrap().unwrap();
        assert_eq!(gfns, vec![3]);
        vmm.note_page_digests([(3, *blake3::hash(&[0; 4096]).as_bytes())]);
        assert_eq!(check(&mut vmm), 0);
    }

    #[test]
    fn untracked_backend_rehashes_every_page_for_each_digest() {
        let mut vmm = Vmm::new(
            configured_mock(Vec::new()),
            GuestRam::new(2 * 4096).unwrap(),
        );
        let mut work = crate::host_telemetry::HashWork::new();
        vmm.memory_digest(&mut work).unwrap();
        vmm.ram.as_mut_bytes()[4096] = 1;
        let mut work = crate::host_telemetry::HashWork::new();
        assert_eq!(
            vmm.memory_digest(&mut work).unwrap(),
            crate::state_digest::memory_digest_of(vmm.guest_memory())
        );
        assert_eq!(work.ram_bytes(), 4096);
    }

    #[test]
    fn state_hash_streaming_keeps_the_frozen_blob_digest() {
        let mut vmm = vtime_vmm(Vec::new(), 0x5eed);
        vmm.ram.as_mut_bytes()[7] = 1;
        let suffix = vmm.state_blob_suffix().unwrap();
        let expected = crate::state_digest::state_hash_of(
            &crate::state_digest::memory_digest_of(vmm.guest_memory()),
            &suffix,
        );
        assert_eq!(vmm.state_hash().unwrap(), expected);
        let cost = vmm
            .hash_telemetry()
            .cost(crate::host_telemetry::HashSite::WholeRequest);
        assert_eq!(cost.calls, 1);
        assert_eq!(cost.ram_bytes, 0x1000);
        assert_eq!(cost.suffix_bytes, suffix.len() as u64);
        assert_eq!(
            cost.metadata_bytes,
            crate::state_digest::metadata_bytes(vmm.guest_memory().len())
        );
        assert_eq!(cost.errors, 0);
        assert_eq!(vmm.state_hash().unwrap(), expected);
        assert_eq!(
            vmm.hash_telemetry()
                .cost(crate::host_telemetry::HashSite::WholeRequest)
                .calls,
            2
        );
    }

    fn identity_vmm(state: VcpuState, hashing: bool) -> Vmm<MockBackend> {
        let mut backend = configured_mock(Vec::new());
        backend.set_state(state);
        let mut vmm = Vmm::new(backend, GuestRam::new(0x1000).unwrap());
        if hashing {
            vmm.wire_snapshot_hashing();
        }
        vmm
    }

    fn identity_state(raw: u64) -> VcpuState {
        let mut xsave = canonical_xsave_image();
        xsave.resize(832, 0);
        VcpuState {
            xsave,
            xsave_restore_bv: Some(raw),
            xcr0: 7,
            ..Default::default()
        }
    }

    #[test]
    fn a_non_standard_xsave_image_keeps_its_raw_restore_bitmap() {
        let mut hashes = Vec::new();
        for raw in [0, 2] {
            let state = VcpuState {
                xsave: vec![0xa5; 64],
                xsave_restore_bv: Some(raw),
                xcr0: 7,
                ..Default::default()
            };
            let mut vmm = identity_vmm(state, true);
            assert_eq!(vmm.save_vm_state().unwrap().xsave_restore_bv, Some(raw));
            hashes.push(vmm.state_hash().unwrap());
        }
        assert_ne!(hashes[0], hashes[1]);
    }

    #[test]
    fn logical_identity_hides_raw_restore_bits_without_changing_snapshots() {
        for hashing in [false, true] {
            let mut hashes = Vec::new();
            let mut persisted = Vec::new();
            for raw in [0, 2, 3] {
                let mut vmm = identity_vmm(identity_state(raw), hashing);
                let before = vmm.save_vm_state().unwrap();
                assert_eq!(before.xsave_restore_bv, Some(raw));
                hashes.push(vmm.state_hash().unwrap());
                persisted.push(before.encode().unwrap());
                assert_eq!(vmm.save_vm_state().unwrap(), before);
                assert_eq!(vmm.backend.save().unwrap().xsave_restore_bv, Some(raw));
            }
            assert!(hashes.windows(2).all(|pair| pair[0] == pair[1]));
            assert!(persisted.windows(2).all(|pair| pair[0] != pair[1]));
        }
    }

    #[test]
    fn logical_identity_preserves_active_fp_vector_and_mxcsr_distinctions() {
        for hashing in [false, true] {
            let baseline = identity_vmm(identity_state(0), hashing)
                .state_hash()
                .unwrap();
            for (bit, offset, byte) in [(1_u64, 32, 1), (2, 160, 1), (2, 25, 0x3f), (4, 576, 1)] {
                let mut state = identity_state(bit);
                state.xsave[512..520].copy_from_slice(&bit.to_le_bytes());
                state.xsave[offset] = byte;
                let mut vmm = identity_vmm(state.clone(), hashing);
                assert_ne!(vmm.state_hash().unwrap(), baseline);
                assert_eq!(vmm.save_vm_state().unwrap().xsave.0, state.xsave);
            }
            let noncanonical = |raw| {
                let mut state = identity_state(raw);
                state.xsave[160] = 1;
                identity_vmm(state, hashing).state_hash().unwrap()
            };
            assert_ne!(
                noncanonical(0),
                noncanonical(2),
                "an image the projection cannot validate keeps its raw bitmap"
            );
        }
    }

    #[test]
    fn a_snapshot_restores_across_equal_logical_identities() {
        let mut source = identity_vmm(identity_state(3), true);
        let snapshot = source.save_vm_state().unwrap();
        let mut target = identity_vmm(identity_state(0), true);
        target.ram.as_mut_bytes().fill(0xa5);
        target
            .restore_snapshot(source.guest_memory(), &snapshot)
            .unwrap();
        assert_eq!(target.save_vm_state().unwrap(), snapshot);
        assert_eq!(target.guest_memory(), source.guest_memory());
    }

    #[test]
    fn absent_xsave_restore_provenance_stays_distinct_from_a_present_bitmap() {
        let state_for = |restore_bv: Option<u64>, snapshot_hashing| {
            let mut backend = configured_mock(Vec::new());
            backend.set_state(VcpuState {
                xsave: canonical_xsave_image(),
                xsave_restore_bv: restore_bv,
                ..Default::default()
            });
            let mut vmm = Vmm::new(backend, GuestRam::new(0x1000).unwrap());
            if snapshot_hashing {
                vmm.wire_snapshot_hashing();
            }
            (vmm.state_blob().unwrap(), vmm.state_hash().unwrap())
        };

        for snapshot_hashing in [false, true] {
            let (none_blob, none_hash) = state_for(None, snapshot_hashing);
            for raw in [0, 2, 3] {
                let (blob, hash) = state_for(Some(raw), snapshot_hashing);
                assert_ne!(blob, none_blob, "present provenance {raw} against absence");
                assert_ne!(hash, none_hash, "present provenance {raw} against absence");
            }
            if !snapshot_hashing {
                assert_eq!(
                    none_hash,
                    [
                        0x7c, 0x6a, 0x67, 0x39, 0xe2, 0x2b, 0x71, 0xd0, 0x05, 0x07, 0x81, 0xc9,
                        0x26, 0xee, 0xfd, 0x6f, 0xa3, 0xaf, 0x19, 0x0c, 0x0c, 0x4b, 0x72, 0x42,
                        0x29, 0x34, 0xc5, 0x2f, 0x1a, 0xd1, 0xb3, 0x6d
                    ],
                    "absent XSAVE provenance must preserve the vCPU hash"
                );
            }
        }
    }

    #[test]
    fn xsave_restore_provenance_stays_in_persisted_snapshot_bytes() {
        let state_for = |restore_bv| {
            let state = vm_state::VmState {
                xsave: vm_state::XsaveImage(canonical_xsave_image()),
                xsave_restore_bv: Some(restore_bv),
                ..Default::default()
            };
            state.encode().unwrap()
        };
        let encoded_three = state_for(3);
        let encoded_two = state_for(2);
        assert_ne!(
            encoded_three, encoded_two,
            "distinct restore provenance must remain distinct on the wire"
        );
        assert_eq!(
            vm_state::VmState::decode(&encoded_three)
                .unwrap()
                .xsave_restore_bv,
            Some(3)
        );
        assert_eq!(
            vm_state::VmState::decode(&encoded_two)
                .unwrap()
                .xsave_restore_bv,
            Some(2)
        );
    }

    #[test]
    fn xsave_hash_uses_complete_snapshot_records() {
        fn chunk_payload<'a>(blob: &'a [u8], wanted: &[u8; 4]) -> &'a [u8] {
            let mut offset = 0;
            while offset < blob.len() {
                assert!(
                    blob.len() - offset >= 12,
                    "truncated state blob chunk header at {offset}"
                );
                let tag = &blob[offset..offset + 4];
                let len = u64::from_le_bytes(
                    blob[offset + 4..offset + 12]
                        .try_into()
                        .expect("eight-byte chunk length"),
                );
                let payload_start = offset + 12;
                let payload_end = payload_start
                    .checked_add(usize::try_from(len).expect("chunk length fits usize"))
                    .expect("chunk end does not overflow");
                assert!(
                    payload_end <= blob.len(),
                    "chunk {tag:?} extends past the state blob"
                );
                if tag == wanted {
                    return &blob[payload_start..payload_end];
                }
                offset = payload_end;
            }
            panic!("state blob has no {wanted:?} chunk");
        }

        for restore_bv in [0, 2, 3] {
            let mut backend = configured_mock(Vec::new());
            backend.set_state(VcpuState {
                xsave: canonical_xsave_image(),
                xsave_restore_bv: Some(restore_bv),
                ..Default::default()
            });
            let mut vmm = Vmm::new(backend, GuestRam::new(0x1000).unwrap());
            vmm.wire_snapshot_hashing();

            let mut snapshot = vmm.save_vm_state().unwrap();
            assert_eq!(snapshot.xsave_restore_bv, Some(restore_bv));
            snapshot.xsave_restore_bv = Some(0);
            let expected = <vm_state::VmState as SnapshotRecords>::encode(&snapshot).unwrap();
            let blob = vmm.state_blob().unwrap();
            let actual = chunk_payload(&blob, b"VMST");
            assert_eq!(
                actual,
                expected.as_slice(),
                "complete VMST for restore BV {restore_bv}"
            );
        }
    }

    #[test]
    fn deferred_checkpoint_hash_is_byte_identical_and_cannot_overwrite() {
        let exits = || {
            (0..256)
                .map(|_| Exit::Arch(X86Exit::Rdmsr { index: 0x10 }))
                .collect::<Vec<_>>()
        };
        let mut synchronous = vtime_vmm(exits(), 7);
        let mut deferred = vtime_vmm(exits(), 7);
        deferred.defer_virtual_time_checkpoint_hashes().unwrap();

        for _ in 0..256 {
            assert_eq!(synchronous.step().unwrap(), Step::Continued);
            assert_eq!(deferred.step().unwrap(), Step::Continued);
        }

        let expected = synchronous
            .virtual_time_trace()
            .unwrap()
            .normalized_log()
            .events[255]
            .state_hash
            .unwrap();
        assert_eq!(deferred.state_hash().unwrap(), expected);
        assert_eq!(
            deferred
                .virtual_time_trace()
                .unwrap()
                .normalized_log()
                .events[255]
                .state_hash,
            None
        );
        deferred
            .checkpoint_virtual_time_trace_at(255, expected)
            .unwrap();
        assert_eq!(
            synchronous.virtual_time_trace().unwrap().normalized_log(),
            deferred.virtual_time_trace().unwrap().normalized_log()
        );
        assert!(
            deferred
                .checkpoint_virtual_time_trace_at(255, expected)
                .is_err()
        );
        assert!(
            deferred
                .checkpoint_virtual_time_trace_at(254, expected)
                .is_err()
        );
    }

    #[test]
    fn deferral_chosen_before_the_first_run_covers_that_run() {
        let exits = || {
            (0..256)
                .map(|_| Exit::Arch(X86Exit::Rdmsr { index: 0x10 }))
                .collect::<Vec<_>>()
        };
        let mut vmm = vtime_vmm(exits(), 11);
        vmm.wire_snapshot_hashing();
        vmm.defer_virtual_time_checkpoint_hashes().unwrap();
        for _ in 0..256 {
            assert_eq!(vmm.step().unwrap(), Step::Continued);
        }
        assert!(vmm.snapshot_hashing_wired());
        assert_eq!(
            vmm.virtual_time_trace().unwrap().normalized_log().events[255].state_hash,
            None,
            "the checkpoint the run itself reached was deferred"
        );
        let hash = vmm.state_hash().unwrap();
        vmm.checkpoint_virtual_time_trace_at(255, hash).unwrap();
        assert_eq!(
            vmm.virtual_time_trace().unwrap().normalized_log().events[255].state_hash,
            Some(hash),
            "the deferred hash still materializes"
        );

        let mut late = vtime_vmm(exits(), 11);
        late.wire_snapshot_hashing();
        assert_eq!(late.step().unwrap(), Step::Continued);
        assert!(late.defer_virtual_time_checkpoint_hashes().is_err());
    }

    #[test]
    fn doorbell_offer_predicate_is_exact_for_an_unconfigured_composition() {
        let mut vmm = Vmm::new(
            configured_mock(Vec::new()),
            GuestRam::new(TEST_RAM).unwrap(),
        );
        for service in [
            ServiceId::Event,
            ServiceId::Sdk,
            ServiceId::Entropy,
            ServiceId::Payload,
            ServiceId::Pvclock,
        ] {
            assert!(!vmm.doorbell_service_offered(service as u16));
        }
        enable_nominal(&mut vmm, 7);
        assert!(vmm.doorbell_service_offered(ServiceId::Event as u16));
        assert!(vmm.doorbell_service_offered(ServiceId::Sdk as u16));
        assert!(vmm.doorbell_service_offered(ServiceId::Entropy as u16));
        assert!(!vmm.doorbell_service_offered(ServiceId::Payload as u16));
        assert!(!vmm.doorbell_service_offered(ServiceId::Pvclock as u16));
    }

    #[test]
    fn drain_unions_backend_log_with_host_writes_and_drains() {
        let mut m = configured_mock(vec![]);
        m.push_dirty_gfns(vec![5, 3, 5]);
        let mut vmm = Vmm::new(m, GuestRam::new(TEST_RAM).unwrap());
        vmm.apply_effect(&channel::Effect::XorMemory {
            gpa: 7 * 4096 - 4,
            bytes: vec![0xff; 8],
        })
        .unwrap();
        assert_eq!(vmm.drain_dirty_pages().unwrap(), Some(vec![3, 5, 6, 7]));
        assert_eq!(vmm.drain_dirty_pages().unwrap(), Some(vec![]));
    }

    fn sdk_attribution_counter(vmm: &Vmm<MockBackend>, name: &str) -> u64 {
        vmm.sdk_dispatch_telemetry()
            .counters()
            .into_iter()
            .find(|(key, _)| key == name)
            .map_or(0, |(_, value)| value)
    }

    fn sdk_attribution_event(vmm: &mut Vmm<MockBackend>) -> u32 {
        let mut frame = [0; HC_PAGE];
        let mut payload = vec![1, 0, 0, 2, 0];
        payload.extend(17_u64.to_le_bytes());
        let n =
            hypercall_proto::encode_request(ServiceId::Event, 1, 1, &payload, &mut frame).unwrap();
        vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + n].copy_from_slice(&frame[..n]);
        n as u32
    }

    #[test]
    fn sdk_dispatch_actual_guards_refusals_and_noncanonical_state() {
        use std::sync::{Arc, Mutex};
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        enable_nominal(&mut vmm, 7);
        let calls = Arc::new(Mutex::new(Vec::new()));
        let captured = calls.clone();
        vmm.set_host_operation_guard(Arc::new(move |site| {
            captured.lock().unwrap().push(site);
            Ok(())
        }));
        let n = sdk_attribution_event(&mut vmm);
        let mut reference = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        enable_nominal(&mut reference, 7);
        assert_eq!(n, sdk_attribution_event(&mut reference));
        assert_eq!(
            vmm.service_doorbell(n).unwrap(),
            reference.service_doorbell(n).unwrap()
        );
        assert_eq!(vmm.state_hash().unwrap(), reference.state_hash().unwrap());
        assert_eq!(vmm.sdk_events(), reference.sdk_events());
        assert_eq!(
            sdk_attribution_counter(&reference, "sdk_dispatch.event.response_guard_calls"),
            0
        );
        assert_eq!(
            sdk_attribution_counter(&reference, "sdk_dispatch.event.requests"),
            1
        );
        assert_eq!(*calls.lock().unwrap(), vec![HostOperationSite::SdkResponse]);
        assert_eq!(
            sdk_attribution_counter(&vmm, "sdk_dispatch.event.response_guard_calls"),
            1
        );
        assert_eq!(
            sdk_attribution_counter(&vmm, "sdk_dispatch.event_shape.2.9.0.response_guard_calls"),
            1
        );
        let hash = vmm.state_hash().unwrap();
        vmm.sdk_dispatch_telemetry
            .borrow_mut()
            .request(Attribution::kind(Kind::Unknown), false);
        assert_eq!(vmm.state_hash().unwrap(), hash);
        let (_, sample) = vmm.measure_sdk_guard_using(HostOperationSite::SdkResponse, || 73);
        assert_eq!(
            sample,
            Callback {
                calls: 1,
                errors: 0,
                nanos: 73
            }
        );
        vmm.set_host_operation_guard(Arc::new(|_| Err("refused".into())));
        let before = vmm.sdk_events().len();
        let response = vmm.ram.as_bytes()[RESP_GPA..RESP_GPA + 64].to_vec();
        assert!(vmm.service_doorbell(n).is_err());
        assert_eq!(vmm.sdk_events().len(), before + 1);
        assert_eq!(vmm.ram.as_bytes()[RESP_GPA..RESP_GPA + 64], response);
        assert_eq!(
            sdk_attribution_counter(&vmm, "sdk_dispatch.event.response_guard_errors"),
            1
        );
        assert_eq!(
            sdk_attribution_counter(&vmm, "sdk_dispatch.event.requests"),
            2
        );
        let (_, sample) = vmm.measure_sdk_guard_using(HostOperationSite::SdkResponse, || 89);
        assert_eq!(
            sample,
            Callback {
                calls: 1,
                errors: 1,
                nanos: 89
            }
        );
        vmm.set_host_operation_guard(Arc::new(|_| Ok(())));
        vmm.service_doorbell(1).unwrap();
        assert_eq!(
            sdk_attribution_counter(&vmm, "sdk_dispatch.invalid.requests"),
            1
        );
        assert_eq!(
            sdk_attribution_counter(&vmm, "sdk_dispatch.invalid.response_guard_calls"),
            1
        );
        vmm.service_doorbell((HC_PAGE + 1) as u32).unwrap();
        assert_eq!(
            sdk_attribution_counter(&vmm, "sdk_dispatch.unreadable.requests"),
            1
        );
        assert_eq!(
            sdk_attribution_counter(&vmm, "sdk_dispatch.unreadable.response_guard_calls"),
            1
        );
    }

    #[test]
    fn sdk_dispatch_deferred_and_pending_response_ownership() {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        enable_nominal(&mut vmm, 7);
        vmm.set_host_operation_guard(std::sync::Arc::new(|_| Ok(())));
        let n = sdk_attribution_event(&mut vmm);
        vmm.run_deadline_vns = Some(0);
        assert_eq!(vmm.service_doorbell(n).unwrap(), Step::SdkStop);
        let pending = vmm.sdk_snapshot().unwrap().unwrap();
        assert_eq!(vmm.step_until(Some(0)).unwrap(), Step::SdkStop);
        assert_eq!(
            sdk_attribution_counter(&vmm, "sdk_dispatch.event.requests"),
            1
        );
        assert_eq!(
            sdk_attribution_counter(&vmm, "sdk_dispatch.event.deferred"),
            1
        );
        assert_eq!(
            sdk_attribution_counter(&vmm, "sdk_dispatch.event.response_guard_calls"),
            0
        );
        vmm.sdk_restore_events(&pending);
        vmm.step_until(Some(1)).unwrap();
        assert_eq!(
            sdk_attribution_counter(&vmm, "sdk_dispatch.event.requests"),
            1
        );
        assert_eq!(
            sdk_attribution_counter(&vmm, "sdk_dispatch.event.response_guard_calls"),
            1
        );
        for opcode in [2, 3] {
            let question =
                channel::Question::with_request_id(7, 8, 1_u64.to_le_bytes().to_vec()).unwrap();
            vmm.sdk.as_mut().unwrap().pending_stop = Some(if opcode == 2 {
                SdkStop::CoverageDecision {
                    moment: 0,
                    seq: 9,
                    question,
                    ready: 1,
                }
            } else {
                SdkStop::Decision {
                    moment: 0,
                    seq: 9,
                    question,
                }
            });
            let request = crate::service_transcript::pending_request(
                vmm.sdk.as_ref().unwrap().pending_stop.as_ref().unwrap(),
            )
            .unwrap();
            vmm.write_service_response(0, &request, opcode, 9, Status::BadRequest, &[])
                .unwrap();
            let kind = if opcode == 2 { "coverage" } else { "service" };
            assert_eq!(
                sdk_attribution_counter(&vmm, &format!("sdk_dispatch.{kind}.response_guard_calls")),
                1
            );
            assert_eq!(
                sdk_attribution_counter(&vmm, &format!("sdk_dispatch.{kind}.requests")),
                0
            );
        }
        assert_eq!(
            sdk_attribution_counter(&vmm, "sdk_dispatch.event.response_guard_calls"),
            1
        );
    }

    #[test]
    fn doorbell_response_write_is_drained_as_host_dirty() {
        let mut m = configured_mock(vec![]);
        m.enable_dirty_tracking();
        let mut vmm = Vmm::new(m, GuestRam::new(TEST_RAM).unwrap());
        vmm.write_doorbell_response(&[0xAB; 16]).unwrap();
        assert_eq!(
            vmm.drain_dirty_pages().unwrap(),
            Some(vec![(RESP_GPA as u64) / 4096])
        );
    }

    #[test]
    fn host_operation_guard_refuses_doorbell_reply_before_guest_memory_write() {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        let changed = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        let signal = std::sync::Arc::clone(&changed);
        let sites = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
        let captured_sites = std::sync::Arc::clone(&sites);
        vmm.set_host_operation_guard(std::sync::Arc::new(move |site| {
            captured_sites.lock().unwrap().push(site);
            if signal.load(std::sync::atomic::Ordering::SeqCst) {
                Err("host loader changed".into())
            } else {
                Ok(())
            }
        }));
        vmm.write_doorbell_response(&[0xAB; 16]).unwrap();
        changed.store(true, std::sync::atomic::Ordering::SeqCst);
        let before = vmm.ram.as_bytes()[RESP_GPA..RESP_GPA + 16].to_vec();
        assert!(matches!(
            vmm.write_doorbell_response(&[0xCD; 16]),
            Err(VmmError::ContractViolation(reason)) if reason == "host loader changed"
        ));
        assert_eq!(&vmm.ram.as_bytes()[RESP_GPA..RESP_GPA + 16], before);
        assert_eq!(
            *sites.lock().unwrap(),
            vec![
                HostOperationSite::SdkResponse,
                HostOperationSite::SdkResponse
            ]
        );
    }

    #[test]
    fn drain_rebases_high_base_gfns_and_excludes_the_doorbell_slot() {
        let mut m = configured_mock(vec![]);
        m.push_dirty_gfns(vec![0x4_0001, 0x4_0003, 15]);
        let mut vmm = Vmm::new(m, GuestRam::new(TEST_RAM).unwrap());
        vmm.ram_base_gpa = 0x4000_0000;

        let dirty = vmm.drain_dirty_pages().unwrap().unwrap();
        assert_eq!(
            dirty,
            vec![1, 3],
            "high GFNs rebased to main-RAM indices; the doorbell slot's GFN excluded"
        );
        let pages = (vmm.ram.len() / 4096) as u64;
        assert!(
            dirty.iter().all(|&g| g < pages),
            "every drained GFN indexes the main RAM — no snapshot_derive fallback"
        );
    }

    #[test]
    fn wholesale_host_write_poisons_the_drain_until_reset() {
        let mut m = configured_mock(vec![]);
        m.enable_dirty_tracking();
        let mut vmm = Vmm::new(m, GuestRam::new(TEST_RAM).unwrap());
        vmm.restore_guest_memory(&vec![7u8; TEST_RAM]).unwrap();
        assert_eq!(
            vmm.drain_dirty_pages().unwrap(),
            None,
            "untrackable ⇒ no dirty set"
        );
        assert!(
            vmm.reset_dirty_tracking().unwrap(),
            "re-arm at the new baseline"
        );
        assert_eq!(vmm.drain_dirty_pages().unwrap(), Some(vec![]));
    }

    #[test]
    fn drain_declines_without_backend_tracking() {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        vmm.write_doorbell_response(&[1]).unwrap();
        assert_eq!(vmm.drain_dirty_pages().unwrap(), None);
        assert!(!vmm.reset_dirty_tracking().unwrap());
    }

    #[test]
    fn write_guest_pages_writes_pages_and_poison_dirty_drain_until_reset() {
        let mut backend = configured_mock(vec![]);
        backend.enable_dirty_tracking();
        let mut vmm = Vmm::new(backend, GuestRam::new(TEST_RAM).unwrap());
        let page_a = [0xA5_u8; 4096];
        let page_b = [0x5A_u8; 4096];

        vmm.write_guest_pages(&[(2, page_a), (5, page_b)]).unwrap();
        assert_eq!(&vmm.guest_memory()[2 * 4096..3 * 4096], &page_a);
        assert_eq!(&vmm.guest_memory()[5 * 4096..6 * 4096], &page_b);
        assert_eq!(vmm.drain_dirty_pages().unwrap(), None);
        assert!(vmm.reset_dirty_tracking().unwrap());
        assert_eq!(vmm.drain_dirty_pages().unwrap(), Some(vec![]));
    }

    #[test]
    fn write_guest_pages_empty_input_is_a_noop() {
        let mut backend = configured_mock(vec![]);
        backend.enable_dirty_tracking();
        let mut vmm = Vmm::new(backend, GuestRam::new(TEST_RAM).unwrap());
        let before = vmm.guest_memory().to_vec();

        vmm.write_guest_pages(&[]).unwrap();

        assert_eq!(vmm.guest_memory(), &before);
        assert!(!vmm.host_dirty_wholesale);
        assert_eq!(vmm.drain_dirty_pages().unwrap(), Some(vec![]));
    }

    #[test]
    fn write_guest_pages_out_of_range_is_atomic() {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        let before = vmm.guest_memory().to_vec();
        let page = [0xCC_u8; 4096];
        let out_of_range = (TEST_RAM / 4096) as u64;

        assert!(matches!(
            vmm.write_guest_pages(&[(1, page), (out_of_range, page)]),
            Err(VmmError::ContractViolation(_))
        ));
        assert_eq!(vmm.guest_memory(), &before);
        assert!(vmm.host_dirty.is_empty());
        assert!(!vmm.host_dirty_wholesale);
    }

    #[test]
    fn write_guest_pages_duplicate_gfn_is_atomic() {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        let before = vmm.guest_memory().to_vec();
        let page_a = [0x11_u8; 4096];
        let page_b = [0x22_u8; 4096];

        assert!(matches!(
            vmm.write_guest_pages(&[(3, page_a), (3, page_b)]),
            Err(VmmError::ContractViolation(_))
        ));
        assert_eq!(vmm.guest_memory(), &before);
        assert!(vmm.host_dirty.is_empty());
        assert!(!vmm.host_dirty_wholesale);
    }

    #[test]
    fn borrowed_guest_pages_validate_before_writing_unsorted_input() {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        let before = vmm.guest_memory().to_vec();
        let a = [0x13; 4096];
        let b = [0x27; 4096];
        let ha = *blake3::hash(&a).as_bytes();
        let hb = *blake3::hash(&b).as_bytes();
        assert!(
            vmm.write_guest_hashed_page_refs(&[(3, &ha, &a), (1, &hb, &b), (3, &hb, &b)])
                .is_err()
        );
        assert_eq!(vmm.guest_memory(), before);
        assert!(!vmm.host_dirty_wholesale);
        assert!(
            vmm.write_guest_hashed_page_refs(&[(1, &ha, &a), ((TEST_RAM / 4096) as u64, &hb, &b)])
                .is_err()
        );
        assert_eq!(vmm.guest_memory(), before);
        vmm.write_guest_hashed_page_refs(&[(3, &ha, &a), (1, &hb, &b)])
            .unwrap();
        assert_eq!(&vmm.guest_memory()[4096..8192], &b);
        assert_eq!(&vmm.guest_memory()[3 * 4096..4 * 4096], &a);
        assert!(vmm.host_dirty_wholesale);
    }

    #[test]
    fn guest_page_write_validation_covers_each_ram_and_gpa_boundary() {
        assert!(!valid_guest_ram_len(0, 4096));
        assert!(!valid_guest_ram_len(4095, 4096));
        assert!(valid_guest_ram_len(4096, 4096));

        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        vmm.ram_base_gpa = u64::MAX - 4095;
        let before = vmm.guest_memory().to_vec();
        assert!(matches!(
            vmm.write_guest_pages(&[(0, [0xA5; 4096])]),
            Err(VmmError::ContractViolation(message))
                if message.contains("invalid GPA range")
        ));
        assert_eq!(vmm.guest_memory(), &before);
    }

    #[test]
    fn doorbell_exit_counter_reports_the_exact_observed_count() {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        vmm.doorbell_exits = 7;
        assert_eq!(vmm.doorbell_exits(), 7);
    }

    #[test]
    fn doorbell_services_events_and_surfaces_stops() {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        enable_nominal(&mut vmm, 7);

        fn ring(
            vmm: &mut Vmm<MockBackend>,
            service: ServiceId,
            payload: &[u8],
        ) -> (Step, u16, Vec<u8>) {
            let mut buf = [0u8; HC_PAGE];
            let n = hypercall_proto::encode_request(service, 1, 1, payload, &mut buf).unwrap();
            vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + n].copy_from_slice(&buf[..n]);
            let step = vmm.dispatch_out(DOORBELL_PORT, 4, n as u32).unwrap();
            let page = vmm.guest_memory()[RESP_GPA..RESP_GPA + HC_PAGE].to_vec();
            let (hdr, pl) = decode(&page).expect("a valid response frame");
            (step, hdr.status, pl.to_vec())
        }

        let hit_id = (1u32 << 24) | 1;
        let mut hit = hit_id.to_le_bytes().to_vec();
        hit.extend_from_slice(&[0, 0, 0]);
        assert_eq!(ring(&mut vmm, ServiceId::Event, &hit).0, Step::Continued);
        assert_eq!(vmm.sdk_events().len(), 1);
    }

    #[test]
    fn coverage_doorbell_uses_the_scheduler_vocabulary() {
        let seed = 0x6d36;
        let mut expected_env = channel::RecordedEnv::nominal(seed);
        let expected = match expected_env
            .decide(&channel::Question::scheduler(3).unwrap())
            .unwrap()
        {
            channel::ServiceResponse::Answered(channel::Answer::Data(bytes)) => {
                u32::from_le_bytes(bytes.try_into().expect("scheduler answer is four bytes"))
            }
            other => panic!("unexpected scheduler answer: {other:?}"),
        };

        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        enable_nominal(&mut vmm, seed);
        let mut request = [0_u8; SDK_COVERAGE_REQUEST_LEN];
        request[0..4].copy_from_slice(&7_u32.to_le_bytes());
        request[4..12].copy_from_slice(&SDK_COVERAGE_QUANTUM.to_le_bytes());
        request[12..16].copy_from_slice(&3_u32.to_le_bytes());
        let mut frame = [0_u8; HC_PAGE];
        let n = hypercall_proto::encode_request(ServiceId::Sdk, 2, 9, &request, &mut frame)
            .expect("coverage request");
        vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + n].copy_from_slice(&frame[..n]);
        assert_eq!(vmm.service_doorbell(n as u32).unwrap(), Step::Continued);
        let page = &vmm.guest_memory()[RESP_GPA..RESP_GPA + HC_PAGE];
        let (header, payload) = decode(page).expect("coverage response");
        assert_eq!(header.status, Status::Ok as u16);
        assert_eq!(
            u32::from_le_bytes(payload[8..12].try_into().unwrap()),
            expected
        );
        assert_eq!(
            vmm.sdk_coverage(),
            &[(0, 7, SDK_COVERAGE_QUANTUM, 3, expected)]
        );
    }

    #[test]
    fn unrecorded_coverage_quantum_stops_before_guest_response_and_replays_recorded_answer() {
        let build = || {
            let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
            enable_seeded_service(&mut vmm, 7);
            vmm
        };
        let mut request = [0_u8; SDK_COVERAGE_REQUEST_LEN];
        request[0..4].copy_from_slice(&7_u32.to_le_bytes());
        request[4..12].copy_from_slice(&1_u64.to_le_bytes());
        request[12..16].copy_from_slice(&2_u32.to_le_bytes());
        let mut frame = [0_u8; HC_PAGE];
        let n =
            hypercall_proto::encode_request(ServiceId::Sdk, 2, 9, &request, &mut frame).unwrap();
        let mut vmm = build();
        vmm.set_host_operation_guard(std::sync::Arc::new(|_| Ok(())));
        vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + n].copy_from_slice(&frame[..n]);
        assert_eq!(vmm.service_doorbell(n as u32).unwrap(), Step::SdkStop);
        let question = channel::Question::with_request_id(
            7,
            channel::SERVICE_COVERAGE_QUANTUM,
            1_u64.to_le_bytes().to_vec(),
        )
        .unwrap();
        assert_eq!(
            vmm.take_sdk_stop(),
            Some(SdkStop::CoverageDecision {
                moment: 0,
                seq: 9,
                question: question.clone(),
                ready: 2,
            })
        );
        assert_eq!(&vmm.guest_memory()[RESP_GPA..RESP_GPA + 16], &[0; 16]);
        assert!(vmm.sdk_coverage().is_empty());
        let stopped = vmm.state_hash().unwrap();
        let invalid = channel::Answer::Data(0_u64.to_le_bytes().to_vec());
        assert!(
            vmm.sdk_snapshot_after_answer(0, &question, &invalid, None)
                .is_err()
        );
        assert_eq!(vmm.state_hash().unwrap(), stopped);
        let answer = channel::Answer::Data(64_u64.to_le_bytes().to_vec());
        vmm.sdk_snapshot_after_answer(0, &question, &answer, None)
            .unwrap();
        let before = sdk_attribution_counter(&vmm, "sdk_dispatch.coverage.response_guard_calls");
        vmm.resolve_service_answer(answer.clone(), None).unwrap();
        assert_eq!(
            sdk_attribution_counter(&vmm, "sdk_dispatch.coverage.response_guard_calls"),
            before + 1
        );
        assert_eq!(
            sdk_attribution_counter(&vmm, "sdk_dispatch.service.response_guard_calls"),
            0
        );
        let (header, payload) = decode(&vmm.guest_memory()[RESP_GPA..RESP_GPA + HC_PAGE]).unwrap();
        assert_eq!(
            (header.opcode, header.seq, header.status),
            (2, 9, Status::Ok as u16)
        );
        assert_eq!(u64::from_le_bytes(payload[..8].try_into().unwrap()), 65);
        let selected = u32::from_le_bytes(payload[8..12].try_into().unwrap());
        assert!(selected < 2);
        assert_eq!(vmm.sdk_coverage(), &[(0, 7, 1, 2, selected)]);
        let after = vmm.state_hash().unwrap();

        let mut replay = build();
        replay.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + n].copy_from_slice(&frame[..n]);
        replay
            .sdk
            .as_mut()
            .unwrap()
            .env
            .record_question(0, &question, answer);
        assert_eq!(replay.service_doorbell(n as u32).unwrap(), Step::Continued);
        assert_eq!(replay.sdk_coverage(), vmm.sdk_coverage());
        assert_eq!(replay.state_hash().unwrap(), after);
    }

    #[test]
    fn coverage_threshold_is_enforced_and_snapshot_replay_reproduces() {
        let build = || {
            let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
            enable_nominal(&mut vmm, 0x51ced);
            vmm
        };
        let mut base = build();
        let CoverageOutcome::Answered(first) = base.decide_coverage(4, 1, 1, 2).unwrap() else {
            panic!("nominal coverage must answer");
        };
        let snap = base.sdk_snapshot().unwrap().expect("SDK snapshot");
        let hash_after_first = base.state_hash().unwrap();
        assert_eq!(base.decide_coverage(5, 1, 3, 2), Err(Status::BadRequest));
        assert_eq!(base.state_hash().unwrap(), hash_after_first);
        let continuation = base.decide_coverage(5, 1, first.next, 2).unwrap();
        let mut replay = build();
        replay.sdk_restore(&snap).unwrap();
        assert_eq!(replay.state_hash().unwrap(), hash_after_first);
        assert_eq!(
            replay.decide_coverage(5, 1, first.next, 2).unwrap(),
            continuation
        );
    }

    #[test]
    fn malformed_scheduler_answer_does_not_advance_the_channel() {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        enable_nominal(&mut vmm, 0x51ced);
        vmm.sdk
            .as_mut()
            .expect("SDK enabled")
            .env
            .record_service_request(
                41,
                channel::SERVICE_SCHEDULER,
                7,
                channel::Answer::Data(vec![1, 2, 3]),
            );
        let before = vmm.state_hash().unwrap();
        assert_eq!(vmm.decide_coverage(41, 7, 1, 2), Err(Status::Internal));
        assert_eq!(vmm.state_hash().unwrap(), before);
        assert!(vmm.sdk_coverage().is_empty());
    }

    #[test]
    fn payload_tape_is_exact_hash_visible_snapshot_complete_and_exhausts_loudly() {
        fn make(entries: Vec<Vec<u8>>) -> Vmm<MockBackend> {
            let mut env: channel::RecordedEnv<Box<dyn channel::ServiceHandler>> =
                channel::RecordedEnv::new(7, Box::new(channel::NominalHandler));
            env.set_payloads(Some(entries)).unwrap();
            let config = ServiceConfig::default();
            let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
            vmm.enable_sdk(env, &config);
            vmm
        }
        fn ring(vmm: &mut Vmm<MockBackend>, bytes: u32) -> (Step, u16, Vec<u8>) {
            let mut frame = [0_u8; HC_PAGE];
            let n = hypercall_proto::encode_request(
                ServiceId::Payload,
                1,
                1,
                &bytes.to_le_bytes(),
                &mut frame,
            )
            .unwrap();
            vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + n].copy_from_slice(&frame[..n]);
            let step = vmm.dispatch_out(DOORBELL_PORT, 4, n as u32).unwrap();
            let page = &vmm.guest_memory()[RESP_GPA..RESP_GPA + HC_PAGE];
            let (header, payload) = decode(page).unwrap();
            (step, header.status, payload.to_vec())
        }
        let mut vmm = make(vec![vec![0x81, 4], vec![0, 2]]);
        assert_eq!(
            ring(&mut vmm, 2),
            (Step::Continued, Status::Ok as u16, vec![0x81, 4])
        );
        let snap = vmm.sdk_snapshot().unwrap().expect("SDK snapshot");
        assert_eq!(snap.remaining_payloads(), Some(vec![vec![0, 2]]));
        assert_eq!(
            ring(&mut vmm, 2),
            (Step::Continued, Status::Ok as u16, vec![0, 2])
        );
        vmm.sdk_restore(&snap).unwrap();
        assert_eq!(ring(&mut vmm, 2).2, vec![0, 2]);
        assert_eq!(ring(&mut vmm, 2).0, Step::SdkStop);
        assert_eq!(vmm.take_sdk_stop(), Some(SdkStop::Quiescent));
    }

    #[test]
    fn doorbell_uses_a_dedicated_memslot_when_ram_is_based_high() {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        vmm.ram_base_gpa = 0x4000_0000;
        enable_nominal(&mut vmm, 7);
        assert!(vmm.service_doorbell(16).is_err());
        vmm.map_doorbell_pages().unwrap();
        let hit_id = (1u32 << 24) | 1;
        let mut payload = hit_id.to_le_bytes().to_vec();
        payload.extend_from_slice(&[0, 0, 0]);
        let mut buf = [0u8; HC_PAGE];
        let n =
            hypercall_proto::encode_request(ServiceId::Event, 1, 1, &payload, &mut buf).unwrap();
        let req_off = REQ_GPA - DOORBELL_MAP_GPA;
        vmm.doorbell_pages.as_mut().unwrap().as_mut_bytes()[req_off..req_off + n]
            .copy_from_slice(&buf[..n]);
        assert_eq!(vmm.service_doorbell(n as u32).unwrap(), Step::Continued);
        let resp_off = RESP_GPA - DOORBELL_MAP_GPA;
        let resp =
            vmm.doorbell_pages.as_ref().unwrap().as_bytes()[resp_off..resp_off + HC_PAGE].to_vec();
        let (hdr, _) = decode(&resp).expect("dedicated response");
        assert_eq!(hdr.status, Status::Ok as u16);
        assert!(
            vmm.guest_memory()[REQ_GPA..RESP_GPA + HC_PAGE]
                .iter()
                .all(|&b| b == 0)
        );
        assert!(vmm.host_dirty.contains(&(RESP_GPA as u64 / 4096)));
    }

    #[test]
    fn high_ram_base_resolves_absolute_gpas_and_hashes_the_doorbell() {
        let make = || {
            let mut v = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
            v.ram_base_gpa = 0x4000_0000;
            v.map_doorbell_pages().unwrap();
            v
        };
        let mut a = make();
        let mut b = make();
        assert_eq!(a.state_hash().unwrap(), b.state_hash().unwrap());
        b.doorbell_pages.as_mut().unwrap().as_mut_bytes()[7] ^= 0xFF;
        assert_ne!(a.state_hash().unwrap(), b.state_hash().unwrap());
        let mut v = make();
        v.ram.as_mut_bytes()[0x100..0x104].copy_from_slice(&[1, 2, 3, 4]);
        assert_eq!(v.guest_slice(0x4000_0100, 4), Some(&[1u8, 2, 3, 4][..]));
        assert_eq!(v.guest_slice(0x100, 4), None);
        assert!(v.guest_slice(REQ_GPA as u64, HC_PAGE).is_some());
        v.apply_effect(&channel::Effect::XorMemory {
            gpa: 0x4000_0100,
            bytes: vec![0xFF],
        })
        .unwrap();
        assert_eq!(v.ram.as_bytes()[0x100], 1 ^ 0xFF);
        assert!(
            v.apply_effect(&channel::Effect::XorMemory {
                gpa: 0x500,
                bytes: vec![0xFF]
            })
            .is_err()
        );
    }

    #[test]
    fn arm64_save_restore_preserves_the_doorbell_pages() {
        use crate::vendor::arm64::board::RAM_BASE as ARM_RAM_BASE;
        use vmm_backend::{Arm64Policy, MockArm64Backend};

        let arm_vmm = || {
            let mut b = MockArm64Backend::new();
            b.set_policy(&Arm64Policy::default()).unwrap();
            let mut v = Vmm::new(b, GuestRam::new(0x10_0000).unwrap());
            v.ram_base_gpa = ARM_RAM_BASE;
            v.map_doorbell_pages().unwrap();
            v
        };

        let mut src = arm_vmm();
        src.doorbell_pages.as_mut().unwrap().as_mut_bytes()[..4]
            .copy_from_slice(&[0xAA, 0xBB, 0xCC, 0xDD]);
        let blob = src.save_vm_state().unwrap();

        let mut dst = arm_vmm();
        dst.restore_vm_state(&blob).unwrap();
        assert_eq!(
            &dst.doorbell_pages.as_ref().unwrap().as_bytes()[..4],
            &[0xAA, 0xBB, 0xCC, 0xDD]
        );

        let mut nodoor = {
            let mut b = MockArm64Backend::new();
            b.set_policy(&Arm64Policy::default()).unwrap();
            Vmm::new(b, GuestRam::new(0x10_0000).unwrap())
        };
        let err = nodoor.restore_vm_state(&blob).unwrap_err();
        assert!(
            format!("{err}").contains("doorbell wiring mismatch"),
            "{err}"
        );
    }

    #[test]
    fn x86_mapped_doorbell_cannot_seal_without_a_device_record() {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        vmm.ram_base_gpa = 0x4000_0000;
        vmm.map_doorbell_pages().unwrap();
        assert!(matches!(
            vmm.save_vm_state(),
            Err(VmmError::ContractViolation(reason))
                if reason == "save_vm_state: mapped doorbell pages are absent from the VM state"
        ));
    }

    #[test]
    fn state_components_localizes_a_doorbell_only_divergence() {
        let make = || {
            let mut v = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
            v.ram_base_gpa = 0x4000_0000;
            v.map_doorbell_pages().unwrap();
            v
        };
        let mut a = make();
        let mut b = make();
        b.doorbell_pages.as_mut().unwrap().as_mut_bytes()[3] ^= 0xFF;

        assert_ne!(a.state_hash().unwrap(), b.state_hash().unwrap());

        let ca = a.state_components().unwrap();
        let cb = b.state_components().unwrap();
        let da = ca
            .iter()
            .find(|(l, _)| *l == "doorbell")
            .expect("a doorbell component");
        let db_ = cb
            .iter()
            .find(|(l, _)| *l == "doorbell")
            .expect("a doorbell component");
        assert_ne!(da.1, db_.1, "the doorbell component must localize it");
        for (la, dga) in &ca {
            if *la == "doorbell" {
                continue;
            }
            let dgb = cb.iter().find(|(lb, _)| lb == la).map(|(_, d)| d);
            assert_eq!(
                Some(dga),
                dgb,
                "component {la} must match (only doorbell differs)"
            );
        }

        let mut plain = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        assert!(
            !plain
                .state_components()
                .unwrap()
                .iter()
                .any(|(l, _)| *l == "doorbell")
        );
    }

    #[test]
    fn observation_registration_is_ram_bounded_and_survives_sdk_restore() {
        use hypercall_proto::observation::{Descriptor, EVENT_ID};
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        vmm.enable_sdk(nominal_env(1), &ServiceConfig::default());
        let ring = |vmm: &mut Vmm<MockBackend>, data: &[u8]| {
            let mut payload = EVENT_ID.to_le_bytes().to_vec();
            payload.extend_from_slice(data);
            let mut request = [0; HC_PAGE];
            let n = hypercall_proto::encode_request(ServiceId::Event, 1, 1, &payload, &mut request)
                .unwrap();
            let mut response = [0; HC_PAGE];
            let (len, stop) = vmm.dispatch_doorbell(7, &request[..n], &mut response);
            assert!(stop.is_none());
            decode(&response[..len]).unwrap().0.status
        };
        let region = Descriptor {
            handle: 1,
            address: 0x1000,
            len: 4096,
        };
        assert_eq!(ring(&mut vmm, &region.encode().unwrap()), Status::Ok as u16);
        let saved = vmm.sdk_snapshot().unwrap().unwrap();
        let original = vmm.sdk_events().to_vec();
        let outside = Descriptor {
            address: TEST_RAM as u64,
            ..region
        };
        assert_eq!(
            ring(&mut vmm, &outside.encode().unwrap()),
            Status::BadRequest as u16
        );
        assert_eq!(ring(&mut vmm, &[0; 23]), Status::BadRequest as u16);
        assert_eq!(vmm.sdk_events(), original);
        let closed = Descriptor {
            address: 0,
            len: 0,
            ..region
        };
        assert_eq!(ring(&mut vmm, &closed.encode().unwrap()), Status::Ok as u16);
        assert_eq!(vmm.sdk_events().len(), 2);
        vmm.sdk_restore(&saved).unwrap();
        assert_eq!(vmm.sdk_events(), original);
    }

    #[test]
    fn doorbell_rejects_malformed_sdk_event_payloads() {
        fn ring(vmm: &mut Vmm<MockBackend>, event_id: u32, data: &[u8]) -> (u16, bool, usize) {
            let mut payload = event_id.to_le_bytes().to_vec();
            payload.extend_from_slice(data);
            let mut buf = [0u8; HC_PAGE];
            let n = hypercall_proto::encode_request(ServiceId::Event, 1, 1, &payload, &mut buf)
                .unwrap();
            vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + n].copy_from_slice(&buf[..n]);
            let step = vmm.dispatch_out(DOORBELL_PORT, 4, n as u32).unwrap();
            let page = vmm.guest_memory()[RESP_GPA..RESP_GPA + HC_PAGE].to_vec();
            let (hdr, _) = decode(&page).expect("a response frame");
            (hdr.status, step == Step::SdkStop, vmm.sdk_events().len())
        }
        let mk = || {
            let mut v = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
            v.enable_sdk(nominal_env(1), &ServiceConfig::default());
            v
        };
        let assert_id = (u32::from(sdk::NAMESPACE_ASSERT) << sdk::NAMESPACE_SHIFT) | 20;
        let setup_id = u32::from(sdk::NAMESPACE_LIFECYCLE) << sdk::NAMESPACE_SHIFT;
        let frame_id = setup_id | 1;

        let mut v = mk();
        assert_eq!(
            ring(&mut v, assert_id, &[1, 2, 0]),
            (Status::BadRequest as u16, false, 0),
            "a malformed assert violation is rejected, never a bug from garbage"
        );

        let mut v = mk();
        assert_eq!(
            ring(&mut v, setup_id, &[0xAB]),
            (Status::BadRequest as u16, false, 0),
            "a non-empty setup_complete is rejected, never arms the deferral"
        );

        let mut v = mk();
        assert_eq!(ring(&mut v, setup_id, &[]), (Status::Ok as u16, false, 1));

        let mut v = mk();
        assert_eq!(
            ring(&mut v, frame_id, &[0; 7]),
            (Status::BadRequest as u16, false, 0),
            "a short frame_complete is rejected, never arms the deferral"
        );

        let mut v = mk();
        assert_eq!(
            ring(&mut v, frame_id, &17_u64.to_le_bytes()),
            (Status::Ok as u16, false, 1)
        );
    }

    #[test]
    fn doorbell_probe_on_a_channel_less_vm_answers_unknown_service() {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        let mut buf = [0u8; HC_PAGE];
        let n = hypercall_proto::encode_request(
            ServiceId::Pvclock,
            1,
            5,
            &0x4000u64.to_le_bytes(),
            &mut buf,
        )
        .unwrap();
        vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + n].copy_from_slice(&buf[..n]);
        let step = vmm.dispatch_out(DOORBELL_PORT, 4, n as u32).unwrap();
        assert_eq!(step, Step::Continued);
        let page = vmm.guest_memory()[RESP_GPA..RESP_GPA + HC_PAGE].to_vec();
        let (hdr, pl) = decode(&page).expect("a response frame is written, not a silent drop");
        assert_eq!(
            hdr.status,
            Status::UnknownService as u16,
            "clean UnknownService"
        );
        assert_eq!(
            hdr.service,
            ServiceId::Pvclock as u16,
            "echoes the probed service id"
        );
        assert_eq!(
            (hdr.opcode, hdr.seq),
            (1, 5),
            "echoes the request opcode + seq"
        );
        assert!(pl.is_empty(), "an error frame carries no payload");
    }

    #[test]
    fn doorbell_unknown_service_returns_an_unknown_service_frame() {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        vmm.enable_sdk(nominal_env(1), &ServiceConfig::default());
        let mut buf = [0u8; HC_PAGE];
        let n = hypercall_proto::encode_request(ServiceId::Sdk, 7, 99, &[], &mut buf).unwrap();
        let unknown: u16 = 0xABCD;
        buf[6..8].copy_from_slice(&unknown.to_le_bytes());
        vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + n].copy_from_slice(&buf[..n]);

        let step = vmm.dispatch_out(DOORBELL_PORT, 4, n as u32).unwrap();
        assert_eq!(step, Step::Continued);
        let page = vmm.guest_memory()[RESP_GPA..RESP_GPA + HC_PAGE].to_vec();
        let (hdr, pl) = decode(&page).expect("a response frame is written, not a silent drop");
        assert_eq!(
            hdr.status,
            Status::UnknownService as u16,
            "clean UnknownService"
        );
        assert_eq!(
            hdr.service, unknown,
            "echoes the raw service id so the guest correlates the reply"
        );
        assert_eq!(hdr.opcode, 7, "echoes the request opcode");
        assert_eq!(hdr.seq, 99, "echoes the request seq");
        assert!(pl.is_empty(), "an error frame carries no payload");
    }

    #[test]
    fn doorbell_rejects_a_non_request_frame() {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        vmm.enable_sdk(nominal_env(1), &ServiceConfig::default());
        let mut buf = [0u8; HC_PAGE];
        let n = hypercall_proto::encode_response(ServiceId::Sdk, 1, 42, Status::Ok, &[], &mut buf)
            .unwrap();
        vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + n].copy_from_slice(&buf[..n]);

        let step = vmm.dispatch_out(DOORBELL_PORT, 4, n as u32).unwrap();
        assert_eq!(
            step,
            Step::Continued,
            "a rejected frame does not stop the run"
        );
        let page = vmm.guest_memory()[RESP_GPA..RESP_GPA + HC_PAGE].to_vec();
        let (hdr, pl) = decode(&page).expect("a response frame is written");
        assert_eq!(
            hdr.status,
            Status::BadRequest as u16,
            "non-request → BadRequest"
        );
        assert_eq!(hdr.service, ServiceId::Sdk as u16, "echoes the raw service");
        assert_eq!(hdr.seq, 42, "echoes the raw seq");
        assert!(pl.is_empty());
    }

    #[test]
    fn doorbell_bad_entropy_opcode_is_unknown_opcode() {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        vmm.enable_sdk(nominal_env(1), &ServiceConfig::default());
        let mut buf = [0u8; HC_PAGE];
        let n = hypercall_proto::encode_request(ServiceId::Entropy, 2, 7, &[], &mut buf).unwrap();
        vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + n].copy_from_slice(&buf[..n]);

        vmm.dispatch_out(DOORBELL_PORT, 4, n as u32).unwrap();
        let page = vmm.guest_memory()[RESP_GPA..RESP_GPA + HC_PAGE].to_vec();
        let (hdr, _) = decode(&page).expect("a response frame is written");
        assert_eq!(
            hdr.status,
            Status::UnknownOpcode as u16,
            "a known service with a bad opcode → UnknownOpcode, not UnknownService"
        );
        assert_eq!(
            hdr.service,
            ServiceId::Entropy as u16,
            "echoes the Entropy service"
        );
        assert_eq!(hdr.opcode, 2, "echoes the bad opcode");
        assert_eq!(hdr.seq, 7);
    }

    #[test]
    fn doorbell_request_header_validation_matrix() {
        fn dispatch_header(mutate: impl FnOnce(&mut [u8])) -> hypercall_proto::FrameHeader {
            let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
            vmm.enable_sdk(nominal_env(1), &ServiceConfig::default());
            let mut buf = [0u8; HC_PAGE];
            let n = hypercall_proto::encode_request(
                ServiceId::Event,
                1,
                5,
                &7u32.to_le_bytes(),
                &mut buf,
            )
            .unwrap();
            mutate(&mut buf);
            vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + n].copy_from_slice(&buf[..n]);
            vmm.dispatch_out(DOORBELL_PORT, 4, n as u32).unwrap();
            let page = vmm.guest_memory()[RESP_GPA..RESP_GPA + HC_PAGE].to_vec();
            decode(&page).expect("a response frame is always written").0
        }
        let ev = ServiceId::Event as u16;

        let h = dispatch_header(|_| {});
        assert_eq!(h.status, Status::Ok as u16, "valid request is serviced");
        assert_eq!((h.service, h.opcode, h.seq), (ev, 1, 5));

        let h = dispatch_header(|b| b[4..6].copy_from_slice(&2u16.to_le_bytes()));
        assert_eq!(
            h.status,
            Status::BadRequest as u16,
            "response-typed rejected"
        );
        assert_eq!((h.service, h.seq), (ev, 5), "BadRequest echoes raw fields");

        let h = dispatch_header(|b| b[10..12].copy_from_slice(&1u16.to_le_bytes()));
        assert_eq!(
            h.status,
            Status::BadRequest as u16,
            "non-zero-status request rejected (round-11 P2)"
        );
        assert_eq!(h.service, ev);

        let h = dispatch_header(|b| b[20..24].copy_from_slice(&1u32.to_le_bytes()));
        assert_eq!(
            h.status,
            Status::BadRequest as u16,
            "non-zero reserved rejected"
        );

        let h = dispatch_header(|b| b[4..6].copy_from_slice(&3u16.to_le_bytes()));
        assert_eq!(
            h.status,
            Status::BadRequest as u16,
            "unrecognized message kind rejected"
        );

        let h = dispatch_header(|b| b[6..8].copy_from_slice(&0xABCDu16.to_le_bytes()));
        assert_eq!(h.status, Status::UnknownService as u16, "unknown service");
        assert_eq!(h.service, 0xABCD, "echoes the raw service id");

        let h = dispatch_header(|b| b[8..10].copy_from_slice(&9u16.to_le_bytes()));
        assert_eq!(h.status, Status::UnknownOpcode as u16, "unknown opcode");
        assert_eq!(
            (h.service, h.opcode),
            (ev, 9),
            "echoes service + bad opcode"
        );
    }

    #[test]
    fn oversized_explicit_service_answer_preserves_channel_state() {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        enable_oversized(&mut vmm, 7);
        let mut payload = 4u16.to_le_bytes().to_vec();
        payload.extend_from_slice(&77u64.to_le_bytes());
        let mut request = [0; HC_PAGE];
        let n =
            hypercall_proto::encode_request(ServiceId::Sdk, 3, 1, &payload, &mut request).unwrap();
        let mut response = [0; HC_PAGE];
        let (length, stop) = vmm.dispatch_doorbell(19, &request[..n], &mut response);
        assert_eq!(length, 0);
        let stop = stop.expect("custom service must stop for input");
        assert!(matches!(stop, SdkStop::Decision { .. }));
        vmm.sdk.as_mut().unwrap().pending_stop = Some(stop.clone());
        let before = vmm
            .sdk
            .as_ref()
            .unwrap()
            .env
            .snapshot_state()
            .unwrap()
            .encode();
        assert!(
            vmm.resolve_service_answer(channel::Answer::Data(vec![0; MAX_PAYLOAD]), None)
                .is_err()
        );
        assert_eq!(vmm.take_sdk_stop(), Some(stop));
        assert!(response.iter().all(|byte| *byte == 0));
        assert_eq!(
            before,
            vmm.sdk
                .as_ref()
                .unwrap()
                .env
                .snapshot_state()
                .unwrap()
                .encode()
        );
    }

    #[test]
    fn sdk_snapshot_preserves_unconsumed_stops() {
        for stop in [
            SdkStop::Quiescent,
            SdkStop::Assertion {
                id: 5,
                data: vec![1],
            },
        ] {
            let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
            enable_nominal(&mut vmm, 7);
            vmm.sdk.as_mut().unwrap().pending_stop = Some(stop);
            assert!(vmm.save_vm_state().is_ok());
            let snapshot = vmm.sdk_snapshot().unwrap().unwrap();
            let pending = vmm.take_sdk_stop().unwrap();
            vmm.sdk_restore(&snapshot).unwrap();
            assert_eq!(vmm.take_sdk_stop(), Some(pending.clone()));
            vmm.sdk_restore_events(&snapshot);
            assert_eq!(vmm.take_sdk_stop(), Some(pending));
            assert!(vmm.save_vm_state().is_ok());
            assert!(vmm.sdk_snapshot().is_ok());
        }
    }

    #[test]
    fn sdk_restore_keeps_the_pending_response_sequence_and_future() {
        let build = || {
            let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
            enable_nominal(&mut vmm, 7);
            vmm
        };
        let mut source = build();
        source.set_host_operation_guard(std::sync::Arc::new(|_| Ok(())));
        let question = channel::Question::with_request_id(77, 19, b"choose".to_vec()).unwrap();
        let stop = SdkStop::Decision {
            moment: 31,
            seq: 42,
            question: question.clone(),
        };
        source.sdk.as_mut().unwrap().pending_stop = Some(stop.clone());
        let before = source.state_hash().unwrap();
        let snapshot = source.sdk_snapshot().unwrap().unwrap();
        assert_eq!(source.state_hash().unwrap(), before);
        assert_eq!(source.take_sdk_stop(), Some(stop.clone()));
        assert_eq!(source.take_sdk_stop(), Some(stop.clone()));
        let mut restored = build();
        assert_ne!(restored.state_hash().unwrap(), before);
        restored.sdk_restore(&snapshot).unwrap();
        assert_eq!(restored.state_hash().unwrap(), before);
        assert_eq!(restored.take_sdk_stop(), Some(stop.clone()));
        let mut branched = build();
        branched.sdk_restore_events(&snapshot);
        assert_eq!(branched.take_sdk_stop(), Some(stop));
        let answer = channel::Answer::Data(vec![4, 5, 6]);
        branched
            .resolve_service_answer(answer.clone(), None)
            .unwrap();
        assert_eq!(
            source.resolve_service_answer(answer.clone(), None).unwrap(),
            (31, question.clone())
        );
        assert_eq!(
            restored.resolve_service_answer(answer, None).unwrap(),
            (31, question)
        );
        assert_eq!(
            sdk_attribution_counter(&source, "sdk_dispatch.service.response_guard_calls"),
            1
        );
        assert_eq!(
            sdk_attribution_counter(&source, "sdk_dispatch.coverage.response_guard_calls"),
            0
        );
        let source_response = source.guest_slice(RESP_GPA as u64, HC_PAGE).unwrap();
        let restored_response = restored.guest_slice(RESP_GPA as u64, HC_PAGE).unwrap();
        assert_eq!(restored_response, source_response);
        assert_eq!(
            branched.guest_slice(RESP_GPA as u64, HC_PAGE).unwrap(),
            source_response
        );
        assert_eq!(restored.state_hash().unwrap(), source.state_hash().unwrap());
        assert_eq!(restored.sdk_events(), source.sdk_events());
        assert!(
            restored
                .resolve_service_answer(channel::Answer::Nominal, None)
                .is_err()
        );
        let completed = source.sdk_snapshot().unwrap().unwrap();
        restored.sdk_restore(&snapshot).unwrap();
        restored.sdk_restore(&completed).unwrap();
        assert!(restored.pending_service_question().is_none());
        assert_eq!(restored.state_hash().unwrap(), source.state_hash().unwrap());
    }

    #[test]
    #[cfg_attr(
        miri,
        ignore = "sha256-dominated (each state_hash/state_blob over the TEST_RAM image interprets ~2 s/KiB under Miri and this test hashes repeatedly); pure safe code over the mock backend — no map_memory on this path (both seams stay Miri-run in bringup); logic covered natively, and the family keeps Miri-run siblings"
    )]
    fn sdk_snapshot_round_trips_the_pending_deferred_point_hash() {
        let mk = || {
            let mut v = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
            enable_nominal(&mut v, 7);
            v
        };
        let mut base = mk();
        let h_false = base.state_hash().unwrap();
        base.sdk.as_mut().unwrap().pending_snapshot = true;
        let h_true = base.state_hash().unwrap();
        assert_ne!(h_false, h_true);
        let snap = base.sdk_snapshot().unwrap().expect("SDK snapshot");
        assert!(snap.pending_snapshot);
        let mut fork = mk();
        fork.sdk_restore(&snap).unwrap();
        assert_eq!(fork.state_hash().unwrap(), h_true);
        let mut events_only = mk();
        events_only.sdk_restore_events(&snap);
        assert_eq!(events_only.state_hash().unwrap(), h_true);
        assert!(events_only.take_snapshot_point());
        assert!(!events_only.take_snapshot_point());
    }

    #[test]
    fn run_stops_on_an_sdk_assertion_not_the_later_terminal() {
        let viol_id: u32 = (1 << 24) | 20;
        let mut payload = viol_id.to_le_bytes().to_vec();
        payload.extend_from_slice(&[1, 0, 0]);
        let mut frame = [0u8; HC_PAGE];
        let n =
            hypercall_proto::encode_request(ServiceId::Event, 1, 1, &payload, &mut frame).unwrap();

        let mut vmm = Vmm::new(
            configured_mock(vec![
                Exit::Arch(X86Exit::Io {
                    port: DOORBELL_PORT,
                    size: 4,
                    write: Some(n as u32),
                }),
                Exit::Common(CommonExit::Idle),
            ]),
            GuestRam::new(TEST_RAM).unwrap(),
        );
        vmm.enable_sdk(nominal_env(1), &ServiceConfig::default());
        vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + n].copy_from_slice(&frame[..n]);

        let r = vmm.run().expect("run");
        assert_eq!(
            r.reason,
            TerminalReason::SdkStop,
            "run stops at the assertion, not the HLT that follows"
        );
        assert_eq!(
            r.sdk_stop,
            Some(SdkStop::Assertion {
                id: 20,
                data: vec![]
            })
        );
    }

    #[test]
    fn run_does_not_cache_the_vcpu_on_a_resumable_sdk_stop() {
        let viol_id: u32 = (1 << 24) | 20;
        let mut payload = viol_id.to_le_bytes().to_vec();
        payload.extend_from_slice(&[1, 0, 0]);
        let mut frame = [0u8; HC_PAGE];
        let n =
            hypercall_proto::encode_request(ServiceId::Event, 1, 1, &payload, &mut frame).unwrap();

        let mut stop_state = nonzero_state();
        stop_state.regs.rip = 0x1000;
        let mut resumed_state = nonzero_state();
        resumed_state.regs.rip = 0x2000;

        let mut mock = configured_mock(vec![Exit::Arch(X86Exit::Io {
            port: DOORBELL_PORT,
            size: 4,
            write: Some(n as u32),
        })]);
        mock.set_state(stop_state.clone());
        let mut vmm = Vmm::new(mock, GuestRam::new(TEST_RAM).unwrap());
        vmm.enable_sdk(nominal_env(1), &ServiceConfig::default());
        vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + n].copy_from_slice(&frame[..n]);

        let r = vmm.run().expect("run");
        assert_eq!(r.reason, TerminalReason::SdkStop);
        assert!(
            vmm.saved_state.is_none(),
            "a resumable SDK stop must NOT cache the vCPU (it would go stale on resume)"
        );

        vmm.backend.set_state(resumed_state.clone());
        assert_eq!(
            vmm.current_vcpu().unwrap(),
            resumed_state,
            "state_blob reads the live resumed vCPU, not the stale stop snapshot"
        );
        assert_ne!(
            vmm.current_vcpu().unwrap(),
            stop_state,
            "not the stop-time vCPU"
        );
    }

    #[test]
    fn doorbell_is_total_on_edge_requests() {
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        vmm.enable_sdk(nominal_env(1), &ServiceConfig::default());

        assert_eq!(
            vmm.dispatch_out(DOORBELL_PORT, 4, 0).unwrap(),
            Step::Continued
        );
        assert_eq!(
            vmm.dispatch_out(DOORBELL_PORT, 4, HC_PAGE as u32 + 1)
                .unwrap(),
            Step::Continued
        );
        let resp = vmm.guest_memory()[RESP_GPA..RESP_GPA + HC_PAGE].to_vec();
        let (hdr, _) = decode(&resp).expect("a valid response frame");
        assert_eq!(
            hdr.status,
            Status::BadRequest as u16,
            "an oversize req_len is rejected, not clamped"
        );
        assert_eq!(
            vmm.dispatch_out(DOORBELL_PORT, 4, u32::MAX).unwrap(),
            Step::Continued
        );
        assert_eq!(
            vmm.dispatch_out(DOORBELL_PORT, 4, HC_PAGE as u32).unwrap(),
            Step::Continued
        );

        for (i, b) in vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + 96]
            .iter_mut()
            .enumerate()
        {
            *b = (i as u8).wrapping_mul(37).wrapping_add(1);
        }
        assert_eq!(
            vmm.dispatch_out(DOORBELL_PORT, 4, 96).unwrap(),
            Step::Continued
        );

        assert!(
            vmm.take_sdk_stop().is_none(),
            "no spurious stop from garbage"
        );
        assert!(
            vmm.sdk_events().is_empty(),
            "garbage never captures an event"
        );
    }

    #[test]
    fn doorbell_routes_entropy_deterministically() {
        let mk = || {
            let mut vmm = Vmm::new(
                configured_mock(vec![Exit::Common(CommonExit::Idle)]),
                GuestRam::new(TEST_RAM).unwrap(),
            );
            vmm.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 99).unwrap());
            vmm.enable_sdk(nominal_env(99), &ServiceConfig::default());
            vmm
        };
        let entropy = |vmm: &mut Vmm<MockBackend>, n: u32| -> (u16, Vec<u8>) {
            let mut buf = [0u8; HC_PAGE];
            let len = hypercall_proto::encode_request(
                ServiceId::Entropy,
                1,
                1,
                &n.to_le_bytes(),
                &mut buf,
            )
            .unwrap();
            vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + len].copy_from_slice(&buf[..len]);
            vmm.dispatch_out(DOORBELL_PORT, 4, len as u32).unwrap();
            let page = vmm.guest_memory()[RESP_GPA..RESP_GPA + HC_PAGE].to_vec();
            let (hdr, pl) = decode(&page).expect("a valid response frame");
            (hdr.status, pl.to_vec())
        };
        let mut a = mk();
        let (status, bytes_a) = entropy(&mut a, 16);
        assert_eq!(status, Status::Ok as u16, "entropy is routed, not rejected");
        assert_eq!(bytes_a.len(), 16);
        let mut b = mk();
        assert_eq!(
            entropy(&mut b, 16).1,
            bytes_a,
            "entropy is deterministic per seed"
        );
    }

    #[test]
    #[cfg_attr(
        miri,
        ignore = "sha256-dominated (each state_hash/state_blob over the TEST_RAM image interprets ~2 s/KiB under Miri and this test hashes repeatedly); pure safe code over the mock backend — no map_memory on this path (both seams stay Miri-run in bringup); logic covered natively, and the family keeps Miri-run siblings"
    )]
    fn state_hash_folds_the_sdk_stream_and_is_absent_when_unwired() {
        let mut unwired = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        let unwired_hash = unwired.state_hash().unwrap();
        let mut wired = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        enable_nominal(&mut wired, 7);
        assert!(
            wired
                .state_blob()
                .unwrap()
                .windows(4)
                .any(|w| w == b"SDK\0")
        );
        assert_ne!(unwired_hash, wired.state_hash().unwrap());
    }

    #[test]
    fn rdtsc_completes_with_vtime_tsc_not_host() {
        let mut vmm = vtime_vmm(
            vec![
                Exit::Arch(X86Exit::Rdmsr { index: 0x10 }),
                Exit::Common(CommonExit::Idle),
            ],
            1,
        );
        assert!(vmm.vtime_wired(), "wire_vtime reports the path as wired");
        let r = vmm.run().expect("run");
        assert_eq!(r.reason, TerminalReason::Idle);
        assert_eq!(vmm.backend.completions(), &[Completion::Read(2)]);
    }

    #[test]
    fn rdtscp_completes_with_vtime_tsc() {
        let mut vmm = vtime_vmm(
            vec![
                Exit::Arch(X86Exit::Rdmsr { index: 0x10 }),
                Exit::Common(CommonExit::Idle),
            ],
            1,
        );
        vmm.run().expect("run");
        assert_eq!(vmm.backend.completions(), &[Completion::Read(2)]);
    }

    #[test]
    fn save_vtime_is_none_when_unwired() {
        let v = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        assert!(v.save_vtime().unwrap().is_none());
        assert!(!v.vtime_wired());
    }

    #[test]
    fn save_vtime_anchors_vns_to_last_intercept_not_live_work() {
        let v = vtime_vmm(vec![], 1);
        let snap = v.save_vtime().expect("save").expect("wired");
        assert_eq!(
            snap.vns, 0,
            "vns must anchor to assigned_clock (0), not the live counter (777)"
        );
    }

    #[test]
    fn restore_vtime_rejects_bad_snapshot_atomically() {
        let mut v = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        v.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 1).unwrap());
        let before = v.state_hash().unwrap();
        let bad = VtimeSnapshot {
            vns: 9_999,
            guest_clock_offset: 0,
            entropy: vec![0u8; 8],
        };
        assert!(matches!(
            v.restore_vtime(&bad),
            Err(VmmError::ContractViolation(_))
        ));
        assert_eq!(
            v.state_hash().unwrap(),
            before,
            "a rejected snapshot must leave the V-time/entropy state untouched"
        );
    }

    #[test]
    fn restore_vtime_does_not_touch_backend_save() {
        let mut v = Vmm::new(
            SaveFailBackend(configured_mock(vec![]), false),
            GuestRam::new(0x1000).unwrap(),
        );
        v.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 1).unwrap());
        let snap0 = v.save_vtime().expect("clean save").expect("V-time wired");
        let snap = VtimeSnapshot {
            vns: snap0.vns + 4_096,
            guest_clock_offset: snap0.guest_clock_offset,
            entropy: snap0.entropy.clone(),
        };
        v.restore_vtime(&snap).expect("V-time-only restore");
        assert_eq!(v.effective_vns(), Some(snap.vns));
    }

    #[test]
    fn rdmsr_ia32_tsc_matches_rdtsc_instruction_and_is_deterministic() {
        let run_msr = || {
            let mut v = vtime_vmm(
                vec![
                    Exit::Arch(X86Exit::Rdmsr { index: 0x10 }),
                    Exit::Common(CommonExit::Idle),
                ],
                1,
            );
            v.run().unwrap();
            v
        };
        let mut insn = vtime_vmm(
            vec![
                Exit::Arch(X86Exit::Rdmsr { index: 0x10 }),
                Exit::Common(CommonExit::Idle),
            ],
            1,
        );
        insn.run().unwrap();

        let mut msr = run_msr();
        assert_eq!(
            msr.backend.completions(),
            insn.backend.completions(),
            "RDMSR(IA32_TSC) must read the same V-time TSC as the RDTSC instruction"
        );
        assert_eq!(msr.backend.completions(), &[Completion::Read(2)]);
        assert_eq!(msr.state_hash().unwrap(), run_msr().state_hash().unwrap());
    }

    #[test]
    fn tsc_adjust_state_is_in_the_hash() {
        let with_adjust = |adjust: u64| {
            let mut v = vtime_vmm(
                vec![Exit::Arch(X86Exit::Wrmsr {
                    index: 0x3b,
                    value: adjust,
                })],
                1,
            );
            v.step().unwrap();
            v
        };
        assert_ne!(
            with_adjust(0).state_hash().unwrap(),
            with_adjust(12_345).state_hash().unwrap(),
            "a written IA32_TSC_ADJUST must change the VTIM hash"
        );
    }

    #[test]
    fn tsc_adjust_access_records_work_in_the_hash() {
        let at_vns = |vns: u64| {
            let mut v = vtime_vmm(vec![Exit::Arch(X86Exit::Rdmsr { index: 0x3b })], 1);
            v.vtime.as_mut().unwrap().advance_virtual_time(vns);
            v.step().unwrap();
            v
        };
        assert_ne!(
            at_vns(100).state_hash().unwrap(),
            at_vns(200).state_hash().unwrap(),
            "a 0x3b access at different work ⇒ different effective V-time ⇒ different hash"
        );
    }

    #[test]
    fn vtime_snapshot_round_trips_tsc_adjust() {
        let mut v = vtime_vmm(
            vec![
                Exit::Arch(X86Exit::Wrmsr {
                    index: 0x3b,
                    value: 9,
                }),
                Exit::Arch(X86Exit::Wrmsr {
                    index: 0x3b,
                    value: 99,
                }),
                Exit::Arch(X86Exit::Rdmsr { index: 0x3b }),
            ],
            1,
        );
        v.step().unwrap();
        let snap = v
            .save_vtime()
            .expect("save with non-zero adjust succeeds")
            .expect("wired");
        assert_eq!(
            snap.guest_clock_offset, 9,
            "snapshot must capture IA32_TSC_ADJUST"
        );
        v.step().unwrap();
        v.restore_vtime(&snap).expect("restore");
        v.step().unwrap();
        assert_eq!(
            v.backend.completions().last(),
            Some(&Completion::Read(9)),
            "restore must re-apply the snapshotted IA32_TSC_ADJUST"
        );
    }

    #[test]
    fn emulate_vtime_tsc_msr_unwired_fails_closed() {
        for idx in [0x10u32, 0x3b] {
            let mut rd = Vmm::new(
                configured_mock(vec![Exit::Arch(X86Exit::Rdmsr { index: idx })]),
                GuestRam::new(0x1000).unwrap(),
            );
            assert!(matches!(rd.step(), Err(VmmError::ContractViolation(_))));
            let mut wr = Vmm::new(
                configured_mock(vec![Exit::Arch(X86Exit::Wrmsr {
                    index: idx,
                    value: 0,
                })]),
                GuestRam::new(0x1000).unwrap(),
            );
            assert!(matches!(wr.step(), Err(VmmError::ContractViolation(_))));
        }
    }

    #[test]
    fn vtime_state_is_hashed_and_distinguishes_seed_and_vns_base() {
        fn contains_tag(blob: &[u8], tag: &[u8; 4]) -> bool {
            blob.windows(4).any(|w| w == tag)
        }
        fn wired(seed: u64, cfg: vtime::VClockConfig) -> Vmm<MockBackend> {
            let mut v = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
            v.wire_vtime(VtimeWiring::new_virtual_time(cfg, seed).unwrap());
            v
        }

        let mut stock = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        assert!(
            !contains_tag(&stock.state_blob().unwrap(), b"VTIM"),
            "stock Vmm must not emit a VTIM chunk (M1/M2 hash unchanged)"
        );
        let mut stock2 = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        assert_eq!(stock.state_hash().unwrap(), stock2.state_hash().unwrap());

        let mut a = wired(1, contract_vclock_config());
        assert!(contains_tag(&a.state_blob().unwrap(), b"VTIM"));
        assert_ne!(
            a.state_hash().unwrap(),
            stock.state_hash().unwrap(),
            "wiring vtime must change the hash"
        );

        let mut b = wired(2, contract_vclock_config());
        assert_ne!(
            a.state_hash().unwrap(),
            b.state_hash().unwrap(),
            "different seed ⇒ different state_hash"
        );

        let base = contract_vclock_config();
        let variants = [
            (
                "guest_hz",
                vtime::VClockConfig {
                    guest_hz: 3_000_000_000,
                    ..base
                },
            ),
            (
                "guest_base",
                vtime::VClockConfig {
                    guest_base: 5,
                    ..base
                },
            ),
            (
                "vns_base",
                vtime::VClockConfig {
                    vns_base: 12_345,
                    ..base
                },
            ),
        ];
        for (field, cfg) in variants {
            assert_ne!(
                a.state_hash().unwrap(),
                wired(1, cfg).state_hash().unwrap(),
                "different {field} ⇒ different state_hash"
            );
        }

        let mut a2 = wired(1, contract_vclock_config());
        assert_eq!(a.state_hash().unwrap(), a2.state_hash().unwrap());
    }

    #[test]
    fn vtime_hash_preimage_keeps_the_frozen_n1_prefix() {
        let wiring =
            VtimeWiring::new_virtual_time(contract_vclock_config(), 1).expect("valid wiring");
        let encoded = encode_vtime(&wiring);
        assert_eq!(encoded[0], 1, "historical assigned-clock marker");
        assert_eq!(&encoded[1..9], &1_u64.to_le_bytes(), "historical ratio");
    }

    fn report_out(value: u32) -> Exit<X86> {
        Exit::Arch(X86Exit::Io {
            port: REPORT_PORT,
            size: 4,
            write: Some(value),
        })
    }

    #[test]
    fn report_port_out_appends_values_in_order() {
        let mut vmm = Vmm::new(
            configured_mock(vec![
                report_out(0x1111_1111),
                report_out(0x0000_0000),
                report_out(0xDEAD_BEEF),
                report_out(0x0000_0001),
                Exit::Common(CommonExit::Idle),
            ]),
            GuestRam::new(0x1000).unwrap(),
        );
        let r = vmm.run().expect("run");
        assert_eq!(r.reason, TerminalReason::Idle);
        assert_eq!(
            vmm.report_stream(),
            [0x1111_1111, 0x0000_0000, 0xDEAD_BEEF, 0x0000_0001]
        );
        assert!(vmm.backend.completions().is_empty());
    }

    #[test]
    fn report_port_advances_the_paravirtual_exit_budget() {
        let mut vmm = vtime_vmm(vec![report_out(0xA5A5_5A5A)], 1);
        let before = vmm.effective_vns().unwrap();
        assert_eq!(vmm.step().unwrap(), Step::Continued);
        assert_eq!(
            vmm.effective_vns().unwrap() - before,
            crate::vendor::x86::contract::virtual_time_timing().paravirtual_device_mmio_vns
        );
        assert_eq!(vmm.report_stream(), [0xA5A5_5A5A]);
    }

    #[test]
    fn tick_port_advances_the_execution_tick_budget() {
        let mut vmm = vtime_vmm(
            vec![Exit::Arch(X86Exit::Io {
                port: VIRTUAL_TIME_TICK_PORT,
                size: 4,
                write: Some(1),
            })],
            1,
        );
        let before = vmm.effective_vns().unwrap();
        assert_eq!(vmm.step().unwrap(), Step::Continued);
        assert_eq!(
            vmm.effective_vns().unwrap() - before,
            crate::vendor::x86::contract::virtual_time_timing().execution_tick_vns
        );
        assert!(vmm.backend.completions().is_empty());
    }

    #[test]
    fn idle_port_idles_like_hlt_after_the_paravirtual_budget() {
        let mut hlt = vtime_vmm(vec![Exit::Common(CommonExit::Idle)], 1);
        let mut port = vtime_vmm(
            vec![Exit::Arch(X86Exit::Io {
                port: IDLE_PORT,
                size: 4,
                write: Some(1),
            })],
            1,
        );
        let before = port.effective_vns().unwrap();
        assert_eq!(port.step().unwrap(), hlt.step().unwrap());
        assert_eq!(
            port.effective_vns().unwrap() - before,
            crate::vendor::x86::contract::virtual_time_timing().paravirtual_device_mmio_vns
                + (hlt.effective_vns().unwrap() - before)
        );
    }

    #[test]
    fn idle_port_rejects_non_protocol_accesses() {
        for (size, write) in [(1u8, Some(1u32)), (4, Some(0)), (4, Some(2)), (4, None)] {
            let mut vmm = Vmm::new(
                configured_mock(vec![Exit::Arch(X86Exit::Io {
                    port: IDLE_PORT,
                    size,
                    write,
                })]),
                GuestRam::new(0x1000).unwrap(),
            );
            assert!(
                matches!(vmm.step(), Err(VmmError::ContractViolation(_))),
                "idle access size {size} write {write:?} must fail closed"
            );
        }
    }

    #[test]
    fn tick_port_rejects_non_protocol_accesses() {
        for (size, value) in [(1u8, 1u32), (2, 1), (4, 0), (4, 2)] {
            let mut vmm = Vmm::new(
                configured_mock(vec![Exit::Arch(X86Exit::Io {
                    port: VIRTUAL_TIME_TICK_PORT,
                    size,
                    write: Some(value),
                })]),
                GuestRam::new(0x1000).unwrap(),
            );
            assert!(
                matches!(vmm.step(), Err(VmmError::ContractViolation(_))),
                "tick access size {size} value {value} must fail closed"
            );
        }
    }

    #[test]
    fn off_protocol_tick_accesses_do_not_advance_virtual_time() {
        let writes = [(1u8, Some(1u32)), (2, Some(1)), (4, Some(0)), (4, Some(2))];
        for (size, write) in writes.into_iter().chain([(1, None), (4, None)]) {
            let mut vmm = vtime_vmm(
                vec![Exit::Arch(X86Exit::Io {
                    port: VIRTUAL_TIME_TICK_PORT,
                    size,
                    write,
                })],
                1,
            );
            let before = vmm.effective_vns().unwrap();
            assert!(
                matches!(vmm.step(), Err(VmmError::ContractViolation(_))),
                "tick access size {size} write {write:?} must fail closed"
            );
            assert_eq!(
                vmm.effective_vns().unwrap(),
                before,
                "rejected tick access size {size} write {write:?} must leave V-time unchanged"
            );
        }
    }

    #[test]
    fn report_port_non_dword_fails_closed() {
        for bad_size in [1u8, 2] {
            let mut vmm = Vmm::new(
                configured_mock(vec![Exit::Arch(X86Exit::Io {
                    port: REPORT_PORT,
                    size: bad_size,
                    write: Some(0xAB),
                })]),
                GuestRam::new(0x1000).unwrap(),
            );
            assert!(
                matches!(vmm.step(), Err(VmmError::ContractViolation(_))),
                "report write of size {bad_size} must fail closed"
            );
        }
    }

    #[test]
    fn observable_digest_tracks_report_stream_but_state_hash_does_not() {
        let mut a = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        let mut b = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        a.report_stream = vec![0xAA, 0xBB];
        assert_eq!(
            a.state_hash().unwrap(),
            b.state_hash().unwrap(),
            "report stream must NOT reach state_hash (M1/M2 hash unchanged)"
        );
        assert_ne!(
            a.observable_digest(),
            b.observable_digest(),
            "report stream MUST reach observable_digest"
        );
        let mut a2 = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        a2.report_stream = vec![0xAA, 0xBB];
        assert_eq!(a.observable_digest(), a2.observable_digest());
        let mut a_rev = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        a_rev.report_stream = vec![0xBB, 0xAA];
        assert_ne!(a.observable_digest(), a_rev.observable_digest());
    }

    #[test]
    fn observable_digest_also_covers_the_serial_banner() {
        let mut quiet = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        let mut loud = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        for &byte in b"PAYLOAD x PASS\n" {
            loud.devices
                .uart
                .write(crate::vendor::x86::devices::UART_PORT_BASE, byte);
        }
        assert_ne!(quiet.observable_digest(), loud.observable_digest());
        quiet.report_stream = vec![u32::from_le_bytes(*b"PAYL")];
        assert_ne!(
            quiet.observable_digest(),
            loud.observable_digest(),
            "domain/length-prefixed digest separates the report stream from serial"
        );
    }

    #[test]
    fn state_components_breakdown_is_stable_and_covers_state() {
        let mut v = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        let comps = v.state_components().unwrap();
        assert_eq!(
            comps,
            v.state_components().unwrap(),
            "pure: two calls agree"
        );
        let labels: Vec<&str> = comps.iter().map(|(l, _)| *l).collect();
        for expect in [
            "RAM:0..64K",
            "regs",
            "segments",
            "control-regs",
            "msrs",
            "xsave-legacy",
            "xsave-header",
            "xsave-extended",
            "serial",
            "dev",
        ] {
            assert!(
                labels.contains(&expect),
                "missing component {expect}: {labels:?}"
            );
        }
        assert!(
            !labels.iter().any(|l| l.starts_with("vtim")),
            "no vtim components when unwired"
        );
        let mut w = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        w.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 1).unwrap());
        let wlabels: Vec<&str> = w
            .state_components()
            .unwrap()
            .iter()
            .map(|(l, _)| *l)
            .collect();
        for expect in ["vtim:cfg", "vtim:eff-vns", "vtim:entropy"] {
            assert!(wlabels.contains(&expect), "missing {expect}: {wlabels:?}");
        }
        let mut v2 = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        assert_eq!(
            v.state_components().unwrap(),
            v2.state_components().unwrap()
        );
        let mut v3 = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        v3.report_stream = vec![0xDEAD_BEEF];
        assert_eq!(
            v.state_components().unwrap(),
            v3.state_components().unwrap()
        );

        let mut raw_backend = configured_mock(vec![]);
        let raw_state = VcpuState {
            xsave_restore_bv: Some(3),
            ..Default::default()
        };
        raw_backend.set_state(raw_state);
        let mut raw = Vmm::new(raw_backend, GuestRam::new(0x1000).unwrap());
        assert!(
            raw.state_components()
                .unwrap()
                .iter()
                .any(|(label, _)| *label == "xsave-restore-bv")
        );
        let mut raw_two_backend = configured_mock(vec![]);
        raw_two_backend.set_state(VcpuState {
            xsave_restore_bv: Some(2),
            ..Default::default()
        });
        let mut raw_two = Vmm::new(raw_two_backend, GuestRam::new(0x1000).unwrap());
        let component = |vmm: &mut Vmm<MockBackend>, name| {
            vmm.state_components()
                .unwrap()
                .into_iter()
                .find(|(label, _)| *label == name)
                .unwrap_or_else(|| panic!("missing diagnostic component {name}"))
                .1
        };
        assert_eq!(
            component(&mut raw, "xsave-header"),
            component(&mut raw_two, "xsave-header"),
            "raw provenance stays out of the canonical XSAVE header component"
        );
        assert_ne!(
            component(&mut raw, "xsave-restore-bv"),
            component(&mut raw_two, "xsave-restore-bv"),
            "the diagnostic provenance component still distinguishes raw values"
        );
    }

    #[test]
    fn restored_and_fresh_at_same_effective_vtime_hash_identically() {
        const E: u64 = 4242;
        const SEED: u64 = 0x1234;

        let mut fresh = Vmm::new(
            configured_mock(vec![Exit::Arch(X86Exit::Rdmsr { index: 0x10 })]),
            GuestRam::new(0x1000).unwrap(),
        );
        let mut cfg = contract_vclock_config();
        cfg.vns_base = E - 1;
        fresh.wire_vtime(VtimeWiring::new_virtual_time(cfg, SEED).unwrap());
        fresh.step().unwrap();

        let mut restored = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        restored.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), SEED).unwrap());
        let snap = VtimeSnapshot {
            vns: E,
            guest_clock_offset: 0,
            entropy: SeededEntropy::new(SEED).save_state(),
        };
        restored.restore_vtime(&snap).unwrap();

        assert_eq!(
            fresh.state_hash().unwrap(),
            restored.state_hash().unwrap(),
            "a restored VM and a fresh VM at the same effective V-time must hash identically"
        );
    }

    fn linux_vmm(exits: Vec<Exit<X86>>) -> Vmm<MockBackend> {
        let mut v = Vmm::new(configured_mock(exits), GuestRam::new(0x1000).unwrap());
        v.wire_lapic(
            lapic::Lapic::new(lapic::LapicConfig {
                apic_id: 0,
                timer_hz: 24_000_000,
            })
            .unwrap(),
        );
        v
    }

    #[test]
    fn x86_clockevent_trace_reports_only_an_armed_lapic_timer() {
        let mut vmm = linux_vmm(Vec::new());
        assert_eq!(<X86 as Vendor>::clockevent_trace_schedule(&vmm), None);

        let lapic = vmm.devices.lapic.as_mut().unwrap();
        lapic.mmio_write(lapic::APIC_SVR, 0x100, 0).unwrap();
        lapic.mmio_write(lapic::APIC_LVT_TIMER, 0x41, 0).unwrap();
        lapic.mmio_write(lapic::APIC_TMICT, 24_000, 0).unwrap();
        let expected = (lapic.next_timer_deadline().unwrap(), 0x41);
        assert_ne!(expected.0, 0);
        assert_eq!(
            <X86 as Vendor>::clockevent_trace_schedule(&vmm),
            Some(expected)
        );
    }

    #[test]
    fn apic_mmio_serviced_only_when_lapic_wired() {
        let mut v = linux_vmm(vec![
            Exit::Common(CommonExit::Mmio {
                gpa: Gpa(0xFEE0_0030),
                size: 4,
                write: None,
            }),
            Exit::Common(CommonExit::Mmio {
                gpa: Gpa(0xFEE0_00B0),
                size: 4,
                write: Some(0),
            }),
            Exit::Common(CommonExit::Idle),
        ]);
        assert!(v.lapic_wired());
        let r = v.run().expect("run");
        assert_eq!(r.reason, TerminalReason::Idle);
        assert_eq!(
            v.backend.completions(),
            &[Completion::Read(u64::from(lapic::APIC_VERSION_VALUE))]
        );

        let mut stock = Vmm::new(
            configured_mock(vec![Exit::Common(CommonExit::Mmio {
                gpa: Gpa(0xFEE0_0030),
                size: 4,
                write: None,
            })]),
            GuestRam::new(0x1000).unwrap(),
        );
        assert!(!stock.lapic_wired(), "stock Vmm has no xAPIC wired");
        assert!(matches!(stock.step(), Err(VmmError::ContractViolation(_))));
    }

    #[test]
    fn xapic_rejects_non_dword_accesses_before_changing_device_state() {
        for size in [8, 1, 2, 0] {
            for write in [None, Some(0x1_0000_0020)] {
                let mut v = linux_vmm(vec![Exit::Common(CommonExit::Mmio {
                    gpa: Gpa(APIC_MMIO_BASE + u64::from(lapic::APIC_TPR)),
                    size,
                    write,
                })]);
                v.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 1).unwrap());
                let before = v.devices.lapic.as_ref().unwrap().snapshot();
                let before_vns = v.now_vns().unwrap();
                assert!(
                    matches!(v.step(), Err(VmmError::ContractViolation(_))),
                    "xAPIC size {size}, write {write:?} should fail closed"
                );
                assert_eq!(v.devices.lapic.as_ref().unwrap().snapshot(), before);
                assert_eq!(v.now_vns().unwrap(), before_vns);
            }
        }

        let mut valid = linux_vmm(vec![Exit::Common(CommonExit::Mmio {
            gpa: Gpa(APIC_MMIO_BASE + u64::from(lapic::APIC_TPR)),
            size: 4,
            write: Some(0x20),
        })]);
        valid.step().unwrap();
        assert_eq!(valid.devices.lapic.as_ref().unwrap().snapshot().tpr, 0x20);
    }

    #[test]
    fn rejected_x86_port_accesses_do_not_advance_virtual_time() {
        let rejected = [
            X86Exit::Io {
                port: 0x3F8,
                size: 2,
                write: Some(u32::from(b'A')),
            },
            X86Exit::Io {
                port: 0x3F8,
                size: 2,
                write: None,
            },
            X86Exit::Io {
                port: 0x1337,
                size: 1,
                write: Some(1),
            },
            X86Exit::Io {
                port: 0x1337,
                size: 1,
                write: None,
            },
        ];
        for exit in rejected {
            let mut v = linux_vmm(vec![Exit::Arch(exit)]);
            v.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 1).unwrap());
            let before = v.now_vns().unwrap();
            assert!(matches!(v.step(), Err(VmmError::ContractViolation(_))));
            assert_eq!(v.now_vns().unwrap(), before, "exit {exit:?}");
        }
    }

    #[test]
    fn legacy_pic_ports_reject_non_byte_io_before_state_or_time_changes() {
        for (port, valid_read) in [(0x0020, 0), (0x0021, 0xFE), (0x00A0, 0), (0x00A1, 0xFE)] {
            for size in [2, 4, 8, 0] {
                let wide_value = if valid_read == 0 { 0xEF00 } else { 0xEF };
                for write in [Some(wide_value), None] {
                    let mut v = linux_vmm(vec![Exit::Arch(X86Exit::Io { port, size, write })]);
                    v.wire_vtime(
                        VtimeWiring::new_virtual_time(contract_vclock_config(), 1).unwrap(),
                    );
                    let before_vns = v.now_vns().unwrap();
                    let before_imr = v.devices.legacy.as_ref().unwrap().pic_imr();
                    assert!(
                        matches!(v.step(), Err(VmmError::ContractViolation(_))),
                        "PIC port {port:#06x}, size {size}, write {write:?} must fail closed"
                    );
                    assert_eq!(v.now_vns().unwrap(), before_vns);
                    assert_eq!(v.devices.legacy.as_ref().unwrap().pic_imr(), before_imr);
                    assert!(v.backend.completions().is_empty());
                }
            }

            let mut valid = linux_vmm(vec![
                Exit::Arch(X86Exit::Io {
                    port,
                    size: 1,
                    write: Some(0xFE),
                }),
                Exit::Arch(X86Exit::Io {
                    port,
                    size: 1,
                    write: None,
                }),
                Exit::Common(CommonExit::Idle),
            ]);
            valid.run().unwrap();
            assert_eq!(valid.backend.completions(), &[Completion::Read(valid_read)]);
        }
    }

    #[test]
    fn rejected_xapic_offsets_do_not_advance_virtual_time() {
        for offset in [0x004, 0xFF4] {
            for write in [None, Some(0x20)] {
                let mut v = linux_vmm(vec![Exit::Common(CommonExit::Mmio {
                    gpa: Gpa(APIC_MMIO_BASE + offset),
                    size: 4,
                    write,
                })]);
                v.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 1).unwrap());
                let before = v.now_vns().unwrap();
                let lapic = v.devices.lapic.as_ref().unwrap().snapshot();
                assert!(matches!(v.step(), Err(VmmError::ContractViolation(_))));
                assert_eq!(v.now_vns().unwrap(), before, "offset {offset:#x}");
                assert_eq!(v.devices.lapic.as_ref().unwrap().snapshot(), lapic);
            }
        }
    }

    #[test]
    fn mmio_outside_apic_page_fails_closed_even_on_linux_path() {
        let mut v = linux_vmm(vec![Exit::Common(CommonExit::Mmio {
            gpa: Gpa(0xFEB0_0000),
            size: 4,
            write: None,
        })]);
        assert!(matches!(v.step(), Err(VmmError::ContractViolation(_))));
    }

    #[test]
    fn legacy_io_serviced_only_when_wired() {
        let mut v = linux_vmm(vec![
            Exit::Arch(X86Exit::Io {
                port: 0x0CF8,
                size: 4,
                write: Some(0x8000_0000),
            }),
            Exit::Arch(X86Exit::Io {
                port: 0x0CFC,
                size: 4,
                write: None,
            }),
            Exit::Common(CommonExit::Idle),
        ]);
        v.run().expect("run");
        assert_eq!(v.backend.completions(), &[Completion::Read(0xFFFF_FFFF)]);

        let mut stock = Vmm::new(
            configured_mock(vec![Exit::Arch(X86Exit::Io {
                port: 0x0CF8,
                size: 4,
                write: Some(0),
            })]),
            GuestRam::new(0x1000).unwrap(),
        );
        assert!(matches!(stock.step(), Err(VmmError::ContractViolation(_))));
    }

    #[test]
    fn linux_platform_state_in_hash_only_when_wired() {
        fn has(blob: &[u8], tag: &[u8; 4]) -> bool {
            blob.windows(4).any(|w| w == tag)
        }
        let mut stock = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        let stock_blob = stock.state_blob().unwrap();
        assert!(!has(&stock_blob, b"LAPC"));
        assert!(!has(&stock_blob, b"LEGY"));

        let mut linux = linux_vmm(vec![]);
        let blob = linux.state_blob().unwrap();
        assert!(has(&blob, b"LAPC"));
        assert!(has(&blob, b"LEGY"));
        assert_ne!(stock.state_hash().unwrap(), linux.state_hash().unwrap());

        let with_pci = |addr: u32| {
            let mut v = linux_vmm(vec![Exit::Arch(X86Exit::Io {
                port: 0x0CF8,
                size: 4,
                write: Some(addr),
            })]);
            v.step().unwrap();
            v
        };
        assert_ne!(
            with_pci(0x1000).state_hash().unwrap(),
            with_pci(0x2000).state_hash().unwrap()
        );
    }

    #[test]
    fn serial_and_exit_counts_accessors_reflect_the_run() {
        let mut v = linux_vmm(vec![
            Exit::Arch(X86Exit::Io {
                port: 0x3F8,
                size: 1,
                write: Some(u32::from(b'H')),
            }),
            Exit::Arch(X86Exit::Io {
                port: 0x3F8,
                size: 1,
                write: Some(u32::from(b'i')),
            }),
            Exit::Common(CommonExit::Idle),
        ]);
        v.run().expect("run");
        assert_eq!(v.serial(), b"Hi");
        assert!(v.exit_counts().io >= 2, "exit_counts reflects the IO exits");
    }

    #[test]
    fn mmio_just_past_apic_page_fails_closed() {
        let mut v = linux_vmm(vec![Exit::Common(CommonExit::Mmio {
            gpa: Gpa(0xFEE0_1000),
            size: 4,
            write: None,
        })]);
        assert!(matches!(v.step(), Err(VmmError::ContractViolation(_))));
    }

    #[test]
    fn lapic_timer_current_count_tracks_vtime() {
        let mut v = Vmm::new(
            configured_mock(vec![
                Exit::Common(CommonExit::Mmio {
                    gpa: Gpa(0xFEE0_00F0),
                    size: 4,
                    write: Some(0x1FF),
                }),
                Exit::Common(CommonExit::Mmio {
                    gpa: Gpa(0xFEE0_0320),
                    size: 4,
                    write: Some(0x40),
                }),
                Exit::Common(CommonExit::Mmio {
                    gpa: Gpa(0xFEE0_0380),
                    size: 4,
                    write: Some(0xFFFF_FFFF),
                }),
                Exit::Arch(X86Exit::Rdmsr { index: 0x10 }),
                Exit::Common(CommonExit::Mmio {
                    gpa: Gpa(0xFEE0_0390),
                    size: 4,
                    write: None,
                }),
                Exit::Common(CommonExit::Idle),
            ]),
            GuestRam::new(0x1000).unwrap(),
        );
        v.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 1).unwrap());
        v.wire_lapic(
            lapic::Lapic::new(lapic::LapicConfig {
                apic_id: 0,
                timer_hz: 24_000_000,
            })
            .unwrap(),
        );

        v.run().expect("run");
        let tmcct = match v.backend.completions().last() {
            Some(Completion::Read(v)) => *v,
            other => panic!("expected a TMCCT read completion, got {other:?}"),
        };
        assert!(tmcct > 0, "timer is running (some count remains)");
        assert!(
            tmcct < 0xFFFF_FFFF,
            "TMCCT decreased from the armed initial count — lapic_now_vns advanced with V-time"
        );
    }

    #[test]
    fn lapic_register_state_is_in_the_hash() {
        let mut base = linux_vmm(vec![]);
        let mut modified = linux_vmm(vec![Exit::Common(CommonExit::Mmio {
            gpa: Gpa(0xFEE0_0080),
            size: 4,
            write: Some(0x20),
        })]);
        modified.step().unwrap();
        assert_ne!(
            base.state_hash().unwrap(),
            modified.state_hash().unwrap(),
            "an xAPIC register write must change the LAPC hash chunk"
        );
    }

    fn configured_stock_mock(exits: Vec<Exit<X86>>) -> MockBackend {
        let mut m = MockBackend::with_capabilities(vmm_backend::Capabilities {
            name: "mock-stock",
            arch: X86Caps,
        });
        m.extend_exits(exits);
        m.set_policy(&X86Policy {
            cpuid: CpuidModel::default(),
            msr_filter: MsrFilter::default(),
        })
        .expect("set_policy");
        m
    }

    fn arm_timer_exits(initial_count: u64) -> Vec<Exit<X86>> {
        let w = |off: u64, v: u64| {
            Exit::Common(CommonExit::Mmio {
                gpa: Gpa(APIC_MMIO_BASE + off),
                size: 4,
                write: Some(v),
            })
        };
        vec![
            w(u64::from(lapic::APIC_SVR), 0x1FF),
            w(u64::from(lapic::APIC_LVT_TIMER), 0x40),
            w(u64::from(lapic::APIC_TMICT), initial_count),
        ]
    }

    #[test]
    fn lapic_timer_delivers_off_intercept_anchor_on_deterministic_backend() {
        let mut exits = arm_timer_exits(1);
        exits.push(read_mmio(isr_gpa(0x40)));
        exits.push(Exit::Arch(X86Exit::Rdmsr { index: 0x10 }));
        exits.push(read_mmio(isr_gpa(0x40)));
        exits.push(Exit::Common(CommonExit::Idle));
        let mut v = lapic_vmm(configured_mock(exits));

        v.run().expect("run");
        let reads = read_completions(&v);
        assert_eq!(
            reads.first().expect("ISR read A") & 1,
            0,
            "not delivered before the anchor advances (off the intercept anchor, not live work)"
        );
        assert_eq!(
            reads.last().expect("ISR read B") & 1,
            1,
            "delivered once the intercept anchor crosses the timer deadline"
        );
    }

    #[test]
    fn stale_vector_re_arbitrated_away_after_tpr_raise() {
        let tpr_write = Exit::Common(CommonExit::Mmio {
            gpa: Gpa(APIC_MMIO_BASE + u64::from(lapic::APIC_TPR)),
            size: 4,
            write: Some(0xF0),
        });
        let mut exits = arm_timer_exits(1);
        exits.push(read_mmio(isr_gpa(0x20)));
        exits.push(tpr_write);
        exits.push(read_mmio(irr_gpa(0x40)));
        exits.push(Exit::Common(CommonExit::Idle));
        let mut mock = configured_mock(exits);
        mock.set_defer_accept(true);
        let mut v = lapic_vmm(mock);

        for _ in 0..5 {
            assert!(matches!(v.step().unwrap(), Step::Continued));
        }
        v.backend.set_defer_accept(false);
        assert!(matches!(v.step().unwrap(), Step::Continued));
        assert!(matches!(
            v.step().unwrap(),
            Step::Terminal(TerminalReason::Idle)
        ));
        assert_eq!(
            v.backend.pending_irq(),
            None,
            "the stale, now-masked vector was re-arbitrated out of the pending slot"
        );
        assert_eq!(
            v.backend.take_accepted_interrupt(),
            None,
            "the stale vector was never accepted (KVM_INTERRUPT not issued for it)"
        );
        let reads = read_completions(&v);
        assert_eq!(
            reads.last().expect("IRR read") & 1,
            1,
            "0x40 is retained in IRR (masked by TPR, not dropped)"
        );
    }

    #[test]
    fn no_injection_when_lapic_unwired() {
        let mut v = Vmm::new(
            configured_mock(vec![Exit::Common(CommonExit::Idle)]),
            GuestRam::new(0x1000).unwrap(),
        );
        assert!(!v.lapic_wired());
        assert!(matches!(
            v.step().unwrap(),
            Step::Terminal(TerminalReason::Idle)
        ));
        assert!(
            v.backend.injected().is_empty(),
            "an unwired LAPIC never drives an injection"
        );
    }

    const UNMASK_IRQ4: Exit<X86> = Exit::Arch(X86Exit::Io {
        port: 0x0021,
        size: 1,
        write: Some(0xEF),
    });
    const ENABLE_THRI: Exit<X86> = Exit::Arch(X86Exit::Io {
        port: 0x03F9,
        size: 1,
        write: Some(0x02),
    });

    #[test]
    fn pending_serial_input_keeps_interruptible_idle_guest_runnable() {
        let mut mock = configured_mock(vec![
            UNMASK_IRQ4,
            Exit::Arch(X86Exit::Io {
                port: 0x03F9,
                size: 1,
                write: Some(0x01),
            }),
            Exit::Common(CommonExit::Idle),
        ]);
        mock.set_defer_accept(true);
        mock.set_state(VcpuState {
            regs: vmm_backend::VcpuRegs {
                rflags: RFLAGS_IF | 0x2,
                ..Default::default()
            },
            ..Default::default()
        });
        let mut v = lapic_vmm(mock);
        v.inject_serial_input(b"x");

        assert_eq!(v.step().unwrap(), Step::Continued);
        assert_eq!(v.step().unwrap(), Step::Continued);
        assert_eq!(v.pending_serial_vector(), Some(COM1_IRQ_VECTOR));
        assert_eq!(v.step().unwrap(), Step::Continued);
        assert_eq!(v.backend.pending_irq(), Some(COM1_IRQ_VECTOR));
        assert!(v.terminal.is_none());
    }

    #[test]
    fn serial_thre_interrupt_injects_com1_vector() {
        let mut mock = configured_mock(vec![
            UNMASK_IRQ4,
            ENABLE_THRI,
            Exit::Common(CommonExit::Idle),
        ]);
        mock.set_defer_accept(true);
        let mut v = lapic_vmm(mock);

        assert!(matches!(v.step().unwrap(), Step::Continued));
        assert_eq!(
            v.backend.pending_irq(),
            None,
            "no THRE interrupt before IER.THRI"
        );
        assert!(matches!(v.step().unwrap(), Step::Continued));
        assert!(matches!(
            v.step().unwrap(),
            Step::Terminal(TerminalReason::Idle)
        ));
        assert_eq!(
            v.backend.pending_irq(),
            Some(COM1_IRQ_VECTOR),
            "the THRE interrupt is injected on the legacy COM1 vector 0x34"
        );
        assert_eq!(COM1_IRQ_VECTOR, 0x34, "ISA_IRQ_VECTOR(4) = 0x30 + 4");
    }

    #[test]
    fn serial_irq_suppressed_while_8259_masks_it() {
        let mut mock = configured_mock(vec![ENABLE_THRI, Exit::Common(CommonExit::Idle)]);
        mock.set_defer_accept(true);
        let mut v = lapic_vmm(mock);
        assert!(matches!(v.step().unwrap(), Step::Continued));
        assert!(matches!(
            v.step().unwrap(),
            Step::Terminal(TerminalReason::Idle)
        ));
        assert_eq!(
            v.backend.pending_irq(),
            None,
            "a masked COM1 line is not injected even with THRE asserted"
        );
    }

    #[test]
    fn lapic_vector_outranks_the_serial_line() {
        let mut exits = arm_timer_exits(1);
        exits.push(UNMASK_IRQ4);
        exits.push(ENABLE_THRI);
        exits.push(Exit::Arch(X86Exit::Rdmsr { index: 0x10 }));
        exits.push(Exit::Common(CommonExit::Idle));
        let mut mock = configured_mock(exits);
        mock.set_defer_accept(true);
        let mut v = lapic_vmm(mock);
        v.run().expect("run");
        assert_eq!(
            v.backend.pending_irq(),
            Some(0x40),
            "the LAPIC timer vector outranks the legacy serial ExtINT line"
        );
    }

    #[test]
    fn serial_acceptance_takes_no_lapic_isr_transition() {
        let mut exits = vec![UNMASK_IRQ4, ENABLE_THRI];
        exits.push(read_mmio(isr_gpa(COM1_IRQ_VECTOR)));
        exits.push(Exit::Common(CommonExit::Idle));
        let mut v = lapic_vmm(configured_mock(exits));
        v.run().expect("run");
        let isr = *read_completions(&v).last().expect("ISR read");
        assert_eq!(
            isr & (1 << (u32::from(COM1_IRQ_VECTOR) % 32)),
            0,
            "the serial vector never enters the LAPIC ISR (EOI'd at the 8259)"
        );
    }

    fn isr_gpa(v: u8) -> Gpa {
        Gpa(APIC_MMIO_BASE + u64::from(lapic::APIC_ISR) + u64::from(v / 32) * 0x10)
    }
    fn irr_gpa(v: u8) -> Gpa {
        Gpa(APIC_MMIO_BASE + u64::from(lapic::APIC_IRR) + u64::from(v / 32) * 0x10)
    }
    fn read_mmio(gpa: Gpa) -> Exit<X86> {
        Exit::Common(CommonExit::Mmio {
            gpa,
            size: 4,
            write: None,
        })
    }

    fn read_completions(v: &Vmm<MockBackend>) -> Vec<u64> {
        v.backend
            .completions()
            .iter()
            .filter_map(|c| match c {
                Completion::Read(x) => Some(*x),
                _ => None,
            })
            .collect()
    }

    fn lapic_vmm(mock: MockBackend) -> Vmm<MockBackend> {
        let mut v = Vmm::new(mock, GuestRam::new(0x1000).unwrap());
        v.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 1).unwrap());
        v.wire_lapic(
            lapic::Lapic::new(lapic::LapicConfig {
                apic_id: 0,
                timer_hz: 24_000_000,
            })
            .unwrap(),
        );
        v
    }

    fn virtual_time_lapic_vmm(mock: MockBackend) -> Vmm<MockBackend> {
        let mut v = Vmm::new(mock, GuestRam::new(0x1000).unwrap());
        v.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 1).unwrap());
        v.wire_lapic(
            lapic::Lapic::new(lapic::LapicConfig {
                apic_id: 0,
                timer_hz: 24_000_000,
            })
            .unwrap(),
        );
        v
    }

    #[test]
    fn virtual_time_lapic_timer_records_schedule_and_delivery() {
        let mut exits = arm_timer_exits(1);
        exits.push(read_mmio(isr_gpa(0x40)));
        exits.push(Exit::Common(CommonExit::Shutdown));
        let mut v = virtual_time_lapic_vmm(configured_mock(exits));
        v.run().expect("run");

        let trace = v.virtual_time_trace().expect("virtual_time trace wired");
        let schedule = trace.schedule();
        assert_eq!(schedule.len(), 1, "the one-shot arm is one schedule record");
        assert_eq!(schedule[0].interrupt_id, 0x40);
        assert_eq!(schedule[0].canceled_at_event, None);
        let log = trace.normalized_log();
        crate::virtual_time::check_delivery_placement(schedule, log)
            .expect("the delivery sits at the first event whose V-time covers the deadline");
        let delivery_events: Vec<u64> = log
            .events
            .iter()
            .filter(|e| !e.interrupts.is_empty())
            .map(|e| e.event_index)
            .collect();
        assert_eq!(
            delivery_events,
            vec![3],
            "fired inside the crossing (ISR-read) event"
        );
    }

    #[test]
    fn changing_lapic_timer_vector_retags_the_live_schedule() {
        let mut exits = arm_timer_exits(1000);
        exits.push(Exit::Common(CommonExit::Mmio {
            gpa: Gpa(APIC_MMIO_BASE + u64::from(lapic::APIC_LVT_TIMER)),
            size: 4,
            write: Some(0x41),
        }));
        exits.push(Exit::Common(CommonExit::Idle));
        exits.push(Exit::Common(CommonExit::Shutdown));
        let mut mock = configured_mock(exits);
        mock.set_state(if_set_state());
        mock.set_defer_accept(true);
        let mut v = virtual_time_lapic_vmm(mock);
        v.run().expect("run");

        assert_eq!(v.backend.pending_irq(), Some(0x41));
        let trace = v.virtual_time_trace().expect("virtual_time trace wired");
        let schedule = trace.schedule();
        assert_eq!(schedule.len(), 2, "vector rewrite replaces the schedule");
        assert_eq!(schedule[0].interrupt_id, 0x40);
        assert_eq!(schedule[0].canceled_at_event, Some(3));
        assert_eq!(schedule[1].interrupt_id, 0x41);
        assert_eq!(schedule[1].armed_for_event, 3);
        assert_eq!(schedule[1].deadline_vns, schedule[0].deadline_vns);
        let deliveries: Vec<_> = trace
            .normalized_log()
            .events
            .iter()
            .flat_map(|event| &event.interrupts)
            .collect();
        assert_eq!(deliveries.len(), 1);
        assert_eq!(deliveries[0].interrupt_id, 0x41);
        crate::virtual_time::check_delivery_placement(schedule, trace.normalized_log())
            .expect("the retagged vector is delivered at its unchanged deadline");
    }

    #[test]
    fn virtual_time_lapic_timer_disarm_cancels_the_schedule() {
        let mut exits = arm_timer_exits(1_000_000);
        exits.push(Exit::Common(CommonExit::Mmio {
            gpa: Gpa(APIC_MMIO_BASE + u64::from(lapic::APIC_TMICT)),
            size: 4,
            write: Some(0),
        }));
        exits.push(Exit::Common(CommonExit::Shutdown));
        let mut v = virtual_time_lapic_vmm(configured_mock(exits));
        v.run().expect("run");

        let trace = v.virtual_time_trace().expect("virtual_time trace wired");
        let schedule = trace.schedule();
        assert_eq!(schedule.len(), 1);
        assert_eq!(
            schedule[0].canceled_at_event,
            Some(3),
            "the TMICT=0 event canceled it"
        );
        crate::virtual_time::check_delivery_placement(schedule, trace.normalized_log())
            .expect("a canceled deadline needs no delivery");
    }

    #[test]
    fn injected_vector_stays_in_irr_until_accepted() {
        let mut exits = arm_timer_exits(1);
        exits.push(read_mmio(isr_gpa(0x20)));
        exits.push(read_mmio(irr_gpa(0x40)));
        exits.push(read_mmio(isr_gpa(0x40)));
        exits.push(Exit::Common(CommonExit::Idle));
        let mut mock = configured_mock(exits);
        mock.set_defer_accept(true);
        let mut v = lapic_vmm(mock);

        v.run().expect("run");
        let reads: Vec<u64> = v
            .backend
            .completions()
            .iter()
            .filter_map(|c| match c {
                Completion::Read(x) => Some(*x),
                _ => None,
            })
            .collect();
        let isr = *reads.last().expect("ISR read");
        let irr = reads[reads.len() - 2];
        assert_eq!(irr & 1, 1, "vector 0x40 is pending in IRR while deferred");
        assert_eq!(
            isr & 1,
            0,
            "vector 0x40 is NOT in service before acceptance"
        );
    }

    #[test]
    fn accepted_vector_moves_irr_to_isr() {
        let mut exits = arm_timer_exits(1);
        exits.push(read_mmio(isr_gpa(0x20)));
        exits.push(read_mmio(irr_gpa(0x40)));
        exits.push(read_mmio(isr_gpa(0x40)));
        exits.push(Exit::Common(CommonExit::Idle));
        let mut v = lapic_vmm(configured_mock(exits));

        v.run().expect("run");
        let reads: Vec<u64> = v
            .backend
            .completions()
            .iter()
            .filter_map(|c| match c {
                Completion::Read(x) => Some(*x),
                _ => None,
            })
            .collect();
        let isr = *reads.last().expect("ISR read");
        let irr = reads[reads.len() - 2];
        assert_eq!(irr & 1, 0, "IRR bit cleared once the vector is accepted");
        assert_eq!(isr & 1, 1, "vector 0x40 is in service after acceptance");
    }

    fn if_set_state() -> VcpuState {
        VcpuState {
            regs: vmm_backend::VcpuRegs {
                rflags: RFLAGS_IF | 0x2,
                ..Default::default()
            },
            ..Default::default()
        }
    }

    #[test]
    fn idle_hlt_without_if_is_terminal() {
        let mut exits = arm_timer_exits(1000);
        exits.push(Exit::Common(CommonExit::Idle));
        let mut v = lapic_vmm(configured_mock(exits));
        let r = v.run().expect("run");
        assert_eq!(r.reason, TerminalReason::Idle);
        assert!(
            v.idle_landings().is_empty(),
            "an IF==0 HLT is terminal, never resumed"
        );
    }

    #[test]
    fn hlt_without_armed_timer_is_terminal_even_with_if() {
        let mut mock = configured_mock(vec![Exit::Common(CommonExit::Idle)]);
        mock.set_state(if_set_state());
        let mut v = lapic_vmm(mock);
        let r = v.run().expect("run");
        assert_eq!(r.reason, TerminalReason::Idle);
        assert!(v.idle_landings().is_empty(), "no armed timer ⇒ terminal");
    }

    #[test]
    fn idle_wake_distinguishes_an_earlier_control_deadline_from_the_timer() {
        let make = || {
            let mut exits = arm_timer_exits(1000);
            exits.push(Exit::Common(CommonExit::Idle));
            let mut mock = configured_mock(exits);
            mock.set_state(if_set_state());
            let mut v = lapic_vmm(mock);
            for _ in 0..3 {
                assert_eq!(v.step().unwrap(), Step::Continued);
            }
            v
        };

        let mut timer_wake = make();
        let timer = timer_wake
            .devices
            .lapic
            .as_ref()
            .unwrap()
            .next_timer_deadline()
            .unwrap();
        timer_wake.set_idle_wake_vns(Some(timer));
        assert_eq!(timer_wake.step().unwrap(), Step::Continued);
        assert_eq!(timer_wake.effective_vns(), Some(timer));
        assert_eq!(timer_wake.last_step_control_idle_landing_vns, None);

        let mut control_wake = make();
        control_wake.set_idle_wake_vns(Some(timer - 1));
        assert_eq!(control_wake.step().unwrap(), Step::Continued);
        assert_eq!(control_wake.effective_vns(), Some(timer - 1));
        assert_eq!(
            control_wake.last_step_control_idle_landing_vns,
            Some(timer - 1)
        );
    }

    #[test]
    fn idle_hlt_on_stock_backend_is_terminal() {
        let mut exits = arm_timer_exits(1000);
        exits.push(Exit::Common(CommonExit::Idle));
        let mut mock = configured_stock_mock(exits);
        mock.set_state(if_set_state());
        let mut v = Vmm::new(mock, GuestRam::new(0x1000).unwrap());
        v.wire_lapic(
            lapic::Lapic::new(lapic::LapicConfig {
                apic_id: 0,
                timer_hz: 24_000_000,
            })
            .unwrap(),
        );
        let r = v.run().expect("run");
        assert_eq!(r.reason, TerminalReason::Idle);
        assert!(
            v.idle_landings().is_empty(),
            "a non-deterministic backend never idle-resumes"
        );
    }

    #[test]
    fn idle_hlt_with_undeliverable_timer_is_terminal() {
        let w = |off: u64, val: u64| {
            Exit::Common(CommonExit::Mmio {
                gpa: Gpa(APIC_MMIO_BASE + off),
                size: 4,
                write: Some(val),
            })
        };
        let undeliverable_timer_hlt_terminates = |setup: Vec<Exit<X86>>| {
            let mut exits = setup;
            exits.push(Exit::Common(CommonExit::Idle));
            let mut mock = configured_mock(exits);
            mock.set_state(if_set_state());
            let mut v = lapic_vmm(mock);
            let r = v.run().expect("run");
            assert_eq!(
                r.reason,
                TerminalReason::Idle,
                "an armed-but-undeliverable timer HLT is terminal"
            );
            assert!(
                v.idle_landings().is_empty(),
                "no idle resume / no V-time advance for an undeliverable timer"
            );
        };

        undeliverable_timer_hlt_terminates(vec![
            w(u64::from(lapic::APIC_SVR), 0x1FF),
            w(u64::from(lapic::APIC_LVT_TIMER), 0x05),
            w(u64::from(lapic::APIC_TMICT), 1000),
        ]);
        undeliverable_timer_hlt_terminates(vec![
            w(u64::from(lapic::APIC_SVR), 0x1FF),
            w(u64::from(lapic::APIC_LVT_TIMER), 0x40),
            w(u64::from(lapic::APIC_TMICT), 1000),
            w(u64::from(lapic::APIC_TPR), 0xF0),
        ]);
    }

    #[test]
    fn idle_discriminator_does_not_capture_unrelated_cpu_state() {
        let mut exits = arm_timer_exits(1000);
        exits.push(Exit::Common(CommonExit::Idle));
        let mut inner = configured_mock(exits);
        inner.set_state(if_set_state());
        let mut v = Vmm::new(
            SaveFailBackend(inner, false),
            GuestRam::new(0x1000).unwrap(),
        );
        v.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 1).unwrap());
        v.wire_lapic(
            lapic::Lapic::new(lapic::LapicConfig {
                apic_id: 0,
                timer_hz: 24_000_000,
            })
            .unwrap(),
        );

        for _ in 0..3 {
            assert!(matches!(v.step().unwrap(), Step::Continued));
        }
        assert_eq!(
            v.step().expect("idle reads flags without full CPU capture"),
            Step::Continued
        );
        assert_eq!(v.idle_landings().len(), 1);
    }

    fn full_vmm(
        state: VcpuState,
        exits: Vec<Exit<X86>>,
        _retired_initial_work: u64,
        seed: u64,
    ) -> Vmm<MockBackend> {
        let mut m = configured_mock(exits);
        m.set_state(state);
        let mut v = Vmm::new(m, GuestRam::new(0x2000).unwrap());
        v.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), seed).unwrap());
        v.wire_lapic(
            lapic::Lapic::new(lapic::LapicConfig {
                apic_id: 0,
                timer_hz: 24_000_000,
            })
            .unwrap(),
        );
        v
    }

    fn nonzero_state() -> VcpuState {
        let mut msrs = std::collections::BTreeMap::new();
        msrs.insert(0xC000_0080u32, 0x501);
        VcpuState {
            regs: vmm_backend::VcpuRegs {
                rax: 0x1111,
                rbx: 0x2222,
                rip: 0x10_0000,
                rsp: 0x8000,
                rflags: 0x2,
                ..Default::default()
            },
            sregs: vmm_backend::VcpuSregs {
                cs: vmm_backend::Segment {
                    selector: 0x10,
                    limit: 0xFFFF_FFFF,
                    type_: 0xB,
                    present: 1,
                    s: 1,
                    l: 1,
                    g: 1,
                    ..Default::default()
                },
                cr0: 0x8000_0011,
                cr3: 0x1000,
                cr4: 0x20,
                efer: 0x500,
                apic_base: 0xFEE0_0900,
                ..Default::default()
            },
            xcr0: 0x7,
            msrs,
            xsave: (0u16..512).map(|i| i as u8).collect(),
            ..Default::default()
        }
    }

    fn mutate_exits() -> Vec<Exit<X86>> {
        vec![
            Exit::Arch(X86Exit::Wrmsr {
                index: 0x3b,
                value: 0x1234,
            }),
            Exit::Common(CommonExit::Mmio {
                gpa: Gpa(0xFEE0_0080),
                size: 4,
                write: Some(0x20),
            }),
            Exit::Arch(X86Exit::Io {
                port: 0x0021,
                size: 1,
                write: Some(0xEF),
            }),
            Exit::Arch(X86Exit::Io {
                port: 0x3F8,
                size: 1,
                write: Some(u32::from(b'H')),
            }),
            Exit::Arch(X86Exit::Io {
                port: 0x3f8,
                size: 1,
                write: Some(b'X'.into()),
            }),
            Exit::Arch(X86Exit::Rdmsr { index: 0x10 }),
        ]
    }

    fn step_n(v: &mut Vmm<MockBackend>, n: usize) {
        for _ in 0..n {
            assert_eq!(v.step().unwrap(), Step::Continued);
        }
    }

    #[test]
    fn save_vm_state_round_trips_through_the_codec() {
        let mut a = full_vmm(nonzero_state(), mutate_exits(), 500, 0xABCD);
        step_n(&mut a, 6);
        let s = a.save_vm_state().expect("clean synchronized boundary");
        let bytes = s.encode().expect("encodable (ratio_den == 1)");
        assert_eq!(vm_state::VmState::decode(&bytes).unwrap(), s);
        assert_eq!(s.regs.rax, 0x1111);
        assert_eq!(s.vtime.snapshot_vns, 40002);
        assert_eq!(
            s.contract_hash,
            crate::vendor::x86::contract::contract_hash()
        );
    }

    #[test]
    #[cfg_attr(
        miri,
        ignore = "sha256-dominated (each state_hash/state_blob over the TEST_RAM image interprets ~2 s/KiB under Miri and this test hashes repeatedly); pure safe code over the mock backend — no map_memory on this path (both seams stay Miri-run in bringup); logic covered natively, and the family keeps Miri-run siblings"
    )]
    fn restore_vm_state_reproduces_the_blob_byte_for_byte() {
        let mut a = full_vmm(nonzero_state(), mutate_exits(), 500, 0xABCD);
        step_n(&mut a, 6);
        let s = a.save_vm_state().unwrap();

        let mut b = full_vmm(VcpuState::default(), vec![], 9999, 0x0000);
        b.restore_vm_state(&s).expect("restore");
        let s2 = b.save_vm_state().expect("re-save after restore");
        assert_eq!(s, s2, "restore-then-save must reproduce the snapshot blob");
    }

    #[test]
    #[cfg_attr(
        miri,
        ignore = "sha256-dominated (each state_hash/state_blob over the TEST_RAM image interprets ~2 s/KiB under Miri and this test hashes repeatedly); pure safe code over the mock backend — no map_memory on this path (both seams stay Miri-run in bringup); logic covered natively, and the family keeps Miri-run siblings"
    )]
    fn restore_vm_state_rejects_a_different_contract_atomically() {
        let mut a = full_vmm(nonzero_state(), mutate_exits(), 500, 0xABCD);
        step_n(&mut a, 6);
        let mut s = a.save_vm_state().unwrap();
        let version_5_hash = [
            0x01, 0xb0, 0x21, 0x4b, 0x93, 0x87, 0xe2, 0x05, 0xe4, 0xc3, 0xdd, 0x41, 0x87, 0x80,
            0xbb, 0xe1, 0x5c, 0x77, 0xf1, 0x71, 0x25, 0x91, 0x20, 0xc2, 0xf7, 0x90, 0x2a, 0xe3,
            0x88, 0x58, 0xff, 0x63,
        ];
        for rejected_hash in [version_5_hash, [0xFFu8; 32]] {
            s.contract_hash = rejected_hash;

            let mut b = full_vmm(nonzero_state(), vec![], 100, 0xABCD);
            let before = b.state_hash().unwrap();
            assert!(matches!(
                b.restore_vm_state(&s),
                Err(VmmError::Snapshot(
                    crate::snapshot::SnapshotError::ContractMismatch
                ))
            ));
            assert_eq!(
                b.state_hash().unwrap(),
                before,
                "a rejected snapshot leaves the VM fully intact (atomic)"
            );
        }
    }

    #[test]
    fn restore_trace_failure_is_classified_after_commit() {
        let mut source = vtime_vmm(vec![Exit::Arch(X86Exit::Rdmsr { index: 0x10 })], 7);
        source.step().unwrap();
        let snapshot = source.save_vm_state().unwrap();

        let mut target = vtime_vmm(Vec::new(), 7);
        target
            .virtual_time_trace
            .as_mut()
            .unwrap()
            .begin(
                ExitReason::Rdmsr,
                "planted active event".to_owned(),
                NormalizedEventClass::TimeRead,
                Vec::new(),
            )
            .unwrap();
        assert!(matches!(
            target.restore_vm_state(&snapshot),
            Err(VmmError::Backend(vmm_backend::BackendError::Internal(message)))
                if message.contains("during an active event")
        ));
        assert!(
            target.save_vm_state().is_ok(),
            "the backend's vcpu state was already committed before the trace \
             classification failed, so it carries nothing pending and prepares on demand"
        );
        assert!(target.state_hash().is_ok());
    }

    #[test]
    fn reseed_entropy_requires_a_wired_stream() {
        let mut stock = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        assert!(matches!(
            stock.reseed_entropy(7),
            Err(VmmError::ContractViolation(_))
        ));
    }

    #[test]
    fn platform_entropy_reseed_does_not_reset_service_or_scheduler_state() {
        use environment::channel::Question;

        const SERVICE_SEED: u64 = 0x5151;
        let scheduler = Question::scheduler(3).unwrap();
        let service = Question::with_request_id(7, 99, vec![0xA5]).unwrap();

        let mut expected = channel::RecordedEnv::new(
            SERVICE_SEED,
            Box::new(SeededService::default()) as Box<dyn channel::ServiceHandler>,
        );
        expected.set_moment(11);
        let mut actual = vtime_vmm(Vec::new(), 0xCAFE);
        enable_seeded_service(&mut actual, SERVICE_SEED);
        actual.sdk.as_mut().expect("SDK enabled").env.set_moment(11);

        assert_eq!(
            actual.sdk.as_mut().unwrap().env.decide(&scheduler).unwrap(),
            expected.decide(&scheduler).unwrap()
        );
        assert_eq!(
            actual.sdk.as_mut().unwrap().env.decide(&service).unwrap(),
            expected.decide(&service).unwrap()
        );
        let before = actual
            .sdk
            .as_ref()
            .unwrap()
            .env
            .snapshot_state()
            .unwrap()
            .encode();
        let expected_after_draw = expected.snapshot_state().unwrap().encode();
        assert_eq!(before, expected_after_draw);

        actual.reseed_entropy(0xDEAD_BEEF).unwrap();
        let after = actual
            .sdk
            .as_ref()
            .unwrap()
            .env
            .snapshot_state()
            .unwrap()
            .encode();
        assert_eq!(
            after, before,
            "platform entropy reseed must not reset the workload scheduler stream or handler state"
        );
    }

    #[test]
    fn branch_input_spec_materializes_handler_with_requested_seed() {
        use environment::input_spec::{InputSpec, ServiceFactory};
        use std::sync::Arc;

        const REQUESTED_SEED: u64 = 0xBEEF_CAFE;
        let config = SeededService::config();
        let mut spec = InputSpec::seeded(REQUESTED_SEED);
        spec.set_config(config.clone());
        let factory: ServiceFactory = Arc::new(move |requested| {
            if requested != &config {
                return Err(channel::ChannelError::Handler(
                    "unexpected service configuration".to_owned(),
                ));
            }
            Ok(Box::new(SeededService::default()))
        });

        let env = spec.materialize(&factory).unwrap();
        let mut expected_state = Vec::new();
        expected_state.extend_from_slice(&REQUESTED_SEED.to_le_bytes());
        expected_state.extend_from_slice(&0_u64.to_le_bytes());
        assert_eq!(
            env.handler().snapshot_state().unwrap(),
            expected_state,
            "branch InputSpec seed initializes workload handler state"
        );
    }

    #[test]
    #[cfg_attr(
        miri,
        ignore = "sha256-dominated (each state_hash/state_blob over the TEST_RAM image interprets ~2 s/KiB under Miri and this test hashes repeatedly); pure safe code over the mock backend — no map_memory on this path (both seams stay Miri-run in bringup); logic covered natively, and the family keeps Miri-run siblings"
    )]
    fn restore_vm_state_rejects_a_clock_rate_mismatch() {
        let mut a = full_vmm(VcpuState::default(), mutate_exits(), 500, 1);
        step_n(&mut a, 6);
        let s = a.save_vm_state().unwrap();
        let reject = |bad: &vm_state::VmState, name: &str| {
            let mut b = full_vmm(VcpuState::default(), vec![], 100, 1);
            assert!(
                matches!(b.restore_vm_state(bad), Err(VmmError::ContractViolation(_))),
                "a {name} clock-rate mismatch must be rejected"
            );
        };
        let mut bad = s.clone();
        bad.vtime.guest_hz += 1;
        reject(&bad, "guest_hz");
        let mut bad = s.clone();
        bad.vtime.guest_base += 1;
        reject(&bad, "guest_base");
    }

    #[test]
    #[cfg_attr(
        miri,
        ignore = "sha256-dominated (each state_hash/state_blob over the TEST_RAM image interprets ~2 s/KiB under Miri and this test hashes repeatedly); pure safe code over the mock backend — no map_memory on this path (both seams stay Miri-run in bringup); logic covered natively, and the family keeps Miri-run siblings"
    )]
    fn restore_into_unwired_vm_rejects_a_vtime_bearing_blob() {
        let mut a = vtime_vmm(vec![Exit::Arch(X86Exit::Rdmsr { index: 0x10 })], 1);
        a.step().unwrap();
        let s = a.save_vm_state().unwrap();
        assert!(
            s.vtime.guest_hz != 0,
            "source blob carries a live V-time block"
        );

        let mut only_hz = s.clone();
        only_hz.vtime.snapshot_vns = 0;
        let mut stock1 = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        assert!(matches!(
            stock1.restore_vm_state(&only_hz),
            Err(VmmError::ContractViolation(_))
        ));

        let mut only_vns = s.clone();
        only_vns.vtime.guest_hz = 0;
        only_vns.vtime.snapshot_vns = 7;
        let mut stock2 = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        assert!(matches!(
            stock2.restore_vm_state(&only_vns),
            Err(VmmError::ContractViolation(_))
        ));
    }

    struct SaveFailBackend(MockBackend, bool);
    impl Backend for SaveFailBackend {
        type A = vmm_backend::X86;

        fn read_x86_regs(&mut self) -> vmm_backend::Result<vmm_backend::VcpuRegs> {
            self.0.read_x86_regs()
        }

        fn read_x86_cpuid_state(&mut self) -> vmm_backend::Result<vmm_backend::X86CpuidState> {
            self.0.read_x86_cpuid_state()
        }

        fn set_policy(&mut self, policy: &X86Policy) -> vmm_backend::Result<()> {
            self.0.set_policy(policy)
        }
        unsafe fn map_memory(&mut self, gpa: Gpa, host: &mut [u8]) -> vmm_backend::Result<()> {
            // SAFETY: forwards to the inner mock, which only records the region
            // (no dereference); this adds no obligation beyond the trait contract.
            unsafe { self.0.map_memory(gpa, host) }
        }
        fn run(&mut self) -> vmm_backend::Result<Exit<vmm_backend::X86>> {
            self.0.run()
        }
        fn inject(&mut self, e: vmm_backend::Injection) -> vmm_backend::Result<()> {
            self.0.inject(e)
        }
        fn set_pending_irq(&mut self, v: Option<u8>) -> vmm_backend::Result<()> {
            self.0.set_pending_irq(v)
        }
        fn take_accepted_interrupt(&mut self) -> Option<u8> {
            self.0.take_accepted_interrupt()
        }
        fn complete_read(&mut self, v: u64) -> vmm_backend::Result<()> {
            self.0.complete_read(v)
        }
        fn complete_fault(&mut self) -> vmm_backend::Result<()> {
            self.0.complete_fault()
        }
        fn complete_ok(&mut self) -> vmm_backend::Result<()> {
            self.0.complete_ok()
        }
        fn complete_hypercall(&mut self, rax: u64) -> vmm_backend::Result<()> {
            self.0.complete_hypercall(rax)
        }
        fn complete_arch(&mut self, c: vmm_backend::X86Completion) -> vmm_backend::Result<()> {
            self.0.complete_arch(c)
        }
        fn save(&mut self) -> vmm_backend::Result<VcpuState> {
            if self.1 {
                Err(vmm_backend::BackendError::Unsupported {
                    what: "induced capture refusal",
                })
            } else {
                Err(vmm_backend::BackendError::Memory("induced save failure"))
            }
        }
        fn restore(&mut self, s: &VcpuState) -> vmm_backend::Result<()> {
            self.0.restore(s)
        }
        fn exit_counts(&self) -> vmm_backend::ExitCounts {
            self.0.exit_counts()
        }
        fn reset_exit_counts(&mut self) {
            self.0.reset_exit_counts()
        }
        fn capabilities(&self) -> vmm_backend::Capabilities<vmm_backend::X86Caps> {
            self.0.capabilities()
        }
    }

    struct CountSaveBackend {
        inner: MockBackend,
        save_calls: std::cell::Cell<usize>,
        fail_after: usize,
        reject_snapshot: bool,
    }

    impl Backend for CountSaveBackend {
        type A = vmm_backend::X86;

        fn read_x86_regs(&mut self) -> vmm_backend::Result<vmm_backend::VcpuRegs> {
            self.inner.read_x86_regs()
        }

        fn read_x86_cpuid_state(&mut self) -> vmm_backend::Result<vmm_backend::X86CpuidState> {
            self.inner.read_x86_cpuid_state()
        }

        fn set_policy(&mut self, policy: &X86Policy) -> vmm_backend::Result<()> {
            self.inner.set_policy(policy)
        }
        unsafe fn map_memory(&mut self, gpa: Gpa, host: &mut [u8]) -> vmm_backend::Result<()> {
            // SAFETY: forwards to the inner mock, which only records the region
            // (no dereference); this adds no obligation beyond the trait contract.
            unsafe { self.inner.map_memory(gpa, host) }
        }
        fn run(&mut self) -> vmm_backend::Result<Exit<vmm_backend::X86>> {
            self.inner.run()
        }
        fn inject(&mut self, e: vmm_backend::Injection) -> vmm_backend::Result<()> {
            self.inner.inject(e)
        }
        fn set_pending_irq(&mut self, v: Option<u8>) -> vmm_backend::Result<()> {
            self.inner.set_pending_irq(v)
        }
        fn take_accepted_interrupt(&mut self) -> Option<u8> {
            self.inner.take_accepted_interrupt()
        }
        fn complete_read(&mut self, v: u64) -> vmm_backend::Result<()> {
            self.inner.complete_read(v)
        }
        fn complete_fault(&mut self) -> vmm_backend::Result<()> {
            self.inner.complete_fault()
        }
        fn complete_ok(&mut self) -> vmm_backend::Result<()> {
            self.inner.complete_ok()
        }
        fn complete_hypercall(&mut self, rax: u64) -> vmm_backend::Result<()> {
            self.inner.complete_hypercall(rax)
        }
        fn complete_arch(&mut self, c: vmm_backend::X86Completion) -> vmm_backend::Result<()> {
            self.inner.complete_arch(c)
        }
        fn save(&mut self) -> vmm_backend::Result<VcpuState> {
            let calls = self.save_calls.get();
            self.save_calls.set(calls + 1);
            if calls >= self.fail_after {
                return Err(vmm_backend::BackendError::Memory(
                    "induced second save failure",
                ));
            }
            self.inner.save()
        }
        fn validate_snapshot_state(&self, _state: &VcpuState) -> vmm_backend::Result<()> {
            if self.reject_snapshot {
                Err(vmm_backend::BackendError::NonportableXsaveMxcsr)
            } else {
                Ok(())
            }
        }
        fn restore(&mut self, s: &VcpuState) -> vmm_backend::Result<()> {
            self.inner.restore(s)
        }
        fn exit_counts(&self) -> vmm_backend::ExitCounts {
            self.inner.exit_counts()
        }
        fn reset_exit_counts(&mut self) {
            self.inner.reset_exit_counts()
        }
        fn capabilities(&self) -> vmm_backend::Capabilities<vmm_backend::X86Caps> {
            self.inner.capabilities()
        }
    }

    #[test]
    fn control_snapshots_capture_once_and_observe_the_next_cpu_state() {
        use crate::control::{ControlServer, server_caps};
        use control_proto::{Reply, Request};

        let backend = CountSaveBackend {
            inner: configured_mock(Vec::new()),
            save_calls: std::cell::Cell::new(0),
            fail_after: usize::MAX,
            reject_snapshot: false,
        };
        let mut vmm = Vmm::new(backend, GuestRam::new(4096).unwrap());
        vmm.wire_snapshot_hashing();
        let mut server = ControlServer::new(vmm, Box::new(|| panic!("unused factory")));
        server
            .handle(&Request::Hello(server_caps()))
            .unwrap()
            .unwrap();
        let mut prior = None;
        for (calls, value) in [(1, 7), (2, 19)] {
            let mut state = VcpuState::default();
            state.regs.rax = value;
            server.vmm_mut().unwrap().backend.restore(&state).unwrap();
            let Reply::Snapshot { id, .. } = server.handle(&Request::Snapshot).unwrap().unwrap()
            else {
                panic!("snapshot reply");
            };
            let vmm = server.vmm().unwrap();
            assert_eq!(vmm.backend.save_calls.get(), calls);
            assert!(vmm.saved_state.is_none());
            let sidecar = server.export_sparse_snapshot(id, id).unwrap().sidecar;
            let decoded = crate::portable_snapshot::decode_sparse_sidecar(&sidecar).unwrap();
            let snapshot = vm_state::VmState::decode(&decoded.vm_state).unwrap();
            assert_eq!(snapshot.regs.rax, value);
            if let Some(previous_suffix) = prior {
                assert_ne!(decoded.state_blob_suffix, previous_suffix);
            }
            prior = Some(decoded.state_blob_suffix);
            assert_eq!(
                server.handle(&Request::Drop(id)).unwrap().unwrap(),
                Reply::Unit
            );
        }
    }

    #[test]
    #[cfg(feature = "xsave-diagnostics")]
    fn diagnostic_requests_preserve_backend_errors_and_ordered_hits() {
        let mut backend = ContinuationBackend::new(Vec::new(), Vec::new());
        backend.debug_hits = vec![0xabc0, 0xdef0, 0xabc0];
        let mut vmm = Vmm::new(backend, GuestRam::new(0x1000).unwrap());
        vmm.diagnostic_breakpoint(0xabc0)
            .expect("accepted breakpoint");
        assert!(matches!(
            vmm.diagnostic_breakpoint(0),
            Err(VmmError::Backend(vmm_backend::BackendError::InvalidState))
        ));
        assert_eq!(vmm.backend.breakpoint_requests, [0xabc0, 0]);
        assert_eq!(vmm.diagnostic_debug_hits(), [0xabc0, 0xdef0, 0xabc0]);
        assert_eq!(vmm.backend.ordinary_runs, 0);
        assert_eq!(vmm.backend.preparation_runs, 0);
    }

    struct ContinuationBackend {
        inner: MockBackend,
        ordinary: VecDeque<Exit<X86>>,
        continuation_scripts: VecDeque<VecDeque<Exit<X86>>>,
        current_continuations: VecDeque<Exit<X86>>,
        ordinary_runs: usize,
        finish_runs: usize,
        preparation_runs: usize,
        mapped: Vec<(Gpa, usize)>,
        #[cfg(feature = "xsave-diagnostics")]
        breakpoint_requests: Vec<u64>,
        #[cfg(feature = "xsave-diagnostics")]
        debug_hits: Vec<u64>,
    }

    impl ContinuationBackend {
        fn new(ordinary: Vec<Exit<X86>>, continuations: Vec<Vec<Exit<X86>>>) -> Self {
            assert_eq!(
                ordinary.len(),
                continuations.len(),
                "each ordinary entry needs one continuation script"
            );
            Self {
                inner: configured_mock(Vec::new()),
                ordinary: ordinary.into(),
                continuation_scripts: continuations.into_iter().map(VecDeque::from).collect(),
                current_continuations: VecDeque::new(),
                ordinary_runs: 0,
                finish_runs: 0,
                preparation_runs: 0,
                mapped: Vec::new(),
                #[cfg(feature = "xsave-diagnostics")]
                breakpoint_requests: Vec::new(),
                #[cfg(feature = "xsave-diagnostics")]
                debug_hits: Vec::new(),
            }
        }
    }

    impl Backend for ContinuationBackend {
        type A = X86;

        fn read_x86_regs(&mut self) -> vmm_backend::Result<vmm_backend::VcpuRegs> {
            self.inner.read_x86_regs()
        }

        fn read_x86_cpuid_state(&mut self) -> vmm_backend::Result<vmm_backend::X86CpuidState> {
            self.inner.read_x86_cpuid_state()
        }

        #[cfg(feature = "xsave-diagnostics")]
        fn diagnostic_breakpoint(&mut self, rip: u64) -> vmm_backend::Result<()> {
            self.breakpoint_requests.push(rip);
            if rip == 0 {
                Err(vmm_backend::BackendError::InvalidState)
            } else {
                Ok(())
            }
        }

        #[cfg(feature = "xsave-diagnostics")]
        fn diagnostic_debug_hits(&self) -> Vec<u64> {
            self.debug_hits.clone()
        }

        fn set_policy(&mut self, policy: &X86Policy) -> vmm_backend::Result<()> {
            self.inner.set_policy(policy)
        }

        unsafe fn map_memory(&mut self, gpa: Gpa, host: &mut [u8]) -> vmm_backend::Result<()> {
            self.mapped.push((gpa, host.len()));
            Ok(())
        }

        fn run(&mut self) -> vmm_backend::Result<Exit<X86>> {
            if !self.current_continuations.is_empty() {
                return Err(vmm_backend::BackendError::PendingCompletion);
            }
            let exit = self
                .ordinary
                .pop_front()
                .ok_or(vmm_backend::BackendError::Internal(
                    "continuation test ordinary run queue empty",
                ))?;
            let continuations = self.continuation_scripts.pop_front().ok_or(
                vmm_backend::BackendError::Internal("continuation test script queue empty"),
            )?;
            self.current_continuations = continuations;
            self.ordinary_runs += 1;
            self.inner.push_exit(exit);
            let exit = self.inner.run()?;
            let mut state = self.inner.save()?;
            state.regs.rip += 2;
            state.regs.rax = state.regs.rax.wrapping_add(1);
            self.inner.set_state(state);
            Ok(exit)
        }

        fn inject(&mut self, event: vmm_backend::Injection) -> vmm_backend::Result<()> {
            self.inner.inject(event)
        }

        fn set_pending_irq(&mut self, id: Option<u8>) -> vmm_backend::Result<()> {
            self.inner.set_pending_irq(id)
        }

        fn take_accepted_interrupt(&mut self) -> Option<u8> {
            self.inner.take_accepted_interrupt()
        }

        fn complete_read(&mut self, value: u64) -> vmm_backend::Result<()> {
            self.inner.complete_read(value)
        }

        fn complete_fault(&mut self) -> vmm_backend::Result<()> {
            self.inner.complete_fault()
        }

        fn complete_ok(&mut self) -> vmm_backend::Result<()> {
            self.inner.complete_ok()
        }

        fn complete_hypercall(&mut self, ret: u64) -> vmm_backend::Result<()> {
            self.inner.complete_hypercall(ret)
        }

        fn complete_arch(
            &mut self,
            completion: vmm_backend::X86Completion,
        ) -> vmm_backend::Result<()> {
            self.inner.complete_arch(completion)
        }

        fn finish_exit(&mut self) -> vmm_backend::Result<Option<Exit<X86>>> {
            let Some(exit) = self.current_continuations.pop_front() else {
                return Ok(None);
            };
            self.finish_runs += 1;
            self.inner.push_exit(exit);
            Ok(Some(self.inner.run()?))
        }

        fn retire_pending_completion(&mut self) -> vmm_backend::Result<()> {
            if !self.current_continuations.is_empty() {
                return Err(vmm_backend::BackendError::PendingCompletion);
            }
            self.inner.retire_pending_completion()
        }

        fn prepare_snapshot(&mut self) -> vmm_backend::Result<()> {
            if !self.current_continuations.is_empty() || self.inner.has_pending() {
                return Err(vmm_backend::BackendError::PendingCompletion);
            }
            self.preparation_runs += 1;
            self.inner.prepare_snapshot()
        }

        fn save(&mut self) -> vmm_backend::Result<VcpuState> {
            if !self.current_continuations.is_empty() || self.inner.has_pending() {
                return Err(vmm_backend::BackendError::PendingCompletion);
            }
            self.inner.save()
        }

        fn restore(&mut self, state: &VcpuState) -> vmm_backend::Result<()> {
            if !self.current_continuations.is_empty() || self.inner.has_pending() {
                return Err(vmm_backend::BackendError::PendingCompletion);
            }
            self.inner.restore(state)
        }

        fn exit_counts(&self) -> vmm_backend::ExitCounts {
            self.inner.exit_counts()
        }

        fn reset_exit_counts(&mut self) {
            self.inner.reset_exit_counts()
        }

        fn capabilities(&self) -> vmm_backend::Capabilities<X86Caps> {
            self.inner.capabilities()
        }
    }

    fn continuation_vmm(
        ordinary: Vec<Exit<X86>>,
        continuations: Vec<Vec<Exit<X86>>>,
        seed: u64,
    ) -> Vmm<ContinuationBackend> {
        let mut vmm = Vmm::new(
            ContinuationBackend::new(ordinary, continuations),
            GuestRam::new(0x2000).unwrap(),
        );
        vmm.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), seed).unwrap());
        vmm.wire_lapic(
            lapic::Lapic::new(lapic::LapicConfig {
                apic_id: 0,
                timer_hz: 24_000_000,
            })
            .unwrap(),
        );
        vmm
    }

    fn boxed_continuation_vmm(
        ordinary: Vec<Exit<X86>>,
        continuations: Vec<Vec<Exit<X86>>>,
        seed: u64,
    ) -> Vmm<Box<ContinuationBackend>> {
        let mut vmm = Vmm::new(
            Box::new(ContinuationBackend::new(ordinary, continuations)),
            GuestRam::new(0x2000).unwrap(),
        );
        vmm.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), seed).unwrap());
        vmm.wire_lapic(
            lapic::Lapic::new(lapic::LapicConfig {
                apic_id: 0,
                timer_hz: 24_000_000,
            })
            .unwrap(),
        );
        vmm
    }

    fn apic_read(offset: u32) -> Exit<X86> {
        Exit::Common(CommonExit::Mmio {
            gpa: Gpa(APIC_MMIO_BASE + u64::from(offset)),
            size: 4,
            write: None,
        })
    }

    fn apic_write(offset: u32, value: u64) -> Exit<X86> {
        Exit::Common(CommonExit::Mmio {
            gpa: Gpa(APIC_MMIO_BASE + u64::from(offset)),
            size: 4,
            write: Some(value),
        })
    }

    #[test]
    fn snapshot_preparation_follows_completion_and_reads_do_not_repeat_it() {
        let mut vmm = boxed_continuation_vmm(
            vec![apic_read(lapic::APIC_VERSION)],
            vec![vec![apic_write(lapic::APIC_TPR, 0x20)]],
            7,
        );
        vmm.wire_snapshot_hashing();
        assert_eq!(vmm.step().unwrap(), Step::Continued);
        assert_eq!(vmm.backend.preparation_runs, 0);
        assert_eq!(vmm.backend.ordinary_runs, 1);
        assert_eq!(vmm.backend.finish_runs, 1);
        let counts = vmm.exit_counts();
        let time = vmm.effective_vns();
        let state = vmm.save_vm_state().unwrap();
        assert_eq!(vmm.backend.preparation_runs, 1);
        let hash = vmm.state_hash().unwrap();
        assert_eq!(vmm.save_vm_state().unwrap(), state);
        assert_eq!(vmm.state_hash().unwrap(), hash);
        assert_eq!(vmm.backend.preparation_runs, 1);
        assert_eq!(vmm.exit_counts(), counts);
        assert_eq!(vmm.effective_vns(), time);
    }

    #[test]
    fn n_exits_then_one_save_prepares_once_and_matches_eager_per_exit_preparation() {
        let tick = Exit::Arch(X86Exit::Io {
            port: VIRTUAL_TIME_TICK_PORT,
            size: 4,
            write: Some(1),
        });
        let ordinary = vec![
            apic_read(lapic::APIC_VERSION),
            tick.clone(),
            apic_read(lapic::APIC_VERSION),
            tick.clone(),
            tick.clone(),
            apic_read(lapic::APIC_VERSION),
            tick,
        ];
        let continuations = vec![Vec::new(); ordinary.len()];

        let mut lazy = boxed_continuation_vmm(ordinary.clone(), continuations.clone(), 7);
        let mut eager = boxed_continuation_vmm(ordinary.clone(), continuations, 7);
        let mut lazy_states = Vec::new();
        let mut eager_states = Vec::new();

        for _ in 0..4 {
            assert_eq!(lazy.step().unwrap(), Step::Continued);
        }
        assert_eq!(lazy.backend.preparation_runs, 0);
        let after_out = lazy.save_vm_state().unwrap();
        assert_eq!(
            lazy.backend.preparation_runs, 1,
            "one on-demand save after N exits prepares exactly once"
        );
        assert_eq!(lazy.save_vm_state().unwrap(), after_out);
        assert_eq!(lazy.backend.preparation_runs, 1);
        lazy_states.push(after_out.encode().unwrap());

        for _ in 0..4 {
            assert_eq!(eager.step().unwrap(), Step::Continued);
            eager.prepare_snapshot().unwrap();
        }
        assert_eq!(eager.backend.preparation_runs, 4);
        eager_states.push(eager.save_vm_state().unwrap().encode().unwrap());
        assert_eq!(
            lazy_states, eager_states,
            "an OUT followed by a save reproduces the eager per-exit snapshot bytes"
        );

        assert_eq!(lazy.step().unwrap(), Step::Continued);
        lazy.retire_pending_completion().unwrap();
        lazy.restore_vm_state(&after_out).unwrap();
        lazy_states.push(lazy.save_vm_state().unwrap().encode().unwrap());
        assert_eq!(
            lazy_states[0], lazy_states[1],
            "an OUT followed by a restore returns to the saved bytes"
        );

        assert_eq!(eager.step().unwrap(), Step::Continued);
        eager.prepare_snapshot().unwrap();
        eager.retire_pending_completion().unwrap();
        eager.restore_vm_state(&after_out).unwrap();
        eager_states.push(eager.save_vm_state().unwrap().encode().unwrap());

        for _ in 0..2 {
            assert_eq!(lazy.step().unwrap(), Step::Continued);
            assert_eq!(eager.step().unwrap(), Step::Continued);
            eager.prepare_snapshot().unwrap();
        }
        lazy_states.push(lazy.save_vm_state().unwrap().encode().unwrap());
        eager_states.push(eager.save_vm_state().unwrap().encode().unwrap());
        assert_eq!(
            lazy_states, eager_states,
            "lazy on-demand preparation reproduces the same snapshot bytes as preparing on \
             every exit across advancing vCPU state, an OUT then save, and an OUT then restore"
        );
        assert_ne!(
            lazy_states[0], lazy_states[2],
            "the vCPU state advances across exits so the comparison is not vacuous"
        );
        assert_eq!(lazy.backend.ordinary_runs, eager.backend.ordinary_runs);
        assert_eq!(lazy.backend.ordinary_runs, 7);
    }

    #[test]
    fn fragmented_lapic_mmio_is_drained_without_an_extra_outer_run() {
        let mut source = boxed_continuation_vmm(
            vec![apic_read(lapic::APIC_VERSION)],
            vec![vec![apic_write(lapic::APIC_TPR, 0x20)]],
            7,
        );
        source.wire_snapshot_hashing();

        assert_eq!(source.step().unwrap(), Step::Continued);
        assert_eq!(source.backend.as_ref().ordinary_runs, 1);
        assert_eq!(source.backend.as_ref().finish_runs, 1);
        assert!(source.backend.as_ref().ordinary.is_empty());
        assert_eq!(source.exit_counts().mmio, 2);
        assert_eq!(
            source.backend.as_ref().inner.completions(),
            &[Completion::Read(u64::from(lapic::APIC_VERSION_VALUE))],
            "the read fragment receives the APIC version response"
        );
        assert_eq!(
            source.devices.lapic.as_ref().unwrap().snapshot().tpr,
            0x20,
            "the write fragment updates the LAPIC"
        );

        let per_mmio =
            crate::vendor::x86::contract::virtual_time_timing().interrupt_controller_mmio_vns;
        assert_eq!(source.effective_vns(), Some(per_mmio * 2));
        let counts = source.exit_counts();
        let vns = source.effective_vns();
        let outer_runs = source.backend.as_ref().ordinary_runs;
        let finish_runs = source.backend.as_ref().finish_runs;
        let hash = source.state_hash().unwrap();
        let bytes = source.save_vm_state().unwrap().encode().unwrap();
        assert_eq!(source.state_hash().unwrap(), hash);
        assert_eq!(source.save_vm_state().unwrap().encode().unwrap(), bytes);
        assert_eq!(source.exit_counts(), counts);
        assert_eq!(source.effective_vns(), vns);
        assert_eq!(source.backend.as_ref().ordinary_runs, outer_runs);
        assert_eq!(source.backend.as_ref().finish_runs, finish_runs);

        let decoded = vm_state::VmState::decode(&bytes).unwrap();
        let memory = source.guest_memory().to_vec();
        let mut cold = boxed_continuation_vmm(vec![], vec![], 7);
        cold.wire_snapshot_hashing();
        cold.restore_snapshot(&memory, &decoded).unwrap();
        assert_eq!(cold.state_hash().unwrap(), hash);
        assert_eq!(cold.save_vm_state().unwrap().encode().unwrap(), bytes);
        assert_eq!(cold.backend.as_ref().ordinary_runs, 0);
        assert_eq!(cold.backend.as_ref().finish_runs, 0);
        assert_eq!(cold.exit_counts(), vmm_backend::ExitCounts::default());
        assert_eq!(cold.effective_vns(), vns);
        assert_eq!(
            cold.devices.lapic.as_ref().unwrap().snapshot(),
            source.devices.lapic.as_ref().unwrap().snapshot()
        );
    }

    #[test]
    fn failed_exit_service_blocks_snapshot_and_hash_publication() {
        let mut vmm = full_vmm(
            VcpuState::default(),
            vec![Exit::Common(CommonExit::Hypercall(
                vmm_backend::HypercallFrame::default(),
            ))],
            10,
            1,
        );
        let before = vmm.save_vm_state().unwrap();
        vmm.saved_state = Some(vmm.backend.save().unwrap());
        assert!(matches!(vmm.step(), Err(VmmError::ContractViolation(_))));
        assert!(vmm.backend.save().is_ok());
        assert!(matches!(
            vmm.save_vm_state(),
            Err(VmmError::Backend(
                vmm_backend::BackendError::PendingCompletion
            ))
        ));
        assert!(matches!(
            vmm.state_blob(),
            Err(VmmError::Backend(
                vmm_backend::BackendError::PendingCompletion
            ))
        ));
        assert!(matches!(
            vmm.state_hash(),
            Err(VmmError::Backend(
                vmm_backend::BackendError::PendingCompletion
            ))
        ));
        let failed = vmm
            .hash_telemetry()
            .cost(crate::host_telemetry::HashSite::WholeRequest);
        assert_eq!(failed.calls, 1);
        assert_eq!(failed.errors, 1);
        assert_eq!(
            failed.ram_bytes,
            crate::state_digest::hashed_page_bytes(vmm.guest_memory())
        );
        assert_eq!(failed.suffix_bytes, 0);
        vmm.backend.complete_hypercall(0).unwrap();
        vmm.backend.retire_pending_completion().unwrap();
        assert!(vmm.restore_vm_state(&before).is_err());
        assert!(
            vmm.save_vm_state().is_ok(),
            "the failed restore's backend mutation already committed a vcpu with nothing \
             pending, so save prepares on demand and succeeds"
        );
        assert!(vmm.state_hash().is_ok());
        vmm.virtual_time_trace = None;
        vmm.restore_vm_state(&before).unwrap();
        assert_eq!(vmm.save_vm_state().unwrap(), before);
    }

    #[test]
    fn snapshot_fails_while_a_continuation_remains_queued() {
        let mut vmm = continuation_vmm(
            vec![apic_read(lapic::APIC_VERSION)],
            vec![vec![apic_write(lapic::APIC_TPR, 0x20)]],
            7,
        );
        vmm.backend.run().unwrap();
        assert!(matches!(
            vmm.save_vm_state(),
            Err(VmmError::Backend(
                vmm_backend::BackendError::PendingCompletion
            ))
        ));
        assert!(matches!(
            vmm.state_hash(),
            Err(VmmError::Backend(
                vmm_backend::BackendError::PendingCompletion
            ))
        ));
        assert!(vmm.prepare_snapshot().is_err());
        vmm.backend.current_continuations.clear();
        vmm.backend.complete_read(0).unwrap();
        vmm.backend.retire_pending_completion().unwrap();
        assert!(vmm.backend.save().is_ok());
        assert!(vmm.save_vm_state().is_ok());
        assert!(vmm.state_hash().is_ok());
    }

    fn fragmented_checkpoint_script() -> (Vec<Exit<X86>>, Vec<Vec<Exit<X86>>>) {
        let mut ordinary = Vec::with_capacity(256);
        let mut continuations = Vec::with_capacity(256);
        for value in 0..255u32 {
            ordinary.push(Exit::Arch(X86Exit::Io {
                port: REPORT_PORT,
                size: 4,
                write: Some(value),
            }));
            continuations.push(Vec::new());
        }
        ordinary.push(apic_read(lapic::APIC_VERSION));
        continuations.push(vec![apic_write(lapic::APIC_TPR, 0x20)]);
        (ordinary, continuations)
    }

    #[test]
    fn deferred_checkpoint_lands_on_the_final_fragment_and_resets_with_trace_segments() {
        let (ordinary, continuations) = fragmented_checkpoint_script();
        let mut synchronous = boxed_continuation_vmm(ordinary.clone(), continuations.clone(), 7);
        synchronous.wire_snapshot_hashing();
        for _ in 0..255 {
            assert_eq!(synchronous.step().unwrap(), Step::Continued);
        }
        assert_eq!(synchronous.step().unwrap(), Step::Continued);
        let synchronous_trace = synchronous.virtual_time_trace().unwrap();
        assert_eq!(synchronous_trace.normalized_log().events.len(), 257);
        assert_eq!(
            synchronous_trace.normalized_log().events[255].state_hash,
            None,
            "the first fragment is not a complete checkpoint boundary"
        );
        let expected = synchronous
            .virtual_time_trace()
            .unwrap()
            .normalized_log()
            .events[256]
            .state_hash
            .expect("the final fragment owns the synchronous checkpoint");

        let mut deferred = boxed_continuation_vmm(ordinary, continuations, 7);
        deferred.wire_snapshot_hashing();
        deferred.defer_virtual_time_checkpoint_hashes().unwrap();
        for _ in 0..255 {
            assert_eq!(deferred.step().unwrap(), Step::Continued);
        }
        assert_eq!(deferred.step().unwrap(), Step::Continued);
        let trace = deferred.virtual_time_trace().unwrap();
        assert_eq!(trace.normalized_log().events.len(), 257);
        assert_eq!(trace.normalized_log().events[255].state_hash, None);
        assert_eq!(trace.normalized_log().events[256].state_hash, None);
        assert!(!deferred.virtual_time_checkpoint_due(255));
        assert!(deferred.virtual_time_checkpoint_due(256));
        assert_eq!(deferred.state_hash().unwrap(), expected);
        deferred
            .checkpoint_virtual_time_trace_at(256, expected)
            .unwrap();
        assert_eq!(
            deferred
                .virtual_time_trace()
                .unwrap()
                .normalized_log()
                .events[256]
                .state_hash,
            Some(expected)
        );
        assert!(
            deferred
                .checkpoint_virtual_time_trace_at(255, expected)
                .is_err()
        );

        let completed_segment = deferred.take_virtual_time_trace().unwrap();
        assert_eq!(completed_segment.normalized_log().events.len(), 257);
        assert!(!deferred.virtual_time_checkpoint_due(256));
        assert!(
            deferred
                .checkpoint_virtual_time_trace_at(256, expected)
                .is_err()
        );
        assert!(
            deferred
                .virtual_time_trace()
                .unwrap()
                .normalized_log()
                .events
                .is_empty()
        );
    }

    #[test]
    fn armed_checkpoint_preimage_reuses_the_synchronous_hash_save() {
        let exits = || (0..256).map(report_out).collect::<Vec<_>>();
        let mut armed = Vmm::new(
            CountSaveBackend {
                inner: configured_mock(exits()),
                save_calls: std::cell::Cell::new(0),
                fail_after: 1,
                reject_snapshot: false,
            },
            GuestRam::new(0x2000).unwrap(),
        );
        armed.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 7).unwrap());
        armed.arm_checkpoint_hash_preimage();
        for _ in 0..256 {
            assert_eq!(armed.step().unwrap(), Step::Continued);
        }
        let cost = armed
            .hash_telemetry()
            .cost(crate::host_telemetry::HashSite::Checkpoint);
        assert_eq!(cost.calls, 1);
        assert_eq!(
            cost.ram_bytes,
            crate::state_digest::hashed_page_bytes(armed.guest_memory())
        );
        assert_eq!(cost.errors, 0);
        assert_eq!(
            armed
                .hash_telemetry()
                .cost(crate::host_telemetry::HashSite::WholeRequest)
                .calls,
            0
        );
        let retained = armed
            .take_checkpoint_hash_preimage()
            .expect("the completed 256th event retains its synchronous hash input");
        assert_eq!(retained.event_index, 255);
        let memory = crate::state_digest::memory_digest_of(armed.guest_memory());
        assert_eq!(retained.memory_length, armed.guest_memory().len());
        assert_eq!(retained.memory_digest, memory);
        assert_eq!(
            retained.state_hash,
            crate::state_digest::state_hash_of(&memory, &retained.state_blob_suffix)
        );
        assert_eq!(
            armed.virtual_time_trace().unwrap().normalized_log().events[255].state_hash,
            Some(retained.state_hash)
        );
        assert_eq!(armed.backend.save_calls.get(), 1);
        assert!(armed.take_checkpoint_hash_preimage().is_none());

        let mut disabled = Vmm::new(
            CountSaveBackend {
                inner: configured_mock(exits()),
                save_calls: std::cell::Cell::new(0),
                fail_after: 1,
                reject_snapshot: false,
            },
            GuestRam::new(0x2000).unwrap(),
        );
        disabled.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 7).unwrap());
        for _ in 0..256 {
            assert_eq!(disabled.step().unwrap(), Step::Continued);
        }
        assert_eq!(disabled.backend.save_calls.get(), 1);
        assert!(disabled.take_checkpoint_hash_preimage().is_none());
    }

    #[test]
    fn terminal_checkpoint_retains_memory_digest_before_consumer_stops() {
        let mut exits = (0..255).map(report_out).collect::<Vec<_>>();
        exits.push(Exit::Common(CommonExit::Shutdown));
        let mut vmm = Vmm::new(configured_mock(exits), GuestRam::new(0x2000).unwrap());
        vmm.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 7).unwrap());
        vmm.arm_checkpoint_hash_preimage();
        for _ in 0..255 {
            assert_eq!(vmm.step().unwrap(), Step::Continued);
        }
        assert_eq!(
            vmm.step().unwrap(),
            Step::Terminal(TerminalReason::Shutdown)
        );
        let retained = vmm
            .take_checkpoint_hash_preimage()
            .expect("terminal checkpoint retained");
        assert_eq!(retained.event_index, 255);
        assert_eq!(retained.memory_length, vmm.guest_memory().len());
        assert_eq!(
            retained.memory_digest,
            crate::state_digest::memory_digest_of(vmm.guest_memory())
        );
    }

    #[test]
    fn save_vm_state_fails_closed_on_backend_save_error() {
        let mut v = Vmm::new(
            SaveFailBackend(configured_mock(vec![]), false),
            GuestRam::new(0x1000).unwrap(),
        );
        assert!(
            matches!(v.save_vm_state(), Err(VmmError::Backend(_))),
            "a failing Backend::save must make save_vm_state fail closed"
        );
        assert!(
            matches!(v.state_hash(), Err(VmmError::Backend(_))),
            "a failing register read must not produce a hash of default CPU state"
        );
    }

    #[test]
    fn rejected_snapshot_preserves_guest_execution_and_state_hashing() {
        let backend = Box::new(CountSaveBackend {
            inner: configured_mock(vec![Exit::Common(CommonExit::Shutdown)]),
            save_calls: std::cell::Cell::new(0),
            fail_after: usize::MAX,
            reject_snapshot: true,
        });
        let mut vmm = Vmm::new(backend, GuestRam::new(0x1000).unwrap());
        assert_eq!(vmm.run().unwrap().reason, TerminalReason::Shutdown);
        assert!(vmm.state_hash().is_ok());
        assert!(matches!(
            vmm.save_vm_state(),
            Err(VmmError::Backend(
                vmm_backend::BackendError::NonportableXsaveMxcsr
            ))
        ));
    }

    #[test]
    fn cpu_observations_fail_closed_on_backend_save_error() {
        let mut v = Vmm::new(
            SaveFailBackend(configured_mock(vec![]), false),
            GuestRam::new(0x1000).unwrap(),
        );
        assert!(matches!(v.inspect_vcpu(), Err(VmmError::Backend(_))));
        assert!(matches!(
            v.has_inflight_event_injection(),
            Err(VmmError::Backend(_))
        ));
        assert!(matches!(
            v.has_active_event_injection(),
            Err(VmmError::Backend(_))
        ));
        assert!(matches!(v.state_components(), Err(VmmError::Backend(_))));

        let captured = nonzero_state();
        v.saved_state = Some(captured.clone());
        assert_eq!(v.inspect_vcpu().unwrap(), captured);
        assert!(!v.has_inflight_event_injection().unwrap());
        assert!(!v.has_active_event_injection().unwrap());
        assert!(v.state_components().is_ok());
    }

    #[test]
    fn regs_request_fails_closed_on_backend_save_error() {
        use crate::control::{ControlServer, ServeError, server_caps};
        use control_proto::Request;

        let mut backend = configured_mock(vec![]);
        let mut state = VcpuState::default();
        state.regs.rip = 0x1234;
        backend.set_state(state);
        let vmm = Vmm::new(
            SaveFailBackend(backend, false),
            GuestRam::new(0x1000).unwrap(),
        );
        let mut server = ControlServer::new(vmm, Box::new(|| panic!("unused factory")));
        server
            .handle(&Request::Hello(server_caps()))
            .unwrap()
            .unwrap();
        let reply = server.handle(&Request::Regs);
        assert!(
            matches!(reply, Err(ServeError::Vmm(VmmError::Backend(_)))),
            "{reply:?}"
        );
    }

    #[test]
    fn unsupported_capture_refuses_observations_without_ending_the_session() {
        use crate::control::{ControlServer, server_caps};
        use control_proto::{ControlError, HashScope, Reply, Request};

        let mut vmm = Vmm::new(
            SaveFailBackend(configured_mock(vec![]), true),
            GuestRam::new(0x1000).unwrap(),
        );
        vmm.wire_snapshot_hashing();
        let mut server = ControlServer::new(vmm, Box::new(|| panic!("unused factory")));
        server
            .handle(&Request::Hello(server_caps()))
            .unwrap()
            .unwrap();
        for request in [
            Request::Regs,
            Request::Hash {
                scope: HashScope::Whole,
            },
            Request::Snapshot,
        ] {
            assert!(matches!(
                server.handle(&request).unwrap(),
                Err(ControlError::SnapshotRefused { reason })
                    if reason == "induced capture refusal"
            ));
            assert_eq!(server.latest_snapshot(), None);
        }
        assert!(matches!(
            server.handle(&Request::Read { gpa: 0, len: 1 }).unwrap(),
            Ok(Reply::Bytes(bytes)) if bytes.len() == 1
        ));
    }

    #[test]
    fn terminal_snapshots_preserve_the_stop_without_guest_reentry() {
        for (exit, reason) in [
            (
                Exit::Arch(X86Exit::Io {
                    port: 0xf4,
                    size: 1,
                    write: Some(7),
                }),
                TerminalReason::DebugExit { code: 7 },
            ),
            (Exit::Common(CommonExit::Idle), TerminalReason::Idle),
            (Exit::Common(CommonExit::Shutdown), TerminalReason::Shutdown),
        ] {
            let mut cpu = nonzero_state();
            cpu.regs.rflags = 2;
            let mut source = full_vmm(cpu.clone(), vec![exit], 0, 7);
            source.wire_snapshot_hashing();
            assert_eq!(source.step().unwrap(), Step::Terminal(reason));
            let hash = source.state_hash().unwrap();
            let at = source.effective_vns();
            let counts = source.exit_counts();
            let memory = source.guest_memory().to_vec();
            let encoded = source.save_vm_state().unwrap().encode().unwrap();
            assert_eq!(source.state_hash().unwrap(), hash);
            assert_eq!(source.effective_vns(), at);
            assert_eq!(source.exit_counts(), counts);
            assert_eq!(source.save_vm_state().unwrap().encode().unwrap(), encoded);
            let snapshot = vm_state::VmState::decode(&encoded).unwrap();

            let next_exit = Exit::Arch(X86Exit::Io {
                port: 0x3f8,
                size: 1,
                write: Some(b'X'.into()),
            });
            let mut cold = full_vmm(cpu, vec![next_exit], 0, 7);
            cold.wire_snapshot_hashing();
            let runnable = cold.save_vm_state().unwrap();
            cold.restore_snapshot(&memory, &snapshot).unwrap();
            assert_eq!(cold.state_hash().unwrap(), hash);
            let cold_counts = cold.exit_counts();
            for _ in 0..3 {
                assert_eq!(source.step().unwrap(), Step::Terminal(reason));
                assert_eq!(cold.step().unwrap(), Step::Terminal(reason));
                assert_eq!(cold.exit_counts(), cold_counts);
                assert_eq!(cold.effective_vns(), at);
                assert_eq!(cold.state_hash().unwrap(), hash);
                assert_eq!(source.state_hash().unwrap(), hash);
            }
            cold.restore_vm_state(&runnable).unwrap();
            assert_eq!(cold.step().unwrap(), Step::Continued);
            assert_eq!(cold.serial_output(), b"X");
        }
    }

    #[test]
    fn lifecycle_restore_rejects_malformed_state_before_mutation() {
        let mut source = full_vmm(nonzero_state(), vec![], 0, 7);
        let mut snapshot = source.save_vm_state().unwrap();
        snapshot.set_engine_state(vec![b'V', b'M', b'E', 1, 4, 0, 0]);
        let mut destination = full_vmm(VcpuState::default(), vec![], 0, 9);
        let before = destination.state_hash().unwrap();
        assert!(matches!(
            destination.restore_vm_state(&snapshot),
            Err(VmmError::Snapshot(
                crate::snapshot::SnapshotError::EngineState(_)
            ))
        ));
        assert_eq!(destination.state_hash().unwrap(), before);
    }

    #[test]
    fn deferred_sdk_reentry_is_part_of_snapshot_and_hash_identity() {
        let build = || {
            let mut vmm = Vmm::new(
                configured_mock(vec![Exit::Arch(X86Exit::Io {
                    port: 0x3f8,
                    size: 1,
                    write: Some(b'X'.into()),
                })]),
                GuestRam::new(TEST_RAM).unwrap(),
            );
            enable_nominal(&mut vmm, 7);
            vmm
        };
        let mut source = build();
        source.sdk.as_mut().unwrap().pending_snapshot = true;
        let ready_hash = source.state_hash().unwrap();
        source.sdk_snapshot_reentry_required = true;
        let deferred_hash = source.state_hash().unwrap();
        assert_ne!(ready_hash, deferred_hash);
        let sdk = source.sdk_snapshot().unwrap().unwrap();
        let snapshot = source.save_vm_state().unwrap();
        let snapshot = vm_state::VmState::decode(&snapshot.encode().unwrap()).unwrap();
        let mut cold = build();
        cold.restore_snapshot(source.guest_memory(), &snapshot)
            .unwrap();
        cold.sdk_restore(&sdk).unwrap();
        assert_eq!(cold.state_hash().unwrap(), deferred_hash);
        assert!(!source.take_snapshot_point());
        assert!(!cold.take_snapshot_point());
        assert_eq!(source.step().unwrap(), Step::Continued);
        assert_eq!(cold.step().unwrap(), Step::Continued);
        assert_eq!(cold.state_hash().unwrap(), source.state_hash().unwrap());
        assert!(source.take_snapshot_point());
        assert!(cold.take_snapshot_point());
        assert!(!cold.take_snapshot_point());
        assert_eq!(cold.state_hash().unwrap(), source.state_hash().unwrap());
    }

    #[test]
    fn report_stream_round_trips_through_save_restore() {
        let mut a = full_vmm(VcpuState::default(), vec![], 0, 1);
        a.report_stream = vec![0xAA, 0x0000_0000, 0xDEAD_BEEF];
        let s = a.save_vm_state().unwrap();

        let mut b = full_vmm(VcpuState::default(), vec![], 0, 1);
        assert!(b.report_stream().is_empty(), "B starts with no reports");
        b.restore_vm_state(&s).unwrap();
        assert_eq!(
            b.report_stream(),
            &[0xAA, 0x0000_0000, 0xDEAD_BEEF],
            "the report stream is restored in execution order"
        );
        assert_eq!(
            b.observable_digest(),
            a.observable_digest(),
            "the restored VM's O2 observable_digest matches the snapshot source"
        );
    }

    #[test]
    fn restore_vm_state_rejects_a_legacy_wiring_mismatch() {
        let mut a = full_vmm(VcpuState::default(), mutate_exits(), 500, 1);
        step_n(&mut a, 6);
        let mut s = a.save_vm_state().unwrap();
        let mut dev = snapshot::decode_device_blob(&s.devices.0).unwrap();
        assert!(
            dev.legacy.is_some() && dev.lapic.is_some(),
            "the full-VM blob carries both LAPIC and legacy state"
        );
        dev.legacy = None;
        s.devices = snapshot::encode_device_blob(&dev);

        let mut b = full_vmm(VcpuState::default(), vec![], 100, 1);
        assert!(
            matches!(b.restore_vm_state(&s), Err(VmmError::ContractViolation(_))),
            "a dropped legacy subrecord must be rejected, not silently skipped"
        );
    }

    #[test]
    fn restore_vm_state_rejects_a_staged_non_rng_completion() {
        let mut src = full_vmm(VcpuState::default(), mutate_exits(), 500, 1);
        step_n(&mut src, 6);
        let snap = src.save_vm_state().unwrap();

        let mut tgt = full_vmm(
            VcpuState::default(),
            vec![Exit::Arch(X86Exit::Rdmsr { index: 0x10 })],
            10,
            1,
        );
        tgt.step().unwrap();
        assert!(matches!(
            tgt.restore_vm_state(&snap),
            Err(VmmError::ContractViolation(_))
        ));
    }

    #[test]
    fn output_completion_must_be_retired_before_restoring_registers() {
        let mut src = full_vmm(VcpuState::default(), vec![], 500, 1);
        let snap = src.save_vm_state().unwrap();
        let mut tgt = full_vmm(
            VcpuState::default(),
            vec![Exit::Arch(X86Exit::Io {
                port: 0x3f8,
                size: 1,
                write: Some(b'x' as u32),
            })],
            10,
            1,
        );
        tgt.step().unwrap();
        assert!(tgt.completion_staged);
        assert!(matches!(
            tgt.restore_vm_state(&snap),
            Err(VmmError::ContractViolation(_))
        ));
        tgt.retire_pending_completion().unwrap();
        tgt.restore_vm_state(&snap).unwrap();
    }

    #[test]
    fn restore_vm_state_rejects_a_non_empty_timer_queue() {
        let mut a = full_vmm(VcpuState::default(), mutate_exits(), 500, 1);
        step_n(&mut a, 6);
        let mut s = a.save_vm_state().unwrap();
        s.timers.entries.push(vm_state::TimerEntry {
            deadline_vns: 1000,
            seq: 0,
            token: 7,
            period_vns: 0,
        });
        s.timers.next_seq = 1;
        let mut b = full_vmm(VcpuState::default(), vec![], 100, 1);
        assert!(matches!(
            b.restore_vm_state(&s),
            Err(VmmError::ContractViolation(_))
        ));
    }

    #[test]
    fn cpu_snapshot_preserves_pae_and_debug_flags_without_guest_execution() {
        for fields in 1..8 {
            let mut cpu = nonzero_state();
            if fields & 1 != 0 {
                cpu.sregs.flags = 1;
            }
            if fields & 2 != 0 {
                cpu.sregs.pdptrs = [0x1001, 0x2001, 0x3001, 0x4001];
            }
            if fields & 4 != 0 {
                cpu.debugregs.flags = 1;
            }
            let exits = vec![
                Exit::Arch(X86Exit::Io {
                    port: 0x3f8,
                    size: 1,
                    write: Some(0x58),
                }),
                Exit::Arch(X86Exit::Rdmsr { index: 0x10 }),
            ];
            let mut source = full_vmm(cpu.clone(), exits.clone(), 0, 7);
            source.wire_snapshot_hashing();
            let before_hash = source.state_hash().unwrap();
            let before_counts = source.exit_counts();
            let saved = source.save_vm_state().unwrap();
            let bytes = saved.encode().unwrap();
            let decoded = vm_state::VmState::decode(&bytes).unwrap();
            assert_eq!(source.state_hash().unwrap(), before_hash);
            assert_eq!(source.exit_counts(), before_counts);
            assert_eq!(source.effective_vns(), Some(0));
            assert_eq!(decoded.sregs.flags, cpu.sregs.flags);
            assert_eq!(decoded.sregs.pdptrs, cpu.sregs.pdptrs);
            assert_eq!(decoded.debugregs.flags, cpu.debugregs.flags);

            let mut cold = full_vmm(VcpuState::default(), exits, 0, 7);
            cold.wire_snapshot_hashing();
            cold.restore_snapshot(source.guest_memory(), &decoded)
                .unwrap();
            assert_eq!(cold.state_hash().unwrap(), before_hash);
            assert_eq!(cold.save_vm_state().unwrap().encode().unwrap(), bytes);
            for _ in 0..2 {
                assert_eq!(source.step().unwrap(), cold.step().unwrap());
                assert_eq!(source.state_hash().unwrap(), cold.state_hash().unwrap());
                assert_eq!(source.effective_vns(), cold.effective_vns());
            }
            assert_eq!(source.serial_output(), cold.serial_output());
            assert_eq!(
                source.save_vm_state().unwrap().encode().unwrap(),
                cold.save_vm_state().unwrap().encode().unwrap()
            );
        }
    }

    #[test]
    #[cfg_attr(
        miri,
        ignore = "sha256-dominated (each state_hash/state_blob over the TEST_RAM image interprets ~2 s/KiB under Miri and this test hashes repeatedly); pure safe code over the mock backend — no map_memory on this path (both seams stay Miri-run in bringup); logic covered natively, and the family keeps Miri-run siblings"
    )]
    fn save_vm_state_captures_in_flight_events_at_a_non_quiescent_point() {
        let in_flight = |events: vmm_backend::VcpuEvents, name: &str| {
            let mut st = nonzero_state();
            st.events = events;
            let mut a = full_vmm(st, vec![], 0, 1);
            let s = a
                .save_vm_state()
                .unwrap_or_else(|e| panic!("{name}: an in-flight point must snapshot, got {e:?}"));
            let want = snapshot::canonical_events(&events);
            let dev = snapshot::decode_device_blob(&s.devices.0).unwrap();
            assert_eq!(
                dev.events, want,
                "{name}: canonical kvm_vcpu_events captured"
            );
            let mut b = full_vmm(VcpuState::default(), vec![], 0, 1);
            b.restore_vm_state(&s)
                .expect("restore the in-flight snapshot");
            assert_eq!(
                b.backend.save().unwrap().events,
                snapshot::events_for_restore(&events),
                "{name}: restore re-establishes the in-flight events (restore form) on the backend"
            );
        };
        in_flight(
            vmm_backend::VcpuEvents {
                nmi_masked: 1,
                ..Default::default()
            },
            "nmi_masked",
        );
        in_flight(
            vmm_backend::VcpuEvents {
                interrupt_injected: 1,
                interrupt_nr: 0x34,
                ..Default::default()
            },
            "interrupt_injected",
        );
        in_flight(
            vmm_backend::VcpuEvents {
                exception_injected: 1,
                exception_nr: 14,
                exception_has_error_code: 1,
                exception_error_code: 0xCAFE,
                ..Default::default()
            },
            "exception_error_code",
        );
        let rejects = |events: vmm_backend::VcpuEvents, needle: &str| {
            let mut st = nonzero_state();
            st.events = events;
            let mut v = full_vmm(st, vec![], 0, 1);
            match v.save_vm_state() {
                Err(VmmError::ContractViolation(msg)) => assert!(
                    msg.contains(needle),
                    "reject reason should name {needle:?}, got: {msg}"
                ),
                other => {
                    panic!("a triple-fault event field must fail closed at save, got {other:?}")
                }
            }
        };
        rejects(
            vmm_backend::VcpuEvents {
                triple_fault_pending: 1,
                ..Default::default()
            },
            "triple_fault_pending",
        );
        let mut v_ok = full_vmm(nonzero_state(), vec![], 0, 1);
        assert!(
            v_ok.save_vm_state().is_ok(),
            "a quiescent point still snapshots"
        );
    }

    #[test]
    #[cfg_attr(
        miri,
        ignore = "sha256-dominated (each state_hash/state_blob over the TEST_RAM image interprets ~2 s/KiB under Miri and this test hashes repeatedly); pure safe code over the mock backend — no map_memory on this path (both seams stay Miri-run in bringup); logic covered natively, and the family keeps Miri-run siblings"
    )]
    fn save_vm_state_preserves_pending_exception_payload_through_fresh_restore() {
        let events = vmm_backend::VcpuEvents {
            exception_pending: 1,
            exception_nr: 14,
            exception_has_error_code: 1,
            exception_error_code: 0xCAFE,
            exception_has_payload: 1,
            exception_payload: 0x1234_5678_9ABC_DEF0,
            ..Default::default()
        };
        let mut source_state = nonzero_state();
        source_state.events = events;
        let mut source = full_vmm(source_state, vec![], 0, 1);
        source.wire_snapshot_hashing();

        let before_counts = source.exit_counts();
        let before_vns = source.effective_vns();
        let before_hash = source.state_hash().unwrap();
        let saved = source
            .save_vm_state()
            .expect("a payload-bearing pending exception is restorable");
        let bytes = <vm_state::VmState as SnapshotRecords>::encode(&saved)
            .expect("the payload snapshot encodes");
        let decoded = <vm_state::VmState as SnapshotRecords>::decode(&bytes)
            .expect("the payload snapshot decodes");
        assert_eq!(decoded, saved, "trait codec preserves the full snapshot");
        let dev = snapshot::decode_device_blob(&decoded.devices.0)
            .expect("the decoded device blob carries events");
        assert_eq!(
            dev.events,
            snapshot::canonical_events(&events),
            "the pending exception vector/error code/payload are serialized canonically"
        );

        assert_eq!(source.exit_counts(), before_counts);
        assert_eq!(source.effective_vns(), before_vns);
        assert_eq!(source.state_hash().unwrap(), before_hash);
        assert_eq!(
            <vm_state::VmState as SnapshotRecords>::encode(&source.save_vm_state().unwrap())
                .unwrap(),
            bytes,
            "repeated capture has stable VM bytes"
        );
        assert_eq!(source.state_hash().unwrap(), before_hash);

        let mut cold = full_vmm(VcpuState::default(), vec![], 9999, 1);
        cold.wire_snapshot_hashing();
        cold.restore_snapshot(source.guest_memory(), &decoded)
            .expect("fresh restore accepts the payload-bearing exception");
        assert_eq!(
            cold.backend.save().unwrap().events,
            snapshot::events_for_restore(&events),
            "fresh restore re-establishes the pending exception payload"
        );
        assert_eq!(cold.state_hash().unwrap(), before_hash);
        assert_eq!(
            <vm_state::VmState as SnapshotRecords>::encode(&cold.save_vm_state().unwrap()).unwrap(),
            bytes,
            "fresh restore re-encodes to the saved VM bytes"
        );
        assert_eq!(cold.exit_counts(), before_counts);
        assert_eq!(cold.effective_vns(), before_vns);
    }

    #[test]
    fn public_snapshot_path_accepts_last_exception_vector() {
        let cases = [
            (
                "pending",
                vmm_backend::VcpuEvents {
                    exception_pending: 1,
                    exception_nr: 31,
                    exception_has_error_code: 1,
                    exception_error_code: 0xCAFE,
                    ..Default::default()
                },
            ),
            (
                "injected",
                vmm_backend::VcpuEvents {
                    exception_injected: 1,
                    exception_nr: 31,
                    exception_has_error_code: 1,
                    exception_error_code: 0xBEEF,
                    ..Default::default()
                },
            ),
        ];

        for (name, events) in cases {
            let mut state = nonzero_state();
            state.events = events;
            let mut source = full_vmm(state, vec![], 0, 1);
            let saved = source
                .save_vm_state()
                .unwrap_or_else(|error| panic!("{name} vector 31 must save: {error:?}"));
            let bytes = <vm_state::VmState as SnapshotRecords>::encode(&saved)
                .unwrap_or_else(|error| panic!("{name} vector 31 must encode: {error:?}"));
            let decoded = <vm_state::VmState as SnapshotRecords>::decode(&bytes)
                .unwrap_or_else(|error| panic!("{name} vector 31 must decode: {error:?}"));
            let device = snapshot::decode_device_blob(&decoded.devices.0)
                .unwrap_or_else(|error| panic!("{name} device blob must decode: {error:?}"));
            assert_eq!(
                device.events.exception_nr, 31,
                "{name} vector survives codec"
            );
            assert_eq!(
                device.events.exception_pending, events.exception_pending,
                "{name} pending shape survives codec"
            );
            assert_eq!(
                device.events.exception_injected, events.exception_injected,
                "{name} injected shape survives codec"
            );

            let mut cold = full_vmm(VcpuState::default(), vec![], 0, 1);
            cold.restore_snapshot(source.guest_memory(), &decoded)
                .unwrap_or_else(|error| panic!("{name} vector 31 must restore: {error:?}"));
            assert_eq!(
                cold.backend.save().unwrap().events,
                snapshot::events_for_restore(&events),
                "{name} vector 31 survives fresh import"
            );
            assert_eq!(
                cold.save_vm_state().unwrap().encode().unwrap(),
                bytes,
                "{name} vector 31 re-encodes identically"
            );
        }
    }

    #[test]
    fn save_vm_state_rejects_invalid_active_exception_shapes() {
        let invalid = [
            (
                vmm_backend::VcpuEvents {
                    exception_injected: 1,
                    exception_pending: 1,
                    exception_nr: 14,
                    ..Default::default()
                },
                "exception_injected",
            ),
            (
                vmm_backend::VcpuEvents {
                    exception_pending: 1,
                    exception_nr: 2,
                    ..Default::default()
                },
                "vector 2",
            ),
            (
                vmm_backend::VcpuEvents {
                    exception_pending: 1,
                    exception_nr: 32,
                    ..Default::default()
                },
                "above 31",
            ),
            (
                vmm_backend::VcpuEvents {
                    exception_injected: 1,
                    exception_nr: 13,
                    exception_has_payload: 1,
                    exception_payload: 0xCAFE,
                    ..Default::default()
                },
                "exception_has_payload",
            ),
        ];
        for (events, needle) in invalid {
            let mut state = nonzero_state();
            state.events = events;
            let mut vmm = full_vmm(state, vec![], 0, 1);
            match vmm.save_vm_state() {
                Err(VmmError::ContractViolation(message)) => assert!(
                    message.contains(needle),
                    "save rejection should identify {needle:?}, got: {message}"
                ),
                other => panic!(
                    "save must reject invalid active exception shape {events:?}, got {other:?}"
                ),
            }
        }
    }

    #[test]
    fn restore_canonicalizes_raw_events_from_an_external_blob() {
        let mut a = full_vmm(nonzero_state(), vec![], 0, 1);
        let mut s = a.save_vm_state().expect("quiescent save");
        let raw = vmm_backend::VcpuEvents {
            interrupt_nr: 0x34,
            exception_nr: 13,
            exception_has_error_code: 1,
            flags: 0x0D,
            ..Default::default()
        };
        let mut dev = snapshot::decode_device_blob(&s.devices.0).unwrap();
        dev.events = raw;
        s.devices = snapshot::encode_device_blob(&dev);
        let mut b = full_vmm(VcpuState::default(), vec![], 0, 1);
        b.restore_vm_state(&s).expect("restore the external blob");
        let restored = b.backend.save().unwrap().events;
        assert_eq!(
            restored,
            snapshot::events_for_restore(&raw),
            "restore strips the residuals and forces the clear-on-restore validity bits"
        );
        assert_eq!(restored.interrupt_nr, 0, "stale interrupt.nr stripped");
        assert_eq!(restored.exception_nr, 0, "stale exception.nr stripped");
        assert_eq!(
            restored.exception_has_error_code, 0,
            "stale has_error_code stripped"
        );
        assert_ne!(
            restored, raw,
            "the raw residuals were NOT forwarded verbatim"
        );
    }

    #[test]
    #[cfg_attr(
        miri,
        ignore = "sha256-dominated (each state_hash/state_blob over the TEST_RAM image interprets ~2 s/KiB under Miri and this test hashes repeatedly); pure safe code over the mock backend — no map_memory on this path (both seams stay Miri-run in bringup); logic covered natively, and the family keeps Miri-run siblings"
    )]
    fn restore_vm_state_rejects_invalid_event_blobs_before_mutation() {
        let reject = |bad: vmm_backend::VcpuEvents, needle: &str| {
            let mut marked = nonzero_state();
            marked.events.interrupt_injected = 1;
            marked.events.interrupt_nr = 0x99;
            let mut b = full_vmm(marked, vec![], 0, 1);
            let before = b.backend.save().unwrap();
            let mut a = full_vmm(nonzero_state(), vec![], 0, 1);
            let mut s = a.save_vm_state().unwrap();
            let mut dev = snapshot::decode_device_blob(&s.devices.0).unwrap();
            dev.events = bad;
            s.devices = snapshot::encode_device_blob(&dev);
            match b.restore_vm_state(&s) {
                Err(VmmError::ContractViolation(msg)) => assert!(
                    msg.contains(needle),
                    "reject reason should name {needle:?}, got: {msg}"
                ),
                other => panic!("restore must reject an invalid event blob, got {other:?}"),
            }
            assert_eq!(
                b.backend.save().unwrap(),
                before,
                "restore must not mutate the target vCPU when it rejects the blob"
            );
        };
        reject(
            vmm_backend::VcpuEvents {
                triple_fault_pending: 1,
                ..Default::default()
            },
            "triple_fault_pending",
        );
        reject(
            vmm_backend::VcpuEvents {
                exception_injected: 1,
                exception_pending: 1,
                exception_nr: 14,
                ..Default::default()
            },
            "exception_injected",
        );
        reject(
            vmm_backend::VcpuEvents {
                exception_pending: 1,
                exception_nr: 2,
                ..Default::default()
            },
            "vector 2",
        );
        reject(
            vmm_backend::VcpuEvents {
                exception_pending: 1,
                exception_nr: 32,
                ..Default::default()
            },
            "above 31",
        );
        reject(
            vmm_backend::VcpuEvents {
                exception_injected: 1,
                exception_nr: 13,
                exception_has_payload: 1,
                exception_payload: 0xCAFE,
                ..Default::default()
            },
            "exception_has_payload",
        );
    }

    #[test]
    fn restore_vm_state_rejects_invalid_xsave_provenance_before_mutation() {
        let mut source = full_vmm(nonzero_state(), vec![], 0, 1);
        let mut snapshot = source.save_vm_state().unwrap();
        snapshot.xsave_restore_bv = Some(u64::MAX);

        let mut target_state = nonzero_state();
        target_state.regs.rax = 0xDEAD;
        target_state.regs.rbx = 0xBEEF;
        let mut target = full_vmm(target_state, vec![], 0, 9);
        let target_memory = vec![0x5A; 0x2000];
        target.restore_guest_memory(&target_memory).unwrap();
        let before = target.backend.save().unwrap();
        let before_blob = target.save_vm_state().unwrap().encode().unwrap();
        let before_vns = target.effective_vns();
        let source_memory = vec![0xA5; 0x2000];
        match target.restore_snapshot(&source_memory, &snapshot) {
            Err(VmmError::ContractViolation(message)) => {
                assert!(message.contains("XSAVE restore provenance"), "{message}")
            }
            other => panic!("malformed XSAVE provenance must be rejected, got {other:?}"),
        }
        assert_eq!(
            target.backend.save().unwrap(),
            before,
            "rejecting malformed XSAVE provenance must leave the target vCPU untouched"
        );
        assert!(
            target.guest_memory() == target_memory,
            "rejecting malformed XSAVE provenance must leave target RAM untouched"
        );
        assert_eq!(target.effective_vns(), before_vns);
        assert_eq!(
            target.save_vm_state().unwrap().encode().unwrap(),
            before_blob,
            "rejecting malformed XSAVE provenance must leave devices and V-time untouched"
        );
    }

    #[test]
    fn has_inflight_event_injection_reflects_the_live_vcpu() {
        let mut quiescent = full_vmm(nonzero_state(), vec![], 0, 1);
        assert!(
            !quiescent.has_inflight_event_injection().unwrap(),
            "a quiescent vCPU is not a non-quiescent point"
        );
        let mut st = nonzero_state();
        st.events.interrupt_injected = 1;
        st.events.interrupt_nr = 0x34;
        let mut in_flight = full_vmm(st, vec![], 0, 1);
        assert!(
            in_flight.has_inflight_event_injection().unwrap(),
            "an injected-but-undelivered interrupt is a non-quiescent point"
        );
    }

    #[test]
    fn has_active_event_injection_reflects_the_live_vcpu() {
        let mut quiescent = full_vmm(nonzero_state(), vec![], 0, 1);
        assert!(
            !quiescent.has_active_event_injection().unwrap(),
            "a quiescent vCPU carries no active event"
        );
        let mut residual = nonzero_state();
        residual.events.interrupt_nr = 0x34;
        let mut residual_vmm = full_vmm(residual, vec![], 0, 1);
        assert!(
            residual_vmm.has_inflight_event_injection().unwrap(),
            "an inert residual is still a would-reject point"
        );
        assert!(
            !residual_vmm.has_active_event_injection().unwrap(),
            "but an inert residual is NOT a genuine active injection — never seal here"
        );
        let mut st = nonzero_state();
        st.events.interrupt_injected = 1;
        st.events.interrupt_nr = 0x34;
        let mut in_flight = full_vmm(st, vec![], 0, 1);
        assert!(
            in_flight.has_active_event_injection().unwrap(),
            "an injected-but-undelivered interrupt is a genuine active injection"
        );
    }

    #[test]
    fn has_pending_guest_interrupt_reflects_a_pending_lapic_vector() {
        let mut q = lapic_vmm(configured_mock(vec![
            Exit::Arch(X86Exit::Rdmsr { index: 0x10 }),
            Exit::Common(CommonExit::Idle),
        ]));
        q.step().unwrap();
        assert!(
            !q.has_pending_guest_interrupt().unwrap(),
            "a quiescent LAPIC has no pending guest interrupt"
        );
        let mut exits = arm_timer_exits(1);
        exits.push(read_mmio(isr_gpa(0x20)));
        exits.push(Exit::Arch(X86Exit::Rdmsr { index: 0x10 }));
        let mut mock = configured_mock(exits);
        mock.set_defer_accept(true);
        let mut a = lapic_vmm(mock);
        step_n(&mut a, 5);
        assert_eq!(
            a.backend.pending_irq(),
            Some(0x40),
            "0x40 is in flight in the IRR (routed to the seam, not yet accepted)"
        );
        assert!(
            a.has_pending_guest_interrupt().unwrap(),
            "a vector pending in the LAPIC IRR is a genuine in-flight guest interrupt"
        );
    }

    #[test]
    fn snapshot_restore_re_derives_the_in_flight_lapic_irq() {
        let mut exits = arm_timer_exits(1);
        exits.push(read_mmio(isr_gpa(0x20)));
        exits.push(Exit::Arch(X86Exit::Rdmsr { index: 0x10 }));
        let mut mock = configured_mock(exits);
        mock.set_defer_accept(true);
        let mut a = lapic_vmm(mock);
        step_n(&mut a, 5);
        assert_eq!(
            a.backend.pending_irq(),
            Some(0x40),
            "the timer vector is in flight (routed to the seam, not yet accepted)"
        );

        let s = a
            .save_vm_state()
            .expect("a point with an in-flight LAPIC vector is snapshottable");
        let dev = snapshot::decode_device_blob(&s.devices.0).unwrap();
        let irr = dev.lapic.expect("lapic captured").irr;
        assert_eq!(irr[2] & 1, 1, "vector 0x40 is pending in the captured IRR");

        let mut bmock = configured_mock(vec![
            Exit::Arch(X86Exit::Rdmsr { index: 0x10 }),
            Exit::Common(CommonExit::Idle),
        ]);
        bmock.set_defer_accept(true);
        let mut b = lapic_vmm(bmock);
        b.restore_vm_state(&s)
            .expect("restore the in-flight LAPIC snapshot");
        b.step().unwrap();
        assert_eq!(
            b.backend.pending_irq(),
            Some(0x40),
            "the restored VM re-derives the in-flight vector from the LAPIC IRR (seam re-armed)"
        );
    }

    #[test]
    fn serial_input_survives_snapshot_continuation() {
        let read = Exit::Arch(X86Exit::Io {
            port: 0x3f8,
            size: 1,
            write: None,
        });
        let mut original = Vmm::new(
            configured_mock(vec![read.clone(), read.clone()]),
            GuestRam::new(4096).unwrap(),
        );
        original.inject_serial_input(b"ab");
        original.step().unwrap();
        let snapshot = original.save_vm_state().unwrap();
        let snapshot = vm_state::VmState::decode(&snapshot.encode().unwrap()).unwrap();
        let mut restored = Vmm::new(configured_mock(vec![read]), GuestRam::new(4096).unwrap());
        restored.inject_serial_input(b"stale");
        restored.restore_vm_state(&snapshot).unwrap();
        original.step().unwrap();
        restored.step().unwrap();
        assert_eq!(
            original.backend.completions().last(),
            Some(&Completion::Read(98))
        );
        assert_eq!(
            restored.backend.completions().last(),
            original.backend.completions().last()
        );
    }

    #[test]
    fn serial_input_is_part_of_state_identity() {
        for hashing in [false, true] {
            let mut v = Vmm::new(configured_mock(vec![]), GuestRam::new(4096).unwrap());
            if hashing {
                v.wire_snapshot_hashing();
            }
            let empty = v.state_hash().unwrap();
            v.inject_serial_input(b"pending");
            assert_ne!(empty, v.state_hash().unwrap());
        }
    }

    #[test]
    fn arm64_serial_input_survives_snapshot_continuation() {
        use vmm_backend::{Arm64MockCompletion, Arm64Policy, MockArm64Backend};
        let read = Exit::Common(CommonExit::Mmio {
            gpa: Gpa(crate::vendor::arm64::board::PL011.0),
            size: 4,
            write: None,
        });
        let make = |exits| {
            let mut backend = MockArm64Backend::with_exits(exits);
            backend.set_policy(&Arm64Policy::default()).unwrap();
            Vmm::new(backend, GuestRam::new(4096).unwrap())
        };
        let write = Exit::Common(CommonExit::Mmio {
            gpa: Gpa(crate::vendor::arm64::board::PL011.0),
            size: 4,
            write: Some(120),
        });
        let mut original = make(vec![read.clone(), write, read.clone()]);
        original.inject_serial_input(b"ab");
        original.step().unwrap();
        original.step().unwrap();
        let snapshot = original.save_vm_state().unwrap();
        let snapshot = vm_state::Arm64VmState::decode(&snapshot.encode().unwrap()).unwrap();
        let mut restored = make(vec![read]);
        restored.inject_serial_input(b"stale");
        restored.restore_vm_state(&snapshot).unwrap();
        original.step().unwrap();
        restored.step().unwrap();
        assert_eq!(
            original.backend.completions().last(),
            Some(&Arm64MockCompletion::Read(98))
        );
        assert_eq!(
            restored.backend.completions().last(),
            original.backend.completions().last()
        );
    }

    #[test]
    fn arm64_serial_input_is_part_of_state_identity() {
        use vmm_backend::{Arm64Policy, MockArm64Backend};
        for hashing in [false, true] {
            let mut backend = MockArm64Backend::new();
            backend.set_policy(&Arm64Policy::default()).unwrap();
            let mut v = Vmm::new(backend, GuestRam::new(4096).unwrap());
            if hashing {
                v.wire_snapshot_hashing();
            }
            let empty = v.state_hash().unwrap();
            v.inject_serial_input(b"pending");
            assert_ne!(empty, v.state_hash().unwrap());
        }
    }

    #[test]
    fn uart_divisor_high_byte_is_part_of_state_identity() {
        for hashing in [false, true] {
            let mut v = Vmm::new(configured_mock(vec![]), GuestRam::new(4096).unwrap());
            if hashing {
                v.wire_snapshot_hashing();
            }
            v.devices.uart.write(0x3fb, 0x80);
            let before = v.state_hash().unwrap();
            v.devices.uart.write(0x3f9, 7);
            assert_eq!(v.devices.uart.read(0x3f9), Some(7));
            assert_ne!(before, v.state_hash().unwrap());
        }
    }

    #[test]
    fn save_vm_state_captures_the_uart_dlm() {
        let mut v = full_vmm(
            VcpuState::default(),
            vec![
                Exit::Arch(X86Exit::Io {
                    port: 0x3FB,
                    size: 1,
                    write: Some(0x80),
                }),
                Exit::Arch(X86Exit::Io {
                    port: 0x3F9,
                    size: 1,
                    write: Some(0x07),
                }),
                Exit::Arch(X86Exit::Rdmsr { index: 0x10 }),
            ],
            0,
            1,
        );
        step_n(&mut v, 3);
        let s = v.save_vm_state().unwrap();
        let dev = snapshot::decode_device_blob(&s.devices.0).unwrap();
        assert_eq!(dev.uart.dlm, 7, "save_vm_state must capture the UART DLM");
        assert!(dev.uart.dlab, "and the latched DLAB window state");
    }

    #[test]
    fn restore_guest_memory_overwrites_the_backing_and_checks_length() {
        let mut v = Vmm::new(configured_mock(vec![]), GuestRam::new(0x2000).unwrap());
        let image = vec![0xABu8; 0x2000];
        v.restore_guest_memory(&image).unwrap();
        assert_eq!(v.guest_memory(), &image[..]);
        assert!(matches!(
            v.restore_guest_memory(&[0u8; 0x1000]),
            Err(VmmError::ContractViolation(_))
        ));
    }

    fn has_tag(blob: &[u8], tag: &[u8; 4]) -> bool {
        blob.windows(4).any(|w| w == tag)
    }

    #[test]
    fn snapshot_hashing_is_disabled_by_default() {
        let mut v = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        assert!(!v.snapshot_hashing_wired());
        assert!(!has_tag(&v.state_blob().unwrap(), b"VMST"));
        let mut v2 = Vmm::new(configured_mock(vec![]), GuestRam::new(0x1000).unwrap());
        assert_eq!(v.state_hash().unwrap(), v2.state_hash().unwrap());
    }

    #[test]
    #[cfg_attr(
        miri,
        ignore = "sha256-dominated (each state_hash/state_blob over the TEST_RAM image interprets ~2 s/KiB under Miri and this test hashes repeatedly); pure safe code over the mock backend — no map_memory on this path (both seams stay Miri-run in bringup); logic covered natively, and the family keeps Miri-run siblings"
    )]
    fn wiring_snapshot_hashing_folds_the_canonical_blob_into_the_hash() {
        let mut base = full_vmm(VcpuState::default(), vec![], 0, 1);
        let base_hash_unwired = base.state_hash().unwrap();

        let mut on = full_vmm(VcpuState::default(), vec![], 0, 1);
        on.wire_snapshot_hashing();
        assert!(on.snapshot_hashing_wired());
        assert!(has_tag(&on.state_blob().unwrap(), b"VMST"));
        assert_ne!(
            on.state_hash().unwrap(),
            base_hash_unwired,
            "folding the canonical blob changes the hash"
        );

        let mut a = full_vmm(VcpuState::default(), vec![], 0, 1);
        a.wire_snapshot_hashing();
        let mut b = full_vmm(
            VcpuState::default(),
            vec![Exit::Common(CommonExit::Mmio {
                gpa: Gpa(0xFEE0_0080),
                size: 4,
                write: Some(0x30),
            })],
            0,
            1,
        );
        b.wire_snapshot_hashing();
        b.step().unwrap();
        assert_ne!(
            a.state_hash().unwrap(),
            b.state_hash().unwrap(),
            "a vm_state difference reaches state_hash when snapshot-hashing is wired"
        );
    }

    use vtime::pvclock::PVCLOCK_PAGE_LEN;

    fn pvclock_vmm(exits: Vec<Exit<X86>>, seed: u64) -> Vmm<MockBackend> {
        let mut vmm = Vmm::new(configured_mock(exits), GuestRam::new(TEST_RAM).unwrap());
        vmm.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), seed).unwrap());
        vmm.enable_pvclock();
        vmm
    }

    fn ring_pvclock_register(vmm: &mut Vmm<MockBackend>, gpa: u64) -> (u16, Vec<u8>) {
        let mut frame = [0_u8; 64];
        let len = hypercall_proto::encode_request(
            ServiceId::Pvclock,
            1,
            1,
            &gpa.to_le_bytes(),
            &mut frame,
        )
        .expect("encode register request");
        vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + len].copy_from_slice(&frame[..len]);
        assert_eq!(
            vmm.service_doorbell(len as u32).expect("doorbell serviced"),
            Step::Continued
        );
        let resp = &vmm.ram.as_bytes()[RESP_GPA..RESP_GPA + HC_PAGE];
        let (header, payload) = decode(resp).expect("well-formed response frame");
        (header.status, payload.to_vec())
    }

    const PV_GPA: u64 = 0x4000;

    #[test]
    fn pvclock_gpa_helpers_resolve_a_high_ram_base() {
        let mut vmm = pvclock_vmm(vec![], 7);
        vmm.ram_base_gpa = 0x4000_0000;

        let high = 0x4000_0000 + PV_GPA;
        assert!(
            vmm.pvclock_validate_gpa(high).is_ok(),
            "a high arm64 pvclock GPA must validate: {:?}",
            vmm.pvclock_validate_gpa(high)
        );
        assert_eq!(
            vmm.pvclock_validate_gpa(0x1000),
            Err("below the guest RAM base")
        );

        assert_eq!(vmm.pvclock_register(high).0 as u16, Status::Ok as u16);
        assert_eq!(vmm.pvclock_registration(), Some(high));
        assert!(
            vmm.pvclock_page().is_some(),
            "pvclock_page must resolve the high GPA"
        );

        let x86 = pvclock_vmm(vec![], 7);
        assert!(x86.pvclock_validate_gpa(PV_GPA).is_ok());
    }

    #[test]
    fn pvclock_registration_rejects_bad_gpas() {
        for bad in [
            PV_GPA + 1,
            TEST_RAM as u64,
            u64::MAX - 4095,
            REQ_GPA as u64,
            RESP_GPA as u64,
        ] {
            let mut vmm = pvclock_vmm(vec![], 7);
            let (status, payload) = ring_pvclock_register(&mut vmm, bad);
            assert_eq!(status, Status::OutOfRange as u16, "gpa {bad:#x}");
            assert!(payload.is_empty());
            assert_eq!(vmm.pvclock_registration(), None, "gpa {bad:#x} recorded");
        }
    }

    #[test]
    #[cfg_attr(
        miri,
        ignore = "4 GiB guest RAM image — lazy mmap, but not for the interpreter"
    )]
    fn pvclock_registration_rejects_the_lapic_mmio_hole() {
        const LAPIC_HOLE: u64 = 0xFEE0_0000;
        let ram_len = (LAPIC_HOLE + 0x2000) as usize;
        let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(ram_len).unwrap());
        vmm.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 7).unwrap());
        vmm.enable_pvclock();
        let (status, _) = ring_pvclock_register(&mut vmm, LAPIC_HOLE);
        assert_eq!(
            status,
            Status::OutOfRange as u16,
            "the xAPIC MMIO page was accepted as a clock page — the host would stamp backing \
             the guest cannot read, and the guest would read the LAPIC instead of its clock"
        );
        assert_eq!(vmm.pvclock_registration(), None);
        let (status, _) = ring_pvclock_register(&mut vmm, LAPIC_HOLE + 0x1000);
        assert_eq!(status, Status::Ok as u16);
        assert_eq!(vmm.pvclock_registration(), Some(LAPIC_HOLE + 0x1000));
    }

    #[test]
    fn pvclock_unavailable_answers_unknown_service_before_classifying() {
        let mut m = MockBackend::new();
        m.set_policy(&X86Policy {
            cpuid: CpuidModel::default(),
            msr_filter: MsrFilter::default(),
        })
        .unwrap();
        let mut vmm = Vmm::new(m, GuestRam::new(TEST_RAM).unwrap());
        vmm.enable_pvclock();
        assert!(!vmm.pvclock_available());

        let ring_raw = |vmm: &mut Vmm<MockBackend>, opcode: u32, payload: &[u8]| -> u16 {
            let mut frame = [0_u8; 64];
            let len =
                hypercall_proto::encode_request(ServiceId::Pvclock, 1, opcode, payload, &mut frame)
                    .expect("encode");
            vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + len].copy_from_slice(&frame[..len]);
            vmm.service_doorbell(len as u32).expect("doorbell");
            let resp = &vmm.ram.as_bytes()[RESP_GPA..RESP_GPA + HC_PAGE];
            decode(resp).expect("well-formed response frame").0.status
        };
        assert_eq!(
            ring_raw(&mut vmm, 1, &PV_GPA.to_le_bytes()),
            Status::UnknownService as u16
        );
        assert_eq!(
            ring_raw(&mut vmm, 1, &[0u8; 3]),
            Status::UnknownService as u16,
            "a malformed payload was graded BadRequest on a service that is not offered"
        );
        assert_eq!(
            ring_raw(&mut vmm, 9, &[]),
            Status::UnknownService as u16,
            "a bad opcode was graded UnknownOpcode on a service that is not offered"
        );
        assert_eq!(vmm.pvclock_registration(), None);
    }

    #[test]
    fn pvclock_channel_configuration_reaches_state_identity() {
        let build = || {
            let mut vmm = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
            vmm.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 7).unwrap());
            vmm.enable_pvclock();
            vmm
        };
        let base = build().state_blob().unwrap();
        assert_eq!(
            base,
            build().state_blob().unwrap(),
            "same configuration must hash identically"
        );
        let mut registered = build();
        let (status, _) = ring_pvclock_register(&mut registered, PV_GPA);
        assert_eq!(status, Status::Ok as u16);
        let pending = registered.state_blob().unwrap();
        assert_ne!(
            base, pending,
            "a registration is a different future — must reach the hash"
        );
        registered.pvclock.as_mut().unwrap().armed = true;
        assert_ne!(
            pending,
            registered.state_blob().unwrap(),
            "pending vs armed is a different future — the handshake bit must reach the hash"
        );
    }

    #[test]
    fn pvclock_snapshot_and_restore_preserve_pending_registration_state() {
        let mut source = pvclock_vmm(vec![], 7);
        assert_eq!(
            ring_pvclock_register(&mut source, PV_GPA).0,
            Status::Ok as u16
        );
        let expected = PvclockSnapshot {
            gpa: Some(PV_GPA),
            registrable: true,
            armed: false,
        };
        assert_eq!(source.pvclock_snapshot(), Some(expected));

        let state = <X86 as crate::vendor::Vendor>::build_vm_state(&source, &VcpuState::default());
        let decoded = snapshot::decode_device_blob(&state.devices.0).unwrap();
        assert_eq!(decoded.pvclock, Some(expected));

        let mut target = pvclock_vmm(vec![], 7);
        target
            .pvclock_validate_restore(decoded.pvclock.as_ref())
            .unwrap();
        target.pvclock_commit_restore(decoded.pvclock.as_ref());
        assert_eq!(target.pvclock_snapshot(), Some(expected));
    }

    #[test]
    fn pvclock_decode_rejects_registered_but_non_registrable() {
        use crate::vendor::x86::records::{DeviceState, encode_device_blob};
        let good = DeviceState {
            pvclock: Some(crate::vmm::PvclockSnapshot {
                gpa: Some(PV_GPA),
                registrable: true,
                armed: false,
            }),
            ..DeviceState::default()
        };
        let mut blob = encode_device_blob(&good).0;
        assert_eq!(
            blob[blob.len() - 6],
            1,
            "the registrable byte precedes armed"
        );
        let registrable_index = blob.len() - 6;
        blob[registrable_index] = 0;
        assert!(
            crate::vendor::x86::records::decode_device_blob(&blob).is_err(),
            "a registered-but-non-registrable v5 record must be rejected at the wire"
        );
    }

    #[test]
    fn pvclock_natural_exits_refresh_with_the_anchor_value() {
        let mut vmm = pvclock_vmm(
            vec![
                Exit::Arch(X86Exit::Rdmsr { index: 0x10 }),
                Exit::Arch(X86Exit::Io {
                    port: 0x3F8,
                    size: 1,
                    write: Some(u32::from(b'x')),
                }),
            ],
            7,
        );
        ring_pvclock_register(&mut vmm, PV_GPA);
        vmm.step().unwrap();
        let stamped = vtime::pvclock::read(vmm.pvclock_page().unwrap()).unwrap();
        let off = PV_GPA as usize + vtime::pvclock::VNS_OFF;
        vmm.ram.as_mut_bytes()[off] ^= 0xA5;
        assert!(vmm.pvclock_check_oracle().is_err(), "scribble visible");
        vmm.step().unwrap();
        let repaired = vtime::pvclock::read(vmm.pvclock_page().unwrap()).unwrap();
        assert!(repaired.vns > stamped.vns);
        vmm.pvclock_check_oracle()
            .expect("the natural-exit refresh restored oracle equality");
    }

    #[test]
    fn pvclock_seal_never_touches_the_live_page() {
        let mut vmm = pvclock_vmm(
            vec![
                Exit::Arch(X86Exit::Rdmsr { index: 0x10 }),
                Exit::Arch(X86Exit::Wrmsr {
                    index: IA32_TSC_ADJUST,
                    value: 5,
                }),
            ],
            7,
        );
        ring_pvclock_register(&mut vmm, PV_GPA);
        vmm.step().unwrap();
        vmm.step().unwrap();
        vmm.host_dirty.clear();
        let page_before = vmm.pvclock_page().unwrap().to_vec();
        assert_ne!(
            vtime::pvclock::read(&page_before).unwrap().seq,
            0,
            "precondition: the live page is non-canonical"
        );
        let refreshes_before = vmm.pvclock_refreshes().to_vec();
        vmm.retire_pending_completion().unwrap();
        let mut bad = vmm.backend.save().unwrap();
        bad.events.triple_fault_pending = 1;
        vmm.backend.restore(&bad).unwrap();
        vmm.saved_state = None;
        assert!(
            matches!(vmm.save_vm_state(), Err(VmmError::ContractViolation(_))),
            "the unsealable vCPU must reject the seal"
        );
        assert_eq!(
            vmm.pvclock_page().unwrap(),
            page_before.as_slice(),
            "a rejected seal canonicalized the page (reject-before-mutation broken)"
        );
        assert_eq!(vmm.pvclock_refreshes(), refreshes_before.as_slice());
        assert!(
            vmm.host_dirty.is_empty(),
            "a rejected seal marked host-dirty state"
        );
        bad.events.triple_fault_pending = 0;
        vmm.backend.restore(&bad).unwrap();
        vmm.save_vm_state().unwrap();
        assert_eq!(
            vmm.pvclock_page().unwrap(),
            page_before.as_slice(),
            "a successful seal rewrote the live page — the ABA the r4 P1 rules out"
        );
        assert!(
            vmm.host_dirty.is_empty(),
            "a seal marked host-dirty state — it wrote to guest RAM"
        );
    }

    #[test]
    fn pvclock_refresh_tracks_the_trap_oracle_through_intercepts() {
        let mut vmm = pvclock_vmm(
            vec![
                Exit::Arch(X86Exit::Rdmsr { index: 0x10 }),
                Exit::Arch(X86Exit::Wrmsr {
                    index: IA32_TSC_ADJUST,
                    value: 5,
                }),
                Exit::Arch(X86Exit::Rdmsr { index: 0x10 }),
            ],
            7,
        );
        let (status, _) = ring_pvclock_register(&mut vmm, PV_GPA);
        assert_eq!(status, Status::Ok as u16);

        assert_eq!(vmm.step().unwrap(), Step::Continued);
        let f = vtime::pvclock::read(vmm.pvclock_page().unwrap()).unwrap();
        assert_eq!((f.vns, f.guest_clock), (1, 2));
        let trap_value = match vmm.backend.completions().last().unwrap() {
            Completion::Read(v) => *v,
            other => panic!("RDTSC completes as a read, got {other:?}"),
        };
        assert_eq!(f.guest_clock, trap_value, "page == what the trap returned");
        vmm.pvclock_check_oracle().unwrap();

        assert_eq!(vmm.step().unwrap(), Step::Continued);
        let f = vtime::pvclock::read(vmm.pvclock_page().unwrap()).unwrap();
        assert_eq!(f.guest_clock, 9, "guest_clock = ticks(2) + adjust 5");
        vmm.pvclock_check_oracle().unwrap();

        let seq_before = f.seq;
        assert_eq!(vmm.step().unwrap(), Step::Continued);
        let f = vtime::pvclock::read(vmm.pvclock_page().unwrap()).unwrap();
        assert_eq!(f.guest_clock, 11);
        assert_ne!(f.seq, seq_before);

        assert_eq!(vmm.pvclock_refreshes(), &[(2, 9), (3, 11)]);
        vmm.pvclock_clear_refreshes();
        assert!(vmm.pvclock_refreshes().is_empty());
    }

    #[test]
    fn pvclock_oracle_check_fails_on_a_corrupted_page() {
        let mut vmm = pvclock_vmm(vec![Exit::Arch(X86Exit::Rdmsr { index: 0x10 })], 7);
        ring_pvclock_register(&mut vmm, PV_GPA);
        vmm.step().unwrap();
        vmm.pvclock_check_oracle().expect("clean page passes");
        let off = PV_GPA as usize + vtime::pvclock::GUEST_CLOCK_OFF;
        vmm.ram.as_mut_bytes()[off] ^= 0xFF;
        assert!(
            matches!(
                vmm.pvclock_check_oracle(),
                Err(VmmError::ContractViolation(_))
            ),
            "a diverged page must fail the G2 check"
        );
        vmm.ram.as_mut_bytes()[off] ^= 0xFF;
        vmm.pvclock_check_oracle()
            .expect("repaired page passes again");
        vmm.vtime.as_mut().unwrap().advance_virtual_time(999);
        assert!(
            matches!(
                vmm.pvclock_check_oracle(),
                Err(VmmError::ContractViolation(_))
            ),
            "a frozen page must fail once the clock has moved on"
        );
    }

    #[test]
    fn restore_vtime_restamps_the_armed_page_to_the_restored_timeline() {
        const SEED: u64 = 7;
        let mut a = pvclock_vmm(vec![Exit::Arch(X86Exit::Rdmsr { index: 0x10 })], SEED);
        a.vtime.as_mut().unwrap().advance_virtual_time(999);
        ring_pvclock_register(&mut a, PV_GPA);
        a.step().unwrap();
        let ahead = vtime::pvclock::read(a.pvclock_page().unwrap()).unwrap();
        assert_eq!(
            (ahead.seq, ahead.vns),
            (0, 1000),
            "armed at the large anchor"
        );

        let snap = VtimeSnapshot {
            vns: 42,
            guest_clock_offset: 0,
            entropy: SeededEntropy::new(SEED).save_state(),
        };
        a.restore_vtime(&snap).unwrap();

        let after = vtime::pvclock::read(a.pvclock_page().unwrap()).unwrap();
        assert_eq!(
            after.vns, 42,
            "restore_vtime must re-stamp the armed page to the restored anchor"
        );
        assert!(
            after.vns < ahead.vns,
            "the page moved BACK to the restored time"
        );
        assert_ne!(
            after.seq, ahead.seq,
            "the seqlock epoch must advance across a live-page restore (ABA-safety)"
        );
        assert_ne!(
            after.seq, 0,
            "a LIVE re-stamp must use the epoch-advancing refresh, not canonical seq=0"
        );
        a.pvclock_check_oracle()
            .expect("re-stamped page matches the restored-clock oracle");
    }

    #[test]
    fn restore_vtime_leaves_a_pending_registration_unstamped() {
        let mut v = pvclock_vmm(vec![], 7);
        ring_pvclock_register(&mut v, PV_GPA);
        assert!(
            vtime::pvclock::read(v.pvclock_page().unwrap()).is_none(),
            "pending registration is un-stamped before restore"
        );
        let snap = VtimeSnapshot {
            vns: 42,
            guest_clock_offset: 0,
            entropy: SeededEntropy::new(7).save_state(),
        };
        v.restore_vtime(&snap).unwrap();
        assert!(
            vtime::pvclock::read(v.pvclock_page().unwrap()).is_none(),
            "restore_vtime must not stamp a pending (un-armed) registration"
        );
    }

    #[test]
    fn save_vm_state_preserves_pending_pvclock_for_the_next_handshake() {
        const SEED: u64 = 7;
        let expected = PvclockSnapshot {
            gpa: Some(PV_GPA),
            registrable: true,
            armed: false,
        };
        let pending = || {
            let mut v = pvclock_vmm(vec![Exit::Arch(X86Exit::Rdmsr { index: 0x10 })], SEED);
            assert_eq!(ring_pvclock_register(&mut v, PV_GPA).0, Status::Ok as u16);
            v.restore_vtime(&VtimeSnapshot {
                vns: 42,
                guest_clock_offset: 0,
                entropy: SeededEntropy::new(SEED).save_state(),
            })
            .unwrap();
            assert_eq!(v.effective_vns(), Some(42));
            assert_eq!(v.pvclock_snapshot(), Some(expected));
            assert!(
                vtime::pvclock::read(v.pvclock_page().unwrap()).is_none(),
                "the pending page is still unstamped"
            );
            v
        };

        let mut uninterrupted = pending();
        let mut save_continue = pending();
        let before_counts = save_continue.exit_counts();
        let before_time = save_continue.effective_vns();
        let before_page = save_continue.pvclock_page().unwrap().to_vec();
        let before_memory = save_continue.guest_memory().to_vec();
        let before_refreshes = save_continue.pvclock_refreshes().to_vec();

        let saved = save_continue
            .save_vm_state()
            .expect("a pending pvclock registration is representable");
        let saved = vm_state::VmState::decode(&saved.encode().unwrap()).unwrap();
        assert_eq!(save_continue.exit_counts(), before_counts);
        assert_eq!(save_continue.effective_vns(), before_time);
        assert_eq!(
            save_continue.pvclock_page().unwrap(),
            before_page.as_slice()
        );
        assert_eq!(save_continue.guest_memory(), before_memory.as_slice());
        assert_eq!(
            save_continue.pvclock_refreshes(),
            before_refreshes.as_slice()
        );
        assert_eq!(save_continue.pvclock_snapshot(), Some(expected));

        let decoded = snapshot::decode_device_blob(&saved.devices.0).unwrap();
        assert_eq!(decoded.pvclock, Some(expected));

        let mut cold = pvclock_vmm(vec![Exit::Arch(X86Exit::Rdmsr { index: 0x10 })], SEED);
        cold.restore_snapshot(&before_memory, &saved)
            .expect("cold restore preserves the pending registration");
        assert_eq!(cold.effective_vns(), before_time);
        assert_eq!(cold.pvclock_snapshot(), Some(expected));
        assert_eq!(cold.pvclock_page().unwrap(), before_page.as_slice());
        assert!(
            vtime::pvclock::read(cold.pvclock_page().unwrap()).is_none(),
            "restore must not stamp a pending page"
        );

        let handshake = |v: &mut Vmm<MockBackend>| {
            assert_eq!(v.step().unwrap(), Step::Continued);
            assert_eq!(
                v.pvclock_snapshot().map(|snapshot| snapshot.armed),
                Some(true)
            );
            let page = v.pvclock_page().unwrap().to_vec();
            assert!(
                vtime::pvclock::read(&page).is_some(),
                "the post-doorbell time read must arm and stamp the page"
            );
            let completions = v.backend.completions().to_vec();
            assert!(
                matches!(completions.as_slice(), [Completion::Read(_)]),
                "the handshake must service one read completion"
            );
            (
                v.effective_vns(),
                v.exit_counts(),
                completions,
                v.pvclock_snapshot(),
                page,
                v.guest_memory().to_vec(),
                v.save_vm_state().unwrap().encode().unwrap(),
                v.state_hash().unwrap(),
            )
        };

        let expected_after = handshake(&mut uninterrupted);
        assert_eq!(handshake(&mut save_continue), expected_after);
        assert_eq!(handshake(&mut cold), expected_after);
    }

    #[test]
    fn pvclock_seal_is_verbatim_and_restore_carries_the_registration() {
        let mut a = pvclock_vmm(
            vec![
                Exit::Arch(X86Exit::Rdmsr { index: 0x10 }),
                Exit::Arch(X86Exit::Wrmsr {
                    index: IA32_TSC_ADJUST,
                    value: 5,
                }),
            ],
            7,
        );
        ring_pvclock_register(&mut a, PV_GPA);
        a.step().unwrap();
        a.step().unwrap();
        let live = vtime::pvclock::read(a.pvclock_page().unwrap()).unwrap();
        assert_ne!(live.seq, 0, "a mid-run refresh bumped the epoch");
        let page_before_seal = a.pvclock_page().unwrap().to_vec();
        let vm_state = a.save_vm_state().unwrap();
        let image = a.guest_memory().to_vec();
        assert_eq!(
            a.pvclock_page().unwrap(),
            page_before_seal.as_slice(),
            "the seal rewrote the live page"
        );
        assert_eq!(
            &image[PV_GPA as usize..PV_GPA as usize + PVCLOCK_PAGE_LEN],
            page_before_seal.as_slice(),
            "the sealed image must reproduce live guest memory, page included"
        );
        let sealed = vtime::pvclock::read(&image[PV_GPA as usize..]).unwrap();
        assert_eq!(
            (sealed.seq, sealed.vns, sealed.guest_clock),
            (live.seq, live.vns, live.guest_clock),
            "the sealed page carries the live epoch and values verbatim"
        );

        let mut b = pvclock_vmm(vec![Exit::Arch(X86Exit::Rdmsr { index: 0x10 })], 7);
        ring_pvclock_register(&mut b, PV_GPA + 0x1000);
        b.restore_snapshot(&image, &vm_state).unwrap();
        assert_eq!(
            b.pvclock_registration(),
            Some(PV_GPA),
            "the blob's sealed registration is authoritative after a direct restore"
        );
        assert_eq!(
            &b.guest_memory()[PV_GPA as usize..PV_GPA as usize + PVCLOCK_PAGE_LEN],
            &image[PV_GPA as usize..PV_GPA as usize + PVCLOCK_PAGE_LEN],
        );
        b.pvclock_check_oracle().unwrap();
    }

    #[test]
    fn pvclock_restore_mismatch_fails_loud() {
        let seal = |register: bool| {
            let mut src = pvclock_vmm(vec![Exit::Arch(X86Exit::Rdmsr { index: 0x10 })], 7);
            if register {
                ring_pvclock_register(&mut src, PV_GPA);
            }
            src.step().unwrap();
            src.save_vm_state().unwrap()
        };
        let registered_state = seal(true);
        let offered_unregistered_state = seal(false);
        let unoffered_state = {
            let mut src = vtime_vmm(vec![Exit::Arch(X86Exit::Rdmsr { index: 0x10 })], 7);
            let _ = &mut src;
            let mut src = Vmm::new(
                configured_mock(vec![Exit::Arch(X86Exit::Rdmsr { index: 0x10 })]),
                GuestRam::new(TEST_RAM).unwrap(),
            );
            src.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 7).unwrap());
            src.step().unwrap();
            src.save_vm_state().unwrap()
        };
        let reject = |vmm: &mut Vmm<MockBackend>, s: &vm_state::VmState, why: &str| {
            assert!(
                matches!(vmm.restore_vm_state(s), Err(VmmError::ContractViolation(_))),
                "expected loud rejection: {why}"
            );
        };

        let mut unoffered = Vmm::new(configured_mock(vec![]), GuestRam::new(TEST_RAM).unwrap());
        unoffered.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 7).unwrap());
        reject(&mut unoffered, &registered_state, "registered -> unoffered");
        reject(
            &mut unoffered,
            &offered_unregistered_state,
            "offered-unregistered -> unoffered",
        );
        unoffered.restore_vm_state(&unoffered_state).unwrap();

        let mut offered = pvclock_vmm(vec![], 7);
        reject(&mut offered, &unoffered_state, "unoffered -> offered");

        let mut small = Vmm::new(configured_mock(vec![]), GuestRam::new(0x2000).unwrap());
        small.wire_vtime(VtimeWiring::new_virtual_time(contract_vclock_config(), 7).unwrap());
        small.enable_pvclock();
        reject(&mut small, &registered_state, "GPA past the target's RAM");
        assert_eq!(small.pvclock_registration(), None, "rejection mutated");
    }

    #[test]
    fn pvclock_doorbell_rejects_bad_frames() {
        let mut vmm = pvclock_vmm(vec![], 7);
        let mut frame = [0_u8; 64];
        let len = hypercall_proto::encode_request(
            ServiceId::Pvclock,
            2,
            1,
            &PV_GPA.to_le_bytes(),
            &mut frame,
        )
        .unwrap();
        vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + len].copy_from_slice(&frame[..len]);
        vmm.service_doorbell(len as u32).unwrap();
        let (header, _) = decode(&vmm.ram.as_bytes()[RESP_GPA..RESP_GPA + HC_PAGE]).unwrap();
        assert_eq!(header.status, Status::UnknownOpcode as u16);

        let len =
            hypercall_proto::encode_request(ServiceId::Pvclock, 1, 2, &[0; 7], &mut frame).unwrap();
        vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + len].copy_from_slice(&frame[..len]);
        vmm.service_doorbell(len as u32).unwrap();
        let (header, _) = decode(&vmm.ram.as_bytes()[RESP_GPA..RESP_GPA + HC_PAGE]).unwrap();
        assert_eq!(header.status, Status::BadRequest as u16);
        assert_eq!(vmm.pvclock_registration(), None);
    }

    #[test]
    fn pvclock_only_composition_rejects_unoffered_doorbell_services() {
        let mut vmm = pvclock_vmm(vec![], 7);
        let entropy_before = vmm.entropy_state();

        let ring = |vmm: &mut Vmm<MockBackend>, frame: &[u8]| -> (Step, u16) {
            vmm.ram.as_mut_bytes()[REQ_GPA..REQ_GPA + frame.len()].copy_from_slice(frame);
            let step = vmm.service_doorbell(frame.len() as u32).unwrap();
            let (header, _) = decode(&vmm.ram.as_bytes()[RESP_GPA..RESP_GPA + HC_PAGE]).unwrap();
            (step, header.status)
        };

        let mut frame = [0_u8; 128];
        let mut payload = Vec::new();
        payload.extend_from_slice(&0x0001_0001u32.to_le_bytes());
        payload.extend_from_slice(b"assert detail bytes");
        let n =
            hypercall_proto::encode_request(ServiceId::Event, 1, 1, &payload, &mut frame).unwrap();
        let (step, status) = ring(&mut vmm, &frame[..n]);
        assert_eq!(
            status,
            Status::UnknownService as u16,
            "Event must be unoffered"
        );
        assert_eq!(step, Step::Continued, "no SdkStop without an SDK channel");

        let n =
            hypercall_proto::encode_request(ServiceId::Sdk, 1, 2, &7u32.to_le_bytes(), &mut frame)
                .unwrap();
        let (step, status) = ring(&mut vmm, &frame[..n]);
        assert_eq!(
            status,
            Status::UnknownService as u16,
            "Sdk must be unoffered"
        );
        assert_eq!(step, Step::Continued);

        let n = hypercall_proto::encode_request(
            ServiceId::Entropy,
            1,
            3,
            &8u32.to_le_bytes(),
            &mut frame,
        )
        .unwrap();
        let (step, status) = ring(&mut vmm, &frame[..n]);
        assert_eq!(
            status,
            Status::UnknownService as u16,
            "Entropy must be unoffered"
        );
        assert_eq!(step, Step::Continued);
        assert_eq!(
            vmm.entropy_state(),
            entropy_before,
            "an unoffered entropy ask advanced the shared seeded stream"
        );

        for (svc, name) in [
            (ServiceId::Event, "Event"),
            (ServiceId::Sdk, "Sdk"),
            (ServiceId::Entropy, "Entropy"),
        ] {
            let n = hypercall_proto::encode_request(svc, 1, 7, &[], &mut frame).unwrap();
            let (step, status) = ring(&mut vmm, &frame[..n]);
            assert_eq!(
                status,
                Status::UnknownService as u16,
                "{name} opcode 7 on a pvclock-only VM must be UnknownService (unoffered), not \
                 UnknownOpcode — that would advertise the service"
            );
            assert_eq!(step, Step::Continued);
        }

        let (status, _) = ring_pvclock_register(&mut vmm, PV_GPA);
        assert_eq!(status, Status::Ok as u16);
    }
}

// SPDX-License-Identifier: AGPL-3.0-or-later

use std::{
    collections::BTreeMap,
    io::{Read, Write},
    sync::Arc,
};

use environment::{channel, input_spec::ServiceConfig};
use sha2::{Digest, Sha256};

use crate::snapshot::SnapshotError;
use crate::vmm::{SdkSnapshot, SdkStop};
use snapshot_store::PAGE_SIZE;

const MAGIC: [u8; 8] = *b"HMSNAP01";
const VERSION: u16 = 11;
const FLAG_SDK: u16 = 1;
const FLAG_TAINTED: u16 = 1 << 1;
const KNOWN_FLAGS: u16 = FLAG_SDK | FLAG_TAINTED;

#[cfg(test)]
const MAX_VM_STATE_LEN: usize = 16 * 1024 * 1024;
#[cfg(test)]
const MAX_SDK_LEN: usize = 64 * 1024 * 1024;
#[cfg(test)]
const MAX_CONTROL_LEN: usize = MAX_SDK_LEN;
#[cfg(test)]
const MAX_POLICY_LEN: usize = 1024 * 1024;
const SPARSE_MAGIC: [u8; 8] = *b"HMSSNAP1";
const SPARSE_VERSION: u16 = 15;
const SPARSE_FLAG_SDK: u16 = 1;
const SPARSE_FLAG_TAINTED: u16 = 1 << 1;
const SPARSE_FLAG_TARGET_PAGES: u16 = 1 << 2;
const SPARSE_KNOWN_FLAGS: u16 = SPARSE_FLAG_SDK | SPARSE_FLAG_TAINTED | SPARSE_FLAG_TARGET_PAGES;
#[cfg(test)]
const MAX_SUFFIX_LEN: usize = 16 * 1024 * 1024;
#[cfg(test)]
const MAX_SPARSE_SIDECAR_LEN: usize = MAX_VM_STATE_LEN
    .saturating_add(MAX_SDK_LEN)
    .saturating_add(MAX_CONTROL_LEN)
    .saturating_add(MAX_POLICY_LEN)
    .saturating_add(MAX_SUFFIX_LEN)
    .saturating_add(201);

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SparsePortableSnapshot {
    pub pages: Vec<(u64, Arc<[u8; PAGE_SIZE]>)>,
    pub sidecar: Vec<u8>,
}

#[derive(Debug)]
pub struct SparseDelta<'a> {
    pub pages: Vec<(u64, &'a [u8; 32], &'a [u8; PAGE_SIZE])>,
    pub reverted: Vec<u64>,
    pub sidecar: Vec<u8>,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct SparsePortableSnapshotReceipt {
    pub id: control_proto::SnapId,
    pub at: control_proto::Moment,
    pub sdk_events: u64,
    pub trace_events: u64,
    pub trace_schedules: u64,
    pub event_history: Option<control_proto::EventHistory>,
    pub tainted: bool,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PortableExecutionComparison {
    pub equal: bool,
    pub left_trace_events: u64,
    pub right_trace_events: u64,
    pub left_trace_schedules: u64,
    pub right_trace_schedules: u64,
}

pub(crate) struct SparsePortableSidecar {
    pub(crate) vm_state: Vec<u8>,
    pub(crate) sdk: Option<SdkSnapshot>,
    pub(crate) policy: ServiceConfig,
    pub(crate) at: u64,
    pub(crate) sdk_events: u64,
    pub(crate) trace_events: u64,
    pub(crate) trace_schedules: u64,
    pub(crate) event_history: Option<control_proto::EventHistory>,
    pub(crate) tainted: bool,
    pub(crate) base_ram_digest: [u8; 32],
    pub(crate) target_pages_digest: Option<[u8; 32]>,
    pub(crate) state_blob_suffix: Vec<u8>,
    pub(crate) control_state: Vec<u8>,
}

pub(crate) struct SparsePortableSidecarRef<'a> {
    pub(crate) vm_state: &'a [u8],
    pub(crate) sdk: Option<&'a SdkSnapshot>,
    pub(crate) policy: &'a ServiceConfig,
    pub(crate) at: u64,
    pub(crate) sdk_events: u64,
    pub(crate) trace_events: u64,
    pub(crate) trace_schedules: u64,
    pub(crate) event_history: Option<control_proto::EventHistory>,
    pub(crate) tainted: bool,
    pub(crate) base_ram_digest: [u8; 32],
    pub(crate) state_blob_suffix: &'a [u8],
    pub(crate) control_state: &'a [u8],
}

pub(crate) struct PortableSnapshot {
    pub(crate) memory: Vec<u8>,
    pub(crate) vm_state: Vec<u8>,
    pub(crate) sdk: Option<SdkSnapshot>,
    pub(crate) policy: ServiceConfig,
    pub(crate) at: u64,
    pub(crate) sdk_events: u64,
    pub(crate) trace_events: u64,
    pub(crate) trace_schedules: u64,
    pub(crate) event_history: Option<control_proto::EventHistory>,
    pub(crate) tainted: bool,
    pub(crate) state_hash: [u8; 32],
    pub(crate) control_state: Vec<u8>,
}

pub(crate) struct PortableSnapshotRef<'a> {
    pub(crate) memory: &'a [u8],
    pub(crate) vm_state: &'a [u8],
    pub(crate) sdk: Option<&'a SdkSnapshot>,
    pub(crate) policy: &'a ServiceConfig,
    pub(crate) at: u64,
    pub(crate) sdk_events: u64,
    pub(crate) trace_events: u64,
    pub(crate) trace_schedules: u64,
    pub(crate) event_history: Option<control_proto::EventHistory>,
    pub(crate) tainted: bool,
    pub(crate) state_hash: [u8; 32],
    pub(crate) control_state: &'a [u8],
}

#[derive(Debug, thiserror::Error)]
pub enum PortableSnapshotError {
    #[error("portable snapshot I/O error")]
    Io(#[from] std::io::Error),
    #[error("portable snapshot has bad magic")]
    BadMagic,
    #[error("portable snapshot version {0} is unsupported")]
    BadVersion(u16),
    #[error("portable snapshot flags are malformed")]
    BadFlags,
    #[error("portable snapshot {section} length {got} exceeds {max}")]
    Length {
        section: &'static str,
        got: u64,
        max: u64,
    },
    #[error("portable snapshot section malformed: {0}")]
    Malformed(&'static str),
    #[error("portable snapshot SHA-256 mismatch")]
    DigestMismatch,
    #[error("portable snapshot environment state malformed")]
    Environment(#[from] channel::ChannelError),
    #[error("portable snapshot store/VM-state failure")]
    Snapshot(#[from] SnapshotError),
    #[error("unknown portable snapshot handle {0}")]
    UnknownSnapshot(u64),
}

fn write_event_history<W: Write>(
    writer: &mut W,
    history: Option<control_proto::EventHistory>,
) -> Result<(), PortableSnapshotError> {
    writer.write_all(&[u8::from(history.is_some())])?;
    if let Some(history) = history {
        put_u64(writer, history.count)?;
        writer.write_all(&history.digest)?;
    }
    Ok(())
}

fn read_event_history<R: Read>(
    reader: &mut R,
) -> Result<Option<control_proto::EventHistory>, PortableSnapshotError> {
    let mut tag = [0];
    reader.read_exact(&mut tag)?;
    match tag[0] {
        0 => Ok(None),
        1 => {
            let count = get_u64(reader)?;
            let mut digest = [0; 32];
            reader.read_exact(&mut digest)?;
            Ok(Some(control_proto::EventHistory { count, digest }))
        }
        _ => Err(PortableSnapshotError::Malformed("event history presence")),
    }
}

impl PortableSnapshotRef<'_> {
    #[cfg(test)]
    pub(crate) fn write_to<W: Write>(&self, writer: W) -> Result<(), PortableSnapshotError> {
        self.write_to_counted(writer, &mut crate::host_telemetry::HashWork::new())
    }

    pub(crate) fn write_to_counted<W: Write>(
        &self,
        mut writer: W,
        work: &mut crate::host_telemetry::HashWork,
    ) -> Result<(), PortableSnapshotError> {
        let sdk = self.sdk.map(encode_sdk).transpose()?;
        let policy = self.policy.encode();
        if self.vm_state.is_empty() {
            return Err(PortableSnapshotError::BadFlags);
        }

        let mut flags = 0;
        if sdk.is_some() {
            flags |= FLAG_SDK;
        }
        if self.tainted {
            flags |= FLAG_TAINTED;
        }

        let mut out = HashWriter::new(&mut writer, work);
        out.write_all(&MAGIC)?;
        put_u16(&mut out, VERSION)?;
        put_u16(&mut out, flags)?;
        put_len(&mut out, self.memory.len())?;
        put_len(&mut out, self.vm_state.len())?;
        put_len(&mut out, sdk.as_ref().map_or(0, Vec::len))?;
        put_len(&mut out, policy.len())?;
        put_len(&mut out, self.control_state.len())?;
        put_u64(&mut out, self.at)?;
        put_u64(&mut out, self.sdk_events)?;
        put_u64(&mut out, self.trace_events)?;
        put_u64(&mut out, self.trace_schedules)?;
        out.write_all(&self.state_hash)?;
        out.ram = true;
        out.write_all(self.memory)?;
        out.ram = false;
        out.write_all(self.vm_state)?;
        if let Some(bytes) = &sdk {
            out.write_all(bytes)?;
        }
        out.write_all(&policy)?;
        out.write_all(self.control_state)?;
        write_event_history(&mut out, self.event_history)?;
        out.flush()?;
        let digest = out.finish();
        writer.write_all(&digest)?;
        writer.flush()?;
        Ok(())
    }
}

impl PortableSnapshot {
    pub(crate) fn read_from<R: Read>(
        reader: R,
        expected_memory_len: usize,
    ) -> Result<Self, PortableSnapshotError> {
        Self::read_from_counted(
            reader,
            expected_memory_len,
            &mut crate::host_telemetry::HashWork::new(),
        )
    }

    pub(crate) fn read_from_counted<R: Read>(
        mut reader: R,
        expected_memory_len: usize,
        work: &mut crate::host_telemetry::HashWork,
    ) -> Result<Self, PortableSnapshotError> {
        let mut input = HashReader::new(&mut reader, work);
        let mut magic = [0; 8];
        input.read_exact(&mut magic)?;
        if magic != MAGIC {
            return Err(PortableSnapshotError::BadMagic);
        }
        let version = get_u16(&mut input)?;
        if version != VERSION {
            return Err(PortableSnapshotError::BadVersion(version));
        }
        let flags = get_u16(&mut input)?;
        if flags & !KNOWN_FLAGS != 0 {
            return Err(PortableSnapshotError::BadFlags);
        }
        let memory_len = get_u64(&mut input)?;
        if memory_len != expected_memory_len as u64 {
            return Err(PortableSnapshotError::Length {
                section: "memory",
                got: memory_len,
                max: expected_memory_len as u64,
            });
        }
        let vm_state_len = section_len(&mut input, "vm_state")?;
        let sdk_len = section_len(&mut input, "sdk")?;
        let policy_len = section_len(&mut input, "policy")?;
        let control_len = section_len(&mut input, "control_state")?;
        let has_sdk = flags & FLAG_SDK != 0;
        if vm_state_len == 0 || has_sdk != (sdk_len != 0) || policy_len == 0 {
            return Err(PortableSnapshotError::BadFlags);
        }
        let at = get_u64(&mut input)?;
        let sdk_events = get_u64(&mut input)?;
        let trace_events = get_u64(&mut input)?;
        let trace_schedules = get_u64(&mut input)?;
        let mut state_hash = [0; 32];
        input.read_exact(&mut state_hash)?;
        input.ram = true;
        let memory = read_vec(&mut input, expected_memory_len)?;
        input.ram = false;
        let vm_state = read_vec(&mut input, vm_state_len)?;
        let sdk_bytes = read_vec(&mut input, sdk_len)?;
        let policy_bytes = read_vec(&mut input, policy_len)?;
        let control_state = read_vec(&mut input, control_len)?;
        let event_history = read_event_history(&mut input)?;
        let calculated = input.finish();
        let mut recorded = [0; 32];
        reader.read_exact(&mut recorded)?;
        if calculated != recorded {
            return Err(PortableSnapshotError::DigestMismatch);
        }
        let mut trailing = [0; 1];
        if reader.read(&mut trailing)? != 0 {
            return Err(PortableSnapshotError::Malformed("trailing bytes"));
        }
        let sdk = has_sdk.then(|| decode_sdk(&sdk_bytes)).transpose()?;
        let policy = ServiceConfig::decode(&policy_bytes)?;
        Ok(Self {
            memory,
            vm_state,
            sdk,
            policy,
            at,
            sdk_events,
            trace_events,
            trace_schedules,
            event_history,
            tainted: flags & FLAG_TAINTED != 0,
            state_hash,
            control_state,
        })
    }
}

pub fn compare_portable_execution_state(
    left: &[u8],
    right: &[u8],
    expected_memory_len: usize,
) -> Result<PortableExecutionComparison, PortableSnapshotError> {
    let (left_trace_events, left_trace_schedules) = {
        let decoded = PortableSnapshot::read_from(left, expected_memory_len)?;
        let values = (decoded.trace_events, decoded.trace_schedules);
        drop(decoded);
        values
    };
    let (right_trace_events, right_trace_schedules) = {
        let decoded = PortableSnapshot::read_from(right, expected_memory_len)?;
        let values = (decoded.trace_events, decoded.trace_schedules);
        drop(decoded);
        values
    };
    let left_trace_start = 68;
    let right_trace_start = 68;
    let equal = left[..left_trace_start] == right[..right_trace_start]
        && left[left_trace_start + 16..left.len() - 32]
            == right[right_trace_start + 16..right.len() - 32];
    Ok(PortableExecutionComparison {
        equal,
        left_trace_events,
        right_trace_events,
        left_trace_schedules,
        right_trace_schedules,
    })
}

pub fn logical_x86_sparse_sidecar(bytes: &[u8]) -> Result<Vec<u8>, PortableSnapshotError> {
    let sidecar = decode_sparse_sidecar(bytes)?;
    let state = vm_state::VmState::decode(&sidecar.vm_state)
        .map_err(|_| PortableSnapshotError::Malformed("invalid x86 sparse CPU state"))?;
    let vm_state = logical_x86_vm_state(state)?;
    encode_sparse_sidecar_with_vm_state(&sidecar, &vm_state)
}

fn logical_x86_vm_state(mut state: vm_state::VmState) -> Result<Vec<u8>, PortableSnapshotError> {
    state.xsave_restore_bv =
        vmm_backend::logical_xsave_restore_bv(&state.xsave.0, state.xsave_restore_bv)
            .map_err(|_| PortableSnapshotError::Malformed("invalid x86 sparse XSAVE state"))?;
    state
        .encode()
        .map_err(|_| PortableSnapshotError::Malformed("invalid x86 sparse CPU state"))
}

fn encode_sparse_sidecar_with_vm_state(
    sidecar: &SparsePortableSidecar,
    vm_state: &[u8],
) -> Result<Vec<u8>, PortableSnapshotError> {
    encode_sparse_sidecar_with_target_pages(
        &SparsePortableSidecarRef {
            vm_state,
            sdk: sidecar.sdk.as_ref(),
            policy: &sidecar.policy,
            at: sidecar.at,
            sdk_events: sidecar.sdk_events,
            trace_events: sidecar.trace_events,
            trace_schedules: sidecar.trace_schedules,
            event_history: sidecar.event_history,
            tainted: sidecar.tainted,
            base_ram_digest: sidecar.base_ram_digest,
            state_blob_suffix: &sidecar.state_blob_suffix,
            control_state: &sidecar.control_state,
        },
        sidecar.target_pages_digest,
    )
}

#[cfg(test)]
pub(crate) fn encode_sparse_sidecar(
    sidecar: &SparsePortableSidecarRef<'_>,
) -> Result<Vec<u8>, PortableSnapshotError> {
    encode_sparse_sidecar_with_target_pages(sidecar, None)
}

pub(crate) fn encode_sparse_sidecar_with_target_pages(
    sidecar: &SparsePortableSidecarRef<'_>,
    target_pages_digest: Option<[u8; 32]>,
) -> Result<Vec<u8>, PortableSnapshotError> {
    let sdk = sidecar.sdk.map(encode_sdk).transpose()?;
    let policy = sidecar.policy.encode();
    if sidecar.vm_state.is_empty() {
        return Err(PortableSnapshotError::BadFlags);
    }

    let mut flags = 0;
    if sdk.is_some() {
        flags |= SPARSE_FLAG_SDK;
    }
    if sidecar.tainted {
        flags |= SPARSE_FLAG_TAINTED;
    }
    if target_pages_digest.is_some() {
        flags |= SPARSE_FLAG_TARGET_PAGES;
    }

    let mut out = Vec::new();
    out.extend_from_slice(&SPARSE_MAGIC);
    put_u16(&mut out, SPARSE_VERSION)?;
    put_u16(&mut out, flags)?;
    put_len(&mut out, sidecar.vm_state.len())?;
    put_len(&mut out, sdk.as_ref().map_or(0, Vec::len))?;
    put_len(&mut out, policy.len())?;
    put_len(&mut out, sidecar.state_blob_suffix.len())?;
    put_len(&mut out, sidecar.control_state.len())?;
    put_u64(&mut out, sidecar.at)?;
    put_u64(&mut out, sidecar.sdk_events)?;
    put_u64(&mut out, sidecar.trace_events)?;
    put_u64(&mut out, sidecar.trace_schedules)?;
    out.extend_from_slice(&sidecar.base_ram_digest);
    if let Some(digest) = target_pages_digest {
        out.extend_from_slice(&digest);
    }
    out.extend_from_slice(sidecar.vm_state);
    if let Some(bytes) = &sdk {
        out.extend_from_slice(bytes);
    }
    out.extend_from_slice(&policy);
    out.extend_from_slice(sidecar.state_blob_suffix);
    out.extend_from_slice(sidecar.control_state);
    write_event_history(&mut out, sidecar.event_history)?;
    Ok(out)
}

pub(crate) fn decode_sparse_sidecar(
    bytes: &[u8],
) -> Result<SparsePortableSidecar, PortableSnapshotError> {
    let mut input = SliceReader::new(bytes);
    if input.take(SPARSE_MAGIC.len())? != SPARSE_MAGIC {
        return Err(PortableSnapshotError::BadMagic);
    }
    let version = input.u16()?;
    if version != SPARSE_VERSION {
        return Err(PortableSnapshotError::BadVersion(version));
    }
    let flags = input.u16()?;
    if flags & !SPARSE_KNOWN_FLAGS != 0 {
        return Err(PortableSnapshotError::BadFlags);
    }
    let vm_state_len = input.section_len("vm_state")?;
    let sdk_len = input.section_len("sdk")?;
    let policy_len = input.section_len("policy")?;
    let suffix_len = input.section_len("state_blob_suffix")?;
    let control_len = input.section_len("control_state")?;
    let has_sdk = flags & SPARSE_FLAG_SDK != 0;
    if vm_state_len == 0 || policy_len == 0 || has_sdk != (sdk_len != 0) {
        return Err(PortableSnapshotError::BadFlags);
    }
    let at = input.u64()?;
    let sdk_events = input.u64()?;
    let trace_events = input.u64()?;
    let trace_schedules = input.u64()?;
    let mut base_ram_digest = [0; 32];
    base_ram_digest.copy_from_slice(input.take(32)?);
    let target_pages_digest = if flags & SPARSE_FLAG_TARGET_PAGES != 0 {
        let mut digest = [0; 32];
        digest.copy_from_slice(input.take(32)?);
        Some(digest)
    } else {
        None
    };
    let vm_state = input.section(vm_state_len)?;
    let sdk_bytes = input.section(sdk_len)?;
    let policy_bytes = input.section(policy_len)?;
    let state_blob_suffix = input.section(suffix_len)?;
    let control_state = input.section(control_len)?;
    let history_tag = input.take(1)?[0];
    let event_history = match history_tag {
        0 => None,
        1 => {
            let count = input.u64()?;
            let mut digest = [0; 32];
            digest.copy_from_slice(input.take(32)?);
            Some(control_proto::EventHistory { count, digest })
        }
        _ => return Err(PortableSnapshotError::Malformed("event history presence")),
    };
    input.finish("sparse sidecar")?;
    let sdk = has_sdk.then(|| decode_sdk(&sdk_bytes)).transpose()?;
    let policy = ServiceConfig::decode(&policy_bytes)?;
    Ok(SparsePortableSidecar {
        vm_state,
        sdk,
        policy,
        at,
        sdk_events,
        trace_events,
        trace_schedules,
        event_history,
        tainted: flags & SPARSE_FLAG_TAINTED != 0,
        base_ram_digest,
        target_pages_digest,
        state_blob_suffix,
        control_state,
    })
}

pub fn sparse_delta_target_commitment(sidecar: &[u8]) -> Result<[u8; 32], PortableSnapshotError> {
    let decoded = decode_sparse_sidecar(sidecar)?;
    if decoded.target_pages_digest.is_none() {
        return Err(PortableSnapshotError::Malformed(
            "sparse delta sidecar lacks target pages digest",
        ));
    }
    let vm_state = match vm_state::VmState::decode(&decoded.vm_state) {
        Ok(state) => logical_x86_vm_state(state)?,
        Err(vm_state::VmStateError::UnsupportedArch(vm_state::ARCH_AARCH64)) => {
            let state = vm_state::Arm64VmState::decode(&decoded.vm_state)
                .map_err(|_| PortableSnapshotError::Malformed("invalid Arm64 sparse CPU state"))?;
            vm_state::SnapshotRecords::encode_for_hash(&state)
                .map_err(|_| PortableSnapshotError::Malformed("invalid Arm64 sparse CPU state"))?
        }
        Err(_) => return Err(PortableSnapshotError::Malformed("invalid sparse CPU state")),
    };
    let logical_sidecar = encode_sparse_sidecar_with_vm_state(&decoded, &vm_state)?;
    let mut digest = Sha256::new();
    digest.update(b"consonance-sparse-delta-target-commitment-v3\0");
    digest.update(&logical_sidecar);
    Ok(digest.finalize().into())
}

fn encode_sdk(sdk: &SdkSnapshot) -> Result<Vec<u8>, PortableSnapshotError> {
    let mut out = Vec::new();
    let recorded = sdk.recorded.encode();
    put_vec_len(&mut out, recorded.len());
    out.extend_from_slice(&recorded);
    out.push(u8::from(sdk.pending_snapshot));
    encode_pending_stop(&mut out, sdk.pending_stop.as_ref());
    put_vec_len(&mut out, sdk.events.len());
    for (moment, local, payload) in &sdk.events {
        out.extend_from_slice(&moment.to_le_bytes());
        out.extend_from_slice(&local.to_le_bytes());
        put_vec_len(&mut out, payload.len());
        out.extend_from_slice(payload);
    }
    if !sdk.coverage_thresholds.is_empty() {
        out.extend_from_slice(b"COVR");
        put_vec_len(&mut out, sdk.coverage_thresholds.len());
        for (thread, threshold) in &sdk.coverage_thresholds {
            out.extend_from_slice(&thread.to_le_bytes());
            out.extend_from_slice(&threshold.to_le_bytes());
        }
    }
    Ok(out)
}

fn decode_sdk(bytes: &[u8]) -> Result<SdkSnapshot, PortableSnapshotError> {
    let mut input = SliceReader::new(bytes);
    let recorded = channel::RecordedState::decode(&input.bytes()?)
        .map_err(|_| PortableSnapshotError::Malformed("SDK recorded state"))?;
    let pending_snapshot = input.boolean()?;
    let pending_stop = decode_pending_stop(&mut input)?;
    let event_count = input.count("SDK event count", 20)?;
    let mut events = Vec::new();
    events
        .try_reserve_exact(event_count)
        .map_err(|_| PortableSnapshotError::Malformed("SDK event allocation"))?;
    for _ in 0..event_count {
        let moment = input.u64()?;
        let local = input.u32()?;
        let payload = input.bytes()?;
        events.push((moment, local, payload));
    }
    let mut coverage_thresholds = BTreeMap::new();
    if input.remaining() != 0 {
        if input.take(4)? != b"COVR" {
            return Err(PortableSnapshotError::Malformed("SDK coverage tag"));
        }
        let count = input.count("SDK coverage threshold count", 12)?;
        if count == 0 {
            return Err(PortableSnapshotError::Malformed(
                "SDK coverage threshold count",
            ));
        }
        let mut previous_thread = None;
        for _ in 0..count {
            let thread = input.u32()?;
            let threshold = input.u64()?;
            if threshold == 0 || previous_thread.is_some_and(|previous| thread <= previous) {
                return Err(PortableSnapshotError::Malformed("SDK coverage threshold"));
            }
            previous_thread = Some(thread);
            coverage_thresholds.insert(thread, threshold);
        }
    }
    input.finish("SDK")?;
    Ok(SdkSnapshot {
        recorded,
        events,
        pending_snapshot,
        pending_stop,
        coverage_thresholds,
    })
}

fn encode_pending_stop(out: &mut Vec<u8>, stop: Option<&SdkStop>) {
    match stop {
        None => out.push(0),
        Some(SdkStop::Quiescent) => out.push(1),
        Some(SdkStop::Assertion { id, data }) => {
            out.push(2);
            out.extend_from_slice(&id.to_le_bytes());
            put_vec_len(out, data.len());
            out.extend_from_slice(data);
        }
        Some(SdkStop::Decision {
            moment,
            seq,
            question,
        }) => {
            out.push(3);
            out.extend_from_slice(&moment.to_le_bytes());
            out.extend_from_slice(&seq.to_le_bytes());
            out.extend_from_slice(&question.service().to_le_bytes());
            out.extend_from_slice(&question.request_id().to_le_bytes());
            put_vec_len(out, question.payload().len());
            out.extend_from_slice(question.payload());
        }
        Some(SdkStop::CoverageDecision {
            moment,
            seq,
            question,
            ready,
        }) => {
            out.push(4);
            out.extend_from_slice(&moment.to_le_bytes());
            out.extend_from_slice(&seq.to_le_bytes());
            out.extend_from_slice(&question.service().to_le_bytes());
            out.extend_from_slice(&question.request_id().to_le_bytes());
            put_vec_len(out, question.payload().len());
            out.extend_from_slice(question.payload());
            out.extend_from_slice(&ready.to_le_bytes());
        }
        Some(SdkStop::DeferredDoorbell {
            moment,
            requested_len,
            request,
        }) => {
            out.push(5);
            out.extend_from_slice(&moment.to_le_bytes());
            out.extend_from_slice(&requested_len.to_le_bytes());
            put_vec_len(out, request.len());
            out.extend_from_slice(request);
        }
    }
}

fn decode_pending_stop(
    input: &mut SliceReader<'_>,
) -> Result<Option<SdkStop>, PortableSnapshotError> {
    Ok(match input.u8()? {
        0 => None,
        1 => Some(SdkStop::Quiescent),
        2 => Some(SdkStop::Assertion {
            id: input.u32()?,
            data: input.bytes()?,
        }),
        3 => {
            let moment = input.u64()?;
            let seq = input.u32()?;
            let service = input.u16()?;
            let request = input.u64()?;
            let payload = input.bytes()?;
            let question = channel::Question::with_request_id(request, service, payload)
                .map_err(|_| PortableSnapshotError::Malformed("SDK pending question"))?;
            let stop = SdkStop::Decision {
                moment,
                seq,
                question,
            };
            if crate::service_transcript::pending_request(&stop).is_none() {
                return Err(PortableSnapshotError::Malformed("SDK pending question"));
            }
            Some(stop)
        }
        4 => {
            let moment = input.u64()?;
            let seq = input.u32()?;
            let service = input.u16()?;
            let request = input.u64()?;
            let payload = input.bytes()?;
            let ready = input.u32()?;
            if service != channel::SERVICE_COVERAGE_QUANTUM
                || u32::try_from(request).is_err()
                || payload.len() != 8
                || ready == 0
            {
                return Err(PortableSnapshotError::Malformed("SDK coverage decision"));
            }
            let question = channel::Question::with_request_id(request, service, payload)
                .map_err(|_| PortableSnapshotError::Malformed("SDK coverage decision"))?;
            Some(SdkStop::CoverageDecision {
                moment,
                seq,
                question,
                ready,
            })
        }
        5 => {
            let moment = input.u64()?;
            let requested_len = input.u32()?;
            let frame_len = usize::try_from(input.u64()?)
                .map_err(|_| PortableSnapshotError::Malformed("SDK deferred doorbell"))?;
            if frame_len > PAGE_SIZE
                || (requested_len as usize <= PAGE_SIZE && frame_len != requested_len as usize)
                || (requested_len as usize > PAGE_SIZE && frame_len != 0)
            {
                return Err(PortableSnapshotError::Malformed("SDK deferred doorbell"));
            }
            let request = input.section(frame_len)?;
            Some(SdkStop::DeferredDoorbell {
                moment,
                requested_len,
                request,
            })
        }
        _ => return Err(PortableSnapshotError::Malformed("SDK pending stop")),
    })
}

fn section_len<R: Read>(
    input: &mut R,
    section: &'static str,
) -> Result<usize, PortableSnapshotError> {
    bounded_len(input, section, isize::MAX as usize)
}

fn check_len(section: &'static str, got: usize, max: usize) -> Result<(), PortableSnapshotError> {
    if got > max {
        return Err(PortableSnapshotError::Length {
            section,
            got: got as u64,
            max: max as u64,
        });
    }
    Ok(())
}

fn bounded_len<R: Read>(
    input: &mut R,
    section: &'static str,
    max: usize,
) -> Result<usize, PortableSnapshotError> {
    let got = get_u64(input)?;
    let len = usize::try_from(got).map_err(|_| PortableSnapshotError::Length {
        section,
        got,
        max: max as u64,
    })?;
    check_len(section, len, max)?;
    Ok(len)
}

fn read_vec<R: Read>(input: &mut R, len: usize) -> Result<Vec<u8>, PortableSnapshotError> {
    let mut chunk = [0_u8; 64 * 1024];
    let mut bytes = Vec::new();
    while bytes.len() < len {
        let wanted = (len - bytes.len()).min(chunk.len());
        let received = match input.read(&mut chunk[..wanted]) {
            Err(error) if error.kind() == std::io::ErrorKind::Interrupted => continue,
            result => result?,
        };
        if received == 0 {
            return Err(std::io::Error::from(std::io::ErrorKind::UnexpectedEof).into());
        }
        bytes
            .try_reserve(received)
            .map_err(|_| PortableSnapshotError::Malformed("section allocation"))?;
        bytes.extend_from_slice(&chunk[..received]);
    }
    Ok(bytes)
}

fn put_vec_len(out: &mut Vec<u8>, len: usize) {
    out.extend_from_slice(&(len as u64).to_le_bytes());
}

fn put_len<W: Write>(out: &mut W, len: usize) -> Result<(), std::io::Error> {
    put_u64(out, len as u64)
}

fn put_u16<W: Write>(out: &mut W, value: u16) -> Result<(), std::io::Error> {
    out.write_all(&value.to_le_bytes())
}

fn put_u64<W: Write>(out: &mut W, value: u64) -> Result<(), std::io::Error> {
    out.write_all(&value.to_le_bytes())
}

fn get_u16<R: Read>(input: &mut R) -> Result<u16, std::io::Error> {
    let mut bytes = [0; 2];
    input.read_exact(&mut bytes)?;
    Ok(u16::from_le_bytes(bytes))
}

fn get_u64<R: Read>(input: &mut R) -> Result<u64, std::io::Error> {
    let mut bytes = [0; 8];
    input.read_exact(&mut bytes)?;
    Ok(u64::from_le_bytes(bytes))
}

struct HashWriter<'a, W> {
    work: &'a mut crate::host_telemetry::HashWork,
    ram: bool,
    inner: W,
    digest: Sha256,
}

impl<'a, W> HashWriter<'a, W> {
    fn new(inner: W, work: &'a mut crate::host_telemetry::HashWork) -> Self {
        Self {
            inner,
            work,
            ram: false,
            digest: Sha256::new(),
        }
    }

    fn finish(self) -> [u8; 32] {
        self.digest.finalize().into()
    }
}

impl<W: Write> Write for HashWriter<'_, W> {
    fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
        let written = self.inner.write(bytes)?;
        self.digest.update(&bytes[..written]);
        if self.ram {
            self.work.ram(written);
        } else {
            self.work.metadata(written);
        }
        Ok(written)
    }

    fn flush(&mut self) -> std::io::Result<()> {
        self.inner.flush()
    }
}

struct HashReader<'a, R> {
    work: &'a mut crate::host_telemetry::HashWork,
    ram: bool,
    inner: R,
    digest: Sha256,
}

impl<'a, R> HashReader<'a, R> {
    fn new(inner: R, work: &'a mut crate::host_telemetry::HashWork) -> Self {
        Self {
            inner,
            work,
            ram: false,
            digest: Sha256::new(),
        }
    }

    fn finish(self) -> [u8; 32] {
        self.digest.finalize().into()
    }
}

impl<R: Read> Read for HashReader<'_, R> {
    fn read(&mut self, bytes: &mut [u8]) -> std::io::Result<usize> {
        let read = self.inner.read(bytes)?;
        self.digest.update(&bytes[..read]);
        if self.ram {
            self.work.ram(read);
        } else {
            self.work.metadata(read);
        }
        Ok(read)
    }
}

struct SliceReader<'a> {
    bytes: &'a [u8],
    offset: usize,
}

impl<'a> SliceReader<'a> {
    fn new(bytes: &'a [u8]) -> Self {
        Self { bytes, offset: 0 }
    }

    fn remaining(&self) -> usize {
        self.bytes.len().saturating_sub(self.offset)
    }

    fn take(&mut self, len: usize) -> Result<&'a [u8], PortableSnapshotError> {
        let end = self
            .offset
            .checked_add(len)
            .ok_or(PortableSnapshotError::Malformed("section offset overflow"))?;
        let bytes = self
            .bytes
            .get(self.offset..end)
            .ok_or(PortableSnapshotError::Malformed("section truncation"))?;
        self.offset = end;
        Ok(bytes)
    }

    fn u8(&mut self) -> Result<u8, PortableSnapshotError> {
        Ok(self.take(1)?[0])
    }

    fn u16(&mut self) -> Result<u16, PortableSnapshotError> {
        let mut bytes = [0; 2];
        bytes.copy_from_slice(self.take(2)?);
        Ok(u16::from_le_bytes(bytes))
    }

    fn boolean(&mut self) -> Result<bool, PortableSnapshotError> {
        match self.u8()? {
            0 => Ok(false),
            1 => Ok(true),
            _ => Err(PortableSnapshotError::Malformed("boolean")),
        }
    }

    fn u32(&mut self) -> Result<u32, PortableSnapshotError> {
        let mut bytes = [0; 4];
        bytes.copy_from_slice(self.take(4)?);
        Ok(u32::from_le_bytes(bytes))
    }

    fn u64(&mut self) -> Result<u64, PortableSnapshotError> {
        let mut bytes = [0; 8];
        bytes.copy_from_slice(self.take(8)?);
        Ok(u64::from_le_bytes(bytes))
    }

    fn count(
        &mut self,
        label: &'static str,
        minimum_record_len: usize,
    ) -> Result<usize, PortableSnapshotError> {
        let count =
            usize::try_from(self.u64()?).map_err(|_| PortableSnapshotError::Malformed(label))?;
        if count > self.remaining() / minimum_record_len {
            return Err(PortableSnapshotError::Malformed(label));
        }
        Ok(count)
    }

    fn bytes(&mut self) -> Result<Vec<u8>, PortableSnapshotError> {
        let len = usize::try_from(self.u64()?)
            .map_err(|_| PortableSnapshotError::Malformed("nested length"))?;
        self.section(len)
    }

    fn section(&mut self, len: usize) -> Result<Vec<u8>, PortableSnapshotError> {
        let bytes = self.take(len)?;
        let mut copy = Vec::new();
        copy.try_reserve_exact(len)
            .map_err(|_| PortableSnapshotError::Malformed("section allocation"))?;
        copy.extend_from_slice(bytes);
        Ok(copy)
    }

    fn section_len(&mut self, section: &'static str) -> Result<usize, PortableSnapshotError> {
        self.bounded_len(section, self.bytes.len())
    }

    fn bounded_len(
        &mut self,
        section: &'static str,
        max: usize,
    ) -> Result<usize, PortableSnapshotError> {
        let got = self.u64()?;
        let len = usize::try_from(got).map_err(|_| PortableSnapshotError::Length {
            section,
            got,
            max: max as u64,
        })?;
        check_len(section, len, max)?;
        Ok(len)
    }

    fn finish(self, section: &'static str) -> Result<(), PortableSnapshotError> {
        if self.offset != self.bytes.len() {
            return Err(PortableSnapshotError::Malformed(section));
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[cfg(target_arch = "x86_64")]
    fn x86_sidecar(state: &vm_state::VmState) -> Vec<u8> {
        encode_sparse_sidecar_with_target_pages(
            &SparsePortableSidecarRef {
                vm_state: &state.encode().unwrap(),
                sdk: None,
                policy: &ServiceConfig {
                    local_services: Vec::new(),
                    identity: b"identity".to_vec(),
                    configuration: b"configuration".to_vec(),
                },
                at: 23,
                sdk_events: 0,
                trace_events: 17,
                trace_schedules: 5,
                event_history: None,
                tainted: true,
                base_ram_digest: [0xa5; 32],
                state_blob_suffix: b"state-suffix",
                control_state: b"control-state",
            },
            Some([0x3c; 32]),
        )
        .unwrap()
    }

    fn arm64_sidecar(state: &vm_state::Arm64VmState) -> Vec<u8> {
        encode_sparse_sidecar_with_target_pages(
            &SparsePortableSidecarRef {
                vm_state: &state.encode().unwrap(),
                sdk: None,
                policy: &ServiceConfig::default(),
                at: 23,
                sdk_events: 0,
                trace_events: 17,
                trace_schedules: 5,
                event_history: None,
                tainted: false,
                base_ram_digest: [0xa5; 32],
                state_blob_suffix: b"state-suffix",
                control_state: b"control-state",
            },
            Some([0x3c; 32]),
        )
        .unwrap()
    }

    #[test]
    fn sparse_target_commitment_deduplicates_equal_logical_arm_counter() {
        let mut state = vm_state::Arm64VmState::default();
        state.vtimer.counter = 10;
        let first = arm64_sidecar(&state);
        let first_commitment = sparse_delta_target_commitment(&first).unwrap();
        state.vtimer.counter = 20;
        let second = arm64_sidecar(&state);
        assert_ne!(first, second);
        assert_eq!(
            sparse_delta_target_commitment(&second).unwrap(),
            first_commitment
        );
        state.regs.x[0] = 1;
        assert_ne!(
            sparse_delta_target_commitment(&arm64_sidecar(&state)).unwrap(),
            first_commitment
        );
        state.regs.x[0] = 0;
        let mut changed = decode_sparse_sidecar(&arm64_sidecar(&state)).unwrap();
        changed.control_state.push(1);
        let changed = encode_sparse_sidecar_with_vm_state(&changed, &changed.vm_state).unwrap();
        assert_ne!(
            sparse_delta_target_commitment(&changed).unwrap(),
            first_commitment
        );
    }

    #[test]
    #[cfg(target_arch = "x86_64")]
    fn sparse_logical_x86_identity_normalizes_only_init_presence_without_mutating_restore_bytes() {
        let mut state = vm_state::VmState::default();
        state.xsave.0 = vec![0; 576];
        vmm_backend::arch::x86::canonicalize_xsave(&mut state.xsave.0);
        state.xsave_restore_bv = Some(0);
        let expected = x86_sidecar(&state);
        for raw in 0..=3 {
            state.xsave_restore_bv = Some(raw);
            let original = x86_sidecar(&state);
            assert_eq!(logical_x86_sparse_sidecar(&original).unwrap(), expected);
            assert_eq!(original, x86_sidecar(&state));
            assert_eq!(
                vm_state::VmState::decode(&decode_sparse_sidecar(&original).unwrap().vm_state)
                    .unwrap()
                    .xsave_restore_bv,
                Some(raw)
            );
        }
        state.regs.rbx = 1;
        assert_ne!(
            logical_x86_sparse_sidecar(&x86_sidecar(&state)).unwrap(),
            expected
        );
        state.regs.rbx = 0;
        state.xsave.0[160] = 0x79;
        state.xsave.0[512] = 2;
        state.xsave_restore_bv = Some(2);
        let active = x86_sidecar(&state);
        assert_eq!(logical_x86_sparse_sidecar(&active).unwrap(), active);
        state.xsave_restore_bv = Some(3);
        assert_eq!(
            logical_x86_sparse_sidecar(&x86_sidecar(&state)).unwrap(),
            active
        );
        state.xsave.0[160] ^= 1;
        assert_ne!(
            logical_x86_sparse_sidecar(&x86_sidecar(&state)).unwrap(),
            active
        );
        state.xsave_restore_bv = Some(0);
        assert!(logical_x86_sparse_sidecar(&x86_sidecar(&state)).is_err());
        assert!(logical_x86_sparse_sidecar(&active[..83]).is_err());
    }

    #[test]
    #[cfg(target_arch = "x86_64")]
    fn sparse_target_commitment_deduplicates_equal_logical_xsave_state() {
        let mut state = vm_state::VmState::default();
        state.xsave.0 = vec![0; 576];
        vmm_backend::arch::x86::canonicalize_xsave(&mut state.xsave.0);
        let mut expected = None;
        for raw in [0, 2, 3] {
            state.xsave_restore_bv = Some(raw);
            let sidecar = x86_sidecar(&state);
            let commitment = sparse_delta_target_commitment(&sidecar).unwrap();
            if let Some(first) = expected {
                assert_eq!(commitment, first);
            } else {
                expected = Some(commitment);
            }
        }
        state.regs.rbx = 1;
        assert_ne!(
            sparse_delta_target_commitment(&x86_sidecar(&state)).unwrap(),
            expected.unwrap()
        );
        state.regs.rbx = 0;
        state.xsave.0[160] = 0x79;
        state.xsave.0[512] = 2;
        state.xsave_restore_bv = Some(2);
        let active = sparse_delta_target_commitment(&x86_sidecar(&state)).unwrap();
        state.xsave.0[160] ^= 1;
        assert_ne!(
            sparse_delta_target_commitment(&x86_sidecar(&state)).unwrap(),
            active
        );
    }

    #[test]
    fn sparse_target_commitment_rejects_unknown_or_invalid_cpu_architecture() {
        let sidecar =
            decode_sparse_sidecar(&arm64_sidecar(&vm_state::Arm64VmState::default())).unwrap();
        for arch in [0u16, 3, u16::MAX] {
            let mut vm_state = sidecar.vm_state.clone();
            vm_state[6..8].copy_from_slice(&arch.to_le_bytes());
            let encoded = encode_sparse_sidecar_with_vm_state(&sidecar, &vm_state).unwrap();
            assert!(sparse_delta_target_commitment(&encoded).is_err());
        }
        let mut vm_state = sidecar.vm_state.clone();
        vm_state[0] ^= 1;
        let encoded = encode_sparse_sidecar_with_vm_state(&sidecar, &vm_state).unwrap();
        assert!(sparse_delta_target_commitment(&encoded).is_err());
    }

    #[test]
    #[cfg_attr(
        miri,
        ignore = "MiB-scale codec size regression; small codec and truncated-length tests run under Miri"
    )]
    fn version_six_round_trips_large_sections_with_optional_control() {
        let (memory, vm, sdk, _) = fixture();
        let policy = ServiceConfig {
            local_services: Vec::new(),
            identity: b"large".to_vec(),
            configuration: vec![0x45; MAX_POLICY_LEN],
        };
        for control in [&[][..], &b"opaque-control"[..]] {
            let mut full = Vec::new();
            PortableSnapshotRef {
                memory: &memory,
                vm_state: &vm,
                sdk: Some(&sdk),
                policy: &policy,
                at: 23,
                sdk_events: 2,
                trace_events: 17,
                trace_schedules: 5,
                event_history: None,
                tainted: true,
                state_hash: [0xa5; 32],
                control_state: control,
            }
            .write_to(&mut full)
            .unwrap();
            assert_eq!(u16::from_le_bytes(full[8..10].try_into().unwrap()), VERSION);
            let restored = PortableSnapshot::read_from(full.as_slice(), memory.len()).unwrap();
            assert_eq!(restored.memory, memory);
            assert_eq!(restored.vm_state, vm);
            assert_eq!(restored.policy, policy);
            assert_eq!(restored.control_state, control);
            assert_eq!(restored.sdk.unwrap().events, sdk.events);
            let mut trailing = full.clone();
            trailing.push(0);
            assert!(PortableSnapshot::read_from(trailing.as_slice(), memory.len()).is_err());
            let mut corrupt = full;
            let end = corrupt.len() - 1;
            corrupt[end] ^= 1;
            assert!(PortableSnapshot::read_from(corrupt.as_slice(), memory.len()).is_err());
            let sparse = encode_sparse_sidecar(&SparsePortableSidecarRef {
                vm_state: &vm,
                sdk: Some(&sdk),
                policy: &policy,
                at: 23,
                sdk_events: 2,
                trace_events: 17,
                trace_schedules: 5,
                event_history: None,
                tainted: true,
                base_ram_digest: [0xa5; 32],
                state_blob_suffix: b"suffix",
                control_state: control,
            })
            .unwrap();
            assert_eq!(
                u16::from_le_bytes(sparse[8..10].try_into().unwrap()),
                SPARSE_VERSION
            );
            let restored = decode_sparse_sidecar(&sparse).unwrap();
            assert_eq!(restored.vm_state, vm);
            assert_eq!(restored.policy, policy);
            assert_eq!(restored.control_state, control);
            assert_eq!(restored.sdk.unwrap().events, sdk.events);
            assert_eq!(restored.state_blob_suffix, b"suffix");
            let mut trailing = sparse.clone();
            trailing.push(0);
            assert!(decode_sparse_sidecar(&trailing).is_err());
            let mut huge = sparse;
            huge[12..20].copy_from_slice(&u64::MAX.to_le_bytes());
            assert!(matches!(
                decode_sparse_sidecar(&huge),
                Err(PortableSnapshotError::Length {
                    section: "vm_state",
                    ..
                })
            ));
        }
    }

    #[test]
    #[cfg_attr(
        miri,
        ignore = "161 MiB sparse-sidecar boundary regression; native-only allocation is intentional"
    )]
    fn large_sparse_sidecar_preserves_all_sections() {
        let suffix = vec![0xA7; MAX_SPARSE_SIDECAR_LEN + 1];
        let policy = ServiceConfig::default();
        let mut encoded = encode_sparse_sidecar(&SparsePortableSidecarRef {
            vm_state: b"large-vm-state",
            sdk: None,
            policy: &policy,
            at: 23,
            sdk_events: 2,
            trace_events: 17,
            trace_schedules: 5,
            event_history: None,
            tainted: true,
            base_ram_digest: [0xa5; 32],
            state_blob_suffix: &suffix,
            control_state: &[],
        })
        .unwrap();
        assert_eq!(
            u16::from_le_bytes(encoded[8..10].try_into().unwrap()),
            SPARSE_VERSION
        );
        assert!(encoded.len() > MAX_SPARSE_SIDECAR_LEN);

        let decoded = decode_sparse_sidecar(&encoded).unwrap();
        assert_eq!(decoded.vm_state, b"large-vm-state");
        assert_eq!(decoded.state_blob_suffix, suffix);
        drop(decoded);
        drop(suffix);

        encoded[8..10].copy_from_slice(&5_u16.to_le_bytes());
        assert!(matches!(
            decode_sparse_sidecar(&encoded),
            Err(PortableSnapshotError::BadVersion(5))
        ));
    }

    #[test]
    #[cfg_attr(
        miri,
        ignore = "large stream size regression; small SDK codecs run under Miri"
    )]
    fn large_sdk_stream_preserves_every_event() {
        let (memory, vm, mut sdk, policy) = fixture();
        sdk.events = (0..65)
            .map(|at| (at, 9, vec![at as u8; 1024 * 1024]))
            .collect();
        let mut full = Vec::new();
        PortableSnapshotRef {
            memory: &memory,
            vm_state: &vm,
            sdk: Some(&sdk),
            policy: &policy,
            at: 65,
            sdk_events: 65,
            trace_events: 0,
            trace_schedules: 0,
            event_history: None,
            tainted: false,
            state_hash: [0xa5; 32],
            control_state: &[],
        }
        .write_to(&mut full)
        .unwrap();
        assert_eq!(u16::from_le_bytes(full[8..10].try_into().unwrap()), VERSION);
        let restored = PortableSnapshot::read_from(full.as_slice(), memory.len()).unwrap();
        assert_eq!(restored.sdk.unwrap().events, sdk.events);
        drop(full);
        let sparse = encode_sparse_sidecar(&SparsePortableSidecarRef {
            vm_state: &vm,
            sdk: Some(&sdk),
            policy: &policy,
            at: 65,
            sdk_events: 65,
            trace_events: 0,
            trace_schedules: 0,
            event_history: None,
            tainted: false,
            base_ram_digest: [0xa5; 32],
            state_blob_suffix: &[],
            control_state: &[],
        })
        .unwrap();
        assert_eq!(
            u16::from_le_bytes(sparse[8..10].try_into().unwrap()),
            SPARSE_VERSION
        );
        assert_eq!(
            decode_sparse_sidecar(&sparse).unwrap().sdk.unwrap().events,
            sdk.events
        );
    }

    #[test]
    fn huge_version_six_declaration_reads_only_bounded_actual_bytes() {
        let mut header = encoded_with_control_state(b"control");
        header[8..10].copy_from_slice(&VERSION.to_le_bytes());
        header[12..20].copy_from_slice(&0_u64.to_le_bytes());
        header[20..28].copy_from_slice(&(isize::MAX as u64).to_le_bytes());
        header.truncate(116);
        struct BoundedReads<'a> {
            bytes: &'a [u8],
            largest: usize,
        }
        impl Read for BoundedReads<'_> {
            fn read(&mut self, out: &mut [u8]) -> std::io::Result<usize> {
                self.largest = self.largest.max(out.len());
                assert!(
                    out.len() <= 64 * 1024,
                    "declared length used as allocation/read size"
                );
                self.bytes.read(out)
            }
        }
        let mut reader = BoundedReads {
            bytes: &header,
            largest: 0,
        };
        let result = PortableSnapshot::read_from(&mut reader, 0);
        assert!(
            matches!(result, Err(PortableSnapshotError::Io(error)) if error.kind() == std::io::ErrorKind::UnexpectedEof)
        );
        assert_eq!(reader.largest, 64 * 1024);
        header[20..28].copy_from_slice(&u64::MAX.to_le_bytes());
        assert!(matches!(
            PortableSnapshot::read_from(header.as_slice(), 0),
            Err(PortableSnapshotError::Length {
                section: "vm_state",
                ..
            })
        ));
    }

    fn refresh_digest(bytes: &mut [u8]) {
        let body_len = bytes.len() - 32;
        let digest: [u8; 32] = Sha256::digest(&bytes[..body_len]).into();
        bytes[body_len..].copy_from_slice(&digest);
    }

    fn fixture_with_memory_len(
        memory_len: usize,
    ) -> (Vec<u8>, Vec<u8>, SdkSnapshot, ServiceConfig) {
        let memory = (0..=255).cycle().take(memory_len).collect();
        let vm_state = b"strict-vm-state".to_vec();
        let mut recorded_env = channel::RecordedEnv::nominal(0x5a5a_5a5a_5a5a_5a5a);
        recorded_env
            .set_payloads(Some(vec![vec![4, 5], Vec::new()]))
            .unwrap();
        let sdk = SdkSnapshot {
            recorded: recorded_env.snapshot_state().unwrap(),
            events: vec![(7, 3, vec![1, 2, 3]), (11, 9, Vec::new())],
            pending_snapshot: true,
            pending_stop: None,
            coverage_thresholds: BTreeMap::from([(2, 9), (7, 14)]),
        };
        (memory, vm_state, sdk, ServiceConfig::default())
    }

    fn fixture() -> (Vec<u8>, Vec<u8>, SdkSnapshot, ServiceConfig) {
        fixture_with_memory_len(8192)
    }

    #[test]
    fn wire_constants_are_exact_contract_values() {
        assert_eq!(MAGIC, *b"HMSNAP01");
        assert_eq!(VERSION, 11);
        assert_eq!((FLAG_SDK, FLAG_TAINTED, KNOWN_FLAGS), (1, 2, 3));
        assert_eq!(MAX_VM_STATE_LEN, 16 * 1024 * 1024);
        assert_eq!(MAX_SDK_LEN, 64 * 1024 * 1024);
        assert_eq!(MAX_CONTROL_LEN, MAX_SDK_LEN);
        assert_eq!(MAX_POLICY_LEN, 1024 * 1024);
        assert_eq!(SPARSE_MAGIC, *b"HMSSNAP1");
        assert_eq!(SPARSE_VERSION, 15);
        assert_eq!(
            (
                SPARSE_FLAG_SDK,
                SPARSE_FLAG_TAINTED,
                SPARSE_FLAG_TARGET_PAGES,
                SPARSE_KNOWN_FLAGS,
            ),
            (1, 2, 4, 7)
        );
        assert_eq!(MAX_SUFFIX_LEN, 16 * 1024 * 1024);
        assert_eq!(
            MAX_SPARSE_SIDECAR_LEN,
            MAX_VM_STATE_LEN
                + MAX_SDK_LEN
                + MAX_CONTROL_LEN
                + MAX_POLICY_LEN
                + MAX_SUFFIX_LEN
                + 201
        );

        for old_version in (1..VERSION).chain([VERSION + 1]) {
            let mut old = encoded();
            old[8..10].copy_from_slice(&old_version.to_le_bytes());
            refresh_digest(&mut old);
            assert!(matches!(
                PortableSnapshot::read_from(old.as_slice(), 8192),
                Err(PortableSnapshotError::BadVersion(version)) if version == old_version
            ));
        }
    }

    fn encoded_with_memory_len(memory_len: usize) -> Vec<u8> {
        let (memory, vm_state, sdk, policy) = fixture_with_memory_len(memory_len);
        let mut bytes = Vec::new();
        PortableSnapshotRef {
            memory: &memory,
            vm_state: &vm_state,
            sdk: Some(&sdk),
            policy: &policy,
            at: 23,
            sdk_events: 2,
            trace_events: 17,
            trace_schedules: 5,
            event_history: None,
            tainted: true,
            state_hash: [0xa5; 32],
            control_state: &[],
        }
        .write_to(&mut bytes)
        .unwrap();
        bytes
    }

    fn encoded() -> Vec<u8> {
        encoded_with_memory_len(8192)
    }

    fn encoded_with_control_state(control_state: &[u8]) -> Vec<u8> {
        let (memory, vm_state, sdk, policy) = fixture();
        let mut bytes = Vec::new();
        PortableSnapshotRef {
            memory: &memory,
            vm_state: &vm_state,
            sdk: Some(&sdk),
            policy: &policy,
            at: 23,
            sdk_events: 2,
            trace_events: 17,
            trace_schedules: 5,
            event_history: None,
            tainted: true,
            state_hash: [0xa5; 32],
            control_state,
        }
        .write_to(&mut bytes)
        .unwrap();
        bytes
    }

    #[test]
    fn compare_portable_execution_ignores_trace_metadata() {
        for original in [encoded_with_control_state(b"control"), encoded()] {
            let trace_start = 68;
            let mut changed = original.clone();
            changed[trace_start..trace_start + 8].copy_from_slice(&u64::MAX.to_le_bytes());
            changed[trace_start + 8..trace_start + 16]
                .copy_from_slice(&(u64::MAX - 1).to_le_bytes());
            refresh_digest(&mut changed);
            let comparison = compare_portable_execution_state(&original, &changed, 8192).unwrap();
            assert!(comparison.equal);
            assert_eq!(comparison.left_trace_events, 17);
            assert_eq!(comparison.right_trace_events, u64::MAX);
            assert_eq!(comparison.left_trace_schedules, 5);
            assert_eq!(comparison.right_trace_schedules, u64::MAX - 1);
        }
    }

    #[test]
    fn compare_portable_execution_rejects_execution_and_version_differences() {
        let left = encoded_with_control_state(b"control");
        let vm_state_start = 116 + 8192;
        let vm_state_len = u64::from_le_bytes(left[20..28].try_into().unwrap()) as usize;
        let sdk_len = u64::from_le_bytes(left[28..36].try_into().unwrap()) as usize;
        let sdk_last_threshold = vm_state_start + vm_state_len + sdk_len - 8;
        for index in [
            52,
            60,
            84,
            116,
            vm_state_start,
            sdk_last_threshold,
            left.len() - 34,
        ] {
            let mut right = left.clone();
            right[index] ^= 1;
            refresh_digest(&mut right);
            let comparison = compare_portable_execution_state(&left, &right, 8192).unwrap();
            assert!(!comparison.equal, "byte index {index}");
        }

        let mut old = left.clone();
        old[8..10].copy_from_slice(&4_u16.to_le_bytes());
        assert!(matches!(
            compare_portable_execution_state(&old, &left, 8192),
            Err(PortableSnapshotError::BadVersion(4))
        ));
    }

    #[test]
    fn compare_portable_execution_rejects_invalid_digest_in_trace_metadata() {
        let left = encoded_with_control_state(b"control");
        let mut right = left.clone();
        right[68] ^= 1;
        for (expected, actual) in [(&left, &right), (&right, &left)] {
            assert!(matches!(
                compare_portable_execution_state(expected, actual, 8192),
                Err(PortableSnapshotError::DigestMismatch)
            ));
        }
    }

    #[test]
    fn compare_portable_execution_rejects_trailing_bytes() {
        let left = encoded_with_control_state(b"control");
        let mut right = left.clone();
        right.push(0);
        assert!(matches!(
            compare_portable_execution_state(&left, &right, 8192),
            Err(PortableSnapshotError::Malformed("trailing bytes"))
        ));
    }

    fn sparse_sidecar_fixture() -> Vec<u8> {
        let (_, vm_state, sdk, policy) = fixture();
        encode_sparse_sidecar(&SparsePortableSidecarRef {
            vm_state: &vm_state,
            sdk: Some(&sdk),
            policy: &policy,
            at: 23,
            sdk_events: 2,
            trace_events: 17,
            trace_schedules: 5,
            event_history: None,
            tainted: true,
            base_ram_digest: [0xa5; 32],
            state_blob_suffix: b"canonical-suffix",
            control_state: &[],
        })
        .unwrap()
    }

    fn sparse_sidecar_fixture_with_control_state(control_state: &[u8]) -> Vec<u8> {
        let (_, vm_state, sdk, policy) = fixture();
        encode_sparse_sidecar(&SparsePortableSidecarRef {
            vm_state: &vm_state,
            sdk: Some(&sdk),
            policy: &policy,
            at: 23,
            sdk_events: 2,
            trace_events: 17,
            trace_schedules: 5,
            event_history: None,
            tainted: true,
            base_ram_digest: [0xa5; 32],
            state_blob_suffix: b"canonical-suffix",
            control_state,
        })
        .unwrap()
    }

    #[test]
    fn sparse_sidecar_is_versioned_non_memory_state_only() {
        let bytes = sparse_sidecar_fixture();
        assert_eq!(&bytes[..8], b"HMSSNAP1");
        assert_eq!(
            u16::from_le_bytes(bytes[8..10].try_into().unwrap()),
            SPARSE_VERSION
        );
        let decoded = decode_sparse_sidecar(&bytes).unwrap();
        assert_eq!(decoded.vm_state, b"strict-vm-state");
        assert_eq!(decoded.sdk.as_ref().unwrap().events.len(), 2);
        assert_eq!(decoded.state_blob_suffix, b"canonical-suffix");
        assert_eq!(decoded.at, 23);
        assert_eq!(decoded.sdk_events, 2);
        assert_eq!(decoded.trace_events, 17);
        assert_eq!(decoded.trace_schedules, 5);
        assert!(decoded.tainted);
        assert_eq!(decoded.base_ram_digest, [0xa5; 32]);
        assert!(decoded.control_state.is_empty());
        assert!(!bytes.windows(4).any(|tag| tag == b"MEM\0"));
        assert!(!bytes.windows(4).any(|tag| tag == b"SHA2"));
    }

    #[test]
    fn complete_snapshot_round_trips_multiple_control_states() {
        for control_state in [
            vec![0x01],
            vec![0x00, 0xfe, 0xa5],
            (0u8..=255).collect::<Vec<_>>(),
        ] {
            let bytes = encoded_with_control_state(&control_state);
            assert_eq!(
                u16::from_le_bytes(bytes[8..10].try_into().unwrap()),
                VERSION
            );
            assert_eq!(
                u64::from_le_bytes(bytes[44..52].try_into().unwrap()),
                control_state.len() as u64
            );
            let decoded = PortableSnapshot::read_from(bytes.as_slice(), 8192).unwrap();
            assert_eq!(decoded.control_state, control_state);

            let mut reencoded = Vec::new();
            PortableSnapshotRef {
                memory: &decoded.memory,
                vm_state: &decoded.vm_state,
                sdk: decoded.sdk.as_ref(),
                policy: &decoded.policy,
                at: decoded.at,
                sdk_events: decoded.sdk_events,
                trace_events: decoded.trace_events,
                trace_schedules: decoded.trace_schedules,
                event_history: decoded.event_history,
                tainted: decoded.tainted,
                state_hash: decoded.state_hash,
                control_state: &decoded.control_state,
            }
            .write_to(&mut reencoded)
            .unwrap();
            assert_eq!(reencoded, bytes);
        }
    }

    #[test]
    fn sparse_sidecar_round_trips_multiple_control_states() {
        for control_state in [
            vec![0x01],
            vec![0x00, 0xfe, 0xa5],
            (0u8..=255).collect::<Vec<_>>(),
        ] {
            let bytes = sparse_sidecar_fixture_with_control_state(&control_state);
            assert_eq!(
                u16::from_le_bytes(bytes[8..10].try_into().unwrap()),
                SPARSE_VERSION
            );
            assert_eq!(
                u64::from_le_bytes(bytes[44..52].try_into().unwrap()),
                control_state.len() as u64
            );
            let decoded = decode_sparse_sidecar(&bytes).unwrap();
            assert_eq!(decoded.control_state, control_state);

            let reencoded = encode_sparse_sidecar(&SparsePortableSidecarRef {
                vm_state: &decoded.vm_state,
                sdk: decoded.sdk.as_ref(),
                policy: &decoded.policy,
                at: decoded.at,
                sdk_events: decoded.sdk_events,
                trace_events: decoded.trace_events,
                trace_schedules: decoded.trace_schedules,
                event_history: decoded.event_history,
                tainted: decoded.tainted,
                base_ram_digest: decoded.base_ram_digest,
                state_blob_suffix: &decoded.state_blob_suffix,
                control_state: &decoded.control_state,
            })
            .unwrap();
            assert_eq!(reencoded, bytes);
        }
    }

    #[test]
    fn complete_snapshot_control_state_is_bounded_trailing_and_authenticated() {
        let good = encoded_with_control_state(&[1, 2, 3]);

        let mut missing = good.clone();
        missing[44..52].copy_from_slice(&0_u64.to_le_bytes());
        refresh_digest(&mut missing);
        assert!(PortableSnapshot::read_from(missing.as_slice(), 8192).is_err());

        let mut oversized = good.clone();
        oversized[44..52].copy_from_slice(&u64::MAX.to_le_bytes());
        assert!(matches!(
            PortableSnapshot::read_from(oversized.as_slice(), 8192),
            Err(PortableSnapshotError::Length {
                section: "control_state",
                ..
            })
        ));

        let mut truncated = good.clone();
        truncated.truncate(truncated.len() - 1);
        assert!(PortableSnapshot::read_from(truncated.as_slice(), 8192).is_err());

        let mut trailing = good.clone();
        trailing.push(0);
        assert!(matches!(
            PortableSnapshot::read_from(trailing.as_slice(), 8192),
            Err(PortableSnapshotError::Malformed("trailing bytes"))
        ));

        let mut corrupted = good;
        let body_last = corrupted.len() - 34;
        corrupted[body_last] ^= 1;
        assert!(matches!(
            PortableSnapshot::read_from(corrupted.as_slice(), 8192),
            Err(PortableSnapshotError::DigestMismatch)
        ));
    }

    #[test]
    fn sparse_sidecar_control_state_is_bounded_trailing_and_total() {
        let good = sparse_sidecar_fixture_with_control_state(&[1, 2, 3]);

        let mut missing = good.clone();
        missing[44..52].copy_from_slice(&0_u64.to_le_bytes());
        assert!(decode_sparse_sidecar(&missing).is_err());

        let mut oversized = good.clone();
        oversized[44..52].copy_from_slice(&u64::MAX.to_le_bytes());
        assert!(matches!(
            decode_sparse_sidecar(&oversized),
            Err(PortableSnapshotError::Length {
                section: "control_state",
                ..
            })
        ));

        let mut trailing = good.clone();
        trailing.push(0);
        assert!(matches!(
            decode_sparse_sidecar(&trailing),
            Err(PortableSnapshotError::Malformed("sparse sidecar"))
        ));

        for end in 0..good.len() {
            assert!(
                decode_sparse_sidecar(&good[..end]).is_err(),
                "truncated sidecar prefix {end} was accepted"
            );
        }
    }

    #[test]
    fn sparse_sidecar_rejects_version_flags_and_truncation() {
        let original = sparse_sidecar_fixture();
        for end in 0..original.len() {
            assert!(
                decode_sparse_sidecar(&original[..end]).is_err(),
                "truncated sidecar prefix {end} was accepted"
            );
        }
        let mut bad_version = original.clone();
        bad_version[8..10].copy_from_slice(&u16::MAX.to_le_bytes());
        assert!(matches!(
            decode_sparse_sidecar(&bad_version),
            Err(PortableSnapshotError::BadVersion(u16::MAX))
        ));
        for old_version in (1..SPARSE_VERSION).chain([SPARSE_VERSION + 1]) {
            let mut old = original.clone();
            old[8..10].copy_from_slice(&old_version.to_le_bytes());
            assert!(matches!(
                decode_sparse_sidecar(&old),
                Err(PortableSnapshotError::BadVersion(version)) if version == old_version
            ));
        }
        let mut bad_flags = original;
        bad_flags[10..12].copy_from_slice(&0x8000_u16.to_le_bytes());
        assert!(matches!(
            decode_sparse_sidecar(&bad_flags),
            Err(PortableSnapshotError::BadFlags)
        ));
    }

    #[test]
    fn sparse_sidecar_optional_flags_are_independent() {
        let (_, vm_state, sdk, policy) = fixture();
        for (has_sdk, tainted) in [(false, false), (true, false), (false, true), (true, true)] {
            let bytes = encode_sparse_sidecar(&SparsePortableSidecarRef {
                vm_state: &vm_state,
                sdk: has_sdk.then_some(&sdk),
                policy: &policy,
                at: 23,
                sdk_events: 2,
                trace_events: 17,
                trace_schedules: 5,
                event_history: None,
                tainted,
                base_ram_digest: [0xa5; 32],
                state_blob_suffix: b"canonical-suffix",
                control_state: &[],
            })
            .unwrap();
            let decoded = decode_sparse_sidecar(&bytes).unwrap();
            assert_eq!(decoded.sdk.is_some(), has_sdk);
            assert_eq!(decoded.tainted, tainted);
        }
    }

    #[test]
    fn sparse_sidecar_target_page_digest_is_optional_and_bounded() {
        let vm_state = vm_state::Arm64VmState::default().encode().unwrap();
        let policy = ServiceConfig::default();
        let sidecar = SparsePortableSidecarRef {
            vm_state: &vm_state,
            sdk: None,
            policy: &policy,
            at: 23,
            sdk_events: 0,
            trace_events: 17,
            trace_schedules: 5,
            event_history: None,
            tainted: false,
            base_ram_digest: [0xa5; 32],
            state_blob_suffix: b"canonical-suffix",
            control_state: &[],
        };
        let without = encode_sparse_sidecar(&sidecar).unwrap();
        assert!(matches!(
            sparse_delta_target_commitment(&without),
            Err(PortableSnapshotError::Malformed(
                "sparse delta sidecar lacks target pages digest"
            ))
        ));
        assert_eq!(
            decode_sparse_sidecar(&without).unwrap().target_pages_digest,
            None
        );
        let with = encode_sparse_sidecar_with_target_pages(&sidecar, Some([0x3c; 32])).unwrap();
        assert_ne!(sparse_delta_target_commitment(&with).unwrap(), [0; 32]);
        assert_eq!(with.len(), without.len() + 32);
        assert_eq!(
            decode_sparse_sidecar(&with).unwrap().target_pages_digest,
            Some([0x3c; 32])
        );
        for end in 116..148 {
            let mut truncated = with.clone();
            truncated.drain(end..148);
            assert!(decode_sparse_sidecar(&truncated).is_err());
        }
    }

    #[test]
    fn sparse_sidecar_rejects_each_invalid_required_or_optional_length_as_flags() {
        const FLAGS: std::ops::Range<usize> = 10..12;
        const VM_STATE_LEN: std::ops::Range<usize> = 12..20;
        const SDK_LEN: std::ops::Range<usize> = 20..28;
        const POLICY_LEN: std::ops::Range<usize> = 28..36;

        let original = sparse_sidecar_fixture();
        for range in [VM_STATE_LEN, POLICY_LEN] {
            let mut malformed = original.clone();
            malformed[range].copy_from_slice(&0_u64.to_le_bytes());
            assert!(matches!(
                decode_sparse_sidecar(&malformed),
                Err(PortableSnapshotError::BadFlags)
            ));
        }

        {
            let range = SDK_LEN;
            let mut missing_section = original.clone();
            missing_section[range].copy_from_slice(&0_u64.to_le_bytes());
            assert!(matches!(
                decode_sparse_sidecar(&missing_section),
                Err(PortableSnapshotError::BadFlags)
            ));
        }

        {
            let flag = SPARSE_FLAG_SDK;
            let mut missing_flag = original.clone();
            let flags = u16::from_le_bytes(missing_flag[FLAGS.clone()].try_into().unwrap());
            missing_flag[FLAGS.clone()].copy_from_slice(&(flags & !flag).to_le_bytes());
            assert!(matches!(
                decode_sparse_sidecar(&missing_flag),
                Err(PortableSnapshotError::BadFlags)
            ));
        }
    }

    #[test]
    fn snapshot_and_sparse_encoders_reject_empty_vm_state() {
        let memory = [0_u8; 16];
        let policy = ServiceConfig::default();
        let mut artifact = Vec::new();
        assert!(matches!(
            (PortableSnapshotRef {
                memory: &memory,
                vm_state: &[],
                sdk: None,
                policy: &policy,
                at: 0,
                sdk_events: 0,
                trace_events: 0,
                trace_schedules: 0,
                event_history: None,
                tainted: false,
                state_hash: [0; 32],
                control_state: &[],
            })
            .write_to(&mut artifact),
            Err(PortableSnapshotError::BadFlags)
        ));
        assert!(artifact.is_empty());

        assert!(matches!(
            encode_sparse_sidecar(&SparsePortableSidecarRef {
                vm_state: &[],
                sdk: None,
                policy: &policy,
                at: 0,
                sdk_events: 0,
                trace_events: 0,
                trace_schedules: 0,
                event_history: None,
                tainted: false,
                base_ram_digest: [0xa5; 32],
                state_blob_suffix: b"suffix",
                control_state: &[],
            }),
            Err(PortableSnapshotError::BadFlags)
        ));
    }

    #[test]
    fn snapshot_decoder_rejects_empty_vm_state() {
        let mut malformed = encoded();
        malformed[20..28].copy_from_slice(&0_u64.to_le_bytes());
        refresh_digest(&mut malformed);
        assert!(matches!(
            PortableSnapshot::read_from(malformed.as_slice(), 8192),
            Err(PortableSnapshotError::BadFlags)
        ));
    }

    #[test]
    fn absent_optional_sections_and_clear_flags_round_trip() {
        let memory = vec![0x5a; 32];
        let policy = ServiceConfig::default();
        let mut bytes = Vec::new();
        PortableSnapshotRef {
            memory: &memory,
            vm_state: b"vm",
            sdk: None,
            policy: &policy,
            at: 1,
            sdk_events: 0,
            trace_events: 0,
            trace_schedules: 0,
            event_history: None,
            tainted: false,
            state_hash: [7; 32],
            control_state: &[],
        }
        .write_to(&mut bytes)
        .unwrap();
        let decoded = PortableSnapshot::read_from(bytes.as_slice(), memory.len()).unwrap();
        assert!(decoded.sdk.is_none());
        assert!(!decoded.tainted);
    }

    #[test]
    fn every_presence_flag_must_match_its_section_length() {
        {
            let flag = FLAG_SDK;
            let mut flag_without_section = encoded();
            flag_without_section[10..12].copy_from_slice(&(KNOWN_FLAGS & !flag).to_le_bytes());
            refresh_digest(&mut flag_without_section);
            assert!(matches!(
                PortableSnapshot::read_from(flag_without_section.as_slice(), 8192),
                Err(PortableSnapshotError::BadFlags)
            ));

            let memory = vec![0; 16];
            let policy = ServiceConfig::default();
            let mut section_without_flag = Vec::new();
            PortableSnapshotRef {
                memory: &memory,
                vm_state: b"v",
                sdk: None,
                policy: &policy,
                at: 0,
                sdk_events: 0,
                trace_events: 0,
                trace_schedules: 0,
                event_history: None,
                tainted: false,
                state_hash: [0; 32],
                control_state: &[],
            }
            .write_to(&mut section_without_flag)
            .unwrap();
            section_without_flag[10..12].copy_from_slice(&flag.to_le_bytes());
            refresh_digest(&mut section_without_flag);
            assert!(matches!(
                PortableSnapshot::read_from(section_without_flag.as_slice(), memory.len()),
                Err(PortableSnapshotError::BadFlags)
            ));
        }

        let mut unknown = encoded();
        unknown[10..12].copy_from_slice(&(KNOWN_FLAGS | 0x8000).to_le_bytes());
        refresh_digest(&mut unknown);
        assert!(matches!(
            PortableSnapshot::read_from(unknown.as_slice(), 8192),
            Err(PortableSnapshotError::BadFlags)
        ));
    }

    #[test]
    fn sdk_without_optional_payloads_round_trips() {
        let (_, _, mut sdk, _) = fixture();
        let mut recorded_env = channel::RecordedEnv::nominal(7);
        recorded_env.set_payloads(None).unwrap();
        sdk.recorded = recorded_env.snapshot_state().unwrap();
        let bytes = encode_sdk(&sdk).unwrap();
        assert_eq!(decode_sdk(&bytes).unwrap().remaining_payloads(), None);
    }

    #[test]
    fn sdk_decoder_rejects_impossible_counts_and_trailing_bytes() {
        let (_, _, sdk, _) = fixture();
        let mut impossible = encode_sdk(&sdk).unwrap();
        let recorded_len = u64::from_le_bytes(impossible[..8].try_into().unwrap()) as usize;
        let event_count = 8 + recorded_len + 2;
        impossible[event_count..event_count + 8].copy_from_slice(&u64::MAX.to_le_bytes());
        assert!(matches!(
            decode_sdk(&impossible),
            Err(PortableSnapshotError::Malformed("SDK event count"))
        ));

        let mut trailing = encode_sdk(&sdk).unwrap();
        trailing.push(0);
        assert!(matches!(
            decode_sdk(&trailing),
            Err(PortableSnapshotError::Malformed("SDK"))
        ));
    }

    #[test]
    fn sdk_decoder_rejects_empty_or_noncanonical_coverage_tables() {
        let (_, _, mut sdk, _) = fixture();
        sdk.coverage_thresholds.clear();
        let mut empty = encode_sdk(&sdk).unwrap();
        empty.extend_from_slice(b"COVR");
        empty.extend_from_slice(&0_u64.to_le_bytes());
        assert!(matches!(
            decode_sdk(&empty),
            Err(PortableSnapshotError::Malformed(
                "SDK coverage threshold count"
            ))
        ));

        let (_, _, sdk, _) = fixture();
        let mut descending = encode_sdk(&sdk).unwrap();
        let tag = descending
            .windows(4)
            .position(|window| window == b"COVR")
            .expect("coverage tag");
        let first_thread = tag + 12;
        let second_thread = first_thread + 12;
        descending[first_thread..first_thread + 4].copy_from_slice(&7_u32.to_le_bytes());
        descending[second_thread..second_thread + 4].copy_from_slice(&2_u32.to_le_bytes());
        assert!(matches!(
            decode_sdk(&descending),
            Err(PortableSnapshotError::Malformed("SDK coverage threshold"))
        ));
    }

    #[test]
    fn snapshot_writer_propagates_the_final_flush_error() {
        struct FlushFails(Vec<u8>);
        impl Write for FlushFails {
            fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
                self.0.extend_from_slice(bytes);
                Ok(bytes.len())
            }
            fn flush(&mut self) -> std::io::Result<()> {
                Err(std::io::Error::other("planted flush failure"))
            }
        }

        let memory = [0; 1];
        let policy = ServiceConfig::default();
        let result = PortableSnapshotRef {
            memory: &memory,
            vm_state: b"v",
            sdk: None,
            policy: &policy,
            at: 0,
            sdk_events: 0,
            trace_events: 0,
            trace_schedules: 0,
            event_history: None,
            tainted: false,
            state_hash: [0; 32],
            control_state: &[],
        }
        .write_to(FlushFails(Vec::new()));
        assert!(matches!(result, Err(PortableSnapshotError::Io(_))));
    }

    #[test]
    fn snapshot_writer_flushes_the_body_and_the_complete_artifact() {
        use std::{cell::Cell, rc::Rc};

        struct FlushCounter {
            bytes: Vec<u8>,
            flushes: Rc<Cell<usize>>,
        }
        impl Write for FlushCounter {
            fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
                self.bytes.extend_from_slice(bytes);
                Ok(bytes.len())
            }
            fn flush(&mut self) -> std::io::Result<()> {
                self.flushes.set(self.flushes.get() + 1);
                Ok(())
            }
        }

        let flushes = Rc::new(Cell::new(0));
        let memory = [0; 1];
        let policy = ServiceConfig::default();
        PortableSnapshotRef {
            memory: &memory,
            vm_state: b"v",
            sdk: None,
            policy: &policy,
            at: 0,
            sdk_events: 0,
            trace_events: 0,
            trace_schedules: 0,
            event_history: None,
            tainted: false,
            state_hash: [0; 32],
            control_state: &[],
        }
        .write_to(FlushCounter {
            bytes: Vec::new(),
            flushes: Rc::clone(&flushes),
        })
        .unwrap();
        assert_eq!(flushes.get(), 2);
    }

    #[test]
    fn section_count_bound_uses_division_not_a_loose_product() {
        let mut bytes = 2_u64.to_le_bytes().to_vec();
        bytes.extend_from_slice(&[0; 20]);
        let mut reader = SliceReader::new(&bytes);
        assert!(matches!(
            reader.count("planted count", 20),
            Err(PortableSnapshotError::Malformed("planted count"))
        ));
    }

    #[test]
    fn read_vec_retries_interrupted_short_reads_and_propagates_other_errors() {
        enum Action {
            Bytes(Vec<u8>),
            Error(std::io::ErrorKind),
            Eof,
        }

        struct ScriptedReader {
            actions: Vec<Action>,
            next: usize,
            largest_request: usize,
        }

        impl Read for ScriptedReader {
            fn read(&mut self, output: &mut [u8]) -> std::io::Result<usize> {
                self.largest_request = self.largest_request.max(output.len());
                let action = self
                    .actions
                    .get_mut(self.next)
                    .map(|action| std::mem::replace(action, Action::Eof))
                    .unwrap_or(Action::Eof);
                self.next += 1;
                match action {
                    Action::Bytes(bytes) => {
                        assert!(bytes.len() <= output.len());
                        output[..bytes.len()].copy_from_slice(&bytes);
                        Ok(bytes.len())
                    }
                    Action::Error(kind) => Err(std::io::Error::new(kind, "scripted read")),
                    Action::Eof => Ok(0),
                }
            }
        }

        let mut retrying = ScriptedReader {
            actions: vec![
                Action::Error(std::io::ErrorKind::Interrupted),
                Action::Bytes(vec![0x10, 0x20]),
                Action::Bytes(vec![0x30]),
            ],
            next: 0,
            largest_request: 0,
        };
        assert_eq!(read_vec(&mut retrying, 3).unwrap(), vec![0x10, 0x20, 0x30]);
        assert_eq!(retrying.next, 3);
        assert_eq!(retrying.largest_request, 3);

        let mut failing = ScriptedReader {
            actions: vec![
                Action::Bytes(vec![0x40]),
                Action::Error(std::io::ErrorKind::PermissionDenied),
                Action::Eof,
            ],
            next: 0,
            largest_request: 0,
        };
        assert!(matches!(
            read_vec(&mut failing, 2),
            Err(PortableSnapshotError::Io(error))
                if error.kind() == std::io::ErrorKind::PermissionDenied
        ));
        assert_eq!(failing.next, 2);
    }

    #[test]
    fn complete_snapshot_round_trips_byte_exactly() {
        let bytes = encoded();
        assert_eq!(
            u16::from_le_bytes(bytes[8..10].try_into().unwrap()),
            VERSION
        );
        let decoded = PortableSnapshot::read_from(bytes.as_slice(), 8192).unwrap();
        assert_eq!(decoded.memory, fixture().0);
        assert_eq!(decoded.vm_state, b"strict-vm-state");
        assert_eq!(decoded.sdk.as_ref().unwrap().recorded, fixture().2.recorded);
        assert_eq!(decoded.sdk.as_ref().unwrap().events.len(), 2);
        assert_eq!(
            decoded.sdk.as_ref().unwrap().coverage_thresholds,
            BTreeMap::from([(2, 9), (7, 14)])
        );
        assert_eq!(
            decoded.sdk.as_ref().unwrap().remaining_payloads().unwrap()[0],
            [4, 5]
        );
        assert_eq!(decoded.policy, ServiceConfig::default());
        assert_eq!(decoded.at, 23);
        assert_eq!(decoded.sdk_events, 2);
        assert_eq!(decoded.trace_events, 17);
        assert_eq!(decoded.trace_schedules, 5);
        assert!(decoded.tainted);
        assert_eq!(decoded.state_hash, [0xa5; 32]);
        assert!(decoded.control_state.is_empty());
    }

    #[test]
    fn complete_snapshot_digest_covers_xsave_restore_provenance() {
        fn canonical_xsave_image() -> Vec<u8> {
            let mut image = vec![0; 576];
            image[0..2].copy_from_slice(&0x037Fu16.to_le_bytes());
            image[24..28].copy_from_slice(&0x1F80u32.to_le_bytes());
            image[28..32].copy_from_slice(&0x0000FFFFu32.to_le_bytes());
            image[512..520].copy_from_slice(&3u64.to_le_bytes());
            vmm_backend::arch::x86::canonicalize_xsave(&mut image);
            image
        }

        let encode_vm_state = |restore_bv| {
            vm_state::VmState {
                xsave: vm_state::XsaveImage(canonical_xsave_image()),
                xsave_restore_bv: Some(restore_bv),
                ..Default::default()
            }
            .encode()
            .unwrap()
        };
        let (memory, _, sdk, policy) = fixture();
        let vm_three = encode_vm_state(3);
        let vm_two = encode_vm_state(2);
        assert_eq!(vm_three.len(), vm_two.len());
        assert_ne!(vm_three, vm_two);

        let mut artifact = Vec::new();
        PortableSnapshotRef {
            memory: &memory,
            vm_state: &vm_three,
            sdk: Some(&sdk),
            policy: &policy,
            at: 23,
            sdk_events: 2,
            trace_events: 17,
            trace_schedules: 5,
            event_history: None,
            tainted: true,
            state_hash: [0xa5; 32],
            control_state: &[],
        }
        .write_to(&mut artifact)
        .unwrap();
        let decoded = PortableSnapshot::read_from(artifact.as_slice(), memory.len()).unwrap();
        assert_eq!(decoded.vm_state, vm_three);
        assert_eq!(
            vm_state::VmState::decode(&decoded.vm_state)
                .unwrap()
                .xsave_restore_bv,
            Some(3)
        );

        let header_len = 116;
        let memory_len =
            usize::try_from(u64::from_le_bytes(artifact[12..20].try_into().unwrap())).unwrap();
        let vm_start = header_len + memory_len;
        artifact[vm_start..vm_start + vm_two.len()].copy_from_slice(&vm_two);
        assert!(matches!(
            PortableSnapshot::read_from(artifact.as_slice(), memory.len()),
            Err(PortableSnapshotError::DigestMismatch)
        ));
    }

    #[test]
    fn sparse_sidecar_keeps_standard_xsave_provenance_at_a_fixed_charge_boundary() {
        fn captured_xsave(raw_bv: u64) -> (Vec<u8>, Option<u64>) {
            let mut image = vec![0_u8; 4096];
            image[0..2].copy_from_slice(&0x037f_u16.to_le_bytes());
            image[24..28].copy_from_slice(&0x1f80_u32.to_le_bytes());
            image[28..32].copy_from_slice(&0xffff_u32.to_le_bytes());
            image[512..520].copy_from_slice(&raw_bv.to_le_bytes());
            let restore_bv = vmm_backend::arch::x86::canonicalize_xsave_with_restore_bv(&mut image);
            (image, restore_bv)
        }

        fn vm_state(image: Vec<u8>, restore_bv: Option<u64>) -> vm_state::VmState {
            vm_state::VmState {
                sregs: vm_state::VcpuSregs {
                    flags: 1,
                    ..Default::default()
                },
                xsave: vm_state::XsaveImage(image),
                xsave_restore_bv: restore_bv,
                ..Default::default()
            }
        }

        let (canonical, restore_zero) = captured_xsave(0);
        assert_eq!(restore_zero, Some(0));
        let initial_vm = vm_state(canonical.clone(), Some(0)).encode().unwrap();

        let policy = ServiceConfig::default();
        let control_state = b"control";
        let encode = |vm: &[u8], suffix: &[u8]| {
            encode_sparse_sidecar(&SparsePortableSidecarRef {
                vm_state: vm,
                sdk: None,
                policy: &policy,
                at: 23,
                sdk_events: 2,
                trace_events: 17,
                trace_schedules: 5,
                event_history: None,
                tainted: false,
                base_ram_digest: [0xa5; 32],
                state_blob_suffix: suffix,
                control_state,
            })
            .unwrap()
        };

        const SHARED_STATE_CHUNK_SIZE: usize = 512;
        let without_suffix = encode(&initial_vm, &[]);
        let suffix_len = (SHARED_STATE_CHUNK_SIZE - without_suffix.len() % SHARED_STATE_CHUNK_SIZE)
            % SHARED_STATE_CHUNK_SIZE;
        let suffix = vec![0xa7; suffix_len];
        let initial_sidecar = encode(&initial_vm, &suffix);
        assert_eq!(initial_sidecar.len() % SHARED_STATE_CHUNK_SIZE, 0);
        assert_eq!(
            decode_sparse_sidecar(&initial_sidecar).unwrap().vm_state,
            initial_vm
        );
        assert_eq!(
            vm_state::VmState::decode(&initial_vm)
                .unwrap()
                .xsave_restore_bv,
            Some(0)
        );

        let mut current_len = None;
        for raw_bv in [0_u64, 2, 3] {
            let (image, restore_bv) = captured_xsave(raw_bv);
            assert_eq!(image, canonical);
            assert_eq!(restore_bv, Some(raw_bv));

            let vm = vm_state(image, restore_bv);
            let vm_bytes = vm.encode().unwrap();
            assert_eq!(vm_bytes.len(), initial_vm.len());
            assert_eq!(
                vm_state::VmState::decode(&vm_bytes)
                    .unwrap()
                    .xsave_restore_bv,
                Some(raw_bv)
            );

            let sidecar = encode(&vm_bytes, &suffix);
            assert_eq!(
                u16::from_le_bytes(sidecar[8..10].try_into().unwrap()),
                SPARSE_VERSION
            );
            assert_eq!(sidecar.len(), initial_sidecar.len());
            assert_eq!(sidecar.len() % SHARED_STATE_CHUNK_SIZE, 0);
            let decoded = decode_sparse_sidecar(&sidecar).unwrap();
            assert_eq!(
                vm_state::VmState::decode(&decoded.vm_state)
                    .unwrap()
                    .xsave_restore_bv,
                Some(raw_bv)
            );
            if let Some(previous) = current_len {
                assert_eq!(sidecar.len(), previous);
            } else {
                current_len = Some(sidecar.len());
            }
        }
    }

    #[test]
    fn planted_corruption_in_each_load_bearing_section_is_rejected() {
        let original = encoded();
        const HEADER_LEN: usize = 116;
        let section_len = |offset: usize| {
            let mut bytes = [0; 8];
            bytes.copy_from_slice(&original[offset..offset + 8]);
            usize::try_from(u64::from_le_bytes(bytes)).unwrap()
        };
        let memory_len = section_len(12);
        let vm_state_len = section_len(20);
        let sdk_len = section_len(28);
        let policy_len = section_len(36);
        let memory_start = HEADER_LEN;
        let vm_state_start = memory_start + memory_len;
        let sdk_start = vm_state_start + vm_state_len;
        let policy_start = sdk_start + sdk_len;
        assert_eq!(policy_start + policy_len + 1 + 32, original.len());
        for index in [memory_start, vm_state_start, sdk_start, policy_start] {
            let mut planted = original.clone();
            planted[index] ^= 1;
            assert!(matches!(
                PortableSnapshot::read_from(planted.as_slice(), 8192),
                Err(PortableSnapshotError::DigestMismatch)
            ));
        }
    }

    #[test]
    fn bad_lengths_and_all_truncations_are_total() {
        let memory_len = if cfg!(miri) { 128 } else { 8192 };
        let bytes = encoded_with_memory_len(memory_len);
        for end in 0..bytes.len() {
            assert!(PortableSnapshot::read_from(&bytes[..end], memory_len).is_err());
        }
        let mut oversized = bytes;
        oversized[20..28].copy_from_slice(&u64::MAX.to_le_bytes());
        assert!(matches!(
            PortableSnapshot::read_from(oversized.as_slice(), memory_len),
            Err(PortableSnapshotError::Length {
                section: "vm_state",
                ..
            })
        ));
    }

    #[test]
    fn sdk_coverage_threshold_fields_fail_independently() {
        let (_, _, sdk, _) = fixture();
        let bytes = encode_sdk(&sdk).unwrap();
        let covr = bytes
            .windows(4)
            .position(|window| window == b"COVR")
            .expect("fixture has coverage extension");

        let mut zero = bytes.clone();
        zero[covr + 16..covr + 24].copy_from_slice(&0_u64.to_le_bytes());
        assert!(matches!(
            decode_sdk(&zero),
            Err(PortableSnapshotError::Malformed("SDK coverage threshold"))
        ));

        let mut duplicate = bytes;
        let first_thread = duplicate[covr + 12..covr + 16].to_vec();
        duplicate[covr + 24..covr + 28].copy_from_slice(&first_thread);
        assert!(matches!(
            decode_sdk(&duplicate),
            Err(PortableSnapshotError::Malformed("SDK coverage threshold"))
        ));
    }
    #[test]
    fn pending_decision_must_fit_the_service_frame_in_full_and_sparse_imports() {
        let limit = hypercall_proto::MAX_PAYLOAD - 10;
        for payload_len in [limit, limit + 1] {
            let (memory, vm_state, mut sdk, policy) = fixture();
            sdk.pending_stop = Some(SdkStop::Decision {
                moment: 31,
                seq: 42,
                question: channel::Question::with_request_id(77, 19, vec![0x5a; payload_len])
                    .unwrap(),
            });
            let mut full = Vec::new();
            PortableSnapshotRef {
                memory: &memory,
                vm_state: &vm_state,
                sdk: Some(&sdk),
                policy: &policy,
                at: 31,
                sdk_events: 2,
                trace_events: 0,
                trace_schedules: 0,
                event_history: None,
                tainted: false,
                state_hash: [0; 32],
                control_state: &[],
            }
            .write_to(&mut full)
            .unwrap();
            let imported = PortableSnapshot::read_from(full.as_slice(), memory.len());
            let sparse = encode_sparse_sidecar(&SparsePortableSidecarRef {
                vm_state: &vm_state,
                sdk: Some(&sdk),
                policy: &policy,
                at: 31,
                sdk_events: 2,
                trace_events: 0,
                trace_schedules: 0,
                event_history: None,
                tainted: false,
                base_ram_digest: [0xa5; 32],
                state_blob_suffix: b"suffix",
                control_state: &[],
            })
            .unwrap();
            let sparse = decode_sparse_sidecar(&sparse);
            if payload_len == limit {
                let full_stop = imported.unwrap().sdk.unwrap().pending_stop.unwrap();
                let sparse_stop = sparse.unwrap().sdk.unwrap().pending_stop.unwrap();
                assert_eq!(full_stop, sparse_stop);
                let request = crate::service_transcript::pending_request(&full_stop).unwrap();
                assert_eq!(
                    request.len(),
                    hypercall_proto::HEADER_LEN + hypercall_proto::MAX_PAYLOAD
                );
                assert_eq!(
                    hypercall_proto::decode(&request).unwrap().1.len(),
                    hypercall_proto::MAX_PAYLOAD
                );
            } else {
                assert!(matches!(
                    imported,
                    Err(PortableSnapshotError::Malformed("SDK pending question"))
                ));
                assert!(matches!(
                    sparse,
                    Err(PortableSnapshotError::Malformed("SDK pending question"))
                ));
            }
        }
    }

    #[test]
    fn pending_stops_round_trip_and_reject_truncated_or_unknown_variants() {
        let stops = [
            None,
            Some(SdkStop::Quiescent),
            Some(SdkStop::Assertion {
                id: 5,
                data: vec![8, 9],
            }),
            Some(SdkStop::Decision {
                moment: 31,
                seq: 42,
                question: channel::Question::with_request_id(77, 19, b"choose".to_vec()).unwrap(),
            }),
            Some(SdkStop::CoverageDecision {
                moment: 31,
                seq: 42,
                question: channel::Question::with_request_id(
                    7,
                    channel::SERVICE_COVERAGE_QUANTUM,
                    1_u64.to_le_bytes().to_vec(),
                )
                .unwrap(),
                ready: 2,
            }),
            Some(SdkStop::DeferredDoorbell {
                moment: 31,
                requested_len: 3,
                request: vec![8, 9, 10],
            }),
        ];
        for stop in stops {
            let (memory, vm_state, mut sdk, policy) = fixture();
            sdk.pending_stop = stop.clone();
            let encoded = encode_sdk(&sdk).unwrap();
            let restored = decode_sdk(&encoded).unwrap();
            assert_eq!(restored.pending_stop, stop);
            assert_eq!(restored.recorded.encode(), sdk.recorded.encode());
            assert_eq!(restored.events, sdk.events);
            assert_eq!(restored.coverage_thresholds, sdk.coverage_thresholds);
            let mut full = Vec::new();
            PortableSnapshotRef {
                memory: &memory,
                vm_state: &vm_state,
                sdk: Some(&sdk),
                policy: &policy,
                at: 31,
                sdk_events: 2,
                trace_events: 0,
                trace_schedules: 0,
                event_history: None,
                tainted: false,
                state_hash: [0; 32],
                control_state: &[],
            }
            .write_to(&mut full)
            .unwrap();
            let restored = PortableSnapshot::read_from(full.as_slice(), memory.len()).unwrap();
            assert_eq!(restored.sdk.unwrap().pending_stop, stop);
            let sparse = encode_sparse_sidecar(&SparsePortableSidecarRef {
                vm_state: &vm_state,
                sdk: Some(&sdk),
                policy: &policy,
                at: 31,
                sdk_events: 2,
                trace_events: 0,
                trace_schedules: 0,
                event_history: None,
                tainted: false,
                base_ram_digest: [0xa5; 32],
                state_blob_suffix: b"suffix",
                control_state: &[],
            })
            .unwrap();
            assert_eq!(
                decode_sparse_sidecar(&sparse)
                    .unwrap()
                    .sdk
                    .unwrap()
                    .pending_stop,
                stop
            );
            let mut bytes = Vec::new();
            encode_pending_stop(&mut bytes, stop.as_ref());
            for end in 0..bytes.len() {
                assert!(decode_pending_stop(&mut SliceReader::new(&bytes[..end])).is_err());
            }
        }
        assert!(decode_pending_stop(&mut SliceReader::new(&[6])).is_err());
        let mut bytes = vec![3];
        bytes.extend_from_slice(&[0; 22]);
        bytes.extend_from_slice(&u64::MAX.to_le_bytes());
        assert!(decode_pending_stop(&mut SliceReader::new(&bytes)).is_err());

        let mut deferred = Vec::new();
        encode_pending_stop(
            &mut deferred,
            Some(&SdkStop::DeferredDoorbell {
                moment: 31,
                requested_len: 3,
                request: vec![8, 9, 10],
            }),
        );
        deferred[9..13].copy_from_slice(&4_u32.to_le_bytes());
        assert!(matches!(
            decode_pending_stop(&mut SliceReader::new(&deferred)),
            Err(PortableSnapshotError::Malformed("SDK deferred doorbell"))
        ));
        deferred[9..13].copy_from_slice(&3_u32.to_le_bytes());
        deferred[13..21].copy_from_slice(&((PAGE_SIZE as u64) + 1).to_le_bytes());
        assert!(matches!(
            decode_pending_stop(&mut SliceReader::new(&deferred)),
            Err(PortableSnapshotError::Malformed("SDK deferred doorbell"))
        ));
    }
}

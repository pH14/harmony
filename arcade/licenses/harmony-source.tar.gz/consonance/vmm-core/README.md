<!-- SPDX-License-Identifier: AGPL-3.0-or-later -->

# vmm-core

`vmm-core` is the deterministic VMM above the `vmm-backend::Backend` trait. It
owns the run loop, guest RAM, virtual-time advancement, entropy, device
dispatch, hypercall/control handling, snapshot and branch operations, and
state hashing. Host hypervisor calls stay behind the backend trait; concrete
backend and architecture pairs are selected by the vendor composition roots.

Native AArch64 Linux and macOS builds enable RustCrypto's runtime-dispatched
SHA-256 backend for state hashes and portable snapshot digests. Hosts with SHA2
instructions use them; hosts without them retain the software implementation.
Miri builds retain the software implementation. Hash inputs, digest bytes,
guest CPU policy, and snapshot formats are independent of this host choice.
The dependency feature also applies to other SHA-256 consumers in the same
Cargo dependency graph.

## Run loop

The live X1 real-mode fixture initializes CS, SS and TR segment types explicitly
before execution, rather than inheriting vendor-dependent KVM reset values.
Its checkpoints still hash the complete saved CPU state. The hardware
qualification retains setup and checkpoint witnesses, RAM and normalized logs
as described in [the qualification registry](../../scripts/qualification/README.md).
Production Linux composition also copies the entry state's complete task
register descriptor, including its defined busy 32-bit TSS type, instead of
inheriting the host's KVM reset descriptor.

`tests/linux_snapshot_continuation.rs` exercises the production Linux boot,
completed-boundary capture and full RAM/VM-state restore APIs with the owned
continuation initramfs. The guest's memory, SIMD, x87, clock and entropy
readbacks supply an oracle independently of the snapshot encoder. Bounded O1
also compares the production whole-state hash at READY, DONE and termination;
O2 fixes RAM/SIMD/x87 goldens; O3 repeats two distinct seeds and requires changed
entropy with equal nonentropy outputs and positive continuation work. A separate
`ControlServer` portable snapshot path preserves the cumulative event history;
raw `VmState` restore does not carry that history. The
[qualification adapter](../../scripts/qualification/README.md#composed-linux-continuation)
retains exact artifacts and cross-host admission outcomes. This bounded x86
fixture does not establish a complete backend register inventory or qualify
Arm Linux continuation.

These are strict acceptance obligations, not a claim of universal portability.
At source `9673f33363395f0850cd2cb5e704432d33434180`, the retained
[hardware run](https://github.com/pH14/harmony/actions/runs/39159236856)
passes the AMD local/export and five AMD import arms. One hosted import matches
READY and the independent guest record, then fails the DONE whole-state hash.
The same retained executable and AMD cut reproduce that failure on nested Intel
KVM. Intel records the post-cut `fstpl` address in x87's last-instruction pointer;
the AMD expected state has zero there. The difference reaches guest RAM through
the kernel's saved FPU image, as well as the VCPU and encoded snapshot. Neither
guest-visible state nor RAM is normalized away. The strict cross-vendor oracle
remains failing, so cross-vendor whole-state identity is unqualified. Standard
libraries remain supported; CPU provenance warnings are advisory. This finite
state witness complements the numerical portability limits in
[#733](https://github.com/pH14/harmony/issues/733).

`Vmm::run` repeatedly obtains one backend exit, classifies it through the
architecture vendor, advances virtual time by the assigned integer duration,
dispatches devices and protocol services, and completes any pending backend
operation. Timer deadlines are applied at exit boundaries. An idle guest can
advance to the next deterministic deadline through the same clock; no host
clock is consulted. A guest idling in its polling loop writes the idle register
(arm64) or idle port (x86), which advances the clock the same way as a halt.
Control `Run` and `Exec` set their own idle wake from the active deadline before
each guest step, so a preceding request cannot alter a replayed command's idle
continuation.

The composition layer can inject a host-operation guard into `ControlServer`.
The server checks it before and after each control request, including before
the request's reply is encoded, and attaches it to every fresh or recovery VM.
The VMM checks the same guard before servicing a doorbell and immediately
before writing any service answer to guest memory. Consonance uses this hook
to reject host loader changes without making the execution core depend on a
particular process-loader implementation. The callback receives a bounded
`HostOperationSite` tag for control-before, control-after, SDK request or SDK
response. Tags describe existing call boundaries and add no guard calls or
executable policy; runtime measurement ownership belongs to the composition.

When a `Run` deadline is the earlier idle wake and resumes the guest, control
refuses `RecordedEnv`: the operator's deadline is absent from the input tape,
so that tape alone cannot replay the continuation from genesis. This includes
an idle exit whose own virtual-time cost crosses the deadline. The landed VM
state is still a usable snapshot; replaying that snapshot retains the
`RecordedEnv` refusal, while branching from it starts a new reproducible
origin. A timer or staged input that would wake the guest at the same time
does not cause this refusal. A deadline reached by ordinary guest steps also
does not cause it. An `Exec` request still taints the snapshot timeline.
`Run` with a deadline and `Exec` require a wired virtual clock. An unwired VM
rejects either request before resolving a pending service answer, injecting a
command, or entering the guest; it cannot treat a missing clock as time zero.
An `Exec` request made while an external SDK service answer is pending is
rejected before its command reaches serial input or changes the control state.
Custom service and coverage-quantum requests stop as decisions before guest
response bytes are written. A coverage stop retains the thread, observation,
ready count, and doorbell sequence in the SDK snapshot and whole-state hash.
`Run { resolve }` binds the answer to the request payload, then completes the
original coverage exchange. Invalid quantum answers leave the pending stop and
coverage threshold unchanged.
If an SDK request reaches a `Run` deadline during a chained guest step, control
reports the deadline before answering it. Valid custom service and coverage
requests remain pending decisions. Other doorbells retain their raw request
frame, including malformed requests, without writing a response or changing the
payload cursor, entropy stream, event log, or pvclock registration. The pending
request is part of the whole-state hash and portable snapshot. A later `Run`
dispatches it under the branch's service plan before resuming the guest.
Resolving a pending decision at or after the `Run` deadline leaves its answer
unrecorded and its response page untouched for the next action.
If a backend completion chains a later SDK decision into the same guest step
after virtual time crosses a staged host effect or reseed, control rejects the
decision as an unsatisfiable schedule instead of exposing it before the input.
Further `Run` requests reject that poisoned schedule before resolving the
pending service answer.
An x86 SDK doorbell does not advance virtual time. An effect added at the
moment of an already surfaced decision would run after its live answer but
before that request when replayed from an earlier snapshot. At a deferred raw
doorbell, the effect would run before its response live but after the response
in an unsplit run. `Perturb` rejects either same-moment input without changing
the pending request. A restored pending decision or raw doorbell with an effect
or reseed already due rejects `Run` before consuming the request or writing
response bytes.
If a backend step or scheduled-input application fails after `Run` begins,
control retires the live VM. A failed step can already have advanced virtual
time or changed guest state, so the session cannot mint a reproducer or accept
another run from an unverified continuation.
The failed run's console and SDK events remain readable from a diagnostic
copy without keeping the failed VM executable. Replay starts with fresh
observations.
An `Exec` substrate failure also retires the VM before a snapshot or hash can
certify a partially completed guest step. Its console and SDK events remain
available for diagnosis.
Arm clockevent deadlines require a zero guest-clock offset. Arm guests do not
write that offset, and both full-VM snapshot restore and V-time-only restore
reject a nonzero value before changing live state. This keeps an armed
clockevent in the next-deadline and virtual-time trace schedules.
An Arm guest MMIO transaction against the pvclock frame is rejected before
advancing virtual time unless the VM offers pvclock. An unoffered frame cannot
arm a clockevent that would be absent from the VM snapshot.

The run loop also times each backend run and each exit it services, keyed by
exit reason, address or port, and direction. `ControlServer::host_telemetry`
adds snapshot seal, restore, export and import time and page counts, including
those of VMs the server has already replaced. These are host wall-clock
measurements for performance accounting; they never enter virtual time, state
hashes, or snapshots.

`hash.<site>.calls`, `ram_bytes`, `suffix_bytes`, `metadata_bytes`, `ns` and
`errors` describe physical SHA-256 stages. Sites are `whole_request`,
`checkpoint`, `portable_export`, `portable_import`, `sparse_base`,
`portable_export_envelope` and `portable_import_envelope`. Whole requests and
checkpoints count actual memory-preimage feeds; the portable export/import
sites also include sparse target-page commitments. Sparse-base cache hits do
not start another hash stage. A call starts when its stage is entered, and a
failure retains any bytes already fed. RAM bytes count actual memory slices;
suffix bytes count the whole-state suffix; metadata bytes count domain/length
framing, page indexes and non-RAM portable-envelope sections. Portable envelope
counters include only bytes actually hashed after successful reads/writes,
excluding the trailing recorded digest. Their time includes codec and I/O waits.
Whole-request and checkpoint time also includes vCPU state capture, readiness
checks and suffix encoding; it is not pure digest CPU time.

The leaves attribute each feed once; wrapper requests do not add another
charge. Retiring or replaying a VMM never rewinds these host totals. Backend physical
entry telemetry is merged on the same retirement and failed-restore boundaries,
independently of normalized exit service counts. Snapshot
store verification appears under `snapshot.verify.*`, with distinct BLAKE3
resident-page and VM-state work. Timings are nested diagnostic envelopes across
hashing and storage, not additive elapsed time. Standalone codec/comparison
helpers outside a ControlServer do not report into a server's telemetry. These
fields do not enter event history, portable records, cache identities, hashes,
retention charges or search policy. Existing snapshot page metrics keep their
original meanings.

Sparse delta export holds one snapshot-store read transaction across full
setup/parent/target integrity verification, delta planning, target comparison,
and the first base-RAM commitment calculation. Each distinct resident page is
integrity-hashed once within that export; subsequent exports start fresh
verification even when the base-RAM digest is cached. BLAKE3 resident integrity
checks and the flat SHA-256 base/target commitments retain their separate
purposes and existing encodings. Sparse delta import shares one immutable read
transaction across target comparison and setup/base verification, including a
cached base digest. Metadata and RAM validation still precede service preflight.
That transaction ends before any user service callback. Rebase analysis then
starts fresh resident verification after preflight; the subsequent mutable derive
also retains its own resident/incoming-page checks. No verified-slot set crosses
those boundaries. Thus a retained page can still be checked again after the
callback or during derive; import does not promise one check per page over the
whole operation.

Guest RAM is owned by `Vmm` for the lifetime of the backend. The canonical state
fingerprint and snapshot machinery cover guest memory, vCPU state, device state,
timer state, virtual time, entropy, control state, and protocol state. Vendor
fingerprint encodings cover the complete state records used for restore, while
the complete portable artifact digest covers the same persisted bytes. The
VMST uses the current version 8 wire format; a present `xsave_restore_bv`
intentionally changes the VCPU identity.
Dirty-page drains and resets distinguish unsupported tracking from backend
errors. Unsupported tracking permits a full capture; an operational error
retires the live VMM and fails the snapshot instead of publishing partial state.
Register, event-injection, and component observations also surface backend CPU
read errors instead of reporting a fabricated default state.

Snapshots can be restored into a copy-on-write memory mapping. In-place restore
combines the snapshot difference and the guest dirty set before loading page
contents. The control server holds a store reference on the image the VM last
sealed or restored, so dropping that snapshot's handle keeps the difference
small instead of forcing a full-image copy. The resulting sorted plan borrows integrity-checked store pages and
copies each selected page directly into guest RAM. Page-write validation sorts
small address/reference records, rejects duplicates and invalid ranges before
any write, then coalesces instruction-cache invalidation ranges in the same pass
that copies the pages. It does not sort or allocate temporary page payloads. Portable format
7 preserves pending SDK stops, unanswered service requests, response sequences,
pending host effects and reseeds, the recorded input prefix, schedule failure,
and command nonce. Replay restores these without reseeding or reapplying consumed
inputs; an explicit branch selects a new plan and retains the command nonce.
Control restores borrow the retained SDK snapshot. Replay restores its service
handler and recorded environment once during preparation, before committing CPU
or RAM changes; a preparation failure leaves the live execution intact. The
prepared environment is moved into the restored VM, then its event prefix,
pending stop, pending snapshot flag, and coverage thresholds are restored from
the borrowed snapshot. Branches install their new environment plan while
preserving the same captured SDK metadata. The stored snapshot remains owned by
the server and reusable; the restored VM owns the state it can mutate.
Seeded branches require a wired entropy stream. A branch into a VM without one
is rejected before the live VM is replaced, leaving the session usable.
The branch preparation also checks the service identity and configuration after
the decode seed zero and both branch handler reseeds. A handler that changes its
advertised contract is rejected before CPU or RAM restore, leaving the live
execution intact.
Before the decode-seed probe, branch preparation checks that cloning the new
handler preserves both the original and clone state. It checks the original
again after the decode seed, rejecting shared-state changes before installing
the branch.
Branch and import preparation also compare a handler-only fingerprint of the
live SDK handler's identity, configuration, and state before and after calling
a service factory or restoring a prepared handler. If a factory or shallow
clone changes that live state, the operation fails and poisons the live SDK
channel, so later hashes and snapshots cannot certify the changed session.
This check relies on
the handler snapshot covering all state that can affect future responses;
service factories must not mutate external state outside that captured contract.
Using the handler alone keeps replay and import available when an otherwise
healthy live recording exceeds the SDK snapshot size limits. An already-poisoned
live channel has no valid state to protect and does not block recovery through
replay or import.
The guard checks the channel's poison flag, since a handler can independently
return a `Poisoned` error while the channel is still live.
Control-server imports require both SDK and control-state sections because every
control snapshot captures both; missing sections are rejected before minting a
handle. The SDK hash chunk also binds its captured event history, including
payloads, so replayed `SdkEvents` cannot differ under the same whole-state hash.
The version-7 envelope pins this expanded identity and rejects older versions.
Import reconstructs the hash suffix from validated VM-state,
SDK, and control records. A full import checks its claimed whole-state hash
against RAM and that suffix; a sparse import compares the reconstructed suffix
with its sidecar before deriving pages or minting a handle. Both imports verify
that the installed service factory can instantiate the recorded policy and
restore the captured handler state before committing the snapshot. Sparse
sidecars also carry the source base snapshot's RAM digest. Export and import
compute that digest once per base snapshot and cache it, verifying every
distinct resident base page before reusing the cached digest. Sparse exports
also verify every distinct resident target page, including inherited pages
omitted from a delta. Pages shared by the base and target are hashed once per
export when the base digest is cached; delta export performs this check before
encoding its sidecar and does not repeat it there. The first base-digest
calculation still reads the base pages to compute its SHA-256 identity. A
release microbenchmark on Apple silicon measured 30.11 ms per
base-only check for 8,192 distinct 4 KiB pages (32 MiB) and 0.45 ms when
those frames shared one interned page. Checking that base together with a
target that replaced one quarter of its pages measured 35.90 ms with distinct
content and 1.07 ms with interned content. These checks hash each distinct
resident page once. Cache deltas use setup
as their base. Imports compare the local base digest before deriving pages or a
delta from a nearer snapshot. This rejects an outer archive whose identity was
rewritten to pair source pages with different setup RAM. Sparse validation does
not materialize guest RAM for each import.
The complete portable format is version 9, and the sparse sidecar is version 11;
older sparse sidecars are rejected. A full sparse snapshot also binds the ordered
changed-page numbers and bytes to its sidecar; import verifies them before
deriving pages or minting a handle. Cache-delta sidecars bind the ordered target
page numbers and bytes that differ from setup, independently of the parent or
near snapshot. Import checks this commitment and every supplied page hash
before minting a handle. Together with the setup RAM digest, the commitment
checks reconstructed target RAM; it is not a standalone whole-state hash. Use
a complete portable snapshot when the imported target's whole-state hash must
be verified directly.
Control seals and imports require VM-state
hashing so every restored VM record participates in identity. Standalone VMM
hashing remains optional. When KVM rejects a nonportable XSAVE MXCSR state,
control `Snapshot` returns `SnapshotRefused` and keeps the execution session
available for hashing or further running; the snapshot and restore portability
guard remains in force. A mapped x86 doorbell cannot seal because the
x86 VM-state record has no dedicated doorbell pages; the production dedicated
mapping belongs to arm64 and is preserved in its device record.
Whole-state hashes include this control state and the recorded prefix used for
duplicate-input rejection. The control state includes the separate
`RecordedEnv` refusal caused by an unrecorded operator deadline wake. A
tainted control timeline also contributes a dedicated hash chunk, so an
imported artifact cannot clear either refusal and make `RecordedEnv` available
under the same claimed identity. Writers always emit
the current format, and readers reject older envelopes. Complete reads
allocate incrementally from received bytes, and sparse section lengths are
bounded by the supplied input.
Whole-VM capture preserves pending SDK stops and is side-effect-free for a
pending pvclock registration, carrying its GPA, `armed = false` state, and page
bytes so the next handshake resumes from the same state.
`compare_portable_execution_state` strictly validates two complete artifacts,
then compares their persisted bytes while ignoring only the stored
`trace_events` and `trace_schedules` counters and independently checked envelope
digests. It reports those counters for diagnostics; they are not restore inputs,
and the helper does not change live trace scheduling or establish backend
admissibility or future execution equivalence.
`RecordedEnv` retains the complete payload tape from the branch origin, including
entries already consumed. SDK snapshots separately retain the unread tail, so a
reproducer can replay an earlier snapshot without shifting the payload order.
Control rejects a new fault or service answer if the recorded inputs plus
pending faults and reseeds would exceed the seven MiB reproducer limit.
The seven MiB reproducer budget reserves one MiB for the largest admitted
service handler state in an eight MiB SDK snapshot, so a payload already read
in the live session remains branchable from its origin after answers are added.
Branch admission also reserves the reseed marker created at its snapshot floor
and checks the resulting SDK snapshot, including service handler state. A
service answer must fit both the reproducer and the SDK snapshot. If a handler
later grows beyond snapshot capacity, Snapshot and whole-state Hash return a
recoverable refusal without retiring the VM.
Pvclock-bearing device records explicitly preserve the registered page GPA,
registration capability, and pending-versus-armed handshake state. The current
x86 device format is version 7 and the current arm64 device format is version
17; each uses presence fields so optional devices retain their state without
selecting historical layouts. Both device records preserve unread serial input
in FIFO order. Restore replaces any residual input, and state identity includes
the unread queue even when full snapshot hashing is disabled. The x86 device
identity also includes the UART divisor high byte independently of the DLAB
register window. Restore rejects a device record whose saved DLAB flag
disagrees with the UART line control register before applying device state.
An enabled, unmasked serial interrupt keeps an interruptible
idle guest runnable while its input remains queued.

The architecture-neutral engine record preserves terminal reasons and deferred
SDK reentry state in the current VM-state container. A terminal restore does not
enter the guest again.

X86 CPU capture retains SREGS2 flags and cached PAE PDPTRs, plus debug-register
flags, in the current VM-state records. Cached PDPTRs are distinct from the
current PDPT contents in guest RAM and must survive restore without reloading
them from that memory. Every standard-format XSAVE capture retains the original
`XSTATE_BV` in the tag-15 record, whether or not canonicalization changes the
x87/SSE init-state bits. The value is validated before restore. It is included in
both the vCPU identity and the complete VMST identity through the logical
projection described below. Short or compacted images may omit that optional
provenance field. A
matching fingerprint is not a proof of whole-guest future equivalence; focused
guest-byte coverage remains required.

Hardware continuation coverage depends on the backend and paging mode. AMD
default NPT has an unresolved legacy 32-bit PAE capture divergence
([#314](https://github.com/pH14/harmony/issues/314)); unchanged stopped records
alone do not prove an unchanged guest future. After AMD KVM guest entry in that
mode, VMM and control capture now fail fatally before publishing a snapshot,
and the source vCPU cannot continue. Intel PAE and AMD long-mode capture stay
supported. The hardware qualification requires the AMD refusal path and a
long-mode continuation on both vendors. Its existing XSAVE fixtures use 32-bit
PAE, so they remain required on Intel while their AMD continuation is excluded.
The original AMD NPT witness remains in #314.
AMD long-mode reused-vCPU restore changes guest-authored XSAVE bytes despite
identical saved CPU records. Restore validation now refuses that reuse before
mutation; the control server retries with a fresh VM. The hardware qualification
requires the public VMM witness to prove refusal without changing the source,
and byte-for-byte equality among uninterrupted, save-and-continue, and fresh
restored continuations. The underlying XSAVE behavior remains tracked in
[#307](https://github.com/pH14/harmony/issues/307).

## Architecture boundary

The engine uses only common exits, guest-physical addresses, bytes, and typed
vendor traits. `vendor/x86` supplies the x86 CPU policy, loaders, device
dispatch, and records. `vendor/arm64` supplies the arm64 Image/DTB boot path,
board devices, policy, and records. The arm64 vendor is also used to exercise
the additive architecture seam on portable mocks and QEMU.

The x86 xAPIC MMIO page accepts only 4-byte register accesses. Other widths
fail before advancing virtual time or changing the modeled LAPIC, so a wider
write cannot be silently truncated into a register transaction.
Misaligned xAPIC offsets and rejected x86 I/O port accesses also fail before
advancing virtual time. Supported ports keep the same assigned durations once
their ownership and any explicit width constraint have been validated.
The modeled 8259 master and slave command and interrupt-mask ports accept only
byte reads and writes; other widths fail before changing masks or virtual time.
Every V-time-wired VMM maintains a v1 ordered normalized-event commitment:
`count` starts at zero with a zero digest; each completed normalized event
advances a SHA-256 chain under `consonance.ordered-event-history.v1`, committing
the preceding digest, checked cumulative count, event class, payload digest,
virtual time after completion, and ordered interrupt deadline/vector pairs.
Delivery outside an active guest-exit context is rejected before consuming the
clockevent schedule. ARM GIC and trapped-system-register exits normally remain
raw-only. If such an exit actually delivers a clockevent, it becomes an
`irq_delivery` normalized event at that exact boundary, with no V-time charge
and no backend-specific raw payload. The interrupt is neither deferred to the
next normalized exit nor left uncommitted across capture. The association of
an interrupt with its completing event is semantic; local trace event indexes,
schedule indexes, backend debug strings, diagnostic
checkpoint hashes, and session segment labels are excluded. Raw-only backend
exits without semantic delivery do not consume a normalized ordinal. Count
overflow fails the event.
This is a constant-size history commitment, separate from logical VM state;
the existing diagnostic log remains available independently.

Fresh V-time wiring resets history. Capturing/hashing a snapshot and retiring
its diagnostic trace do not advance or reset it. Replay and branch restore the
captured commitment before continuation, regardless of local snapshot IDs or
restore mode. Full portable snapshots (v9) and sparse sidecars (v11) retain its
presence, count and digest independently of the logical state hash. Imports
require a live validator and check availability against its V-time model before
creating a handle. Restore also rejects a mismatch on the actual target.
Unwired VMMs explicitly carry no history. These formats reject older versions.
The control `EventHistory` request reports history only for a wired VMM.
Checksum validation authenticates artifact bytes against corruption; comparing
a replay requires the archived source certificate, not a newly invented history.

The virtual-time LAPIC trace records both the timer deadline and interrupt
vector. Reprogramming either value replaces the active schedule, so a vector
rewrite cannot leave the trace naming an interrupt that the LAPIC will not raise.
Restore checks the live trace's pending event, active clockevent record, and
schedule capacity before changing backend CPU state. A rejected trace restore
therefore leaves the running VM intact, including after a failed guest exit.

Boot does not require a particular host CPU model, stepping, or microcode.
Each architecture supplies a guest machine policy; the backend supplies the
required virtualization capabilities. The x86 runtime boots controlled Linux on stock KVM; instruction interception
patches, Multiboot payloads, and the legacy acceptance runner have been retired.
The x86 policy and snapshot compatibility
rules are documented in [contracts/x86](contracts/x86/README.md).

`boot_linux_nested_host_virtual_time` composes the separate experimental x86
nested-host contract with production `KvmBackend`. It selects KVM-supported
Intel VMX or AMD SVM and binds the vendor's exposed capabilities into snapshot
contract identity. SVM presents AuthenticAMD, revision 1, the supported ASID
count and only NPT, NRIPS, VMCB clean bits, flush-by-ASID and decode assists.
VM_CR and VM_HSAVE_PA use native KVM handling and are saved with all other
stateful MSRs. HWCR reads return the fixed P0-frequency bit for Linux's
invariant-TSC check. SYSCFG reads return zero for AMD's fixed-MTRR boot check,
with DRAM-range modification and memory encryption disabled; writes to either
fixed MSR are rejected. The matching kernel includes both
vendor backends. Nested state is carried through CPU records,
VMST tag 16, raw and component identities, whole-state hashes, and portable
artifacts. Publication requires L1 outside L2 guest mode; the inner VM remains
allocated and VMX remains enabled. `nested-driver` qualifies repeated and cold
outer restores at SDK lifecycle boundaries after inner KVM_RUN has returned.
The ignored `nested_restore_preserves_unsynchronized_vmcs_fields` test uses the
direct nested-host fixture's `harmony_nested_cache_check` mode. Its minimal L2
runner leaves segment fields unread after VM exit, then direct outer restore
must preserve the saved nested payload. L2 counts its exits in DS, and the
restored fixture must run to its last exit, so host-cached L2 segment state
from the detour fails the test. This isolates host VMCS and VMCB cache state
from the production driver's segment-state capture.
The ignored `interrupt_raised_before_nested_entry_reaches_the_nested_host` test
runs the same fixture and raises vector 0xFF each time L1 reads DEBUGCTL with
interrupts disabled before it enters L2. KVM can report an open interrupt
window while that entry is pending; the backend must hold the vector until L1
leaves guest mode, so L1 receives it and L2 never does.
The ignored `restore_before_nested_operation_onto_a_nested_host` test restores
a cut taken before L1 enabled VMX or SVM onto the same vCPU after it did, then
runs the restored guest through the fixture again.
The boxed bringup entry point uses the same composition and capability capture
for the client's dynamically dispatched session backend.

`portable_snapshot::logical_x86_sparse_sidecar` produces a non-mutating identity
projection for recorded nested campaigns. It validates the complete sidecar and
CPU records and applies the existing logical XSAVE restore-bitmap rule: presence
bits for init-valued x87/SSE components normalize, while active components remain
bound. Every other sidecar field remains encoded. The original portable bytes
retain the host restore bitmap and remain the input used for restore.

Sparse-delta cache publication commits to the complete sidecar and target-pages
digest after projecting only that x86 XSAVE metadata or the Arm virtual timer's
captured counter, according to the validated VM-state architecture. Unknown or
invalid CPU records cannot publish. The image prefix and every other sidecar
field remain bound, including SDK, policy, control and trace state; the extent
keeps its original restore bytes.

The non-default `harmony_omit_nested_state` compiler configuration is the qualification negative
control. Snapshot publication replaces captured VMX state with a valid inactive
header; for enabled SVM it discards the saved GIF flag. Raw CPU observations
still capture the real state. Uninterrupted and capture-only cases must pass.
The first restored VMX continuation or SVM control-state readback must fail.
Production builds, including `--all-features`, retain the complete state.
The control requires the explicit compiler flag
`RUSTFLAGS="--cfg harmony_omit_nested_state"`; it is not a Cargo feature.
A portable live-payload publication test fails under that configuration.

## Checks

Portable tests use scripted mock backends and cover the run loop, loaders,
protocol, virtual time, and snapshot/branch behavior. Live tests are selected
by platform and require the corresponding KVM or Hypervisor.framework host.

```sh
cargo test -p vmm-core
cargo clippy -p vmm-core --all-targets -- -D warnings
```

The SHA-256 qualification builds the production VMM and a software-backed
copy into one release executable. The copy uses the same VMM source and the
locked RustCrypto source archive, verified against its Cargo.lock checksum,
under separate package names so Cargo cannot unify the two hashing backends.
Only the control's hashing dependency changes. Neither copy is installed.

```sh
cargo fetch --locked
python3 consonance/vmm-core/qualification/qualify-sha256.py --check
python3 consonance/vmm-core/qualification/qualify-sha256.py
```

`--check` compares digests across padding boundaries, streaming chunk sizes,
unaligned inputs, cloned prefix states, and complete VMM state hashes.
The Snapshot and Restore job runs it without timing thresholds, as do the
macOS Arm64 and Linux Arm64 Qualification jobs of Harmony Host Compatibility.
Backend
selection is checked against the features reported
by the compiler artifacts for the actual build, including cached artifacts. The full run
also reports nine alternating software/native timing pairs for small and large
digests and whole-state hashes over zero and populated RAM from 4 KiB through
128 MiB. Each timed result is checked. ARM timings qualify this build change;
the software control deliberately disables acceleration on every architecture.
These are host hashing costs, not guest execution throughput. The executable's
SHA-256 is printed with the results to bind both arms to the same build.

The contract-cache qualification compares the production x86 or ARM fingerprint with a
same-source VMM copy whose only change bypasses the fingerprint cache. Both use
the same SHA backend in one executable. It checks concurrent first callers,
fresh-process initialization, zero allocations for warmed fingerprint reads,
complete state hashes and CPU/device captures, full-memory restores, and rejection
of a changed contract. ARM checks cover both ASID widths, including concurrent
initialization of the two caches and rejection of cross-width restores. Default
runs count allocations; use `--system-allocator` for timings with the normal
allocator and without allocation instrumentation. In that mode, the allocation
fields are disabled counters and must not be interpreted as allocation counts.
Capture timings cover CPU/device state, while restore timings include comparing
the complete RAM image. These mock-backend measurements do not measure guest
execution or hypervisor entry costs.

```sh
python3 consonance/vmm-core/qualification/qualify-contract.py --check
python3 consonance/vmm-core/qualification/qualify-contract.py --system-allocator
python3 consonance/vmm-core/qualification/qualify-contract.py --architecture arm64 --check
python3 consonance/vmm-core/qualification/qualify-contract.py --architecture arm64
python3 consonance/vmm-core/qualification/qualify-contract.py --architecture arm64 --system-allocator
python3 consonance/vmm-core/qualification/qualify-contract.py --miri
```

The full run reports nine alternating pairs at 4 KiB, 64 KiB, 1 MiB, and
128 MiB RAM. Allocation bytes are cumulative requests, not peak RSS. `--miri`
exercises the qualification allocator, including reallocation and deallocation.

The snapshot-capture qualification compares production control requests with a
same-source VMM copy that restores the two independent CPU captures. Both arms
run in one release executable, whose SHA-256 is printed with the results.

```sh
python3 consonance/vmm-core/qualification/qualify-capture.py --check
python3 consonance/vmm-core/qualification/qualify-capture.py
python3 consonance/vmm-core/qualification/qualify-capture.py --hvf --check
python3 consonance/vmm-core/qualification/qualify-capture.py --hvf
```

The portable check compares complete exported sidecars and full VMM state
hashes for x86 and ARM mock backends, including populated XSAVE and ARM SIMD
state. Snapshot receipts and cleanup are checked on every timed request. The
full run reports nine alternating timing pairs for snapshot-and-release over
16 KiB and 1 MiB RAM, with zero, sparse (every sixteenth page populated), and
dense contents. It also measures standalone public save-and-hash-encode calls.
Setup, VM creation, and export are outside the timed region; RAM hashing and
snapshot-store work are inside. These are snapshot costs, not guest execution
throughput. `--hvf` requires a real Apple silicon host with Hypervisor.framework;
it creates only one VM at a time. Both modes compare the canonical hashes
returned by portable snapshot export, which hashes the stored RAM and the
actual snapshot suffix, as well as standalone VMM hashes. Live HVF
stored sidecars may differ because the hardware virtual counter advances
between captures. Portable checks run without timing thresholds in Snapshot and
Restore and in the macOS Arm64 and Linux Arm64 Qualification jobs of Harmony
Host Compatibility. Hosted macOS runners cannot run the live HVF
qualification because nested HVF is unavailable.

The SDK-capture qualification compares request-local SDK capture reuse against
capturing the environment again for the hash suffix, in one executable:

```sh
python3 consonance/vmm-core/qualification/qualify-sdk-capture.py --check
python3 consonance/vmm-core/qualification/qualify-sdk-capture.py
python3 consonance/vmm-core/qualification/qualify-sdk-capture.py --hvf --check
python3 consonance/vmm-core/qualification/qualify-sdk-capture.py --hvf
```

It compares standalone and exported hashes and complete mock sidecars. Fixtures
cover the default nominal SDK, empty custom handlers, handler states of 4 KiB, 64 KiB, and 1 MiB,
and 256 recorded answers plus 256 pending payloads of 256 bytes each. The
16 KiB guest RAM stays zero-filled. The measured operation is snapshot-and-drop;
setup, VM creation, export, and independent hash reads are outside the timing.
Nine alternating pairs report host snapshot cost, not guest throughput. Live
HVF uses one VM at a time and compares canonical hashes; advancing hardware
counters prevent raw sidecar comparison. CI runs portable checks without timing
thresholds in Snapshot and Restore and in the macOS Arm64 and Linux Arm64
Qualification jobs of Harmony Host Compatibility.

The SDK capture driver also accepts `--encoding` to compare direct encoding into
the canonical hash suffix with the original intermediate-buffer encoder. Both
arms reuse the SDK capture; the only difference is buffer construction. It uses
the same fixtures, hash/sidecar checks, timing boundaries, and optional `--hvf`
mode. Portable `--encoding --check` runs in the same CI jobs. The checked-in
reference encoder also checks all pending-stop variants, pending-snapshot flags,
and empty/populated coverage thresholds against direct encoding in unit tests.
Both comparisons use the host system allocator. Each run prints its allocator, comparison,
and executable identity. The two arms always run inside the same executable.

The control-state capture qualification compares reuse of serialized control
history against serializing it again for storage, in one executable:

```sh
python3 consonance/vmm-core/qualification/qualify-control-capture.py --check
python3 consonance/vmm-core/qualification/qualify-control-capture.py
python3 consonance/vmm-core/qualification/qualify-control-capture.py --hvf --check
python3 consonance/vmm-core/qualification/qualify-control-capture.py --hvf
```

It uses the same snapshot-and-drop timing and hash/sidecar checks as the SDK
capture qualification, with 16 KiB zero RAM. Fixtures exercise an empty plan,
4 KiB, 64 KiB, and 512 KiB of payloads, 64 KiB of recorded answers, and 64 KiB
of pending memory-write effects. Data is split into 256-byte entries. The
pending effects are never executed in the timed region. Portable checks run
in the existing snapshot and ARM host CI jobs without timing thresholds.

Add `--inputs` to compare direct nested input encoding with the prior buffered
encoder, leaving control-state encoding reuse enabled in both arms. The input
reference uses public accessors and the standalone configuration/effect encoders
to reproduce the old framing. Its bytes are also checked by environment unit
tests over all effect variants and tape shapes. The probe uses the host system
allocator, matching the macOS CLI. Each run identifies
the allocator and comparison. CI runs `--inputs --check` without timing limits.

Add `--borrowed` instead of `--inputs` to compare borrowing the recorded history
with cloning it for capture. Both arms keep the direct nested encoder and
control-state serialization reuse. Whole-control hash requests, exported
snapshot hashes, and VMM hashes must agree; mock runs also compare all sidecar
bytes. The `reference` and `optimized` row labels always identify the two arms.
CI runs `--borrowed --check` without timing limits.

The SDK-restore qualification compares this path with a same-source VMM copy
that clones the entire SDK snapshot and restores the replay environment twice.
Both versions run in one release executable, identified by its printed SHA-256.

```sh
python3 consonance/vmm-core/qualification/qualify-restore.py --check
python3 consonance/vmm-core/qualification/qualify-restore.py
```

It checks repeated Replay and Branch requests on mock x86 and ARM machines in
both memcpy and in-place restore modes. Each arm captures the resulting VM and
compares complete sparse sidecars across versions; replay also reproduces its
original sidecar, and neither path changes the reusable source snapshot. The
fixtures have 16 KiB RAM and service-handler states of 0, 4 KiB, 64 KiB, and
1 MiB. A separate history fixture contains 256 recorded answers and 256 pending
payloads of 256 bytes each. The full run reports nine alternating timing pairs. `--filter handler_4096`
repeats just the small-state cases. Timing includes the complete control restore operation; construction, source
snapshot capture, and output comparisons are outside the measured loop. These
measure host restore work above mock backends, not live hypervisor or guest
throughput. The Snapshot and Restore job runs `--check` without timing
thresholds, as do the macOS Arm64 and Linux Arm64 Qualification jobs of
Harmony Host Compatibility.

The x86 exit dispatcher finishes the current instruction's device-access chain
before returning a stopped endpoint. Continuation accesses retain their device,
virtual-time, and trace accounting, but do not enter the next guest instruction
or deliver new scheduled inputs between fragments. Snapshot capture performs no
completion work. A periodic trace checkpoint crossed inside an instruction
lands on its final access; deferred hash consumers use
`virtual_time_checkpoint_due` to identify that exact capture position.

`Vmm::arm_checkpoint_hash_preimage` enables one bounded retained record for
the most recent synchronous checkpoint. The record returned by
`take_checkpoint_hash_preimage` contains the completed trace event index, the
published state hash, exact state-blob suffix, RAM length, and the SHA256 digest
of the `MEM\0 || length_le64 || RAM` prefix. The memory digest reuses a cloned
hash context before appending the suffix; it adds no RAM traversal. It
reuses the checkpoint's existing backend save and does not copy guest RAM or
perform another CPU read; calling the arm method again clears the prior
record. The feature is disabled by default and captures only completed
checkpoint boundaries, so it is suitable for a paired diagnostic that already
retains the corresponding RAM image. Read the record and RAM immediately after
that `step` returns, before advancing or otherwise mutating the VM; the record
alone does not freeze RAM. Hashing retains its original RAM-then-CPU-read order.

`Checks / Consonance` combines the portable contract suite with bounded
hardware checks on every pull request, and `Checks / Consonance / Analysis`
carries the Miri, coverage, mutation and proof work. The KVM job requires the
published snapshot identity/replay matrix and serviced-exit checks. The platform
job compares two complete same-seed Linux execution logs, requiring guest
readiness, nonzero events and zero differences. The scheduled and dispatched
`Checks / Consonance / Hardware Qualification` retains broader serviced-exit,
RF, PAE translation and guest-written XSAVE coverage, including dirty reused
vCPUs, and `Checks / Harmony Workloads / OCI` retains the full-state workload
restore oracle.

Linux snapshot fixtures come from the shared source-keyed platform
publisher. The bounded check requires exact source provenance, verifies the manifest,
and uses its direct Linux fixture. The scheduled/manual producer builds the
Nix kernel once, packages the runtime fixture without another kernel build,
and publishes only after platform replay passes. Execution stays bounded
independently of builds, and failed checks retain diagnostics. Broader repetitions and vendor sampling
remain scheduled/manual. These checks are regression evidence, not a claim that
all XSAVE-presence and AMD NPT PAE behavior is resolved.

`ControlServer::export_sparse_delta(setup, parent, target)` returns a
snapshot's pages over its parent, with their hashes, the pages that returned to
the setup snapshot's content, and the sparse sidecar. The pages borrow the
store. `import_sparse_delta(setup, near, pages, sidecar)` takes a complete
page list over the setup snapshot and derives the imported snapshot from `near`,
writing only the pages where the two differ. Once `near`'s chain reaches the
maximum chain length, the import derives from `setup` instead, so repeated
imports keep the same chain bound as seals. Every supplied page must match its
hash, including a page reused from `near`. The complete page list must match
the sidecar's target-page commitment; a mismatch is refused before a handle is
minted.

Full and sparse portable imports share the VMM's read-only restore preparation
before entering the snapshot store. Invalid engine state, XSAVE provenance,
device records, and clock wiring are rejected before changing the destination
execution. Import requires a live validation target, but its backend check is
for the artifact's shape, not the current vCPU's reuse eligibility. That lets
an AMD session import a valid artifact after guest entry; replay then creates
a fresh VM or refuses in-place reuse before changing CPU or RAM. This preflight
does not replace backend validation or make host ioctl failures transactional.

## Publishing prepared snapshot boundaries

The x86 Linux composition prepares its initial CPU state before publishing the
VM. The VMM prepares each fully serviced exit before checkpoint hashing, and
full-memory and control-server restores prepare after installing RAM and CPU
state. `Vmm::prepare_snapshot` is explicit for low-level callers that construct
or restore CPU state separately from memory; call it only once the complete
boundary is installed. Snapshot reads and hash reads do not enter KVM.
Entering the backend invalidates snapshot publication until exit servicing and
preparation succeed. A failed entry, completion chain, preparation, or live
restore cannot publish a cached CPU image as a new snapshot or hash. Raw backend
register reads remain available to service an exit; they are not snapshot
admission checks.

A control-server snapshot captures the raw CPU state once and uses that same
request-local capture for both the stored VM state and the canonical hash
suffix. Snapshot admission checks still run before publication, and the SDK
snapshot stays between VM-state construction and suffix construction. No guest
execution or backend mutation occurs between these consumers. The raw capture
is discarded after the request; it is not cached for later snapshots. Stored
ARM timer counters and canonical counter normalization retain their distinct
representations. Standalone snapshot and hash reads retain their own capture
and readiness checks.

The same control snapshot also reuses its SDK environment capture when encoding
the canonical hash suffix. The saved handler state, recorded answers, and
pending payloads are captured once per request, after snapshot admission and
before publication. No execution or SDK mutation occurs before suffix encoding.
Standalone hash reads capture their own SDK state; nothing is cached across
requests. SDK capture errors still poison the server before a snapshot is
published. The wire encoding and hashed bytes are unchanged. The SDK record is
encoded directly into the hash suffix; its two nested length fields are filled
from the resulting byte ranges. This avoids temporary record and chunk buffers
while preserving the same framing and independently owned retained SDK state.
When the backend declares a state unsupported for capture, Snapshot, whole-VM
Hash, and Regs reply with `SnapshotRefused` and leave the session available;
unexpected backend failures remain fatal.

A control snapshot encodes its recorded inputs, pending effects/reseeds, failure
state, and execution nonce once. It appends these encoded bytes to the canonical
hash suffix and moves that same encoding into retained snapshot metadata. This
avoids a second serialization of the history and plan; each request still
captures fresh state and retains the same independently owned metadata.
Control capture borrows the recorded input history only until serialization
finishes, avoiding a temporary deep copy of its payloads and answers. Pending
plans are still assembled independently. Decoding always produces owned inputs,
and retained snapshots never borrow the live controller.

KVM preparation round-trips FPU state without executing a guest instruction,
while preserving modeled RAM, CPU fields other than hardware XSAVE presence,
and execution accounting. Raw XSAVE presence remains restoration metadata; the
logical projection below decides how it enters identity. The execution
requirement is one qualified host core type for related boots and restores;
see the backend README for affinity admission and its limits. On Linux KVM
hosts reporting P-core/E-core topology, the captured
class is bound into the x86 snapshot contract and the raw CPU state. Portable
import and raw backend restore refuse a different class before changing the
guest. A changed thread-affinity mask also refuses capture and restore. Hosts
without reported class masks and without a hybrid CPUID indication require
placement qualification; a host reporting hybrid CPUID without the masks is
refused. Cross-host placement and broader XSAVE state lie outside the
qualified set.
A mock-backed test runs in ordinary CI to enforce the VMM contract binding.
The live cross-class qualification runs during pre-push on a Linux KVM host
only when both P and E cores are accessible; it fails if that requirement
disappears before the test starts.

The supported x86 workload is the shipped 64-bit Linux kernel and initramfs on
a 64-bit host. Application bitness is separate: 32-bit compatibility-mode
userspace can run under long-mode paging. [AMD's architecture manual](https://www.amd.com/content/dam/amd/en/documents/processor-tech-docs/programmer-references/24593.pdf)
requires CR4.PAE in long mode, so the bit does not, by itself, select legacy
32-bit PAE paging. Linux-composed VMs reject
CPU records without active long-mode paging (CR0.PG, CR4.PAE, EFER.LMA) when
publishing snapshots and before restoring snapshots. State hashes can still
observe transient CPU modes during Linux boot; a hash is not a snapshot
admission decision. Generic
VMM instances remain available for synthetic CPU-mode diagnostics. The backend
does not expose every guest mode transition as a checked boundary, so these
admission checks do not confine
an arbitrary kernel that changes modes between observed boundaries.

The shipped Linux guest follows architectural page-table update and invalidation
rules and cannot replace its kernel through kexec. Required PAE continuation
coverage reloads CR3 after a guest-authored PDPT update, comparing reference,
captured, cold-restored, and reused-restored endpoints. Intel's cached-PDPTR
preservation regression remains required. AMD NPT fixtures that rely on stale
PDPTR persistence without invalidation remain recorded informational diagnostics;
they do not define the supported Linux guest contract. The loader's 64-bit entry
check does not establish the later mode behavior of arbitrary supplied kernels.

The required MMIO full-snapshot fixture creates active XMM0 data with a guest
PCMPEQD before the LAPIC read/modify/write. It checks the captured value and a
subsequent guest MOVDQU store, while retaining exact RAM, CPU, serialized state
and hash comparisons and the MMIO completion/timing assertions. There is no
extra guest exit, warmup or host restore-bitmap forcing. The original init-only
program remains an informational characterization using the same exercise.

### Published XSAVE identity check

`vendor::x86::logical_identity_live_tests::public_snapshot_replay_recapture_preserves_xsave_identity`
exercises
`ControlServer`'s published Snapshot, Replay and portable export APIs. It mints a
new snapshot after restore, rather than re-exporting the original handle. The
required fixed-core CI check covers raw init seeds 0/2/3, XCR0 3/7, initial and
serviced UART boundaries, init and active register values, fresh and verified
in-place restores, repeated captures, and three additional host-only preparation
entries. The guest dirties FP/vector/MXCSR state before replay. Independent
single-component changes to x87, XMM, YMM and MXCSR must change published identity
with identical guest RAM and program bytes.

The check compares logical hashes and complete persisted execution state, then
resumes both paths to the same guest endpoint. Comparisons validate each artifact
before projecting only the permitted raw restoration metadata. RAM, canonical
CPU state, MXCSR, devices and control state remain part of the comparison. The
existing diagnostic trace counters remain excluded across replay. Artifact
checksums still cover every original byte, including raw restoration metadata.

On fixed-core AMD, an extra host-only preparation entry can change the published
hash with no guest instruction executed. The raw restore bitmap changes from 0
to 2 while RAM and every other serialized CPU field stay identical. The ordinary
two-boot Linux check reproduces the same field difference: matching event context
and RAM digest, and exactly one changed byte in VCPU's XSRB field. RAM is
compared there by digest rather than bytewise. Intel's fixed-P-core matrix
passes. Avoiding duplicate preparation calls does not remove the difference, and
a passing retry does not establish raw identity stability across extra entries.

Logical identity separates logical state from raw restoration metadata.
`logical_xsave_restore_bv` validates the standard XSAVE image and its raw
provenance, then removes only raw x87/SSE presence bits for components already
absent from the canonical image. The condition is decided from the snapshot
bytes alone, so it needs no list of approved guests. Every other presence bit,
canonical component byte, MXCSR and all non-CPU state remain significant. Both
VCPU and VMST hashing use the same projection through
`Vendor::logical_identity_vcpu`. `save_vm_state` and portable exports retain the
complete original metadata for restoration: equal logical identities can
therefore have different artifact bytes and artifact checksums.

Equal logical identity is not a proof that the guests are interchangeable. It
assumes the admitted kernel and userspace execution contract: no unreviewed
executable code, code mutation, raw userspace XSAVE-family saves, or XGETBV with
ECX=1. It does not qualify arbitrary ROMs, SQL, injected machine state or
external events merely because the initial image matches.

The published API regression remains required on AMD and Intel under supported
core placement. A successful regression does not establish raw bitmap stability
or support for arbitrary guest code.

An SDK coverage exchange checks the thread's expected threshold, asks the
scheduler service which thread runs, and asks environment service 4 for the
next quantum. The next threshold is part of the SDK snapshot. A thread whose
count restarts at the first threshold gets a fresh entry, because Linux reuses
thread IDs. A zero, malformed or overflowing quantum leaves the environment and
every threshold unchanged.

## ARM executable RAM restore qualification

`tests/arm64_executable_restore.rs` promotes the public-VMM experiment in
[issue #633](https://github.com/pH14/harmony/issues/633) into a registered Linux
ARM hardware test. It compares guest-authored PL011 bytes for cold A/B,
uninterrupted B, capture-only B, fresh-restored B, and a warmed reused VM
alternating A/B executable page contents. A separate RAM-only restoration
control avoids CPU restoration as a cache-maintenance confounder. Every
transition checks that only executable page 0 differs, that full restored RAM
matches, and that the guest RAM allocation stays in place. The guest loops back
to the same instruction address; no RAM remapping is requested. A portable
negative control rejects stale, missing and extra observation bytes.

Before any guest entry, the fixture sets `SCTLR_EL1.I` through the public state
restore API and checks the captured control value, including after warmup and
restoration. Stage-1 translation stays disabled. The four-instruction guest
loops directly to the variant instruction, without a cache-enabling prologue or
cache-maintenance instruction. Thus the RAM-only control never re-enables the
cache between the host write and guest fetch. The test pins its thread to its
current allowed CPU before constructing any VM, verifies placement during the
restore loops, and restores the original affinity on exit. External `taskset`
selects which core class it exercises; ordinary registered invocation also
remains pinned. Output records CPU number, available sysfs MIDR and raw host
MMFR2, and observed guest SCTLR. Missing sysfs register information is reported
as unavailable; the test does not infer host stage-2 FWB or CTR cache-coherence
features from virtualized guest IDs. Guest instruction-cache enablement and CPU
placement are controls, not proof that a particular host retains stale lines.
A passing result remains specific to its actual host/kernel/cache behavior.

Run on a Linux ARM host with accessible KVM, pinning each qualified core class:

```sh
taskset -c 0 cargo test --locked -p vmm-core --test arm64_executable_restore live::executable_ram_restores_match_guest_continuations -- --ignored --exact --nocapture
```

Require exactly one passed test. An unavailable KVM device fails the requested
hardware test; an empty test selection on another platform is not qualification.
Record source revision, kernel, CPU/core placement and output with the result.
The earlier public-path experiment passed on Linux 6.18.43-current-arm64 on
Cortex-A720 and Cortex-A520 cores; those negative observations do not establish
cache coherence on other hosts or kernels. ARM KVM still inherits the default
instruction-cache hook, and #633 remains an investigation without a confirmed
stale-instruction witness. This fixture does not qualify cross-host restore,
arbitrary code mutation, or continuously enforced executable admission.

### x86 capability admission

The contract adapter declares the following CPUID bits as supplied by the VMM
when constructing `CpuidModel.emulated_features`. They remain in the frozen
guest model; this metadata tells the KVM substrate which host bits are not
required. Every other advertised capability word is checked against KVM's
supported or emulated inventory, including all scalar/SIMD instruction flags.

| Contract fields | Provider and implementation |
| --- | --- |
| `6:EAX[2]` ARAT | Userspace LAPIC timer scheduling uses virtual time, independent of host power states (`lapic`, x86 dispatch) |
| `7:EBX[1]` TSC_ADJUST | `IA32_TSC_ADJUST` reads/writes use the virtual-clock state (`vendor/x86/dispatch.rs`) |
| `7:EDX[29]` ARCH_CAPABILITIES | Contract MSR `0x10a` has an explicit fixed userspace read disposition, handled by MSR dispatch |
| `80000007:EDX[8]` invariant TSC | Virtual TSC rate comes from the contract clock, independent of host frequency (`vtime`, x86 dispatch) |

The current contract requires these remaining capabilities from KVM's
supported inventory, or its explicit instruction-emulation inventory:

| Contract feature word | Required capabilities |
| --- | --- |
| `1:ECX` | SSE3, PCLMULQDQ, SSSE3, FMA, CMPXCHG16B, PCID, SSE4.1, SSE4.2, MOVBE, POPCNT, AES, XSAVE, AVX, F16C |
| `1:EDX` | FPU, VME, DE, PSE, TSC, MSR, PAE, CMPXCHG8B, APIC, SEP, MTRR, PGE, CMOV, PAT, PSE36, CLFLUSH, MMX, FXSR, SSE, SSE2 |
| `7:EBX` | FSGSBASE, BMI1, AVX2, SMEP, BMI2, ERMS, INVPCID, ADX, SMAP, CLFLUSHOPT |
| `80000001:ECX` | LAHF/SAHF in long mode, ABM/LZCNT, PREFETCHW |
| `80000001:EDX` | SYSCALL/SYSRET, NX, 1-GiB pages, RDTSCP, long mode |
| `D.0`, `D.2` | x87/SSE/YMM state; YMM component size 256 and standard offset 576 |

Policy version 7 explicitly clears self-snoop (`1:EDX[27]`) on every host and
changes the ordinary and nested contract fingerprints. The bit describes
conflicting-memory-type cache behavior, not an instruction enable. AMD does
not enumerate the Intel bit, and the stateful guest MTRR/PAT surface does not
establish equivalent alias semantics. It is neither a host intersection nor a
userspace-emulation exemption. Older snapshots are rejected by contract
identity before restore. Standard instruction features are unchanged.
KVM recommends always setting the inverse x87 absence flags `7:EBX[6,13]`;
these describe unavailable legacy x87 fields rather than native capabilities.

This checks the complete requested capability words, so newly requested bits
in these words automatically require admission too. KVM may provide a feature
through virtualization rather than native execution: 1-GiB pages can be
provided through shadow paging, and MOVBE has explicit software emulation.
The supported/emulated API results, not a raw hardware-only mask, decide.

The generic backend contains no frozen-profile feature exemption mask. It
validates the caller's declarations against the advertised model and never
allows them to exempt XSAVE state or component layouts. CPUID identity, caches,
topology, and frequency descriptions remain fixed guest values. Standard math
libraries remain supported; admission is about execution capability, not a
claim of identical arithmetic results across all admitted CPUs.

The controller resolves declared local generic service namespaces from the
actual pending SDK question after schedule and deadline checks. Coverage and
deferred doorbells retain their existing resolution rules. Local and external
answers share the controller transaction: prepare the request-bound input tape
and projected SDK recording, check both bounded encodings, publish through the
response guard, then install the candidate SDK handler/answer and controller
tape. Local handler errors retire the failed VM; a capacity refusal leaves the
pending question uncommitted. A response-guard failure in either a local answer
or an explicit Run resolution retires the failed VM while retaining its console
and SDK events for diagnostics, without committing the candidate answer or tape.
A handler returning External preserves that stop.
The request, including the response guard on its initial pending boundary,
remains present. No guest request suppression or unchecked reply path exists.

Dispatch declarations survive branch, replay and portable import through
ServiceConfig and the recorded handler snapshot. Control-state magic is
HCSTATE3; channel and input records explicitly reject previous versions. Host
RPC stop counts may change under this recorded policy; guest request order,
virtual moments and mandatory doorbell guards do not disappear.

Local-answer capability is deliberately stateless: an answered candidate must
leave its complete captured handler fingerprint (identity, configuration,
dispatch declaration and state) unchanged. A stateful answer is a typed host
failure before response or tape publication, not an external fallback. This
allows a fresh reproducer to use its recorded override without skipping a
handler state transition. External handlers retain their existing stateful
contract. Supporting stateful computed local answers would require separate
computed-answer provenance and replay semantics and is outside this format.

Branch preflight rejects an answer binding that conflicts with the selected
snapshot's actual pending Decision or CoverageDecision payload, before calling
the service factory or changing the live VM/tape. It does not inspect a different
current live question in place of the selected snapshot. This applies to local
and external policies alike. Ordinary nonpending request binding mismatches
still produce the guarded guest BadRequest response. A local deadline-pending
request with an initially supplied or replayed conflicting binding also produces
BadRequest after independently checking its actual tuple and payload. The common
guarded writer uses the captured sequence and opcode; only successful publication
clears the pending stop. This rejection changes neither environment nor tape. A
handler error cannot substitute for proof of a recorded binding mismatch.

Local and explicit resolution share the control answer-frame bound before
recording or publishing anything. Canonical Data encoding is one tag byte plus
the data, so at most MAX_PAYLOAD - 1 data bytes fit. Oversized local responses
return MalformedEnvironment with the question still pending, matching explicit
resolution, rather than reaching a writer failure that retires the VM.

SDK dispatch attribution partitions existing request and response guard callback
calls, errors, and outer callback nanoseconds by bounded generic wire-operation
bins. It does not add checks, RPCs, copied-byte estimates, or canonical state.
The outer duration wraps `check_host_operation_guard`, including its optional
callback invocation and error mapping, and overlaps session guard metrics.
Constructing the callback record, classifying the request, and updating witness
rows occur outside this timer. Inner strict-check time and executable-read bytes
are unavailable by operation. Request counts include unreadable and predecode-refused attempts;
callback counts/time do not count successful response writes or semantic
outcomes. The first scope has no separate semantic-status/write-success or
copy-byte counters. An absent guard contributes zero callback calls, not a measured
successful check. Request refusals before reading guest memory remain explicitly
unclassified. Invalid frames and unreadable/oversize requests have separate
bins; a valid frame's
operation bin does not imply a semantically valid payload.

Up to 32 exact event shapes retain namespace byte, data length, and optional
first data byte. These are opaque wire witnesses, not workload register meanings.
Known shapes keep their slots; unseen shapes after capacity go to an explicit
aggregate overflow. Shape rows plus overflow cover eligible Event.emit requests
and response callbacks, and are subsets of operation totals, not additional work.
No inference of zero is valid for missing shapes when overflow is nonzero.
The cap applies to each VMM or merged controller table. `event_shape_slots`
reports that table's filled slots and is monotone within its lifetime. Summing
independent controller reports counts per-controller slot memberships; that sum
is not a global unique-shape count, current table fill, or memory charge.

Deferred doorbells charge the original request once; later completion derives
response attribution from the retained request without another request check.
Pending service and coverage responses use their actual response operation.
Requests and responses need not balance within a query interval. Attribution is
cumulative host work, includes setup, survives VMM retirement through the existing
telemetry owner, and is never restored from a snapshot. Worker telemetry queries
replace previous cumulative child values and preserve the last values on error.
Neither worker sums nor these breakdowns are additive to shared cache totals or
the existing guard timers. This measurement establishes no batching speedup or
permission to remove publication, deadline, interrupt, or image-check boundaries.

// SPDX-License-Identifier: AGPL-3.0-or-later

use crate::credentials;
pub use crate::credentials::{CredentialsError, ProcessCredentials};
use crate::exact;
use guest_image::Owner;
use serde::Deserialize;
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, BTreeSet, VecDeque};
use std::ffi::{OsStr, OsString};
use std::io::{Read, Seek, SeekFrom, Write};
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::PermissionsExt;
use std::path::{Component, Path, PathBuf};
use std::process::{Command, Stdio};
use std::sync::Arc;

#[derive(Debug, thiserror::Error)]
pub enum ImageError {
    #[error("no container tool found: install docker or podman, or pass a `docker save` tarball")]
    NoTool,
    #[error("`{tool} image save {image}` failed: {detail}")]
    ExportFailed {
        tool: &'static str,
        image: String,
        detail: String,
    },
    #[error("unrecognized image input {0}: not a docker-save tarball or OCI layout")]
    Unrecognized(PathBuf),
    #[error("image has no config/rootfs for this architecture")]
    NoConfig,
    #[error("image environment entry {index} is not VARNAME=VARVALUE")]
    InvalidEnvironment { index: usize },
    #[error("image environment key {key:?} occurs more than once")]
    DuplicateEnvironmentKey { key: String },
    #[error("image working directory {0:?} is not an absolute normalized path")]
    InvalidWorkingDirectory(String),
    #[error("image runtime field {field} contains a NUL byte")]
    InvalidRuntimeField { field: &'static str },
    #[error("image names a path outside its layout or rootfs: {0}")]
    UnsafePath(String),
    #[error("OCI descriptor has an unsupported or malformed digest: {0}")]
    InvalidDigest(String),
    #[error("OCI descriptor {digest} declares {expected} bytes but contains {actual}")]
    DescriptorSize {
        digest: String,
        expected: u64,
        actual: u64,
    },
    #[error("OCI descriptor {0} does not match its blob's SHA-256")]
    DescriptorDigest(String),
    #[error("image path is non-ASCII and not portable across host filesystems: {0}")]
    NonPortableName(String),
    #[error("image path {path:?} aliases {other:?} on case-insensitive hosts")]
    CaseCollision { path: String, other: String },
    #[error("tar: {0}")]
    Tar(String),
    #[error(transparent)]
    Io(#[from] std::io::Error),
    #[error(transparent)]
    Json(#[from] serde_json::Error),
    #[error(transparent)]
    Credentials(#[from] CredentialsError),
}

#[derive(Debug, Clone, Default, serde::Serialize, Deserialize)]
pub struct RuntimeConfig {
    pub entrypoint: Vec<String>,
    pub cmd: Vec<String>,
    pub env: Vec<String>,
    pub working_dir: Option<String>,
    pub user: Option<String>,
}

impl RuntimeConfig {
    pub fn validate(&self) -> Result<(), ImageError> {
        credentials::validate_user_spec(self.user.as_deref())?;
        let mut environment_keys = BTreeSet::new();
        for (index, variable) in self.env.iter().enumerate() {
            let Some((name, _)) = variable.split_once('=') else {
                return Err(ImageError::InvalidEnvironment { index });
            };
            if name.is_empty()
                || !name.bytes().enumerate().all(|(at, byte)| {
                    byte == b'_'
                        || byte.is_ascii_alphabetic() && at == 0
                        || byte.is_ascii_alphanumeric() && at != 0
                })
            {
                return Err(ImageError::InvalidEnvironment { index });
            }
            if !environment_keys.insert(name) {
                return Err(ImageError::DuplicateEnvironmentKey {
                    key: name.to_owned(),
                });
            }
        }
        for argument in self
            .entrypoint
            .iter()
            .chain(self.cmd.iter())
            .chain(self.working_dir.iter())
            .chain(self.user.iter())
            .chain(self.env.iter())
        {
            if argument.contains('\0') {
                return Err(ImageError::InvalidRuntimeField {
                    field: "runtime metadata",
                });
            }
        }
        if let Some(directory) = self.working_dir.as_deref()
            && !directory.is_empty()
            && !absolute_normalized(directory)
        {
            return Err(ImageError::InvalidWorkingDirectory(directory.to_owned()));
        }
        Ok(())
    }

    pub fn resolve_process_credentials(
        &self,
        rootfs: &Path,
    ) -> Result<ProcessCredentials, ImageError> {
        self.validate()?;
        match credentials::resolve(self.user.as_deref(), rootfs) {
            Ok(credentials) => Ok(credentials),
            Err(
                CredentialsError::Rootfs { source, .. }
                | CredentialsError::AccountFile { source, .. },
            ) if source.kind() == std::io::ErrorKind::PermissionDenied => {
                with_host_read_access(rootfs, |_| {
                    credentials::resolve(self.user.as_deref(), rootfs).map_err(ImageError::from)
                })
            }
            Err(error) => Err(error.into()),
        }
    }
}

fn absolute_normalized(path: &str) -> bool {
    let candidate = Path::new(path);
    if !candidate.is_absolute() {
        return false;
    }
    let mut normalized = PathBuf::from("/");
    for component in candidate.components() {
        match component {
            Component::RootDir => {}
            Component::Normal(part) => normalized.push(part),
            Component::CurDir | Component::ParentDir | Component::Prefix(_) => return false,
        }
    }
    normalized.to_str() == Some(path)
}

pub struct StagedImage {
    pub rootfs: PathBuf,
    pub owners: Ownership,
    pub config: RuntimeConfig,
}

#[derive(Clone, Debug, Eq, PartialEq, serde::Serialize)]
pub struct OciInputDigest {
    pub sha256: String,
    pub size: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OciInputProvenance {
    files: BTreeMap<String, OciInputDigest>,
}

impl OciInputProvenance {
    pub fn files(&self) -> &BTreeMap<String, OciInputDigest> {
        &self.files
    }
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct Ownership {
    owners: BTreeMap<PathBuf, Owner>,
    modes: BTreeMap<PathBuf, u32>,
}

impl Ownership {
    #[must_use]
    pub fn owner_of(&self, path: &Path) -> Owner {
        self.owners
            .get(&normalized(path))
            .copied()
            .unwrap_or(Owner::ROOT)
    }

    pub fn record(&mut self, path: &Path, owner: Owner) {
        let path = normalized(path);
        if path.as_os_str().is_empty() {
            return;
        }
        self.owners.insert(path, owner);
    }

    pub fn mode_of(&self, path: &Path, staged_mode: u32) -> u32 {
        self.modes
            .get(&normalized(path))
            .copied()
            .unwrap_or(staged_mode)
    }

    fn record_mode(&mut self, path: &Path, mode: u32) {
        let path = normalized(path);
        if !path.as_os_str().is_empty() {
            self.modes.insert(path, mode);
        }
    }

    fn remove_tree(&mut self, path: &Path) {
        let path = normalized(path);
        remove_path_tree(&mut self.owners, &path, true);
        remove_path_tree(&mut self.modes, &path, true);
    }

    fn remove_below(&mut self, path: &Path) {
        let path = normalized(path);
        remove_path_tree(&mut self.owners, &path, false);
        remove_path_tree(&mut self.modes, &path, false);
    }
}

fn remove_path_tree<V>(map: &mut BTreeMap<PathBuf, V>, path: &Path, include_root: bool) {
    let doomed: Vec<PathBuf> = map
        .range::<Path, _>((std::ops::Bound::Included(path), std::ops::Bound::Unbounded))
        .map(|(recorded, _)| recorded)
        .take_while(|recorded| recorded.starts_with(path))
        .filter(|recorded| include_root || recorded.as_path() != path)
        .cloned()
        .collect();
    for recorded in doomed {
        map.remove(&recorded);
    }
}

fn normalized(path: &Path) -> PathBuf {
    path.components()
        .filter_map(|component| match component {
            Component::Normal(part) => Some(part),
            _ => None,
        })
        .collect()
}

pub fn tool() -> Option<&'static str> {
    ["docker", "podman"]
        .into_iter()
        .find(|tool| Command::new(tool).arg("--version").output().is_ok())
}

pub fn local_image_id(tool: &str, image: &str) -> Option<String> {
    let out = Command::new(tool)
        .args(["image", "inspect", "-f", "{{.Id}}", image])
        .output()
        .ok()?;
    if !out.status.success() {
        return None;
    }
    let id = String::from_utf8_lossy(&out.stdout).trim().to_string();
    (!id.is_empty()).then_some(id)
}

pub fn stage(image: &str, stage_dir: &Path) -> Result<StagedImage, ImageError> {
    stage_with_provenance(image, stage_dir).map(|(staged, _)| staged)
}

pub fn stage_with_provenance(
    image: &str,
    stage_dir: &Path,
) -> Result<(StagedImage, Option<OciInputProvenance>), ImageError> {
    let tarball_path = Path::new(image);
    let explicit_path =
        tarball_path.is_absolute() || image.starts_with("./") || image.starts_with("../");
    let local_candidate = explicit_path || exact::local_candidate(tarball_path)?;
    if local_candidate && !exact::path(tarball_path)? {
        return Err(ImageError::UnsafePath(image.to_string()));
    }
    std::fs::create_dir_all(stage_dir)?;
    let isolated = tempfile::Builder::new()
        .prefix("image-stage-")
        .tempdir_in(stage_dir)?;
    let staged = if local_candidate {
        stage_from_path_with_provenance(tarball_path, isolated.path())
    } else {
        let tarball = export_from_tool(image, isolated.path())?;
        stage_from_path_with_provenance(&tarball, isolated.path())
    }?;
    let _ = isolated.keep();
    Ok(staged)
}

fn export_from_tool(image: &str, stage_dir: &Path) -> Result<PathBuf, ImageError> {
    let tarball = stage_dir.join("image.tar");
    for tool in ["docker", "podman"] {
        if Command::new(tool).arg("--version").output().is_err() {
            continue;
        }
        if local_image_id(tool, image).is_none() {
            let _ = Command::new(tool).args(["pull", image]).status();
        }
        let out = Command::new(tool)
            .args(["image", "save", "-o"])
            .arg(&tarball)
            .arg(image)
            .output()?;
        if out.status.success() {
            return Ok(tarball);
        }
        return Err(ImageError::ExportFailed {
            tool: if tool == "docker" { "docker" } else { "podman" },
            image: image.to_string(),
            detail: String::from_utf8_lossy(&out.stderr).trim().to_string(),
        });
    }
    Err(ImageError::NoTool)
}

#[cfg(test)]
fn stage_from_path(input: &Path, stage_dir: &Path) -> Result<StagedImage, ImageError> {
    stage_from_path_with_provenance(input, stage_dir).map(|(staged, _)| staged)
}

fn stage_from_path_with_provenance(
    input: &Path,
    stage_dir: &Path,
) -> Result<(StagedImage, Option<OciInputProvenance>), ImageError> {
    if !exact::path(input)? {
        return Err(ImageError::UnsafePath(input.display().to_string()));
    }
    let layout = if input.is_dir() {
        input.to_path_buf()
    } else {
        let dir = stage_dir.join("layout");
        std::fs::create_dir_all(&dir)?;
        extract_checked(input, &dir)?;
        dir
    };

    let manifest = contained_join(&layout, "manifest.json")
        .ok()
        .is_some_and(|path| path.is_file());
    let index = contained_join(&layout, "index.json")
        .ok()
        .is_some_and(|path| path.is_file());
    let (layers, config_blob, provenance) = if manifest {
        let (layers, config) = docker_save_layers(&layout)?;
        (layers, config, None)
    } else if index {
        let (layers, config, provenance) = oci_layout_layers_with_provenance(&layout)?;
        (layers, config, Some(provenance))
    } else {
        return Err(ImageError::Unrecognized(input.to_path_buf()));
    };

    let config = parse_runtime_config(&config_blob)?;
    let rootfs = stage_dir.join("rootfs");
    std::fs::create_dir_all(&rootfs)?;
    let mut owners = Ownership::default();
    let mut portable_names = BTreeMap::new();
    for layer in &layers {
        apply_layer_tracked(
            &layer.path,
            &rootfs,
            &mut owners,
            &mut portable_names,
            layer.descriptor.as_ref(),
        )?;
    }
    Ok((
        StagedImage {
            rootfs,
            owners,
            config,
        },
        provenance,
    ))
}

#[derive(Deserialize)]
struct DockerSaveManifestEntry {
    #[serde(rename = "Config")]
    config: String,
    #[serde(rename = "Layers")]
    layers: Vec<String>,
}

#[derive(Debug)]
struct Layer {
    path: PathBuf,
    descriptor: Option<OciDescriptor>,
}

fn docker_save_layers(layout: &Path) -> Result<(Vec<Layer>, Vec<u8>), ImageError> {
    let manifest: Vec<DockerSaveManifestEntry> =
        serde_json::from_slice(&std::fs::read(contained_join(layout, "manifest.json")?)?)?;
    let entry = manifest.into_iter().next().ok_or(ImageError::NoConfig)?;
    let layers = entry
        .layers
        .iter()
        .map(|l| {
            Ok(Layer {
                path: contained_join(layout, l)?,
                descriptor: None,
            })
        })
        .collect::<Result<Vec<_>, ImageError>>()?;
    let config = std::fs::read(contained_join(layout, &entry.config)?)?;
    Ok((layers, config))
}

#[derive(Deserialize)]
struct OciIndex {
    manifests: Vec<OciDescriptor>,
}
#[derive(Debug, Deserialize)]
struct OciDescriptor {
    digest: String,
    size: u64,
}
#[derive(Deserialize)]
struct OciManifest {
    config: OciDescriptor,
    layers: Vec<OciDescriptor>,
}

fn blob_path(layout: &Path, digest: &str) -> Result<PathBuf, ImageError> {
    let encoded = sha256_suffix(digest)?;
    contained_join(layout, &format!("blobs/sha256/{encoded}"))
}

fn sha256_suffix(digest: &str) -> Result<&str, ImageError> {
    let Some(encoded) = digest.strip_prefix("sha256:") else {
        return Err(ImageError::InvalidDigest(digest.to_string()));
    };
    if encoded.len() != 64
        || !encoded
            .bytes()
            .all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
    {
        return Err(ImageError::InvalidDigest(digest.to_string()));
    }
    Ok(encoded)
}

fn verify_descriptor(
    descriptor: &OciDescriptor,
    actual_size: u64,
    actual_digest: impl std::fmt::LowerHex,
) -> Result<(), ImageError> {
    sha256_suffix(&descriptor.digest)?;
    if actual_size != descriptor.size {
        return Err(ImageError::DescriptorSize {
            digest: descriptor.digest.clone(),
            expected: descriptor.size,
            actual: actual_size,
        });
    }
    if descriptor.digest != format!("sha256:{actual_digest:x}") {
        return Err(ImageError::DescriptorDigest(descriptor.digest.clone()));
    }
    Ok(())
}

fn read_verified_blob(layout: &Path, descriptor: &OciDescriptor) -> Result<Vec<u8>, ImageError> {
    let bytes = std::fs::read(blob_path(layout, &descriptor.digest)?)?;
    verify_descriptor(descriptor, bytes.len() as u64, Sha256::digest(&bytes))?;
    Ok(bytes)
}

fn verify_pinned_archive(
    pinned: &PinnedArchive,
    descriptor: &OciDescriptor,
) -> Result<(), ImageError> {
    let mut file = pinned.reader()?;
    let mut hasher = Sha256::new();
    let mut size = 0u64;
    let mut buffer = [0u8; 64 * 1024];
    loop {
        let read = file.read(&mut buffer)?;
        if read == 0 {
            break;
        }
        size = size
            .checked_add(read as u64)
            .ok_or_else(|| ImageError::DescriptorSize {
                digest: descriptor.digest.clone(),
                expected: descriptor.size,
                actual: u64::MAX,
            })?;
        hasher.update(&buffer[..read]);
    }
    verify_descriptor(descriptor, size, hasher.finalize())
}

#[cfg(test)]
fn oci_layout_layers(layout: &Path) -> Result<(Vec<Layer>, Vec<u8>), ImageError> {
    oci_layout_layers_with_provenance(layout).map(|(layers, config, _)| (layers, config))
}

fn oci_layout_layers_with_provenance(
    layout: &Path,
) -> Result<(Vec<Layer>, Vec<u8>, OciInputProvenance), ImageError> {
    let index_bytes = std::fs::read(contained_join(layout, "index.json")?)?;
    let index: OciIndex = serde_json::from_slice(&index_bytes)?;
    let first = index.manifests.first().ok_or(ImageError::NoConfig)?;
    let manifest: OciManifest = serde_json::from_slice(&read_verified_blob(layout, first)?)?;
    let mut files = BTreeMap::from([
        (
            "index.json".to_owned(),
            OciInputDigest {
                sha256: format!("{:x}", Sha256::digest(&index_bytes)),
                size: index_bytes.len() as u64,
            },
        ),
        provenance_entry(first)?,
        provenance_entry(&manifest.config)?,
    ]);
    let layers = manifest
        .layers
        .into_iter()
        .map(|descriptor| {
            let (path, digest) = provenance_entry(&descriptor)?;
            files.insert(path, digest);
            Ok(Layer {
                path: blob_path(layout, &descriptor.digest)?,
                descriptor: Some(descriptor),
            })
        })
        .collect::<Result<Vec<_>, ImageError>>()?;
    let config = read_verified_blob(layout, &manifest.config)?;
    Ok((layers, config, OciInputProvenance { files }))
}

fn provenance_entry(descriptor: &OciDescriptor) -> Result<(String, OciInputDigest), ImageError> {
    let encoded = sha256_suffix(&descriptor.digest)?;
    Ok((
        format!("blobs/sha256/{encoded}"),
        OciInputDigest {
            sha256: encoded.to_owned(),
            size: descriptor.size,
        },
    ))
}

#[derive(Deserialize)]
struct ImageConfigFile {
    config: Option<ImageConfigSection>,
}
#[derive(Deserialize)]
#[serde(rename_all = "PascalCase")]
struct ImageConfigSection {
    entrypoint: Option<Vec<String>>,
    cmd: Option<Vec<String>>,
    env: Option<Vec<String>>,
    working_dir: Option<String>,
    user: Option<String>,
}

fn parse_runtime_config(blob: &[u8]) -> Result<RuntimeConfig, ImageError> {
    let file: ImageConfigFile = serde_json::from_slice(blob)?;
    let section = file.config;
    let config = section
        .map(|c| RuntimeConfig {
            entrypoint: c.entrypoint.unwrap_or_default(),
            cmd: c.cmd.unwrap_or_default(),
            env: c.env.unwrap_or_default(),
            working_dir: c.working_dir,
            user: c.user,
        })
        .unwrap_or_default();
    config.validate()?;
    Ok(config)
}

pub fn resolve_process_credentials(
    config: &RuntimeConfig,
    rootfs: &Path,
) -> Result<ProcessCredentials, ImageError> {
    config.resolve_process_credentials(rootfs)
}

pub(crate) fn with_host_read_access<T, E>(
    rootfs: &Path,
    action: impl FnOnce(&BTreeMap<PathBuf, u32>) -> Result<T, E>,
) -> Result<T, E>
where
    E: From<std::io::Error>,
{
    let mut changed = Vec::new();
    let prepared = allow_tree_reads(rootfs, &mut changed);
    let original_modes = changed.iter().cloned().collect();
    let result = prepared
        .map_err(E::from)
        .and_then(|_| action(&original_modes));
    let restored = restore_tree_modes(changed);
    match (result, restored) {
        (Err(error), _) => Err(error),
        (Ok(_), Err(error)) => Err(error.into()),
        (Ok(value), Ok(())) => Ok(value),
    }
}

pub fn with_staged_read_access<T, E>(
    staged: &StagedImage,
    action: impl FnOnce() -> Result<T, E>,
) -> Result<T, E>
where
    E: From<std::io::Error>,
{
    with_host_read_access(&staged.rootfs, |_| action())
}

fn allow_tree_reads(path: &Path, changed: &mut Vec<(PathBuf, u32)>) -> std::io::Result<()> {
    let meta = std::fs::symlink_metadata(path)?;
    let needed = if meta.is_dir() {
        0o500
    } else if meta.is_file() {
        0o400
    } else {
        return Ok(());
    };
    let mode = meta.permissions().mode() & 0o7777;
    if mode & needed != needed {
        std::fs::set_permissions(path, std::fs::Permissions::from_mode(mode | needed))?;
        changed.push((path.to_path_buf(), mode));
    }
    if meta.is_dir() {
        let mut entries: Vec<_> = std::fs::read_dir(path)?.collect::<Result<_, _>>()?;
        entries.sort_by_key(std::fs::DirEntry::file_name);
        for entry in entries {
            allow_tree_reads(&entry.path(), changed)?;
        }
    }
    Ok(())
}

fn restore_tree_modes(changed: Vec<(PathBuf, u32)>) -> std::io::Result<()> {
    let mut error = None;
    for (path, mode) in changed.into_iter().rev() {
        if let Err(failed) = std::fs::set_permissions(path, std::fs::Permissions::from_mode(mode)) {
            error.get_or_insert(failed);
        }
    }
    match error {
        Some(error) => Err(error),
        None => Ok(()),
    }
}

fn check_relative(path: &Path) -> Result<(), ImageError> {
    if path.as_os_str().as_bytes().contains(&0) {
        return Err(ImageError::UnsafePath(path.to_string_lossy().into_owned()));
    }
    for component in path.components() {
        match component {
            Component::Normal(_) | Component::CurDir => {}
            Component::ParentDir | Component::RootDir | Component::Prefix(_) => {
                return Err(ImageError::UnsafePath(path.to_string_lossy().into_owned()));
            }
        }
    }
    Ok(())
}

fn contained_join(root: &Path, relative: &str) -> Result<PathBuf, ImageError> {
    check_relative(Path::new(relative))?;
    if Path::new(relative).components().next().is_none() {
        return Err(ImageError::UnsafePath(relative.to_string()));
    }
    let real_root = root.canonicalize()?;
    let mut exact_path = real_root.clone();
    let mut pending: VecDeque<OsString> = Path::new(relative)
        .components()
        .filter_map(|component| match component {
            Component::Normal(part) => Some(part.to_os_string()),
            _ => None,
        })
        .collect();
    let mut symlink_hops = 0;
    while let Some(part) = pending.pop_front() {
        if part == OsStr::new("..") {
            if exact_path == real_root {
                return Err(ImageError::UnsafePath(relative.to_string()));
            }
            exact_path.pop();
            continue;
        }
        let Some(next) = exact::entry(&exact_path, &part)? else {
            return Err(ImageError::Io(std::io::ErrorKind::NotFound.into()));
        };
        if std::fs::symlink_metadata(&next)?.file_type().is_symlink() {
            symlink_hops += 1;
            if symlink_hops > 40 {
                return Err(ImageError::UnsafePath(relative.to_string()));
            }
            let target = std::fs::read_link(&next)?;
            if target.is_absolute() {
                return Err(ImageError::UnsafePath(relative.to_string()));
            }
            let mut target_parts = Vec::new();
            for component in target.components() {
                match component {
                    Component::CurDir => {}
                    Component::ParentDir => target_parts.push(OsString::from("..")),
                    Component::Normal(part) => target_parts.push(part.to_os_string()),
                    Component::RootDir | Component::Prefix(_) => {
                        return Err(ImageError::UnsafePath(relative.to_string()));
                    }
                }
            }
            for part in target_parts.into_iter().rev() {
                pending.push_front(part);
            }
            continue;
        }
        exact_path = next;
    }
    let resolved = resolve_deepest(&exact_path)?;
    if !resolved.starts_with(&real_root) {
        return Err(ImageError::UnsafePath(relative.to_string()));
    }
    Ok(resolved)
}

fn resolve_deepest(path: &Path) -> Result<PathBuf, ImageError> {
    let mut missing: Vec<std::ffi::OsString> = Vec::new();
    let mut cursor = path.to_path_buf();
    loop {
        match cursor.canonicalize() {
            Ok(mut resolved) => {
                for part in missing.iter().rev() {
                    resolved.push(part);
                }
                return Ok(resolved);
            }
            Err(err) if err.kind() == std::io::ErrorKind::NotFound => {
                let Some(name) = cursor.file_name().map(std::ffi::OsStr::to_os_string) else {
                    return Err(ImageError::Io(err));
                };
                missing.push(name);
                if !cursor.pop() {
                    return Err(ImageError::Io(err));
                }
            }
            Err(err) => return Err(ImageError::Io(err)),
        }
    }
}

fn member_key(name: &Path) -> Vec<u8> {
    let parts: Vec<&[u8]> = name
        .components()
        .filter_map(|c| match c {
            Component::Normal(part) => Some(part.as_bytes()),
            _ => None,
        })
        .collect();
    parts.join(&b'/').to_ascii_lowercase()
}

fn check_members(members: &[Member]) -> Result<(), ImageError> {
    let mut non_directories: BTreeSet<Vec<u8>> = BTreeSet::new();
    let mut keys: Vec<(Vec<u8>, &Member)> = Vec::new();
    for member in members {
        check_relative(member.path())?;
        if member.path().components().any(|component| {
            matches!(component, Component::Normal(part) if part.as_bytes().starts_with(b"._"))
        }) {
            return Err(ImageError::Tar(
                "archive carries an AppleDouble metadata name".into(),
            ));
        }
        let key = member_key(member.path());
        if key.is_empty() {
            continue;
        }
        if !member.is_dir {
            non_directories.insert(key.clone());
        }
        keys.push((key, member));
    }
    for (key, member) in &keys {
        for (at, byte) in key.iter().enumerate() {
            if *byte == b'/' && non_directories.contains(&key[..at]) {
                return Err(ImageError::UnsafePath(member.shown()));
            }
        }
    }
    let mut kinds: BTreeMap<Vec<u8>, u8> = BTreeMap::new();
    for (_, member) in keys {
        let exact = normalized(member.path()).as_os_str().as_bytes().to_vec();
        if let Some(kind) = kinds.insert(exact, member.kind) {
            if kind != member.kind {
                return Err(ImageError::Tar(
                    "archive changes a member's type at the same path".into(),
                ));
            }
            if kind == b'2' {
                return Err(ImageError::Tar(
                    "archive repeats a symlink at the same path".into(),
                ));
            }
        }
    }
    Ok(())
}

fn check_portable_names(
    members: &[Member],
    names: &mut BTreeMap<Vec<u8>, Vec<u8>>,
) -> Result<(), ImageError> {
    for member in members {
        check_portable_path(member.path(), names, true)?;
    }
    Ok(())
}

fn check_portable_path(
    path: &Path,
    names: &mut BTreeMap<Vec<u8>, Vec<u8>>,
    insert: bool,
) -> Result<Vec<u8>, ImageError> {
    check_relative(path)?;
    let mut folded = Vec::new();
    let mut exact = Vec::new();
    for component in path.components() {
        let Component::Normal(part) = component else {
            continue;
        };
        let bytes = part.as_bytes();
        if !bytes.is_ascii() {
            return Err(ImageError::NonPortableName(
                path.to_string_lossy().into_owned(),
            ));
        }
        if !folded.is_empty() {
            folded.push(b'/');
            exact.push(b'/');
        }
        folded.extend(bytes.to_ascii_lowercase());
        exact.extend_from_slice(bytes);
        if let Some(other) = names.get(&folded) {
            if other != &exact {
                return Err(ImageError::CaseCollision {
                    path: path.to_string_lossy().into_owned(),
                    other: String::from_utf8_lossy(other).into_owned(),
                });
            }
        } else if insert {
            names.insert(folded.clone(), exact.clone());
        }
    }
    Ok(folded)
}

fn remove_portable_tree(names: &mut BTreeMap<Vec<u8>, Vec<u8>>, key: &[u8], include_root: bool) {
    if key.is_empty() {
        names.clear();
        return;
    }
    if include_root {
        names.remove(key);
    }
    let mut prefix = key.to_vec();
    prefix.push(b'/');
    let doomed: Vec<Vec<u8>> = names
        .range::<[u8], _>((
            std::ops::Bound::Included(prefix.as_slice()),
            std::ops::Bound::Unbounded,
        ))
        .map(|(candidate, _)| candidate)
        .take_while(|candidate| candidate.starts_with(&prefix))
        .cloned()
        .collect();
    for candidate in doomed {
        names.remove(&candidate);
    }
}

fn check_layer_portable_names(
    members: &[Member],
    names: &mut BTreeMap<Vec<u8>, Vec<u8>>,
) -> Result<(), ImageError> {
    for member in members {
        match whiteout(member.path()) {
            Some(Whiteout::Opaque(directory)) => {
                check_portable_path(member.path(), names, false)?;
                check_portable_path(directory, names, false)?;
            }
            Some(Whiteout::Entry(target)) => {
                check_portable_path(member.path(), names, false)?;
                check_portable_path(&target, names, false)?;
            }
            None => {}
        }
    }
    for member in members {
        match whiteout(member.path()) {
            Some(Whiteout::Opaque(directory)) => {
                let key = member_key(directory);
                remove_portable_tree(names, &key, false);
            }
            Some(Whiteout::Entry(target)) => {
                let key = member_key(&target);
                remove_portable_tree(names, &key, true);
            }
            None => {}
        }
    }
    for member in members {
        if whiteout(member.path()).is_some() {
            continue;
        }
        let key = check_portable_path(member.path(), names, true)?;
        if !member.is_dir {
            remove_portable_tree(names, &key, false);
        }
    }
    for member in members {
        if whiteout(member.path()).is_some() {
            check_portable_path(member.path(), names, false)?;
        }
    }
    Ok(())
}

fn check_hardlinks(members: &[Member]) -> Result<(), ImageError> {
    let mut seen = BTreeSet::new();
    for member in members {
        if let Some(target) = &member.hardlink_target {
            let path = Path::new(std::ffi::OsStr::from_bytes(target));
            check_relative(path)?;
            if !target.is_ascii() {
                return Err(ImageError::NonPortableName(
                    path.to_string_lossy().into_owned(),
                ));
            }
            let exact = normalized(path);
            if exact == normalized(member.path()) {
                return Err(ImageError::UnsafePath(format!(
                    "hardlink {} points to itself",
                    member.shown()
                )));
            }
            if exact.as_os_str().is_empty() || !seen.contains(&exact) {
                return Err(ImageError::UnsafePath(format!(
                    "hardlink {} has no earlier matching target {}",
                    member.shown(),
                    path.display()
                )));
            }
        }
        seen.insert(normalized(member.path()));
    }
    Ok(())
}

const TAR_BLOCK: usize = 512;
const MAX_PORTABLE_TIMESTAMP_SECONDS: u64 = i64::MAX as u64 / 1_000_000_000;
const MAX_MEMBERS: usize = 1 << 20;
const MAX_HEADER_DATA: u64 = 1 << 16;
const MAX_PORTABLE_SYMLINK_TARGET: usize = 1023;
const MAX_PORTABLE_MEMBER_PATH: usize = 768;
const MAX_PORTABLE_STAGING_ROOT: usize = 254;

struct Member {
    name: Vec<u8>,
    kind: u8,
    is_dir: bool,
    mode: u32,
    owner: Owner,
    hardlink_target: Option<Vec<u8>>,
}

impl Member {
    fn path(&self) -> &Path {
        Path::new(std::ffi::OsStr::from_bytes(&self.name))
    }

    fn shown(&self) -> String {
        self.path().to_string_lossy().into_owned()
    }
}

struct ArchiveReader {
    reader: Box<dyn Read>,
    child: Option<std::process::Child>,
    feeder: Option<std::thread::JoinHandle<std::io::Result<()>>>,
}

impl Read for ArchiveReader {
    fn read(&mut self, buf: &mut [u8]) -> std::io::Result<usize> {
        self.reader.read(buf)
    }
}

impl ArchiveReader {
    fn finish(&mut self) -> Result<(), ImageError> {
        let Some(mut child) = self.child.take() else {
            return Ok(());
        };
        let fed = self.feeder.take().map(|feeder| {
            feeder
                .join()
                .map_err(|_| {
                    ImageError::Io(std::io::Error::other("archive input feeder panicked"))
                })?
                .map_err(ImageError::from)
        });
        let status = child.wait()?;
        if !status.success() {
            return Err(ImageError::Tar(format!(
                "archive decompressor exited with {status}"
            )));
        }
        fed.transpose()?;
        Ok(())
    }
}

impl Drop for ArchiveReader {
    fn drop(&mut self) {
        let Some(mut child) = self.child.take() else {
            return;
        };
        self.reader = Box::new(std::io::empty());
        let _ = child.kill();
        let _ = child.wait();
        if let Some(feeder) = self.feeder.take() {
            let _ = feeder.join();
        }
    }
}

fn open_archive<R: Read + Send + 'static>(mut input: R) -> Result<ArchiveReader, ImageError> {
    let mut magic = Vec::with_capacity(6);
    input.by_ref().take(6).read_to_end(&mut magic)?;
    let whole = std::io::Cursor::new(magic.clone()).chain(input);
    if magic.starts_with(&[0x1f, 0x8b]) {
        return Ok(ArchiveReader {
            reader: Box::new(flate2::bufread::MultiGzDecoder::new(
                std::io::BufReader::new(whole),
            )),
            child: None,
            feeder: None,
        });
    }
    let tool = if magic.starts_with(&[0x28, 0xb5, 0x2f, 0xfd]) {
        "zstd"
    } else if magic.starts_with(&[0xfd, b'7', b'z', b'X', b'Z', 0x00]) {
        "xz"
    } else if magic.starts_with(b"BZh") {
        "bzip2"
    } else {
        return Ok(ArchiveReader {
            reader: Box::new(std::io::BufReader::with_capacity(64 * 1024, whole)),
            child: None,
            feeder: None,
        });
    };
    let mut child = archive_tool(tool)
        .arg("-dc")
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|err| ImageError::Tar(format!("{tool} is needed to read this layer: {err}")))?;
    let stdin = child
        .stdin
        .take()
        .ok_or_else(|| ImageError::Tar(format!("{tool} produced no input pipe for this layer")))?;
    let stdout = child
        .stdout
        .take()
        .ok_or_else(|| ImageError::Tar(format!("{tool} produced no output for this layer")))?;
    let feeder = std::thread::spawn(move || {
        let mut whole = whole;
        let mut stdin = stdin;
        match std::io::copy(&mut whole, &mut stdin) {
            Ok(_) => Ok(()),
            Err(error) if error.kind() == std::io::ErrorKind::BrokenPipe => {
                std::io::copy(&mut whole, &mut std::io::sink()).map(|_| ())
            }
            Err(error) => Err(error),
        }
    });
    Ok(ArchiveReader {
        reader: Box::new(std::io::BufReader::with_capacity(64 * 1024, stdout)),
        child: Some(child),
        feeder: Some(feeder),
    })
}

fn archive_tool(tool: &str) -> Command {
    let mut command = Command::new(tool);
    command
        .env_clear()
        .env(
            "PATH",
            std::env::var_os("PATH").unwrap_or_else(|| std::ffi::OsString::from("/usr/bin:/bin")),
        )
        .env("LC_ALL", "C");
    command
}

#[cfg(test)]
fn read_members(archive: &Path) -> Result<Vec<Member>, ImageError> {
    read_members_file(std::fs::File::open(archive)?)
}

#[cfg(test)]
fn read_members_file<R: Read + Send + 'static>(reader: R) -> Result<Vec<Member>, ImageError> {
    let mut stream = open_archive(reader)?;
    let members = read_members_stream(&mut stream)?;
    require_trailing_zeros(&mut stream)?;
    stream.finish()?;
    Ok(members)
}

fn read_members_stream(mut stream: &mut impl Read) -> Result<Vec<Member>, ImageError> {
    let mut members: Vec<Member> = Vec::new();
    let mut long_name: Option<Vec<u8>> = None;
    let mut long_link: Option<Vec<u8>> = None;
    let mut pax = Pax::default();
    let mut pax_header_seen = false;
    let mut block = [0u8; TAR_BLOCK];
    while read_block(&mut stream, &mut block)? {
        if block.iter().all(|byte| *byte == 0) {
            if long_name.is_some() || long_link.is_some() || pax_header_seen {
                return Err(ImageError::Tar(
                    "archive ends with an orphaned extension header".into(),
                ));
            }
            return Ok(members);
        }
        verify_checksum(&block)?;
        let magic = &block[257..265];
        if magic.starts_with(b"ustar")
            && &block[257..263] != b"ustar\0"
            && magic != b"ustar  \0"
            && !tar_field(&block[345..500]).is_empty()
        {
            return Err(ImageError::Tar(
                "ambiguous tar header has a nonempty prefix field".into(),
            ));
        }
        if magic == b"ustar  \0" && block[386..495].iter().any(|byte| *byte != 0) {
            return Err(ImageError::Tar(
                "GNU tar header carries unsupported sparse metadata".into(),
            ));
        }
        let size = parse_octal(&block[124..136])?;
        if size >= i64::MAX as u64 {
            return Err(ImageError::Tar("tar member size is too large".into()));
        }
        if parse_octal(&block[136..148])? > MAX_PORTABLE_TIMESTAMP_SECONDS {
            return Err(ImageError::Tar("tar timestamp is too large".into()));
        }
        check_device_number(&block[329..337])?;
        check_device_number(&block[337..345])?;
        match block[156] {
            b'L' => {
                let mut data = header_data(&mut stream, size)?;
                data.truncate(
                    data.iter()
                        .position(|byte| *byte == 0)
                        .unwrap_or(data.len()),
                );
                long_name = Some(data);
            }
            b'K' => {
                let mut data = header_data(&mut stream, size)?;
                data.truncate(
                    data.iter()
                        .position(|byte| *byte == 0)
                        .unwrap_or(data.len()),
                );
                long_link = Some(data);
            }
            b'x' => {
                if pax_header_seen {
                    return Err(ImageError::Tar("member has multiple pax headers".into()));
                }
                pax_header_seen = true;
                let data = header_data(&mut stream, size)?;
                parse_pax(&data, &mut pax)?;
            }
            b'g' => {
                return Err(ImageError::Tar(
                    "archive carries a global pax header".into(),
                ));
            }
            b'S' | b'M' => {
                return Err(ImageError::Tar(
                    "archive carries an unsupported member type".into(),
                ));
            }
            typeflag => {
                pax_header_seen = false;
                if !matches!(typeflag, 0 | b'0' | b'1' | b'2' | b'5') {
                    return Err(ImageError::Tar(
                        "archive carries an unsupported member type".into(),
                    ));
                }
                if members.len() == MAX_MEMBERS {
                    return Err(ImageError::Tar(format!(
                        "archive has more than {MAX_MEMBERS} members"
                    )));
                }
                let Pax {
                    path,
                    size: pax_size,
                    uid,
                    gid,
                    link_path,
                } = std::mem::take(&mut pax);
                let no_data_kind = match typeflag {
                    b'1' => Some("hardlink"),
                    b'2' => Some("symlink"),
                    b'5' => Some("directory"),
                    _ => None,
                };
                if let Some(kind) = no_data_kind
                    && (size != 0 || pax_size.is_some_and(|size| size != 0))
                {
                    return Err(ImageError::Tar(format!(
                        "{kind} member has nonzero data size"
                    )));
                }
                let gnu_name = long_name.take();
                let gnu_link = long_link.take();
                if path.is_some() && gnu_name.is_some() {
                    return Err(ImageError::Tar(
                        "member has conflicting GNU and pax name overrides".into(),
                    ));
                }
                if link_path.is_some() && gnu_link.is_some() {
                    return Err(ImageError::Tar(
                        "member has conflicting GNU and pax link overrides".into(),
                    ));
                }
                let owner = Owner {
                    uid: owner_id(uid, &block[108..116])?,
                    gid: owner_id(gid, &block[116..124])?,
                };
                let name = path.or(gnu_name).unwrap_or_else(|| ustar_name(&block));
                if name.is_empty() {
                    return Err(ImageError::Tar("archive member has an empty name".into()));
                }
                if host_dependent_tar_prefix(&name) {
                    return Err(ImageError::Tar(
                        "archive member has a host-dependent prefix".into(),
                    ));
                }
                if name.len() > MAX_PORTABLE_MEMBER_PATH {
                    return Err(ImageError::Tar("archive member path is too long".into()));
                }
                if typeflag != b'5' && name.ends_with(b"/") {
                    return Err(ImageError::Tar(
                        "non-directory member has a trailing slash".into(),
                    ));
                }
                if typeflag != b'5' && has_terminal_dot_after_named_component(&name) {
                    return Err(ImageError::Tar(
                        "non-directory member has a host-dependent terminal dot".into(),
                    ));
                }
                let header_link = tar_field(&block[157..257]);
                if typeflag == b'1' && (header_link.is_empty() || !header_link.is_ascii()) {
                    return Err(ImageError::Tar(
                        "hardlink member has a nonportable header target".into(),
                    ));
                }
                if typeflag == b'1'
                    && link_path
                        .as_deref()
                        .or(gnu_link.as_deref())
                        .unwrap_or(&header_link)
                        .len()
                        > MAX_PORTABLE_MEMBER_PATH
                {
                    return Err(ImageError::Tar("hardlink target is too long".into()));
                }
                if typeflag == b'1'
                    && host_dependent_tar_prefix(
                        link_path
                            .as_deref()
                            .or(gnu_link.as_deref())
                            .unwrap_or(&header_link),
                    )
                {
                    return Err(ImageError::Tar(
                        "hardlink target has a host-dependent prefix".into(),
                    ));
                }
                if typeflag == b'2' {
                    let portable = |target: &[u8]| {
                        !target.is_empty()
                            && target.len() <= MAX_PORTABLE_SYMLINK_TARGET
                            && target.is_ascii()
                            && !target.contains(&0)
                    };
                    let effective = link_path
                        .as_deref()
                        .or(gnu_link.as_deref())
                        .unwrap_or(&header_link);
                    if !portable(&header_link) || !portable(effective) {
                        return Err(ImageError::Tar(
                            "symlink member has a nonportable target".into(),
                        ));
                    }
                }
                members.push(Member {
                    name,
                    kind: if typeflag == 0 { b'0' } else { typeflag },
                    is_dir: typeflag == b'5',
                    mode: (parse_octal(&block[100..108])? & 0o7777) as u32,
                    owner,
                    hardlink_target: (typeflag == b'1')
                        .then(|| link_path.or(gnu_link).unwrap_or(header_link)),
                });
                let size = pax_size.unwrap_or(size);
                let data = size
                    .checked_add(padding(size))
                    .ok_or_else(|| ImageError::Tar("tar member size is too large".into()))?;
                skip(&mut stream, data)?;
            }
        }
    }
    Err(ImageError::Tar("archive ends without a terminator".into()))
}

fn read_block(stream: &mut impl Read, block: &mut [u8; TAR_BLOCK]) -> Result<bool, ImageError> {
    if stream.read(&mut block[..1])? == 0 {
        return Ok(false);
    }
    stream
        .read_exact(&mut block[1..])
        .map_err(|e| ImageError::Tar(format!("archive ends inside a header: {e}")))?;
    Ok(true)
}

fn padding(size: u64) -> u64 {
    let block = TAR_BLOCK as u64;
    (block - size % block) % block
}

fn skip(stream: &mut impl Read, bytes: u64) -> Result<(), ImageError> {
    let skipped = std::io::copy(&mut stream.take(bytes), &mut std::io::sink())?;
    if skipped == bytes {
        Ok(())
    } else {
        Err(ImageError::Tar("archive ends inside a member".into()))
    }
}

fn header_data(stream: &mut impl Read, size: u64) -> Result<Vec<u8>, ImageError> {
    if size > MAX_HEADER_DATA {
        return Err(ImageError::Tar(format!(
            "archive has a {size}-byte name header"
        )));
    }
    let mut data = vec![0u8; size as usize];
    stream.read_exact(&mut data)?;
    skip(stream, padding(size))?;
    Ok(data)
}

fn require_trailing_zeros(stream: &mut impl Read) -> Result<(), ImageError> {
    let mut buffer = [0u8; 8192];
    loop {
        match stream.read(&mut buffer)? {
            0 => return Ok(()),
            read if buffer[..read].iter().all(|byte| *byte == 0) => {}
            _ => {
                return Err(ImageError::Tar(
                    "archive carries data after its terminator".into(),
                ));
            }
        }
    }
}

fn verify_checksum(block: &[u8; TAR_BLOCK]) -> Result<(), ImageError> {
    let stored = parse_octal(&block[148..156])?;
    let sum: u32 = block
        .iter()
        .enumerate()
        .map(|(at, byte)| {
            u32::from(if (148..156).contains(&at) {
                b' '
            } else {
                *byte
            })
        })
        .sum();
    if u64::from(sum) == stored {
        Ok(())
    } else {
        Err(ImageError::Tar("tar header checksum mismatch".into()))
    }
}

fn parse_octal(field: &[u8]) -> Result<u64, ImageError> {
    if let Some(first) = field.first()
        && first & 0x80 != 0
    {
        if *first != 0x80 {
            return Err(ImageError::Tar("negative tar header field".into()));
        }
        return field[1..].iter().try_fold(0u64, |value, byte| {
            value
                .checked_mul(256)
                .and_then(|value| value.checked_add(u64::from(*byte)))
                .ok_or_else(|| ImageError::Tar("tar header field is too large".into()))
        });
    }
    let invalid = || ImageError::Tar("tar header field is not octal".into());
    let digits = match field.iter().position(|byte| *byte == 0) {
        Some(end) => {
            if field[end..].iter().any(|byte| !matches!(*byte, 0 | b' ')) {
                return Err(invalid());
            }
            &field[..end]
        }
        None => field,
    };
    let start = digits.iter().take_while(|byte| **byte == b' ').count();
    let digits = &digits[start..];
    let end = digits
        .iter()
        .rposition(|byte| *byte != b' ')
        .map_or(0, |at| at + 1);
    let digits = &digits[..end];
    if digits.is_empty() {
        return if field.first() == Some(&0) {
            Ok(0)
        } else {
            Err(invalid())
        };
    }
    if !digits.iter().all(|byte| (b'0'..=b'7').contains(byte)) {
        return Err(invalid());
    }
    u64::from_str_radix(std::str::from_utf8(digits).map_err(|_| invalid())?, 8)
        .map_err(|_| invalid())
}

fn check_device_number(field: &[u8]) -> Result<(), ImageError> {
    if field.iter().all(|byte| matches!(*byte, 0 | b' ')) || matches!(field[0], 0x80 | 0xff) {
        return Ok(());
    }
    parse_octal(field).map(|_| ())
}

fn host_dependent_tar_prefix(name: &[u8]) -> bool {
    name.first() == Some(&b'\\') || (name.get(1) == Some(&b':') && name[0].is_ascii_alphabetic())
}

fn has_terminal_dot_after_named_component(name: &[u8]) -> bool {
    name.strip_suffix(b"/.").is_some_and(|prefix| {
        prefix
            .split(|byte| *byte == b'/')
            .any(|component| !component.is_empty() && component != b".")
    })
}

fn owner_id(pax: Option<u64>, field: &[u8]) -> Result<u32, ImageError> {
    let header = parse_octal(field)?;
    u32::try_from(header).map_err(|_| ImageError::Tar("tar owner id is too large".into()))?;
    let id = pax.unwrap_or(header);
    u32::try_from(id).map_err(|_| ImageError::Tar("tar owner id is too large".into()))
}

fn ustar_name(block: &[u8; TAR_BLOCK]) -> Vec<u8> {
    let name = tar_field(&block[0..100]);
    if &block[257..263] != b"ustar\0" {
        return name;
    }
    let prefix = tar_field(&block[345..500]);
    if prefix.is_empty() {
        return name;
    }
    [prefix, vec![b'/'], name].concat()
}

fn tar_field(bytes: &[u8]) -> Vec<u8> {
    bytes
        .split(|byte| *byte == 0)
        .next()
        .unwrap_or_default()
        .to_vec()
}

#[derive(Default)]
struct Pax {
    path: Option<Vec<u8>>,
    size: Option<u64>,
    uid: Option<u64>,
    gid: Option<u64>,
    link_path: Option<Vec<u8>>,
}

fn parse_pax(records: &[u8], pax: &mut Pax) -> Result<(), ImageError> {
    let malformed = || ImageError::Tar("malformed pax header".into());
    let mut rest = records;
    while !rest.is_empty() {
        let space = rest
            .iter()
            .position(|byte| *byte == b' ')
            .ok_or_else(malformed)?;
        if space == 0 || !rest[..space].iter().all(u8::is_ascii_digit) {
            return Err(malformed());
        }
        let length: usize = std::str::from_utf8(&rest[..space])
            .map_err(|_| malformed())?
            .parse()
            .map_err(|_| malformed())?;
        if length <= space || length > rest.len() {
            return Err(malformed());
        }
        let record = &rest[space + 1..length];
        let equals = record
            .iter()
            .position(|byte| *byte == b'=')
            .ok_or_else(malformed)?;
        let (key, value) = record.split_at(equals);
        if key.is_empty()
            || key
                .iter()
                .any(|byte| *byte == 0 || byte.is_ascii_whitespace())
        {
            return Err(malformed());
        }
        let value = &value[1..];
        let value = value.strip_suffix(b"\n").ok_or_else(malformed)?;
        match key {
            b"path" => pax.path = Some(value.to_vec()),
            b"linkpath" => pax.link_path = Some(value.to_vec()),
            b"size" => {
                pax.size = Some(parse_pax_decimal(value, "size")?);
            }
            b"uid" | b"gid" => {
                let id = parse_pax_decimal(value, "owner")?;
                if key == b"uid" {
                    pax.uid = Some(id);
                } else {
                    pax.gid = Some(id);
                }
            }
            b"mtime" | b"atime" | b"ctime" => check_pax_timestamp(value)?,
            b"SCHILY.fflags" => {
                return Err(ImageError::Tar(
                    "archive carries platform-specific file flags".into(),
                ));
            }
            key if key.starts_with(b"SCHILY.acl.") => {
                return Err(ImageError::Tar(
                    "archive carries platform-specific ACL metadata".into(),
                ));
            }
            key if key == b"SCHILY.realsize"
                || key == b"SUN.holesdata"
                || key.starts_with(b"GNU.sparse.") =>
            {
                return Err(ImageError::Tar(
                    "archive uses an unsupported sparse pax record".into(),
                ));
            }
            _ => {}
        }
        rest = &rest[length..];
    }
    Ok(())
}

fn parse_pax_decimal(value: &[u8], kind: &str) -> Result<u64, ImageError> {
    let invalid = || ImageError::Tar(format!("unreadable pax {kind} record"));
    if value.is_empty() || !value.iter().all(u8::is_ascii_digit) {
        return Err(invalid());
    }
    std::str::from_utf8(value)
        .map_err(|_| invalid())?
        .parse()
        .map_err(|_| invalid())
}

fn check_pax_timestamp(value: &[u8]) -> Result<(), ImageError> {
    let invalid = || ImageError::Tar("invalid pax timestamp".into());
    let (whole, fraction) = match value.iter().position(|byte| *byte == b'.') {
        Some(at) => (&value[..at], Some(&value[at + 1..])),
        None => (value, None),
    };
    let (negative, whole) = match whole.strip_prefix(b"-") {
        Some(digits) => (true, digits),
        None => (false, whole),
    };
    if whole.is_empty()
        || !whole.iter().all(u8::is_ascii_digit)
        || fraction.is_some_and(|digits| !digits.iter().all(u8::is_ascii_digit))
    {
        return Err(invalid());
    }
    let seconds = std::str::from_utf8(whole)
        .map_err(|_| invalid())?
        .parse::<u64>()
        .map_err(|_| invalid())?;
    let fraction = fraction.unwrap_or_default();
    if negative && fraction.iter().any(|digit| *digit != b'0') {
        return Err(invalid());
    }
    let mut fractional_nanos = [b'0'; 9];
    for (out, digit) in fractional_nanos.iter_mut().zip(fraction) {
        *out = *digit;
    }
    if seconds > MAX_PORTABLE_TIMESTAMP_SECONDS
        || (!negative
            && seconds == MAX_PORTABLE_TIMESTAMP_SECONDS
            && (fractional_nanos > *b"854775807"
                || (fractional_nanos == *b"854775807"
                    && fraction
                        .get(9..)
                        .is_some_and(|remaining| remaining.iter().any(|digit| *digit != b'0')))))
    {
        return Err(invalid());
    }
    Ok(())
}

fn extract_checked(archive: &Path, dest: &Path) -> Result<(), ImageError> {
    check_portable_staging_root(dest)?;
    let pinned = pin_archive(archive, dest.parent().unwrap_or(dest))?;
    let (decoded, members) = decode_archive(&pinned, dest.parent().unwrap_or(dest))?;
    drop(pinned);
    check_members(&members)?;
    check_portable_names(&members, &mut BTreeMap::new())?;
    check_hardlinks(&members)?;
    untar(&decoded, dest)
}

fn check_portable_staging_root(path: &Path) -> Result<(), ImageError> {
    let resolved = path.canonicalize()?;
    if path
        .as_os_str()
        .as_bytes()
        .len()
        .max(resolved.as_os_str().as_bytes().len())
        > MAX_PORTABLE_STAGING_ROOT
    {
        return Err(ImageError::Tar("archive staging path is too long".into()));
    }
    Ok(())
}

const ARCHIVE_CHUNK: usize = 64 * 1024;

struct PinnedArchive {
    file: std::fs::File,
    size: u64,
    chunks: Arc<Vec<[u8; 32]>>,
}

impl PinnedArchive {
    fn reader(&self) -> Result<VerifiedArchiveReader, ImageError> {
        Ok(VerifiedArchiveReader {
            file: self.file.try_clone()?,
            size: self.size,
            chunks: Arc::clone(&self.chunks),
            position: 0,
            buffered_at: None,
            buffer: Vec::new(),
        })
    }
}

struct VerifiedArchiveReader {
    file: std::fs::File,
    size: u64,
    chunks: Arc<Vec<[u8; 32]>>,
    position: u64,
    buffered_at: Option<u64>,
    buffer: Vec<u8>,
}

impl Read for VerifiedArchiveReader {
    fn read(&mut self, output: &mut [u8]) -> std::io::Result<usize> {
        if output.is_empty() {
            return Ok(0);
        }
        if self.file.metadata()?.len() != self.size {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                "pinned archive size changed",
            ));
        }
        if self.position == self.size {
            return Ok(0);
        }
        let chunk = self.position / ARCHIVE_CHUNK as u64;
        let start = chunk * ARCHIVE_CHUNK as u64;
        if self.buffered_at != Some(start) {
            let length = (self.size - start).min(ARCHIVE_CHUNK as u64) as usize;
            self.buffer.resize(length, 0);
            self.file.seek(SeekFrom::Start(start))?;
            self.file.read_exact(&mut self.buffer)?;
            let digest: [u8; 32] = Sha256::digest(&self.buffer).into();
            if digest != self.chunks[chunk as usize] {
                return Err(std::io::Error::new(
                    std::io::ErrorKind::InvalidData,
                    "pinned archive content changed",
                ));
            }
            self.buffered_at = Some(start);
        }
        let at = (self.position - start) as usize;
        let length = output.len().min(self.buffer.len() - at);
        output[..length].copy_from_slice(&self.buffer[at..at + length]);
        self.position += length as u64;
        Ok(length)
    }
}

fn pin_archive(archive: &Path, staging: &Path) -> Result<PinnedArchive, ImageError> {
    let mut source = std::fs::File::open(archive)?;
    pin_reader(&mut source, staging)
}

struct CapturedArchiveReader<'a, R> {
    source: &'a mut R,
    captured: &'a mut std::fs::File,
}

impl<R: Read> Read for CapturedArchiveReader<'_, R> {
    fn read(&mut self, output: &mut [u8]) -> std::io::Result<usize> {
        let read = self.source.read(output)?;
        self.captured.write_all(&output[..read])?;
        Ok(read)
    }
}

fn decode_archive(
    archive: &PinnedArchive,
    staging: &Path,
) -> Result<(PinnedArchive, Vec<Member>), ImageError> {
    let mut stream = open_archive(archive.reader()?)?;
    let mut file = tempfile::tempfile_in(staging)?;
    {
        let mut captured = CapturedArchiveReader {
            source: &mut stream,
            captured: &mut file,
        };
        read_members_stream(&mut captured)?;
    }
    require_trailing_zeros(&mut stream)?;
    stream.finish()?;
    file.write_all(&[0; TAR_BLOCK])?;
    let decoded = pin_written_file(file)?;
    let mut reader = decoded.reader()?;
    let members = read_members_stream(&mut reader)?;
    require_trailing_zeros(&mut reader)?;
    Ok((decoded, members))
}

fn pin_reader(source: &mut impl Read, staging: &Path) -> Result<PinnedArchive, ImageError> {
    let mut file = tempfile::tempfile_in(staging)?;
    let mut buffer = [0u8; ARCHIVE_CHUNK];
    let mut chunks = Vec::new();
    let mut size = 0u64;
    loop {
        let mut length = 0;
        while length < ARCHIVE_CHUNK {
            let read = source.read(&mut buffer[length..])?;
            if read == 0 {
                break;
            }
            length += read;
        }
        if length == 0 {
            break;
        }
        file.write_all(&buffer[..length])?;
        chunks.push(Sha256::digest(&buffer[..length]).into());
        size = size
            .checked_add(length as u64)
            .ok_or_else(|| ImageError::Io(std::io::Error::other("pinned archive size overflow")))?;
    }
    Ok(PinnedArchive {
        file,
        size,
        chunks: Arc::new(chunks),
    })
}

fn pin_written_file(mut file: std::fs::File) -> Result<PinnedArchive, ImageError> {
    let size = file.metadata()?.len();
    file.seek(SeekFrom::Start(0))?;
    let mut buffer = [0u8; ARCHIVE_CHUNK];
    let mut chunks = Vec::new();
    let mut remaining = size;
    while remaining > 0 {
        let length = remaining.min(ARCHIVE_CHUNK as u64) as usize;
        file.read_exact(&mut buffer[..length])?;
        chunks.push(Sha256::digest(&buffer[..length]).into());
        remaining -= length as u64;
    }
    Ok(PinnedArchive {
        file,
        size,
        chunks: Arc::new(chunks),
    })
}

fn writable_layer_mode(mode: u32) -> u32 {
    mode | 0o700
}

fn merge_layer(
    staged: &Path,
    rootfs: &Path,
    relative: &Path,
    implicit_dirs: &BTreeSet<PathBuf>,
    opaque_modes: &BTreeMap<PathBuf, u32>,
    preserved_modes: &mut BTreeMap<PathBuf, u32>,
) -> Result<(), ImageError> {
    let mut entries: Vec<_> = std::fs::read_dir(staged)?.collect::<Result<Vec<_>, _>>()?;
    entries.sort_by_key(std::fs::DirEntry::file_name);
    for entry in entries {
        let name = entry.file_name();
        if name.to_string_lossy().starts_with(".wh.") {
            continue;
        }
        let source = staged.join(&name);
        let target = rootfs.join(&name);
        let path = relative.join(&name);
        let meta = std::fs::symlink_metadata(&source)?;
        let existing = std::fs::symlink_metadata(&target).ok();
        if meta.is_dir() {
            match &existing {
                Some(found) if found.is_symlink() => {
                    return Err(ImageError::UnsafePath(target.display().to_string()));
                }
                Some(found) if found.is_dir() => {}
                Some(_) => {
                    std::fs::remove_file(&target)?;
                    std::fs::create_dir(&target)?;
                }
                None => std::fs::create_dir(&target)?,
            }
            let mode = match &existing {
                Some(found) if found.is_dir() && implicit_dirs.contains(&path) => {
                    let mode = opaque_modes
                        .get(&path)
                        .copied()
                        .unwrap_or(found.permissions().mode() & 0o7777);
                    preserved_modes.insert(path.clone(), mode);
                    mode
                }
                _ => meta.permissions().mode() & 0o7777,
            };
            let open = std::fs::Permissions::from_mode(writable_layer_mode(mode));
            std::fs::set_permissions(&source, open.clone())?;
            std::fs::set_permissions(&target, open)?;
            merge_layer(
                &source,
                &target,
                &path,
                implicit_dirs,
                opaque_modes,
                preserved_modes,
            )?;
            std::fs::set_permissions(&target, std::fs::Permissions::from_mode(mode))?;
        } else {
            match &existing {
                Some(found) if found.is_dir() => std::fs::remove_dir_all(&target)?,
                Some(_) => std::fs::remove_file(&target)?,
                None => {}
            }
            std::fs::rename(&source, &target)?;
        }
    }
    Ok(())
}

fn open_directory(path: &Path, opened: &mut BTreeMap<PathBuf, u32>) -> Result<(), ImageError> {
    let mode = std::fs::symlink_metadata(path)?.permissions().mode() & 0o7777;
    if mode & 0o700 != 0o700 {
        std::fs::set_permissions(
            path,
            std::fs::Permissions::from_mode(writable_layer_mode(mode)),
        )?;
        opened.entry(path.to_path_buf()).or_insert(mode);
    }
    Ok(())
}

fn open_tree(path: &Path, opened: &mut BTreeMap<PathBuf, u32>) -> Result<(), ImageError> {
    if !std::fs::symlink_metadata(path)?.is_dir() {
        return Ok(());
    }
    open_directory(path, opened)?;
    for entry in std::fs::read_dir(path)? {
        let entry = entry?;
        if entry.file_type()?.is_dir() {
            open_tree(&entry.path(), opened)?;
        }
    }
    Ok(())
}

fn restore_directories(opened: BTreeMap<PathBuf, u32>) -> Result<(), ImageError> {
    let mut opened: Vec<_> = opened.into_iter().collect();
    opened.sort_by_key(|(path, _)| std::cmp::Reverse(path.components().count()));
    for (path, mode) in opened {
        match std::fs::symlink_metadata(&path) {
            Ok(meta) if meta.is_dir() => {
                std::fs::set_permissions(&path, std::fs::Permissions::from_mode(mode))?;
            }
            Ok(_) => {}
            Err(error)
                if matches!(
                    error.kind(),
                    std::io::ErrorKind::NotFound | std::io::ErrorKind::NotADirectory
                ) => {}
            Err(error) => return Err(error.into()),
        }
    }
    Ok(())
}

fn resolve_under(
    rootfs: &Path,
    relative: &Path,
    opened: &mut BTreeMap<PathBuf, u32>,
) -> Result<Option<PathBuf>, ImageError> {
    let Ok(mut cursor) = rootfs.canonicalize() else {
        return Ok(None);
    };
    let parts: Vec<_> = relative
        .components()
        .filter_map(|component| match component {
            Component::Normal(part) => Some(part),
            _ => None,
        })
        .collect();
    for (at, part) in parts.iter().enumerate() {
        if !std::fs::symlink_metadata(&cursor)?.is_dir() {
            return Ok(None);
        }
        open_directory(&cursor, opened)?;
        let next = match exact::entry(&cursor, part) {
            Ok(Some(next)) => next,
            Ok(None) => return Ok(None),
            Err(error)
                if matches!(
                    error.kind(),
                    std::io::ErrorKind::NotFound | std::io::ErrorKind::NotADirectory
                ) =>
            {
                return Ok(None);
            }
            Err(error) => return Err(error.into()),
        };
        if at + 1 < parts.len() && std::fs::symlink_metadata(&next)?.file_type().is_symlink() {
            return Err(ImageError::UnsafePath(relative.display().to_string()));
        }
        cursor = next;
    }
    Ok(Some(cursor))
}

fn untar(tarball: &PinnedArchive, dest: &Path) -> Result<(), ImageError> {
    let mut archive = tarball.reader()?;
    let mut stderr = tempfile::tempfile_in(dest.parent().unwrap_or(dest))?;
    let mut child = archive_tool("sh")
        .arg("-c")
        .arg("umask 022; exec tar \"$@\"")
        .arg("tar")
        .arg("-xpf")
        .arg("-")
        .arg("--no-same-owner")
        .arg("--no-xattrs")
        .arg("-C")
        .arg(dest)
        .stdin(Stdio::piped())
        .stdout(Stdio::null())
        .stderr(Stdio::from(stderr.try_clone()?))
        .spawn()?;
    let mut input = child
        .stdin
        .take()
        .ok_or_else(|| ImageError::Tar("tar produced no input pipe".into()))?;
    let transferred = match std::io::copy(&mut archive, &mut input) {
        Ok(_) => Ok(()),
        Err(error) if error.kind() == std::io::ErrorKind::BrokenPipe => {
            std::io::copy(&mut archive, &mut std::io::sink())
                .map(|_| ())
                .map_err(ImageError::from)
        }
        Err(error) => Err(error.into()),
    };
    drop(input);
    let status = child.wait()?;
    if !status.success() {
        stderr.seek(SeekFrom::Start(0))?;
        let mut detail = String::new();
        stderr.read_to_string(&mut detail)?;
        return Err(ImageError::Tar(detail));
    }
    transferred
}

#[cfg(test)]
fn apply_layer(layer: &Path, rootfs: &Path, owners: &mut Ownership) -> Result<(), ImageError> {
    apply_layer_tracked(layer, rootfs, owners, &mut BTreeMap::new(), None)
}

fn apply_layer_tracked(
    layer: &Path,
    rootfs: &Path,
    owners: &mut Ownership,
    portable_names: &mut BTreeMap<Vec<u8>, Vec<u8>>,
    descriptor: Option<&OciDescriptor>,
) -> Result<(), ImageError> {
    check_portable_staging_root(rootfs)?;
    let staging = rootfs.parent().unwrap_or(rootfs);
    let pinned = pin_archive(layer, staging)?;
    if let Some(descriptor) = descriptor {
        verify_pinned_archive(&pinned, descriptor)?;
    }
    let (decoded, members) = decode_archive(&pinned, staging)?;
    drop(pinned);
    check_members(&members)?;
    check_layer_portable_names(&members, portable_names)?;
    check_hardlinks(&members)?;
    let staged = tempfile::tempdir_in(staging)?;
    check_portable_staging_root(staged.path())?;
    let opaque_modes = apply_whiteouts(&members, rootfs)?;
    let implicit_dirs = implicit_layer_dirs(&members);
    untar(&decoded, staged.path())?;
    let mut preserved_modes = BTreeMap::new();
    merge_layer(
        staged.path(),
        rootfs,
        Path::new(""),
        &implicit_dirs,
        &opaque_modes,
        &mut preserved_modes,
    )?;
    record_owners(&members, owners, &implicit_dirs, &preserved_modes);
    Ok(())
}

fn implicit_layer_dirs(members: &[Member]) -> BTreeSet<PathBuf> {
    let explicit_dirs: BTreeSet<PathBuf> = members
        .iter()
        .filter(|member| member.is_dir && whiteout(member.path()).is_none())
        .map(|member| normalized(member.path()))
        .collect();
    let mut implicit_dirs = BTreeSet::new();
    for member in members {
        let path = normalized(member.path());
        let mut parent = path.parent();
        while let Some(dir) = parent.filter(|dir| !dir.as_os_str().is_empty()) {
            if !explicit_dirs.contains(dir) {
                implicit_dirs.insert(dir.to_path_buf());
            }
            parent = dir.parent();
        }
    }
    implicit_dirs
}

fn record_owners(
    members: &[Member],
    owners: &mut Ownership,
    implicit_dirs: &BTreeSet<PathBuf>,
    preserved_modes: &BTreeMap<PathBuf, u32>,
) {
    for member in members {
        let path = member.path();
        match whiteout(path) {
            Some(Whiteout::Opaque(dir)) => owners.remove_below(dir),
            Some(Whiteout::Entry(target)) => owners.remove_tree(&target),
            None => {}
        }
    }
    for dir in implicit_dirs {
        if !preserved_modes.contains_key(dir) {
            owners.remove_tree(dir);
            owners.record(dir, Owner::ROOT);
            owners.record_mode(dir, 0o755);
        }
    }
    for member in members {
        let path = member.path();
        if whiteout(path).is_some() {
            continue;
        }
        let (owner, mode) =
            member
                .hardlink_target
                .as_ref()
                .map_or((member.owner, member.mode), |target| {
                    let target = Path::new(OsStr::from_bytes(target));
                    (owners.owner_of(target), owners.mode_of(target, member.mode))
                });
        if !member.is_dir {
            owners.remove_tree(path);
        }
        owners.record(path, owner);
        owners.record_mode(path, mode);
    }
}

enum Whiteout<'a> {
    Opaque(&'a Path),
    Entry(PathBuf),
}

fn whiteout(path: &Path) -> Option<Whiteout<'_>> {
    let name = path.file_name()?.to_str()?;
    if name == ".wh..wh..opq" {
        Some(Whiteout::Opaque(path.parent().unwrap_or(Path::new(""))))
    } else {
        name.strip_prefix(".wh.")
            .map(|hidden| Whiteout::Entry(path.with_file_name(hidden)))
    }
}

fn apply_whiteouts(
    members: &[Member],
    rootfs: &Path,
) -> Result<BTreeMap<PathBuf, u32>, ImageError> {
    let mut opened = BTreeMap::new();
    let result = (|| {
        let mut opaque_modes = BTreeMap::new();
        for member in members {
            let path = member.path();
            let Some(name) = path.file_name().and_then(|n| n.to_str()) else {
                continue;
            };
            if name == ".wh..wh..opq" {
                let parent = path.parent().unwrap_or(Path::new(""));
                let Some(dir) = resolve_under(rootfs, parent, &mut opened)? else {
                    continue;
                };
                let Ok(meta) = std::fs::symlink_metadata(&dir) else {
                    continue;
                };
                if meta.is_symlink() {
                    return Err(ImageError::UnsafePath(member.shown()));
                }
                if meta.is_dir() {
                    let mode = opened
                        .get(&dir)
                        .copied()
                        .unwrap_or(meta.permissions().mode() & 0o7777);
                    opaque_modes.entry(normalized(parent)).or_insert(mode);
                    open_tree(&dir, &mut opened)?;
                    std::fs::remove_dir_all(&dir)?;
                    std::fs::create_dir_all(&dir)?;
                }
            } else if let Some(hidden) = name.strip_prefix(".wh.") {
                let Some(target) =
                    resolve_under(rootfs, &path.with_file_name(hidden), &mut opened)?
                else {
                    continue;
                };
                let Ok(meta) = std::fs::symlink_metadata(&target) else {
                    continue;
                };
                if meta.is_dir() {
                    open_tree(&target, &mut opened)?;
                    std::fs::remove_dir_all(&target)?;
                } else {
                    std::fs::remove_file(&target)?;
                }
            }
        }
        Ok(opaque_modes)
    })();
    let restored = restore_directories(opened);
    match (result, restored) {
        (Err(error), _) => Err(error),
        (Ok(_), Err(error)) => Err(error),
        (Ok(modes), Ok(())) => Ok(modes),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tree_removal_matches_a_full_prefix_scan() {
        let names = [
            "a", "a/b", "a/b/c", "a/b/c/d", "a/b.txt", "a/bc", "a/b-c", "b", "b/a",
        ];
        for target in ["a", "a/b", "a/b/c", "b", "c", ""] {
            for include_root in [false, true] {
                let mut fast: BTreeMap<PathBuf, ()> =
                    names.iter().map(|name| (PathBuf::from(name), ())).collect();
                let mut slow = fast.clone();
                let path = Path::new(target);
                remove_path_tree(&mut fast, path, include_root);
                slow.retain(|recorded, _| {
                    (!include_root && recorded == path) || !recorded.starts_with(path)
                });
                assert_eq!(fast, slow, "{target} {include_root}");

                let mut fast: BTreeMap<Vec<u8>, Vec<u8>> = names
                    .iter()
                    .map(|name| (name.as_bytes().to_vec(), Vec::new()))
                    .collect();
                let mut slow = fast.clone();
                let key = target.as_bytes();
                remove_portable_tree(&mut fast, key, include_root);
                let mut prefix = key.to_vec();
                prefix.push(b'/');
                slow.retain(|candidate, _| {
                    !((include_root && candidate == key)
                        || key.is_empty()
                        || candidate.starts_with(&prefix))
                });
                assert_eq!(fast, slow, "{target} {include_root}");
            }
        }
    }

    struct OciFixture {
        manifest: PathBuf,
        config: PathBuf,
        layers: Vec<PathBuf>,
    }

    fn write_oci_blob(layout: &Path, bytes: &[u8]) -> (serde_json::Value, PathBuf) {
        let encoded = format!("{:x}", Sha256::digest(bytes));
        let digest = format!("sha256:{encoded}");
        let directory = layout.join("blobs/sha256");
        std::fs::create_dir_all(&directory).unwrap();
        let path = directory.join(encoded);
        std::fs::write(&path, bytes).unwrap();
        (
            serde_json::json!({"digest": digest, "size": bytes.len()}),
            path,
        )
    }

    fn write_oci_layout(layout: &Path, config: &[u8], layers: &[&[u8]]) -> OciFixture {
        std::fs::create_dir_all(layout).unwrap();
        let (config_descriptor, config) = write_oci_blob(layout, config);
        let (layer_descriptors, layers): (Vec<_>, Vec<_>) = layers
            .iter()
            .map(|bytes| write_oci_blob(layout, bytes))
            .unzip();
        let manifest = serde_json::to_vec(&serde_json::json!({
            "config": config_descriptor,
            "layers": layer_descriptors
        }))
        .unwrap();
        let (manifest_descriptor, manifest) = write_oci_blob(layout, &manifest);
        std::fs::write(
            layout.join("index.json"),
            serde_json::to_vec(&serde_json::json!({"manifests": [manifest_descriptor]})).unwrap(),
        )
        .unwrap();
        OciFixture {
            manifest,
            config,
            layers,
        }
    }

    #[test]
    fn public_credential_resolver_preserves_explicit_ids() {
        let rootfs = tempfile::tempdir().unwrap();
        let config = RuntimeConfig {
            user: Some("123:456".into()),
            ..RuntimeConfig::default()
        };
        assert_eq!(
            resolve_process_credentials(&config, rootfs.path()).unwrap(),
            ProcessCredentials {
                uid: 123,
                gid: 456,
                additional_gids: Vec::new()
            }
        );
    }

    #[test]
    fn runtime_config_parses_the_config_section() {
        let blob = br#"{"config":{"Entrypoint":["/e"],"Cmd":["run"],
            "Env":["A=1"],"WorkingDir":"/w","User":"worker:shared"},"rootfs":{}}"#;
        let config = parse_runtime_config(blob).unwrap();
        assert_eq!(config.entrypoint, ["/e"]);
        assert_eq!(config.cmd, ["run"]);
        assert_eq!(config.env, ["A=1"]);
        assert_eq!(config.working_dir.as_deref(), Some("/w"));
        assert_eq!(config.user.as_deref(), Some("worker:shared"));

        let empty = parse_runtime_config(b"{}").unwrap();
        assert!(empty.entrypoint.is_empty() && empty.cmd.is_empty());
    }

    #[test]
    fn runtime_config_rejects_environment_entries_the_launcher_would_drop() {
        for env in [
            vec!["MISSING_EQUALS".to_string()],
            vec!["1NAME=value".to_string()],
        ] {
            let blob = serde_json::json!({"config": {"Env": env}});
            assert!(matches!(
                parse_runtime_config(&serde_json::to_vec(&blob).unwrap()),
                Err(ImageError::InvalidEnvironment { .. })
            ));
        }
    }

    #[test]
    fn runtime_config_rejects_duplicate_environment_and_unnormalized_cwd() {
        let duplicate = serde_json::json!({
            "config": {"Env": ["A=one", "A=two"]}
        });
        assert!(matches!(
            parse_runtime_config(&serde_json::to_vec(&duplicate).unwrap()),
            Err(ImageError::DuplicateEnvironmentKey { .. })
        ));
        for directory in ["relative", "/a/../b", "/a//b", "/a/"] {
            let blob = serde_json::json!({"config": {"WorkingDir": directory}});
            assert!(matches!(
                parse_runtime_config(&serde_json::to_vec(&blob).unwrap()),
                Err(ImageError::InvalidWorkingDirectory(_)),
            ));
        }
    }

    #[test]
    fn blob_path_splits_the_digest() {
        let dir = tempfile::tempdir().unwrap();
        let (descriptor, path) = write_oci_blob(dir.path(), b"blob");
        assert_eq!(
            blob_path(dir.path(), descriptor["digest"].as_str().unwrap()).unwrap(),
            path.canonicalize().unwrap()
        );
    }

    #[test]
    fn blob_path_refuses_a_symlinked_layout() {
        let dir = tempfile::tempdir().unwrap();
        let encoded = format!("{:x}", Sha256::digest(b"secret"));
        let digest = format!("sha256:{encoded}");
        let outside = dir.path().join("outside/sha256");
        std::fs::create_dir_all(&outside).unwrap();
        std::fs::write(outside.join(&encoded), b"secret").unwrap();

        let via_dir = dir.path().join("via-dir");
        std::fs::create_dir_all(&via_dir).unwrap();
        std::os::unix::fs::symlink(dir.path().join("outside"), via_dir.join("blobs")).unwrap();
        let err = blob_path(&via_dir, &digest).unwrap_err();
        assert!(matches!(err, ImageError::UnsafePath(_)), "{err:?}");

        let via_blob = dir.path().join("via-blob");
        std::fs::create_dir_all(via_blob.join("blobs/sha256")).unwrap();
        std::os::unix::fs::symlink(
            outside.join(&encoded),
            via_blob.join("blobs/sha256").join(&encoded),
        )
        .unwrap();
        let err = blob_path(&via_blob, &digest).unwrap_err();
        assert!(matches!(err, ImageError::UnsafePath(_)), "{err:?}");
    }

    #[test]
    fn oci_layout_refuses_a_symlinked_index_or_blob() {
        let dir = tempfile::tempdir().unwrap();
        let outside = dir.path().join("outside");
        std::fs::create_dir_all(&outside).unwrap();
        std::fs::write(outside.join("secret"), br#"{"manifests":[]}"#).unwrap();

        let layout = dir.path().join("layout");
        std::fs::create_dir_all(layout.join("blobs/sha256")).unwrap();
        std::os::unix::fs::symlink(outside.join("secret"), layout.join("index.json")).unwrap();
        let err = oci_layout_layers(&layout).unwrap_err();
        assert!(matches!(err, ImageError::UnsafePath(_)), "{err:?}");

        std::fs::remove_file(layout.join("index.json")).unwrap();
        let encoded = format!("{:x}", Sha256::digest(br#"{"manifests":[]}"#));
        std::fs::write(
            layout.join("index.json"),
            serde_json::to_vec(&serde_json::json!({
                "manifests": [{
                    "digest": format!("sha256:{encoded}"),
                    "size": br#"{"manifests":[]}"#.len()
                }]
            }))
            .unwrap(),
        )
        .unwrap();
        std::os::unix::fs::symlink(
            outside.join("secret"),
            layout.join("blobs/sha256").join(&encoded),
        )
        .unwrap();
        let err = oci_layout_layers(&layout).unwrap_err();
        assert!(matches!(err, ImageError::UnsafePath(_)), "{err:?}");
    }

    #[test]
    fn docker_save_refuses_symlinked_references() {
        let dir = tempfile::tempdir().unwrap();
        let outside = dir.path().join("outside");
        std::fs::create_dir_all(&outside).unwrap();
        std::fs::write(outside.join("secret"), b"[]").unwrap();

        let layout = dir.path().join("layout");
        std::fs::create_dir_all(&layout).unwrap();
        std::os::unix::fs::symlink(outside.join("secret"), layout.join("manifest.json")).unwrap();
        let err = docker_save_layers(&layout).unwrap_err();
        assert!(matches!(err, ImageError::UnsafePath(_)), "{err:?}");

        std::fs::remove_file(layout.join("manifest.json")).unwrap();
        std::fs::write(
            layout.join("manifest.json"),
            br#"[{"Config":"c.json","Layers":["l1.tar"]}]"#,
        )
        .unwrap();
        std::fs::write(layout.join("c.json"), b"{}").unwrap();
        std::os::unix::fs::symlink(outside.join("secret"), layout.join("l1.tar")).unwrap();
        let err = docker_save_layers(&layout).unwrap_err();
        assert!(matches!(err, ImageError::UnsafePath(_)), "{err:?}");
    }

    #[test]
    fn blob_path_refuses_a_traversing_digest() {
        for digest in [
            "sha256:../../etc/passwd",
            "sha512:abcd",
            "sha256:ABCDEF",
            "sha256:abc",
            "..:..",
            "/etc:passwd",
            "",
        ] {
            assert!(
                matches!(
                    blob_path(Path::new("/l"), digest),
                    Err(ImageError::InvalidDigest(_))
                ),
                "{digest} was accepted"
            );
        }
    }

    #[test]
    fn docker_save_manifest_refuses_traversing_references() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(
            dir.path().join("manifest.json"),
            br#"[{"Config":"c.json","Layers":["../../outside.tar"]}]"#,
        )
        .unwrap();
        assert!(matches!(
            docker_save_layers(dir.path()),
            Err(ImageError::UnsafePath(_))
        ));

        std::fs::write(
            dir.path().join("manifest.json"),
            br#"[{"Config":"/etc/passwd","Layers":[]}]"#,
        )
        .unwrap();
        assert!(matches!(
            docker_save_layers(dir.path()),
            Err(ImageError::UnsafePath(_))
        ));
    }

    #[test]
    fn docker_save_manifest_lists_layers_in_order() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::write(
            dir.path().join("manifest.json"),
            br#"[{"Config":"c.json","Layers":["l1.tar","l2.tar"]}]"#,
        )
        .unwrap();
        std::fs::write(dir.path().join("c.json"), b"{\"config\":{}}").unwrap();
        std::fs::write(dir.path().join("l1.tar"), b"").unwrap();
        std::fs::write(dir.path().join("l2.tar"), b"").unwrap();
        let (layers, config) = docker_save_layers(dir.path()).unwrap();
        let real = dir.path().canonicalize().unwrap();
        assert_eq!(
            layers.iter().map(|layer| &layer.path).collect::<Vec<_>>(),
            [&real.join("l1.tar"), &real.join("l2.tar")]
        );
        assert_eq!(config, b"{\"config\":{}}");
    }

    #[test]
    fn oci_layout_resolves_blobs_through_the_index() {
        let dir = tempfile::tempdir().unwrap();
        let fixture = write_oci_layout(dir.path(), b"cfg", &[b""]);
        let (layers, config) = oci_layout_layers(dir.path()).unwrap();
        assert_eq!(layers[0].path, fixture.layers[0].canonicalize().unwrap());
        assert_eq!(config, b"cfg");
    }

    #[test]
    fn provenance_follows_the_index_selection_staging_consumes() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        let first_layer =
            std::fs::read(tar_layer(dir.path(), "first", &[("marker", b"FIRST")])).unwrap();
        let first = write_oci_layout(&layout, br#"{"config":{"Cmd":["FIRST"]}}"#, &[&first_layer]);
        let first_index = std::fs::read(layout.join("index.json")).unwrap();
        let stale_index = OciInputDigest {
            sha256: format!("{:x}", Sha256::digest(&first_index)),
            size: first_index.len() as u64,
        };

        let second_layer =
            std::fs::read(tar_layer(dir.path(), "second", &[("marker", b"SECOND")])).unwrap();
        let (config_descriptor, config_path) =
            write_oci_blob(&layout, br#"{"config":{"Cmd":["SECOND"]}}"#);
        let (layer_descriptor, layer_path) = write_oci_blob(&layout, &second_layer);
        let second_manifest = serde_json::to_vec(&serde_json::json!({
            "config": config_descriptor,
            "layers": [layer_descriptor]
        }))
        .unwrap();
        let (manifest_descriptor, manifest_path) = write_oci_blob(&layout, &second_manifest);
        let second_index =
            serde_json::to_vec(&serde_json::json!({"manifests": [manifest_descriptor]})).unwrap();
        std::fs::write(layout.join("index.json"), &second_index).unwrap();

        let (staged, Some(provenance)) =
            stage_with_provenance(layout.to_str().unwrap(), &dir.path().join("stage")).unwrap()
        else {
            panic!("OCI layout must return provenance");
        };
        assert_eq!(staged.config.cmd, ["SECOND"]);
        assert_eq!(
            std::fs::read(staged.rootfs.join("marker")).unwrap(),
            b"SECOND"
        );
        let files = provenance.files();
        assert_ne!(files["index.json"], stale_index);
        assert_eq!(
            files["index.json"].sha256,
            format!("{:x}", Sha256::digest(&second_index))
        );
        assert_eq!(files["index.json"].size, second_index.len() as u64);
        for path in [&config_path, &layer_path, &manifest_path] {
            let relative = path.strip_prefix(&layout).unwrap().to_str().unwrap();
            let bytes = std::fs::read(path).unwrap();
            assert_eq!(
                files[relative].sha256,
                format!("{:x}", Sha256::digest(&bytes))
            );
            assert_eq!(files[relative].size, bytes.len() as u64);
        }
        assert_eq!(files.len(), 4);
        for path in [first.config, first.layers[0].clone(), first.manifest] {
            let relative = path.strip_prefix(&layout).unwrap().to_str().unwrap();
            assert!(!files.contains_key(relative));
        }
    }

    #[test]
    fn staging_rejects_modified_oci_manifest_config_and_layer_blobs() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        let original_layer = tar_layer(dir.path(), "original", &[("marker", b"ORIGINAL")]);
        let replacement_layer = tar_layer(dir.path(), "replacement", &[("marker", b"SPOOFED!")]);
        let original_layer = std::fs::read(original_layer).unwrap();
        let replacement_layer = std::fs::read(replacement_layer).unwrap();
        assert_eq!(original_layer.len(), replacement_layer.len());
        let original_config = br#"{"config":{"Cmd":["ORIGINAL"]}}"#;
        let replacement_config = br#"{"config":{"Cmd":["SPOOFED!"]}}"#;
        assert_eq!(original_config.len(), replacement_config.len());
        let fixture = write_oci_layout(&layout, original_config, &[&original_layer]);

        let staged = stage(layout.to_str().unwrap(), &dir.path().join("stage-original")).unwrap();
        assert_eq!(staged.config.cmd, ["ORIGINAL"]);
        assert_eq!(
            std::fs::read(staged.rootfs.join("marker")).unwrap(),
            b"ORIGINAL"
        );

        std::fs::write(&fixture.config, replacement_config).unwrap();
        assert!(matches!(
            stage(layout.to_str().unwrap(), &dir.path().join("stage-config")),
            Err(ImageError::DescriptorDigest(_))
        ));
        std::fs::write(&fixture.config, original_config).unwrap();

        std::fs::write(&fixture.layers[0], &replacement_layer).unwrap();
        assert!(matches!(
            stage(layout.to_str().unwrap(), &dir.path().join("stage-layer")),
            Err(ImageError::DescriptorDigest(_))
        ));
        std::fs::write(&fixture.layers[0], &original_layer).unwrap();

        let original_manifest = std::fs::read(&fixture.manifest).unwrap();
        let (replacement_descriptor, _) = write_oci_blob(&layout, &replacement_layer);
        let mut changed: serde_json::Value = serde_json::from_slice(&original_manifest).unwrap();
        changed["layers"][0] = replacement_descriptor;
        let changed = serde_json::to_vec(&changed).unwrap();
        assert_eq!(original_manifest.len(), changed.len());
        std::fs::write(&fixture.manifest, changed).unwrap();
        assert!(matches!(
            stage(layout.to_str().unwrap(), &dir.path().join("stage-manifest")),
            Err(ImageError::DescriptorDigest(_))
        ));
    }

    #[test]
    fn staging_uses_the_verified_oci_layer_bytes_for_extraction() {
        if let Some(layout) = std::env::var_os("HARMONY_OCI_PINNED_ARCHIVE_CHILD") {
            let stage_dir =
                PathBuf::from(std::env::var_os("HARMONY_OCI_PINNED_ARCHIVE_STAGE").unwrap());
            let staged = stage(Path::new(&layout).to_str().unwrap(), &stage_dir).unwrap();
            assert_eq!(
                std::fs::read(staged.rootfs.join("marker")).unwrap(),
                b"ORIGINAL"
            );
            return;
        }

        let dir = tempfile::tempdir().unwrap();
        let original = tar_layer(dir.path(), "original", &[("marker", b"ORIGINAL")]);
        let replacement = tar_layer(dir.path(), "replacement", &[("marker", b"SPOOFED!")]);
        let original = std::fs::read(original).unwrap();
        let replacement = std::fs::read(replacement).unwrap();
        assert_eq!(original.len(), replacement.len());
        let layout = dir.path().join("layout");
        write_oci_layout(&layout, br#"{"config":{}}"#, &[&original]);
        let bin = dir.path().join("bin");
        std::fs::create_dir(&bin).unwrap();
        std::fs::write(bin.join("replacement"), replacement).unwrap();
        let wrapper = bin.join("tar");
        std::fs::write(
            &wrapper,
            b"#!/bin/sh\ndir=${0%/*}\nif [ \"$1\" = -xpf ]; then\n  case \"$2\" in\n    */checked-archive-*.tar) cat \"$dir/replacement\" > \"$2\"; touch \"$dir/swapped\" ;;\n    -) touch \"$dir/stdin\" ;;\n  esac\nfi\nexec /usr/bin/tar \"$@\"\n",
        )
        .unwrap();
        std::fs::set_permissions(&wrapper, std::fs::Permissions::from_mode(0o755)).unwrap();
        let output = Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "image::tests::staging_uses_the_verified_oci_layer_bytes_for_extraction",
            ])
            .env("HARMONY_OCI_PINNED_ARCHIVE_CHILD", &layout)
            .env("HARMONY_OCI_PINNED_ARCHIVE_STAGE", dir.path().join("stage"))
            .env(
                "PATH",
                format!("{}:{}", bin.display(), std::env::var("PATH").unwrap()),
            )
            .output()
            .unwrap();
        assert!(
            output.status.success(),
            "{}\n{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
        assert!(bin.join("stdin").exists());
        assert!(!bin.join("swapped").exists());
    }

    #[test]
    fn staging_validates_and_extracts_one_decoded_archive() {
        if let Some(source) = std::env::var_os("HARMONY_OCI_DECODE_CHILD") {
            let stage_dir = PathBuf::from(std::env::var_os("HARMONY_OCI_DECODE_STAGE").unwrap());
            let marker = if std::env::var("HARMONY_OCI_DECODE_KIND").unwrap() == "layer" {
                stage(Path::new(&source).to_str().unwrap(), &stage_dir)
                    .unwrap()
                    .rootfs
                    .join("marker")
            } else {
                std::fs::create_dir(&stage_dir).unwrap();
                extract_checked(Path::new(&source), &stage_dir).unwrap();
                stage_dir.join("marker")
            };
            assert_eq!(std::fs::read(marker).unwrap(), b"ORIGINAL");
            return;
        }

        let dir = tempfile::tempdir().unwrap();
        let original = tar_layer(dir.path(), "original", &[("marker", b"ORIGINAL")]);
        let replacement = tar_layer(dir.path(), "replacement", &[("marker", b"SPOOFED!")]);
        let layout = dir.path().join("layout");
        write_oci_layout(&layout, br#"{"config":{}}"#, &[b"\x28\xb5\x2f\xfdlayer"]);
        let outer = dir.path().join("outer.zst");
        std::fs::write(&outer, b"\x28\xb5\x2f\xfdouter").unwrap();
        for (kind, source) in [("layer", &layout), ("outer", &outer)] {
            let bin = dir.path().join(format!("bin-{kind}"));
            std::fs::create_dir(&bin).unwrap();
            std::fs::copy(&original, bin.join("original")).unwrap();
            std::fs::copy(&replacement, bin.join("replacement")).unwrap();
            let wrapper = bin.join("zstd");
            std::fs::write(
                &wrapper,
                b"#!/bin/sh\ndir=${0%/*}\ncat >/dev/null\nif [ -e \"$dir/seen\" ]; then\n  touch \"$dir/again\"\n  cat \"$dir/replacement\"\nelse\n  touch \"$dir/seen\"\n  cat \"$dir/original\"\nfi\n",
            )
            .unwrap();
            std::fs::set_permissions(&wrapper, std::fs::Permissions::from_mode(0o755)).unwrap();
            let output = Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "image::tests::staging_validates_and_extracts_one_decoded_archive",
                ])
                .env("HARMONY_OCI_DECODE_CHILD", source)
                .env("HARMONY_OCI_DECODE_KIND", kind)
                .env(
                    "HARMONY_OCI_DECODE_STAGE",
                    dir.path().join(format!("stage-{kind}")),
                )
                .env(
                    "PATH",
                    format!("{}:{}", bin.display(), std::env::var("PATH").unwrap()),
                )
                .output()
                .unwrap();
            assert!(
                output.status.success(),
                "{kind}: {}\n{}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
            assert!(bin.join("seen").exists());
            assert!(!bin.join("again").exists());
        }
    }

    #[test]
    fn decoded_snapshot_does_not_store_compressed_tar_padding() {
        let dir = tempfile::tempdir().unwrap();
        let tarball = tar_layer(dir.path(), "layer", &[("marker", b"ORIGINAL")]);
        let tar = std::fs::read(tarball).unwrap();
        let mut padded = tar.clone();
        padded.extend(vec![0; 2 * 1024 * 1024]);
        let mut encoder = flate2::write::GzEncoder::new(Vec::new(), flate2::Compression::default());
        encoder.write_all(&padded).unwrap();
        let compressed = dir.path().join("layer.tar.gz");
        std::fs::write(&compressed, encoder.finish().unwrap()).unwrap();
        let pinned = pin_archive(&compressed, dir.path()).unwrap();
        let (decoded, members) = decode_archive(&pinned, dir.path()).unwrap();
        assert_eq!(members.len(), 1);
        assert!(decoded.size <= tar.len() as u64);
        let dest = dir.path().join("dest");
        std::fs::create_dir(&dest).unwrap();
        untar(&decoded, &dest).unwrap();
        assert_eq!(std::fs::read(dest.join("marker")).unwrap(), b"ORIGINAL");
    }

    #[test]
    fn early_exiting_decoder_still_verifies_unread_archive_bytes() {
        if let Some(source) = std::env::var_os("HARMONY_OCI_EARLY_DECODER_CHILD") {
            let staging =
                PathBuf::from(std::env::var_os("HARMONY_OCI_EARLY_DECODER_STAGE").unwrap());
            let pinned = pin_archive(Path::new(&source), &staging).unwrap();
            let (_, members) = decode_archive(&pinned, &staging).unwrap();
            assert_eq!(members.len(), 1);
            let mut retained = pinned.file.try_clone().unwrap();
            retained.seek(SeekFrom::Start(pinned.size - 1)).unwrap();
            retained.write_all(b"X").unwrap();
            assert!(matches!(
                decode_archive(&pinned, &staging),
                Err(ImageError::Io(error)) if error.kind() == std::io::ErrorKind::InvalidData
            ));
            return;
        }

        let dir = tempfile::tempdir().unwrap();
        let tarball = tar_layer(dir.path(), "layer", &[("marker", b"ORIGINAL")]);
        let bin = dir.path().join("bin");
        std::fs::create_dir(&bin).unwrap();
        std::fs::copy(tarball, bin.join("decoded")).unwrap();
        let decoder = bin.join("bzip2");
        std::fs::write(&decoder, b"#!/bin/sh\ndir=${0%/*}\ncat \"$dir/decoded\"\n").unwrap();
        std::fs::set_permissions(&decoder, std::fs::Permissions::from_mode(0o755)).unwrap();
        let source = dir.path().join("layer.tar.bz2");
        let mut bytes = b"BZh9".to_vec();
        bytes.extend(vec![b'x'; 2 * 1024 * 1024]);
        std::fs::write(&source, bytes).unwrap();
        let output = Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "image::tests::early_exiting_decoder_still_verifies_unread_archive_bytes",
            ])
            .env("HARMONY_OCI_EARLY_DECODER_CHILD", &source)
            .env("HARMONY_OCI_EARLY_DECODER_STAGE", dir.path())
            .env(
                "PATH",
                format!("{}:{}", bin.display(), std::env::var("PATH").unwrap()),
            )
            .output()
            .unwrap();
        assert!(
            output.status.success(),
            "{}\n{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    #[test]
    fn pinned_archive_detects_in_place_change_after_descriptor_and_member_checks() {
        let dir = tempfile::tempdir().unwrap();
        let original = tar_layer(dir.path(), "original", &[("marker", b"ORIGINAL")]);
        let replacement = tar_layer(dir.path(), "replacement", &[("marker", b"SPOOFED!")]);
        let original_bytes = std::fs::read(&original).unwrap();
        let replacement_bytes = std::fs::read(replacement).unwrap();
        assert_eq!(original_bytes.len(), replacement_bytes.len());
        let descriptor = OciDescriptor {
            digest: format!("sha256:{:x}", Sha256::digest(&original_bytes)),
            size: original_bytes.len() as u64,
        };
        let pinned = pin_archive(&original, dir.path()).unwrap();
        verify_pinned_archive(&pinned, &descriptor).unwrap();
        read_members_file(pinned.reader().unwrap()).unwrap();
        let mut retained = pinned.file.try_clone().unwrap();
        retained.seek(SeekFrom::Start(0)).unwrap();
        retained.write_all(&replacement_bytes).unwrap();
        assert!(matches!(
            read_members_file(pinned.reader().unwrap()),
            Err(ImageError::Io(error)) if error.kind() == std::io::ErrorKind::InvalidData
        ));
        let dest = dir.path().join("dest");
        std::fs::create_dir(&dest).unwrap();
        assert!(untar(&pinned, &dest).is_err());
        assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
    }

    #[test]
    fn pinned_archive_checks_boundary_partial_chunk_and_length_changes() {
        let dir = tempfile::tempdir().unwrap();
        let original: Vec<u8> = (0..ARCHIVE_CHUNK * 2 + 17)
            .map(|at| (at % 251) as u8)
            .collect();
        let source = dir.path().join("source.bin");
        std::fs::write(&source, &original).unwrap();
        let pinned = pin_archive(&source, dir.path()).unwrap();
        let mut accepted = Vec::new();
        pinned.reader().unwrap().read_to_end(&mut accepted).unwrap();
        assert_eq!(accepted, original);
        let mut retained = pinned.file.try_clone().unwrap();
        for at in [ARCHIVE_CHUNK - 1, ARCHIVE_CHUNK, original.len() - 1] {
            retained.seek(SeekFrom::Start(at as u64)).unwrap();
            retained.write_all(&[original[at] ^ 1]).unwrap();
            assert_eq!(
                pinned
                    .reader()
                    .unwrap()
                    .read_to_end(&mut Vec::new())
                    .unwrap_err()
                    .kind(),
                std::io::ErrorKind::InvalidData
            );
            retained.seek(SeekFrom::Start(at as u64)).unwrap();
            retained.write_all(&[original[at]]).unwrap();
        }
        pinned.file.set_len(original.len() as u64 - 1).unwrap();
        assert_eq!(
            pinned.reader().unwrap().read(&mut [0]).unwrap_err().kind(),
            std::io::ErrorKind::InvalidData
        );
        pinned.file.set_len(original.len() as u64 + 1).unwrap();
        assert_eq!(
            pinned.reader().unwrap().read(&mut [0]).unwrap_err().kind(),
            std::io::ErrorKind::InvalidData
        );
    }

    #[test]
    fn staging_rejects_oci_descriptor_size_mismatches() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        let layer = tar_layer(dir.path(), "layer", &[("marker", b"data")]);
        let layer = std::fs::read(layer).unwrap();
        let fixture = write_oci_layout(&layout, br#"{"config":{}}"#, &[&layer]);
        std::fs::write(&fixture.layers[0], [&layer[..], b" "].concat()).unwrap();
        assert!(matches!(
            stage(layout.to_str().unwrap(), &dir.path().join("stage")),
            Err(ImageError::DescriptorSize { .. })
        ));
    }

    #[test]
    fn staging_checks_the_compressed_layer_blob_not_just_its_tar_contents() {
        use std::io::Write as _;

        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        let tarball = tar_layer(dir.path(), "layer", &[("marker", b"data")]);
        let mut encoder = flate2::write::GzEncoder::new(Vec::new(), flate2::Compression::default());
        encoder.write_all(&std::fs::read(tarball).unwrap()).unwrap();
        let compressed = encoder.finish().unwrap();
        let fixture = write_oci_layout(&layout, br#"{"config":{}}"#, &[&compressed]);
        let staged = stage(layout.to_str().unwrap(), &dir.path().join("valid")).unwrap();
        assert_eq!(
            std::fs::read(staged.rootfs.join("marker")).unwrap(),
            b"data"
        );

        let mut changed = compressed;
        changed[4] ^= 1;
        std::fs::write(&fixture.layers[0], changed).unwrap();
        assert!(matches!(
            stage(layout.to_str().unwrap(), &dir.path().join("changed-header")),
            Err(ImageError::DescriptorDigest(_))
        ));
    }

    fn tar_layer(dir: &Path, name: &str, files: &[(&str, &[u8])]) -> PathBuf {
        let stage = dir.join(format!("{name}-stage"));
        std::fs::create_dir_all(&stage).unwrap();
        let mut args: Vec<String> = Vec::new();
        for (path, data) in files {
            let file = stage.join(path);
            std::fs::create_dir_all(file.parent().unwrap()).unwrap();
            std::fs::write(&file, data).unwrap();
            args.push(path.to_string());
        }
        let tarball = dir.join(format!("{name}.tar"));
        let status = Command::new("tar")
            .env("COPYFILE_DISABLE", "1")
            .arg("-cf")
            .arg(&tarball)
            .arg("-C")
            .arg(&stage)
            .args(&args)
            .status()
            .unwrap();
        assert!(status.success());
        tarball
    }

    #[test]
    fn staging_a_second_image_in_the_same_directory_has_no_prior_files() {
        let dir = tempfile::tempdir().unwrap();
        let layout = |name: &str, file: &str, data: &[u8]| {
            let layout = dir.path().join(name);
            std::fs::create_dir_all(&layout).unwrap();
            std::fs::write(
                layout.join("manifest.json"),
                br#"[{"Config":"config.json","Layers":["layer.tar"]}]"#,
            )
            .unwrap();
            std::fs::write(layout.join("config.json"), br#"{"config":{}}"#).unwrap();
            let layer = tar_layer(dir.path(), name, &[(file, data)]);
            std::fs::copy(layer, layout.join("layer.tar")).unwrap();
            layout
        };
        let first = layout("first", "old", b"old");
        let second = layout("second", "new", b"new");
        let reused = dir.path().join("reused");
        std::fs::create_dir_all(&reused).unwrap();

        let original = stage(first.to_str().unwrap(), &reused).unwrap();
        assert_eq!(std::fs::read(original.rootfs.join("old")).unwrap(), b"old");
        let after_reuse = stage(second.to_str().unwrap(), &reused).unwrap();
        let fresh_dir = dir.path().join("fresh");
        std::fs::create_dir_all(&fresh_dir).unwrap();
        let fresh = stage(second.to_str().unwrap(), &fresh_dir).unwrap();

        assert_ne!(original.rootfs, after_reuse.rootfs);
        assert_eq!(std::fs::read(original.rootfs.join("old")).unwrap(), b"old");
        assert!(!after_reuse.rootfs.join("old").exists());
        assert_eq!(
            std::fs::read(after_reuse.rootfs.join("new")).unwrap(),
            b"new"
        );
        assert_eq!(
            super::super::bundle::build_rootfs_segment(&after_reuse.rootfs, &after_reuse.owners)
                .unwrap(),
            super::super::bundle::build_rootfs_segment(&fresh.rootfs, &fresh.owners).unwrap()
        );
    }

    #[test]
    fn staging_an_oci_archive_after_a_docker_archive_uses_only_the_oci_layout() {
        let dir = tempfile::tempdir().unwrap();
        let docker = dir.path().join("docker");
        std::fs::create_dir_all(&docker).unwrap();
        std::fs::write(
            docker.join("manifest.json"),
            br#"[{"Config":"config.json","Layers":["layer.tar"]}]"#,
        )
        .unwrap();
        std::fs::write(
            docker.join("config.json"),
            br#"{"config":{"Cmd":["/old"]}}"#,
        )
        .unwrap();
        let old_layer = tar_layer(dir.path(), "old-layer", &[("old", b"old")]);
        std::fs::copy(old_layer, docker.join("layer.tar")).unwrap();

        let oci = dir.path().join("oci");
        let new_layer = tar_layer(dir.path(), "new-layer", &[("new", b"new")]);
        let new_layer = std::fs::read(new_layer).unwrap();
        write_oci_layout(&oci, br#"{"config":{"Cmd":["/new"]}}"#, &[&new_layer]);

        let archive = |layout: &Path, name: &str, entries: &[&str]| {
            let path = dir.path().join(name);
            let status = Command::new("tar")
                .env("COPYFILE_DISABLE", "1")
                .arg("-cf")
                .arg(&path)
                .arg("-C")
                .arg(layout)
                .args(entries)
                .status()
                .unwrap();
            assert!(status.success());
            path
        };
        let docker_archive = archive(
            &docker,
            "docker-archive.tar",
            &["manifest.json", "config.json", "layer.tar"],
        );
        let oci_archive = archive(&oci, "oci-archive.tar", &["index.json", "blobs"]);
        let reused = dir.path().join("reused");
        let original = stage(docker_archive.to_str().unwrap(), &reused).unwrap();
        assert_eq!(original.config.cmd, ["/old"]);

        let after_reuse = stage(oci_archive.to_str().unwrap(), &reused).unwrap();
        assert_eq!(after_reuse.config.cmd, ["/new"]);
        assert_eq!(
            std::fs::read(after_reuse.rootfs.join("new")).unwrap(),
            b"new"
        );
        assert!(!after_reuse.rootfs.join("old").exists());
    }

    #[test]
    fn extract_checked_extracts_into_dest() {
        let dir = tempfile::tempdir().unwrap();
        let tarball = tar_layer(dir.path(), "t", &[("hello.txt", b"hi")]);
        let dest = dir.path().join("out");
        std::fs::create_dir_all(&dest).unwrap();
        extract_checked(&tarball, &dest).unwrap();
        assert_eq!(std::fs::read(dest.join("hello.txt")).unwrap(), b"hi");
        assert!(extract_checked(Path::new("/nonexistent.tar"), &dest).is_err());
    }

    #[test]
    fn archive_replacement_after_validation_cannot_change_extraction() {
        if let Some(kind) = std::env::var_os("HARMONY_ARCHIVE_SWAP_CHILD") {
            let original =
                PathBuf::from(std::env::var_os("HARMONY_ARCHIVE_SWAP_ORIGINAL").unwrap());
            let dest = PathBuf::from(std::env::var_os("HARMONY_ARCHIVE_SWAP_DEST").unwrap());
            std::fs::create_dir(&dest).unwrap();
            if kind == "layer" {
                apply_layer(&original, &dest, &mut Ownership::default()).unwrap();
            } else {
                extract_checked(&original, &dest).unwrap();
            }
            assert_eq!(std::fs::read(dest.join("accepted")).unwrap(), b"checked");
            assert!(!dest.join("a").exists());
            return;
        }

        let dir = tempfile::tempdir().unwrap();
        let bin = dir.path().join("bin");
        std::fs::create_dir(&bin).unwrap();
        let wrapper = bin.join("tar");
        std::fs::write(
            &wrapper,
            b"#!/bin/sh\ndir=${0%/*}\ncat \"$dir/replacement\" > \"$dir/original\"\nexec /usr/bin/tar \"$@\"\n",
        )
        .unwrap();
        std::fs::set_permissions(&wrapper, std::fs::Permissions::from_mode(0o755)).unwrap();
        let replacement = write_archive(
            dir.path(),
            "replacement.tar",
            &[
                raw_member(b"A", b'0', "", b"first"),
                raw_member(b"a", b'0', "", b"second"),
            ]
            .concat(),
        );
        std::os::unix::fs::symlink(&replacement, bin.join("replacement")).unwrap();
        for kind in ["outer", "layer"] {
            let original = write_archive(
                dir.path(),
                &format!("{kind}.tar"),
                &raw_member(b"accepted", b'0', "", b"checked"),
            );
            let original_link = bin.join("original");
            if original_link.exists() {
                std::fs::remove_file(&original_link).unwrap();
            }
            std::os::unix::fs::symlink(&original, &original_link).unwrap();
            let dest = dir.path().join(format!("{kind}-dest"));
            let status = Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "image::tests::archive_replacement_after_validation_cannot_change_extraction",
                ])
                .env("HARMONY_ARCHIVE_SWAP_CHILD", kind)
                .env("HARMONY_ARCHIVE_SWAP_ORIGINAL", &original)
                .env("HARMONY_ARCHIVE_SWAP_REPLACEMENT", &replacement)
                .env("HARMONY_ARCHIVE_SWAP_DEST", &dest)
                .env(
                    "PATH",
                    format!("{}:{}", bin.display(), std::env::var("PATH").unwrap()),
                )
                .status()
                .unwrap();
            assert!(status.success(), "{kind} extracted unchecked bytes");
            assert_eq!(
                std::fs::read(&original).unwrap(),
                std::fs::read(&replacement).unwrap()
            );
        }
    }

    #[test]
    fn staging_refuses_a_traversing_outer_tarball() {
        let dir = tempfile::tempdir().unwrap();
        let (_, victim) = planted(dir.path());
        let tarball = tar_with_raw_name(dir.path(), "image.tar", "../victim/pwn");
        let stage_dir = dir.path().join("stage");
        std::fs::create_dir_all(&stage_dir).unwrap();
        let staged = stage_from_path(&tarball, &stage_dir);
        assert!(matches!(staged, Err(ImageError::UnsafePath(_))));
        assert!(!victim.join("pwn").exists());
    }

    fn raw_member(name: &[u8], typeflag: u8, linkname: &str, data: &[u8]) -> Vec<u8> {
        raw_member_owned(name, typeflag, linkname, data, Owner::ROOT)
    }

    fn raw_member_owned(
        name: &[u8],
        typeflag: u8,
        linkname: &str,
        data: &[u8],
        owner: Owner,
    ) -> Vec<u8> {
        let mode = if typeflag == b'5' { 0o755 } else { 0o644 };
        raw_member_with_mode(name, typeflag, linkname, data, owner, mode)
    }

    fn raw_member_with_mode(
        name: &[u8],
        typeflag: u8,
        linkname: &str,
        data: &[u8],
        owner: Owner,
        mode: u32,
    ) -> Vec<u8> {
        let mut header = [b'\0'; 512];
        let mut put = |offset: usize, bytes: &[u8]| {
            header[offset..offset + bytes.len()].copy_from_slice(bytes);
        };
        put(0, &name[..name.len().min(100)]);
        put(100, format!("{mode:07o}\0").as_bytes());
        put(108, format!("{:07o}\0", owner.uid).as_bytes());
        put(116, format!("{:07o}\0", owner.gid).as_bytes());
        put(124, format!("{:011o}\0", data.len()).as_bytes());
        put(136, b"00000000000\0");
        put(148, b"        ");
        put(156, &[typeflag]);
        put(157, linkname.as_bytes());
        put(257, b"ustar\0");
        put(263, b"00");
        let sum: u32 = header.iter().map(|b| u32::from(*b)).sum();
        header[148..156].copy_from_slice(format!("{sum:06o}\0 ").as_bytes());
        let mut block = header.to_vec();
        block.extend_from_slice(data);
        block.resize(block.len().next_multiple_of(TAR_BLOCK), 0);
        block
    }

    fn write_archive(dir: &Path, name: &str, body: &[u8]) -> PathBuf {
        let tarball = dir.join(name);
        std::fs::write(&tarball, [body, &[0u8; 1024]].concat()).unwrap();
        tarball
    }

    fn pax_record(key: &str, value: &str) -> String {
        let mut length = key.len() + value.len() + 3;
        loop {
            let record = format!("{length} {key}={value}\n");
            if record.len() == length {
                return record;
            }
            length = record.len();
        }
    }

    fn reseal(block: &mut [u8]) {
        block[148..156].copy_from_slice(b"        ");
        let sum: u32 = block[..TAR_BLOCK].iter().map(|b| u32::from(*b)).sum();
        block[148..156].copy_from_slice(format!("{sum:06o}\0 ").as_bytes());
    }

    fn raw_tar(dir: &Path, name: &str, members: &[(&str, u8, &str)]) -> PathBuf {
        let body: Vec<u8> = members
            .iter()
            .flat_map(|(member, typeflag, linkname)| {
                raw_member(member.as_bytes(), *typeflag, linkname, b"")
            })
            .collect();
        write_archive(dir, name, &body)
    }

    fn tar_with_raw_name(dir: &Path, name: &str, member: &str) -> PathBuf {
        raw_tar(dir, name, &[(member, b'0', "")])
    }

    fn planted(dir: &Path) -> (PathBuf, PathBuf) {
        let rootfs = dir.join("rootfs");
        std::fs::create_dir_all(&rootfs).unwrap();
        let victim = dir.join("victim");
        std::fs::create_dir_all(&victim).unwrap();
        std::fs::write(victim.join("sentinel"), b"survives").unwrap();
        (rootfs, victim)
    }

    #[test]
    fn apply_layer_refuses_traversing_members() {
        let dir = tempfile::tempdir().unwrap();
        let (rootfs, victim) = planted(dir.path());

        for (n, member) in [
            "../victim/.wh..wh..opq",
            "../../victim/.wh..wh..opq",
            "../victim/.wh.sentinel",
            "/victim/.wh.sentinel",
            "./../victim/.wh.sentinel",
            "../victim/payload",
        ]
        .iter()
        .enumerate()
        {
            let layer = tar_with_raw_name(dir.path(), &format!("evil{n}.tar"), member);
            let err = apply_layer(&layer, &rootfs, &mut Ownership::default()).unwrap_err();
            assert!(
                matches!(err, ImageError::UnsafePath(_)),
                "{member} gave {err:?}"
            );
            assert!(
                victim.join("sentinel").is_file(),
                "{member} deleted outside"
            );
            assert!(victim.is_dir(), "{member} removed the directory outside");
        }
    }

    #[test]
    fn apply_layer_refuses_whiteouts_through_a_symlink() {
        let dir = tempfile::tempdir().unwrap();
        let (rootfs, victim) = planted(dir.path());
        std::os::unix::fs::symlink(&victim, rootfs.join("link")).unwrap();

        for (n, member) in ["link/.wh.sentinel", "link/.wh..wh..opq"]
            .iter()
            .enumerate()
        {
            let layer = tar_with_raw_name(dir.path(), &format!("sym{n}.tar"), member);
            let err = apply_layer(&layer, &rootfs, &mut Ownership::default()).unwrap_err();
            assert!(
                matches!(err, ImageError::UnsafePath(_)),
                "{member} gave {err:?}"
            );
            assert!(
                victim.join("sentinel").is_file(),
                "{member} deleted outside"
            );
        }
        assert!(std::fs::symlink_metadata(rootfs.join("link")).is_ok());
    }

    #[test]
    fn a_whiteout_cannot_follow_an_internal_symlink_parent() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir_all(rootfs.join("actual")).unwrap();
        std::fs::write(rootfs.join("actual/sentinel"), b"unchanged").unwrap();
        std::os::unix::fs::symlink("actual", rootfs.join("link")).unwrap();
        let upper = write_archive(
            dir.path(),
            "upper.tar",
            &raw_member(b"link/.wh.sentinel", b'0', "", b""),
        );

        assert!(matches!(
            apply_layer(&upper, &rootfs, &mut Ownership::default()),
            Err(ImageError::UnsafePath(_))
        ));
        assert_eq!(
            std::fs::read(rootfs.join("actual/sentinel")).unwrap(),
            b"unchanged"
        );
    }

    #[test]
    fn whiteout_of_a_symlink_removes_only_the_link() {
        let dir = tempfile::tempdir().unwrap();
        let (rootfs, victim) = planted(dir.path());
        std::os::unix::fs::symlink(&victim, rootfs.join("link")).unwrap();

        let layer = tar_with_raw_name(dir.path(), "wh-link.tar", ".wh.link");
        apply_layer(&layer, &rootfs, &mut Ownership::default()).unwrap();
        assert!(std::fs::symlink_metadata(rootfs.join("link")).is_err());
        assert!(victim.join("sentinel").is_file());
        assert!(victim.is_dir());
    }

    #[test]
    fn apply_layer_refuses_a_member_under_a_lower_layer_symlink() {
        let dir = tempfile::tempdir().unwrap();
        let (rootfs, victim) = planted(dir.path());

        let stage = dir.path().join("base-stage");
        std::fs::create_dir_all(&stage).unwrap();
        std::os::unix::fs::symlink("../victim", stage.join("link")).unwrap();
        let base = dir.path().join("base.tar");
        assert!(
            Command::new("tar")
                .env("COPYFILE_DISABLE", "1")
                .arg("-cf")
                .arg(&base)
                .arg("-C")
                .arg(&stage)
                .arg("link")
                .status()
                .unwrap()
                .success()
        );
        apply_layer(&base, &rootfs, &mut Ownership::default()).unwrap();
        assert!(
            std::fs::symlink_metadata(rootfs.join("link"))
                .unwrap()
                .is_symlink()
        );

        let upper = tar_layer(dir.path(), "upper", &[("link/pwn", b"owned")]);
        let err = apply_layer(&upper, &rootfs, &mut Ownership::default()).unwrap_err();
        assert!(matches!(err, ImageError::UnsafePath(_)), "{err:?}");
        assert!(!victim.join("pwn").exists(), "wrote outside the rootfs");
        assert!(victim.join("sentinel").is_file());
    }

    #[test]
    fn apply_layer_refuses_a_name_stored_as_both_a_directory_and_a_symlink() {
        let dir = tempfile::tempdir().unwrap();
        let (rootfs, victim) = planted(dir.path());
        let layer = raw_tar(
            dir.path(),
            "dup.tar",
            &[
                ("link/", b'5', ""),
                ("link", b'2', "../../victim"),
                ("link/pwn", b'0', ""),
            ],
        );
        assert!(matches!(
            apply_layer(&layer, &rootfs, &mut Ownership::default()),
            Err(ImageError::UnsafePath(_))
        ));
        assert!(victim.join("sentinel").exists());
        assert!(!victim.join("pwn").exists());
    }

    #[test]
    fn apply_layer_refuses_a_case_folded_duplicate_name() {
        let dir = tempfile::tempdir().unwrap();
        let (rootfs, victim) = planted(dir.path());
        let layer = raw_tar(
            dir.path(),
            "case.tar",
            &[
                ("Link/", b'5', ""),
                ("link", b'2', "../../victim"),
                ("LINK/pwn", b'0', ""),
            ],
        );
        assert!(matches!(
            apply_layer(&layer, &rootfs, &mut Ownership::default()),
            Err(ImageError::UnsafePath(_))
        ));
        assert!(victim.join("sentinel").exists());
        assert!(!victim.join("pwn").exists());
    }

    #[test]
    fn case_distinct_layer_members_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        std::fs::write(rootfs.join("sentinel"), b"unchanged").unwrap();
        let body = [
            raw_member(b"A", b'0', "", b"first"),
            raw_member(b"a", b'0', "", b"second"),
        ]
        .concat();
        let layer = write_archive(dir.path(), "case-files.tar", &body);

        assert!(matches!(
            apply_layer(&layer, &rootfs, &mut Ownership::default()),
            Err(ImageError::CaseCollision { .. })
        ));
        let names: Vec<_> = std::fs::read_dir(&rootfs)
            .unwrap()
            .map(|entry| entry.unwrap().file_name())
            .collect();
        assert_eq!(names, ["sentinel"]);
        assert_eq!(
            std::fs::read(rootfs.join("sentinel")).unwrap(),
            b"unchanged"
        );
    }

    #[test]
    fn case_distinct_ancestor_components_are_rejected() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        let body = [
            raw_member(b"Dir/first", b'0', "", b"first"),
            raw_member(b"dir/second", b'0', "", b"second"),
        ]
        .concat();
        let layer = write_archive(dir.path(), "case-ancestors.tar", &body);

        assert!(matches!(
            apply_layer(&layer, &rootfs, &mut Ownership::default()),
            Err(ImageError::CaseCollision { .. })
        ));
        assert_eq!(std::fs::read_dir(rootfs).unwrap().count(), 0);
    }

    #[test]
    fn case_distinct_names_across_layers_are_rejected_before_the_upper_merge() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        let lower = write_archive(
            dir.path(),
            "lower.tar",
            &raw_member(b"A", b'0', "", b"lower"),
        );
        let upper = write_archive(
            dir.path(),
            "upper.tar",
            &raw_member(b"a", b'0', "", b"upper"),
        );
        let mut owners = Ownership::default();
        let mut names = BTreeMap::new();
        apply_layer_tracked(&lower, &rootfs, &mut owners, &mut names, None).unwrap();

        assert!(matches!(
            apply_layer_tracked(&upper, &rootfs, &mut owners, &mut names, None),
            Err(ImageError::CaseCollision { .. })
        ));
        let entries: Vec<_> = std::fs::read_dir(&rootfs)
            .unwrap()
            .map(|entry| entry.unwrap().file_name())
            .collect();
        assert_eq!(entries, ["A"]);
        assert_eq!(std::fs::read(rootfs.join("A")).unwrap(), b"lower");
    }

    #[test]
    fn staging_rejects_case_distinct_names_across_layers() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        std::fs::create_dir(&layout).unwrap();
        std::fs::write(
            layout.join("manifest.json"),
            br#"[{"Config":"config.json","Layers":["lower.tar","upper.tar"]}]"#,
        )
        .unwrap();
        std::fs::write(layout.join("config.json"), br#"{"config":{}}"#).unwrap();
        write_archive(&layout, "lower.tar", &raw_member(b"A", b'0', "", b"lower"));
        write_archive(&layout, "upper.tar", &raw_member(b"a", b'0', "", b"upper"));
        let staging = dir.path().join("staging");

        assert!(matches!(
            stage(layout.to_str().unwrap(), &staging),
            Err(ImageError::CaseCollision { .. })
        ));
        assert_eq!(std::fs::read_dir(staging).unwrap().count(), 0);
    }

    #[test]
    fn a_whiteout_cannot_hide_a_differently_cased_lower_name() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        let lower = write_archive(
            dir.path(),
            "lower.tar",
            &raw_member(b"Foo", b'0', "", b"lower"),
        );
        let upper = write_archive(
            dir.path(),
            "upper.tar",
            &raw_member(b".wh.foo", b'0', "", b""),
        );
        let mut owners = Ownership::default();
        let mut names = BTreeMap::new();
        apply_layer_tracked(&lower, &rootfs, &mut owners, &mut names, None).unwrap();

        assert!(matches!(
            apply_layer_tracked(&upper, &rootfs, &mut owners, &mut names, None),
            Err(ImageError::CaseCollision { .. })
        ));
        assert_eq!(std::fs::read(rootfs.join("Foo")).unwrap(), b"lower");
    }

    #[test]
    fn an_exact_whiteout_allows_a_new_case_after_removal() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        let lower = write_archive(
            dir.path(),
            "lower.tar",
            &raw_member(b"Foo", b'0', "", b"lower"),
        );
        let upper = write_archive(
            dir.path(),
            "upper.tar",
            &[
                raw_member(b".wh.Foo", b'0', "", b""),
                raw_member(b"foo", b'0', "", b"upper"),
            ]
            .concat(),
        );
        let mut owners = Ownership::default();
        let mut names = BTreeMap::new();
        apply_layer_tracked(&lower, &rootfs, &mut owners, &mut names, None).unwrap();
        apply_layer_tracked(&upper, &rootfs, &mut owners, &mut names, None).unwrap();

        assert_eq!(std::fs::read(rootfs.join("foo")).unwrap(), b"upper");
        assert_eq!(std::fs::read_dir(&rootfs).unwrap().count(), 1);
    }

    #[test]
    fn layout_control_files_require_exact_spelling() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        std::fs::create_dir(&layout).unwrap();
        std::fs::write(
            layout.join("MANIFEST.JSON"),
            br#"[{"Config":"config.json","Layers":[]}]"#,
        )
        .unwrap();
        std::fs::write(layout.join("config.json"), br#"{"config":{}}"#).unwrap();

        assert!(matches!(
            stage(layout.to_str().unwrap(), &dir.path().join("staging")),
            Err(ImageError::Unrecognized(_))
        ));
    }

    #[test]
    fn docker_save_layers_can_reuse_a_prior_layer_by_relative_symlink() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        std::fs::create_dir_all(layout.join("a")).unwrap();
        std::fs::create_dir_all(layout.join("b")).unwrap();
        std::fs::write(
            layout.join("manifest.json"),
            br#"[{"Config":"config.json","Layers":["a/layer.tar","b/layer.tar"]}]"#,
        )
        .unwrap();
        std::fs::write(layout.join("config.json"), br#"{"config":{}}"#).unwrap();
        write_archive(
            &layout.join("a"),
            "layer.tar",
            &raw_member(b"file", b'0', "", b"data"),
        );
        std::os::unix::fs::symlink("../a/layer.tar", layout.join("b/layer.tar")).unwrap();

        let staged = stage(layout.to_str().unwrap(), &dir.path().join("staging")).unwrap();
        assert_eq!(std::fs::read(staged.rootfs.join("file")).unwrap(), b"data");
    }

    #[test]
    fn layout_type_ignores_a_case_alias_symlinked_manifest() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        write_oci_layout(&layout, br#"{"config":{}}"#, &[]);
        std::os::unix::fs::symlink("INDEX.JSON", layout.join("manifest.json")).unwrap();

        let staged = stage(layout.to_str().unwrap(), &dir.path().join("stage")).unwrap();
        assert!(staged.rootfs.is_dir());
    }

    #[test]
    fn staging_refuses_a_case_aliased_layout_path() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        write_oci_layout(&layout, br#"{"config":{}}"#, &[]);

        let aliased = dir.path().join("LAYOUT");
        assert!(matches!(
            stage_from_path(&aliased, &dir.path().join("stage")),
            Err(ImageError::UnsafePath(_))
        ));
        let staging = dir.path().join("public-stage");
        assert!(matches!(
            stage(aliased.to_str().unwrap(), &staging),
            Err(ImageError::UnsafePath(_))
        ));
        assert!(!staging.exists());

        let parent = dir.path().join("Parent");
        std::fs::create_dir(&parent).unwrap();
        std::os::unix::fs::symlink("../layout", parent.join("image")).unwrap();
        let aliased_parent = dir.path().join("parent/image");
        assert!(matches!(
            stage(aliased_parent.to_str().unwrap(), &staging),
            Err(ImageError::UnsafePath(_))
        ));
        assert!(!staging.exists());

        let bad_target = parent.join("bad-target");
        std::os::unix::fs::symlink("../LAYOUT", &bad_target).unwrap();
        assert!(matches!(
            stage(bad_target.to_str().unwrap(), &staging),
            Err(ImageError::UnsafePath(_))
        ));
        assert!(!staging.exists());

        let exact_link = parent.join("image");
        let staged = stage(exact_link.to_str().unwrap(), &staging).unwrap();
        assert!(staged.rootfs.is_dir());
    }

    #[test]
    fn case_aliased_local_entry_does_not_shadow_image_reference() {
        if let Ok(mode) = std::env::var("HARMONY_IMAGE_REF_CHILD") {
            match mode.as_str() {
                "alias" => {
                    assert!(matches!(
                        stage("./app", Path::new("explicit-stage")),
                        Err(ImageError::UnsafePath(_))
                    ));
                    assert!(!Path::new("explicit-stage").exists());
                    let staged = stage("app", Path::new("stage")).unwrap();
                    assert!(staged.rootfs.is_dir());
                }
                "bad-link" | "dangling-link" => {
                    assert!(matches!(
                        stage("app", Path::new("rejected-stage")),
                        Err(ImageError::UnsafePath(_))
                    ));
                    assert!(!Path::new("rejected-stage").exists());
                }
                _ => panic!("unknown test mode"),
            }
            return;
        }
        let dir = tempfile::tempdir().unwrap();
        let work = dir.path().join("work");
        std::fs::create_dir(&work).unwrap();
        std::fs::create_dir(work.join("App")).unwrap();
        let archive = write_archive(
            dir.path(),
            "image.tar",
            &[
                raw_member(
                    b"manifest.json",
                    b'0',
                    "",
                    br#"[{"Config":"config.json","Layers":[]}]"#,
                ),
                raw_member(b"config.json", b'0', "", br#"{"config":{}}"#),
            ]
            .concat(),
        );
        let bin = dir.path().join("bin");
        std::fs::create_dir(&bin).unwrap();
        let tool = bin.join("docker");
        std::fs::write(
            &tool,
            b"#!/bin/sh\nif [ \"$1\" = --version ]; then exit 0; fi\nif [ \"$1\" = image ] && [ \"$2\" = inspect ]; then echo sha256:fixture; exit 0; fi\nif [ \"$1\" = image ] && [ \"$2\" = save ]; then cp \"$FAKE_IMAGE_TAR\" \"$4\"; exit $?; fi\nexit 1\n",
        )
        .unwrap();
        std::fs::set_permissions(&tool, std::fs::Permissions::from_mode(0o755)).unwrap();
        let child = |mode| {
            Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "image::tests::case_aliased_local_entry_does_not_shadow_image_reference",
                ])
                .current_dir(&work)
                .env("HARMONY_IMAGE_REF_CHILD", mode)
                .env("FAKE_IMAGE_TAR", &archive)
                .env(
                    "PATH",
                    format!("{}:{}", bin.display(), std::env::var("PATH").unwrap()),
                )
                .status()
                .unwrap()
        };
        assert!(child("alias").success());
        std::fs::remove_dir(work.join("App")).unwrap();
        std::fs::create_dir(work.join("layout")).unwrap();
        std::os::unix::fs::symlink("LAYOUT", work.join("app")).unwrap();
        assert!(child("bad-link").success());
        std::fs::remove_file(work.join("app")).unwrap();
        std::os::unix::fs::symlink("missing", work.join("app")).unwrap();
        assert!(child("dangling-link").success());
    }

    #[test]
    fn layout_symlink_targets_require_exact_names_and_stay_inside_the_layout() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        std::fs::create_dir_all(layout.join("a")).unwrap();
        std::fs::create_dir_all(layout.join("b")).unwrap();
        std::fs::write(layout.join("a/layer.tar"), b"layer").unwrap();
        for (name, target) in [("case", "../a/LAYER.TAR"), ("escape", "../../outside")] {
            std::os::unix::fs::symlink(target, layout.join("b/layer.tar")).unwrap();
            assert!(
                contained_join(&layout, "b/layer.tar").is_err(),
                "{name} symlink resolved"
            );
            std::fs::remove_file(layout.join("b/layer.tar")).unwrap();
        }
    }

    #[test]
    fn archive_names_outside_ascii_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let dest = dir.path().join("layout");
        std::fs::create_dir(&dest).unwrap();
        let archive = write_archive(
            dir.path(),
            "unicode.tar",
            &raw_member(b"caf\xc3\xa9", b'0', "", b"data"),
        );

        assert!(matches!(
            extract_checked(&archive, &dest),
            Err(ImageError::NonPortableName(_))
        ));
        assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
    }

    #[test]
    fn host_dependent_drive_prefix_names_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let cases = [
            ("raw", raw_member(b"a:b", b'0', "", b"data")),
            (
                "pax",
                [
                    raw_member(
                        b"PaxHeaders/0",
                        b'x',
                        "",
                        pax_record("path", "a:b").as_bytes(),
                    ),
                    raw_member(b"valid", b'0', "", b"data"),
                ]
                .concat(),
            ),
            (
                "gnu",
                [
                    raw_member(b"././@LongLink", b'L', "", b"a:b\0"),
                    raw_member(b"valid", b'0', "", b"data"),
                ]
                .concat(),
            ),
        ];
        for (label, body) in cases {
            let archive = write_archive(dir.path(), &format!("drive-name-{label}.tar"), &body);
            let dest = dir.path().join(format!("drive-name-{label}"));
            std::fs::create_dir(&dest).unwrap();
            assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
            assert!(matches!(
                extract_checked(&archive, &dest),
                Err(ImageError::Tar(_))
            ));
            assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
        }
    }

    #[test]
    fn leading_backslash_member_names_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let cases = [
            ("raw", raw_member(b"\\foo", b'0', "", b"data")),
            (
                "pax",
                [
                    raw_member(
                        b"PaxHeaders/0",
                        b'x',
                        "",
                        pax_record("path", "\\foo").as_bytes(),
                    ),
                    raw_member(b"valid", b'0', "", b"data"),
                ]
                .concat(),
            ),
            (
                "gnu",
                [
                    raw_member(b"././@LongLink", b'L', "", b"\\foo\0"),
                    raw_member(b"valid", b'0', "", b"data"),
                ]
                .concat(),
            ),
        ];
        for (label, body) in cases {
            let archive = write_archive(dir.path(), &format!("backslash-name-{label}.tar"), &body);
            let dest = dir.path().join(format!("backslash-name-{label}"));
            std::fs::create_dir(&dest).unwrap();
            assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
            assert!(matches!(
                extract_checked(&archive, &dest),
                Err(ImageError::Tar(_))
            ));
            assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
        }
    }

    #[test]
    fn terminal_dot_non_directory_names_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        for (kind, target) in [(b'0', ""), (b'1', "source"), (b'2', "source")] {
            let data: &[u8] = if kind == b'0' { b"payload" } else { b"" };
            for (label, body) in [
                ("raw", raw_member(b"d/.", kind, target, data)),
                ("repeated-slash", raw_member(b"d//.", kind, target, data)),
                ("repeated-dot", raw_member(b"d/./.", kind, target, data)),
                ("leading-dot", raw_member(b"./d/.", kind, target, data)),
                (
                    "pax",
                    [
                        raw_member(
                            b"PaxHeaders/0",
                            b'x',
                            "",
                            pax_record("path", "d/.").as_bytes(),
                        ),
                        raw_member(b"valid", kind, target, data),
                    ]
                    .concat(),
                ),
                (
                    "gnu",
                    [
                        raw_member(b"././@LongLink", b'L', "", b"d/.\0"),
                        raw_member(b"valid", kind, target, data),
                    ]
                    .concat(),
                ),
            ] {
                let archive = write_archive(
                    dir.path(),
                    &format!("terminal-dot-{kind}-{label}.tar"),
                    &[raw_member(b"source", b'0', "", b"source"), body].concat(),
                );
                let dest = dir.path().join(format!("terminal-dot-{kind}-{label}"));
                std::fs::create_dir(&dest).unwrap();
                assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
                assert!(matches!(
                    extract_checked(&archive, &dest),
                    Err(ImageError::Tar(_))
                ));
                assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
            }
        }
    }

    #[test]
    fn orphan_name_link_and_pax_extensions_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let cases = [
            (
                "gnu-name",
                raw_member(b"././@LongLink", b'L', "", b"next\0"),
            ),
            (
                "gnu-link",
                raw_member(b"././@LongLink", b'K', "", b"next\0"),
            ),
            (
                "pax-path",
                raw_member(
                    b"PaxHeaders/0",
                    b'x',
                    "",
                    pax_record("path", "next").as_bytes(),
                ),
            ),
            (
                "pax-comment",
                raw_member(
                    b"PaxHeaders/0",
                    b'x',
                    "",
                    pax_record("comment", "next").as_bytes(),
                ),
            ),
            (
                "empty-gnu-name",
                raw_member(b"././@LongLink", b'L', "", b""),
            ),
            (
                "empty-gnu-link",
                raw_member(b"././@LongLink", b'K', "", b""),
            ),
            ("empty-pax", raw_member(b"PaxHeaders/0", b'x', "", b"")),
        ];
        for (label, extension) in cases {
            for (prefix_label, prefix) in [
                ("alone", Vec::new()),
                ("after-file", raw_member(b"file", b'0', "", b"content")),
            ] {
                let archive = write_archive(
                    dir.path(),
                    &format!("orphan-{label}-{prefix_label}.tar"),
                    &[prefix, extension.clone()].concat(),
                );
                let dest = dir.path().join(format!("orphan-{label}-{prefix_label}"));
                std::fs::create_dir(&dest).unwrap();
                assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
                assert!(matches!(
                    extract_checked(&archive, &dest),
                    Err(ImageError::Tar(_))
                ));
                assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
            }
        }
    }

    #[test]
    fn consumed_name_link_and_pax_extensions_remain_admitted() {
        let dir = tempfile::tempdir().unwrap();
        let cases = [
            (
                "gnu-name",
                raw_member(b"././@LongLink", b'L', "", b"next\0"),
                "next",
            ),
            (
                "gnu-link",
                raw_member(b"././@LongLink", b'K', "", b"next\0"),
                "file",
            ),
            (
                "pax-comment",
                raw_member(
                    b"PaxHeaders/0",
                    b'x',
                    "",
                    pax_record("comment", "next").as_bytes(),
                ),
                "file",
            ),
        ];
        for (label, extension, name) in cases {
            let archive = write_archive(
                dir.path(),
                &format!("consumed-{label}.tar"),
                &[extension, raw_member(b"file", b'0', "", b"content")].concat(),
            );
            let dest = dir.path().join(format!("consumed-{label}"));
            std::fs::create_dir(&dest).unwrap();
            assert_eq!(read_members(&archive).unwrap().len(), 1);
            extract_checked(&archive, &dest).unwrap();
            assert_eq!(std::fs::read(dest.join(name)).unwrap(), b"content");
        }
    }

    #[test]
    fn directory_terminal_dots_and_overridden_base_names_remain_admitted() {
        let dir = tempfile::tempdir().unwrap();
        let archive = write_archive(
            dir.path(),
            "portable-terminal-dot.tar",
            &[
                raw_member(b"d/.", b'5', "", b""),
                raw_member(b"d/child", b'0', "", b"child"),
                raw_member(
                    b"PaxHeaders/0",
                    b'x',
                    "",
                    pax_record("path", "pax-valid").as_bytes(),
                ),
                raw_member(b"d/.", b'0', "", b"pax"),
                raw_member(b"././@LongLink", b'L', "", b"gnu-valid\0"),
                raw_member(b"d/.", b'0', "", b"gnu"),
            ]
            .concat(),
        );
        let dest = dir.path().join("dest");
        std::fs::create_dir(&dest).unwrap();
        assert_eq!(read_members(&archive).unwrap().len(), 4);
        extract_checked(&archive, &dest).unwrap();
        assert_eq!(std::fs::read(dest.join("d/child")).unwrap(), b"child");
        assert_eq!(std::fs::read(dest.join("pax-valid")).unwrap(), b"pax");
        assert_eq!(std::fs::read(dest.join("gnu-valid")).unwrap(), b"gnu");
    }

    #[test]
    fn host_dependent_drive_prefix_hardlink_targets_are_rejected() {
        let dir = tempfile::tempdir().unwrap();
        let setup = [
            raw_member(b"./a:b", b'0', "", b"first"),
            raw_member(b"b", b'0', "", b"second"),
        ]
        .concat();
        let cases = [
            ("raw", raw_member(b"copy", b'1', "a:b", b"")),
            (
                "pax",
                [
                    raw_member(
                        b"PaxHeaders/0",
                        b'x',
                        "",
                        pax_record("linkpath", "a:b").as_bytes(),
                    ),
                    raw_member(b"copy", b'1', "./a:b", b""),
                ]
                .concat(),
            ),
            (
                "gnu",
                [
                    raw_member(b"././@LongLink", b'K', "", b"a:b\0"),
                    raw_member(b"copy", b'1', "./a:b", b""),
                ]
                .concat(),
            ),
        ];
        for (label, link) in cases {
            let archive = write_archive(
                dir.path(),
                &format!("drive-link-{label}.tar"),
                &[setup.as_slice(), link.as_slice()].concat(),
            );
            let dest = dir.path().join(format!("drive-link-{label}"));
            std::fs::create_dir(&dest).unwrap();
            assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
            assert!(matches!(
                extract_checked(&archive, &dest),
                Err(ImageError::Tar(_))
            ));
            assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
        }
    }

    #[test]
    fn leading_backslash_hardlink_targets_are_rejected() {
        let dir = tempfile::tempdir().unwrap();
        let setup = [
            raw_member(b"./\\foo", b'0', "", b"first"),
            raw_member(b"foo", b'0', "", b"second"),
        ]
        .concat();
        let cases = [
            ("raw", raw_member(b"copy", b'1', "\\foo", b"")),
            (
                "pax",
                [
                    raw_member(
                        b"PaxHeaders/0",
                        b'x',
                        "",
                        pax_record("linkpath", "\\foo").as_bytes(),
                    ),
                    raw_member(b"copy", b'1', "./\\foo", b""),
                ]
                .concat(),
            ),
            (
                "gnu",
                [
                    raw_member(b"././@LongLink", b'K', "", b"\\foo\0"),
                    raw_member(b"copy", b'1', "./\\foo", b""),
                ]
                .concat(),
            ),
        ];
        for (label, link) in cases {
            let archive = write_archive(
                dir.path(),
                &format!("backslash-link-{label}.tar"),
                &[setup.as_slice(), link.as_slice()].concat(),
            );
            let dest = dir.path().join(format!("backslash-link-{label}"));
            std::fs::create_dir(&dest).unwrap();
            assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
            assert!(matches!(
                extract_checked(&archive, &dest),
                Err(ImageError::Tar(_))
            ));
            assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
        }
    }

    #[test]
    fn portable_colon_paths_and_overridden_drive_prefixes_remain_admitted() {
        let dir = tempfile::tempdir().unwrap();
        let portable = write_archive(
            dir.path(),
            "portable-colon.tar",
            &[
                raw_member(b"./a:b", b'0', "", b"first"),
                raw_member(b"copy", b'1', "./a:b", b""),
                raw_member(b"link", b'2', "a:b", b""),
            ]
            .concat(),
        );
        let portable_dest = dir.path().join("portable");
        std::fs::create_dir(&portable_dest).unwrap();
        assert_eq!(read_members(&portable).unwrap().len(), 3);
        extract_checked(&portable, &portable_dest).unwrap();
        assert_eq!(std::fs::read(portable_dest.join("copy")).unwrap(), b"first");
        assert_eq!(
            std::fs::read_link(portable_dest.join("link")).unwrap(),
            Path::new("a:b")
        );

        let overridden = write_archive(
            dir.path(),
            "overridden-drive.tar",
            &[
                raw_member(b"./a:b", b'0', "", b"first"),
                raw_member(
                    b"PaxHeaders/0",
                    b'x',
                    "",
                    pax_record("path", "valid").as_bytes(),
                ),
                raw_member(b"a:b", b'0', "", b"first"),
                raw_member(
                    b"PaxHeaders/1",
                    b'x',
                    "",
                    pax_record("linkpath", "./a:b").as_bytes(),
                ),
                raw_member(b"copy", b'1', "a:b", b""),
            ]
            .concat(),
        );
        let overridden_dest = dir.path().join("overridden");
        std::fs::create_dir(&overridden_dest).unwrap();
        assert_eq!(read_members(&overridden).unwrap().len(), 3);
        extract_checked(&overridden, &overridden_dest).unwrap();
        assert_eq!(
            std::fs::read(overridden_dest.join("valid")).unwrap(),
            b"first"
        );
        assert_eq!(
            std::fs::read(overridden_dest.join("copy")).unwrap(),
            b"first"
        );
    }

    #[test]
    fn portable_backslash_paths_and_overridden_base_fields_remain_admitted() {
        let dir = tempfile::tempdir().unwrap();
        let archive = write_archive(
            dir.path(),
            "portable-backslash.tar",
            &[
                raw_member(b"./\\foo", b'0', "", b"first"),
                raw_member(
                    b"PaxHeaders/0",
                    b'x',
                    "",
                    pax_record("path", "valid").as_bytes(),
                ),
                raw_member(b"\\foo", b'0', "", b"other"),
                raw_member(
                    b"PaxHeaders/1",
                    b'x',
                    "",
                    pax_record("linkpath", "./\\foo").as_bytes(),
                ),
                raw_member(b"copy", b'1', "\\foo", b""),
                raw_member(b"link", b'2', "\\foo", b""),
            ]
            .concat(),
        );
        let dest = dir.path().join("dest");
        std::fs::create_dir(&dest).unwrap();
        assert_eq!(read_members(&archive).unwrap().len(), 4);
        extract_checked(&archive, &dest).unwrap();
        assert_eq!(std::fs::read(dest.join("copy")).unwrap(), b"first");
        assert_eq!(std::fs::read(dest.join("./\\foo")).unwrap(), b"first");
        assert_eq!(std::fs::read(dest.join("valid")).unwrap(), b"other");
        assert_eq!(
            std::fs::read_link(dest.join("link")).unwrap(),
            Path::new("\\foo")
        );
    }

    #[test]
    fn hardlink_target_requires_an_earlier_case_exact_archive_name() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        std::fs::write(rootfs.join("sentinel"), b"unchanged").unwrap();
        let body = [
            raw_member(b"A", b'0', "", b"data"),
            raw_member(b"link", b'1', "a", b""),
        ]
        .concat();
        let layer = write_archive(dir.path(), "case-hardlink.tar", &body);

        assert!(matches!(
            apply_layer(&layer, &rootfs, &mut Ownership::default()),
            Err(ImageError::UnsafePath(_))
        ));
        assert_eq!(std::fs::read_dir(&rootfs).unwrap().count(), 1);
        assert_eq!(
            std::fs::read(rootfs.join("sentinel")).unwrap(),
            b"unchanged"
        );

        let body = [
            raw_member(b"A", b'0', "", b"data"),
            raw_member(b"link", b'1', "A", b""),
        ]
        .concat();
        let layer = write_archive(dir.path(), "exact-hardlink.tar", &body);
        apply_layer(&layer, &rootfs, &mut Ownership::default()).unwrap();
        assert_eq!(std::fs::read(rootfs.join("link")).unwrap(), b"data");
    }

    #[test]
    fn hardlink_target_accepts_portable_dot_and_separator_spellings() {
        let dir = tempfile::tempdir().unwrap();
        for (label, target) in [
            ("dot", "d/./f"),
            ("separator", "d//f"),
            ("leading-dot", "./d/f"),
        ] {
            let archive = write_archive(
                dir.path(),
                &format!("normalized-hardlink-{label}.tar"),
                &[
                    raw_member(b"d/f", b'0', "", b"content"),
                    raw_member(b"copy", b'1', target, b""),
                ]
                .concat(),
            );
            let dest = dir.path().join(format!("normalized-hardlink-{label}"));
            std::fs::create_dir(&dest).unwrap();
            extract_checked(&archive, &dest).unwrap();
            assert_eq!(std::fs::read(dest.join("copy")).unwrap(), b"content");
        }
    }

    #[test]
    fn self_referential_repeated_hardlink_is_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let dest = dir.path().join("dest");
        std::fs::create_dir(&dest).unwrap();
        let archive = write_archive(
            dir.path(),
            "self-hardlink.tar",
            &[
                raw_member(b"target", b'0', "", b"content"),
                raw_member(b"link", b'1', "target", b""),
                raw_member(b"link", b'1', "link", b""),
            ]
            .concat(),
        );

        assert!(matches!(
            extract_checked(&archive, &dest),
            Err(ImageError::UnsafePath(_))
        ));
        assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
    }

    #[test]
    fn noncanonical_ustar_prefix_is_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let dest = dir.path().join("dest");
        std::fs::create_dir(&dest).unwrap();
        let mut member = raw_member(b"payload", b'0', "", b"data");
        member[257..263].copy_from_slice(b"ustar ");
        member[345..351].copy_from_slice(b"prefix");
        reseal(&mut member);
        let archive = write_archive(dir.path(), "noncanonical-prefix.tar", &member);

        assert!(matches!(
            extract_checked(&archive, &dest),
            Err(ImageError::Tar(_))
        ));
        assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
    }

    #[test]
    fn gnu_timestamp_field_is_not_treated_as_a_path_prefix() {
        let dir = tempfile::tempdir().unwrap();
        let dest = dir.path().join("dest");
        std::fs::create_dir(&dest).unwrap();
        let mut member = raw_member(b"payload", b'0', "", b"data");
        member[257..265].copy_from_slice(b"ustar  \0");
        member[345..357].copy_from_slice(b"00000000001\0");
        reseal(&mut member);
        let archive = write_archive(dir.path(), "gnu-time-header.tar", &member);

        extract_checked(&archive, &dest).unwrap();
        assert_eq!(std::fs::read(dest.join("payload")).unwrap(), b"data");
    }

    #[test]
    fn gnu_sparse_metadata_on_regular_file_is_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let dest = dir.path().join("dest");
        std::fs::create_dir(&dest).unwrap();
        let mut member = raw_member(b"payload", b'0', "", b"data");
        member[257..265].copy_from_slice(b"ustar  \0");
        member[483..495].copy_from_slice(b"00000000010\0");
        reseal(&mut member);
        let archive = write_archive(dir.path(), "gnu-sparse-regular.tar", &member);

        assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
        assert!(matches!(
            extract_checked(&archive, &dest),
            Err(ImageError::Tar(_))
        ));
        assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
    }

    #[test]
    fn gnu_sparse_map_cannot_hide_a_later_member() {
        let dir = tempfile::tempdir().unwrap();
        let dest = dir.path().join("dest");
        std::fs::create_dir(&dest).unwrap();
        let mut first = raw_member(b"first", b'0', "", b"");
        first[257..265].copy_from_slice(b"ustar  \0");
        first[386..398].copy_from_slice(b"00000000001\0");
        first[398..410].copy_from_slice(b"00000000001\0");
        first[482] = b'1';
        reseal(&mut first);
        let archive = write_archive(
            dir.path(),
            "gnu-sparse-map.tar",
            &[first, raw_member(b"later", b'0', "", b"data")].concat(),
        );

        assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
        assert!(matches!(
            extract_checked(&archive, &dest),
            Err(ImageError::Tar(_))
        ));
        assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
    }

    #[test]
    fn invalid_tar_timestamps_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        for (label, timestamp) in [("invalid", b"xxxxxxxxxxxx"), ("negative", b"-0000000001\0")] {
            let mut member = raw_member(b"payload", b'0', "", b"data");
            member[136..148].copy_from_slice(timestamp);
            reseal(&mut member);
            let archive = write_archive(dir.path(), &format!("{label}.tar"), &member);
            let dest = dir.path().join(label);
            std::fs::create_dir(&dest).unwrap();

            assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
            assert!(matches!(
                extract_checked(&archive, &dest),
                Err(ImageError::Tar(_))
            ));
            assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
        }
    }

    #[test]
    fn out_of_range_binary_tar_timestamp_is_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let dest = dir.path().join("dest");
        std::fs::create_dir(&dest).unwrap();
        let mut member = raw_member(b"payload", b'0', "", b"data");
        let mut timestamp = [0u8; 12];
        timestamp[0] = 0x80;
        timestamp[4] = 0x80;
        member[136..148].copy_from_slice(&timestamp);
        reseal(&mut member);
        let archive = write_archive(dir.path(), "huge-mtime.tar", &member);

        assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
        assert!(matches!(
            extract_checked(&archive, &dest),
            Err(ImageError::Tar(_))
        ));
        assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
    }

    #[test]
    fn host_nanosecond_overflow_in_tar_timestamp_is_rejected() {
        let dir = tempfile::tempdir().unwrap();
        let dest = dir.path().join("dest");
        std::fs::create_dir(&dest).unwrap();
        let mut member = raw_member(b"payload", b'0', "", b"data");
        let mut timestamp = [0u8; 12];
        timestamp[0] = 0x80;
        timestamp[4..12].copy_from_slice(&9_223_372_037_u64.to_be_bytes());
        member[136..148].copy_from_slice(&timestamp);
        reseal(&mut member);
        let archive = write_archive(dir.path(), "host-ns-overflow.tar", &member);

        assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
        assert!(matches!(
            extract_checked(&archive, &dest),
            Err(ImageError::Tar(_))
        ));
        assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
    }

    #[test]
    fn nonportable_pax_timestamps_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        for key in ["mtime", "atime", "ctime"] {
            for (label, value) in [
                ("invalid", "abc"),
                ("plus", "+1"),
                ("spaces", " "),
                ("missing-integer", ".5"),
                ("too-large", "99999999999999999999"),
                ("too-negative", "-9223372036854775808.9"),
                ("negative-fraction", "-0.1"),
                ("host-nanosecond-overflow", "16725225600"),
                ("host-nanosecond-edge", "9223372036.854775808"),
                ("host-nanosecond-fraction", "9223372036.8547758071"),
                ("negative-host-nanosecond-overflow", "-9223372037"),
            ] {
                let body = [
                    raw_member(b"PaxHeaders/0", b'x', "", pax_record(key, value).as_bytes()),
                    raw_member(b"payload", b'0', "", b"data"),
                ]
                .concat();
                let case = format!("{key}-{label}");
                let archive = write_archive(dir.path(), &format!("{case}.tar"), &body);
                let dest = dir.path().join(case);
                std::fs::create_dir(&dest).unwrap();

                assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
                assert!(matches!(
                    extract_checked(&archive, &dest),
                    Err(ImageError::Tar(_))
                ));
                assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
            }
        }
    }

    #[test]
    fn portable_pax_timestamps_remain_admitted() {
        let dir = tempfile::tempdir().unwrap();
        for value in [
            "0",
            "-1.0",
            "-0.0",
            "123.456789",
            "0.",
            "9223372036.854775807",
        ] {
            let body = [
                raw_member(
                    b"PaxHeaders/0",
                    b'x',
                    "",
                    pax_record("mtime", value).as_bytes(),
                ),
                raw_member(b"payload", b'0', "", b"data"),
            ]
            .concat();
            let archive = write_archive(dir.path(), &format!("valid-mtime-{value}.tar"), &body);
            assert_eq!(read_members(&archive).unwrap().len(), 1);
        }
    }

    #[test]
    fn signed_pax_size_and_owner_fields_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        for (key, value) in [("size", "+4"), ("uid", "+1"), ("gid", "+1")] {
            let body = [
                raw_member(b"PaxHeaders/0", b'x', "", pax_record(key, value).as_bytes()),
                raw_member(b"payload", b'0', "", b"data"),
            ]
            .concat();
            let archive = write_archive(dir.path(), &format!("plus-{key}.tar"), &body);
            let dest = dir.path().join(key);
            std::fs::create_dir(&dest).unwrap();

            assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
            assert!(matches!(
                extract_checked(&archive, &dest),
                Err(ImageError::Tar(_))
            ));
            assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
        }
    }

    #[test]
    fn padded_pax_size_and_owner_fields_remain_admitted() {
        let dir = tempfile::tempdir().unwrap();
        for (key, value) in [("size", "0004"), ("uid", "0001"), ("gid", "0001")] {
            let body = [
                raw_member(b"PaxHeaders/0", b'x', "", pax_record(key, value).as_bytes()),
                raw_member(b"payload", b'0', "", b"data"),
            ]
            .concat();
            let archive = write_archive(dir.path(), &format!("padded-{key}.tar"), &body);
            assert_eq!(read_members(&archive).unwrap().len(), 1);
        }
    }

    #[test]
    fn malformed_pax_record_framing_is_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        for (label, record) in [
            ("plus-uid", b"+10 uid=1\n".as_slice()),
            ("plus-size", b"+11 size=4\n".as_slice()),
            ("missing-newline", b"9 uid=123".as_slice()),
            ("extra-space", b"14  path=Evil\n".as_slice()),
            ("extra-tab", b"14 \tpath=Evil\n".as_slice()),
            ("nul-key", b"15 path\0x=Evil\n".as_slice()),
        ] {
            let body = [
                raw_member(b"PaxHeaders/0", b'x', "", record),
                raw_member(b"payload", b'0', "", b"data"),
            ]
            .concat();
            let archive = write_archive(dir.path(), &format!("bad-pax-{label}.tar"), &body);
            let dest = dir.path().join(label);
            std::fs::create_dir(&dest).unwrap();

            assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
            assert!(matches!(
                extract_checked(&archive, &dest),
                Err(ImageError::Tar(_))
            ));
            assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
        }
    }

    #[test]
    fn ambiguous_tar_numeric_fields_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        for (name, field) in [
            ("mode", 100..108),
            ("uid", 108..116),
            ("gid", 116..124),
            ("mtime", 136..148),
        ] {
            for (label, bytes) in [
                ("nul-junk", b"1\0x".as_slice()),
                ("plus", b"+1".as_slice()),
                ("newline", b"\n1".as_slice()),
                ("spaces", b" ".as_slice()),
            ] {
                let mut member = raw_member(b"payload", b'0', "", b"data");
                member[field.clone()].fill(if label == "spaces" { b' ' } else { 0 });
                if label != "spaces" {
                    member[field.start..field.start + bytes.len()].copy_from_slice(bytes);
                }
                reseal(&mut member);
                let case = format!("{name}-{label}");
                let archive = write_archive(dir.path(), &format!("{case}.tar"), &member);
                let dest = dir.path().join(case);
                std::fs::create_dir(&dest).unwrap();

                assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
                assert!(matches!(
                    extract_checked(&archive, &dest),
                    Err(ImageError::Tar(_))
                ));
                assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
            }
        }
    }

    #[test]
    fn pax_owner_override_does_not_hide_an_invalid_base_owner() {
        let dir = tempfile::tempdir().unwrap();
        for (name, field) in [("uid", 108..116), ("gid", 116..124)] {
            for (label, bytes) in [
                ("spaces", b"        ".as_slice()),
                ("junk", b"abcdef\0 ".as_slice()),
                ("too-large", b"\x80\xff\xff\xff\xff\xff\xff\xff".as_slice()),
            ] {
                let mut member = raw_member(b"payload", b'0', "", b"data");
                member[field.clone()].copy_from_slice(bytes);
                reseal(&mut member);
                let body = [
                    raw_member(b"PaxHeaders/0", b'x', "", pax_record(name, "0").as_bytes()),
                    member,
                ]
                .concat();
                let case = format!("pax-{name}-{label}");
                let archive = write_archive(dir.path(), &format!("{case}.tar"), &body);
                let dest = dir.path().join(case);
                std::fs::create_dir(&dest).unwrap();

                assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
                assert!(matches!(
                    extract_checked(&archive, &dest),
                    Err(ImageError::Tar(_))
                ));
                assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
            }
        }
    }

    #[test]
    fn pax_owner_override_accepts_an_all_nul_base_owner() {
        let dir = tempfile::tempdir().unwrap();
        let mut member = raw_member(b"payload", b'0', "", b"data");
        member[108..124].fill(0);
        reseal(&mut member);
        let pax = [pax_record("uid", "3000000"), pax_record("gid", "3000000")].concat();
        let body = [
            raw_member(b"PaxHeaders/0", b'x', "", pax.as_bytes()),
            member,
        ]
        .concat();
        let archive = write_archive(dir.path(), "all-nul-base-owner.tar", &body);

        assert_eq!(
            read_members(&archive).unwrap()[0].owner,
            Owner {
                uid: 3_000_000,
                gid: 3_000_000
            }
        );
        let dest = dir.path().join("dest");
        std::fs::create_dir(&dest).unwrap();
        extract_checked(&archive, &dest).unwrap();
        assert_eq!(std::fs::read(dest.join("payload")).unwrap(), b"data");
    }

    #[test]
    fn malformed_device_number_fields_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        for (name, field) in [("major", 329..337), ("minor", 337..345)] {
            for (label, bytes) in [
                ("plus", b"     +1\0".as_slice()),
                ("junk", b"abcdef\0 ".as_slice()),
                ("nul-junk", b"0\0garbag".as_slice()),
                ("binary-lead-81", b"\x81\0\0\0\0\0\0\0".as_slice()),
                ("binary-lead-fe", b"\xfe\0\0\0\0\0\0\0".as_slice()),
            ] {
                let mut member = raw_member(b"payload", b'0', "", b"data");
                member[field.clone()].copy_from_slice(bytes);
                reseal(&mut member);
                let case = format!("device-{name}-{label}");
                let archive = write_archive(dir.path(), &format!("{case}.tar"), &member);
                let dest = dir.path().join(case);
                std::fs::create_dir(&dest).unwrap();

                assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
                assert!(matches!(
                    extract_checked(&archive, &dest),
                    Err(ImageError::Tar(_))
                ));
                assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
            }
        }
    }

    #[test]
    fn portable_device_number_fields_remain_admitted() {
        let dir = tempfile::tempdir().unwrap();
        for (name, bytes) in [
            ("spaces", b"        ".as_slice()),
            ("spaces-nul", b"       \0".as_slice()),
            ("nul-spaces", b"\0       ".as_slice()),
            ("positive-binary", b"\x80\0\0\0\0\0\0\0".as_slice()),
            ("binary", b"\xff\0\0\0\0\0\0\0".as_slice()),
        ] {
            let mut member = raw_member(b"payload", b'0', "", b"data");
            member[329..337].copy_from_slice(bytes);
            member[337..345].copy_from_slice(bytes);
            reseal(&mut member);
            let archive = write_archive(dir.path(), &format!("{name}.tar"), &member);
            assert_eq!(read_members(&archive).unwrap().len(), 1);

            let dest = dir.path().join(name);
            std::fs::create_dir(&dest).unwrap();
            extract_checked(&archive, &dest).unwrap();
            assert_eq!(std::fs::read(dest.join("payload")).unwrap(), b"data");
        }
    }

    #[test]
    fn hardlink_with_data_is_rejected_before_rootfs_mutation() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        std::fs::write(rootfs.join("sentinel"), b"unchanged").unwrap();
        let raw = [
            raw_member(b"a", b'0', "", b"original"),
            raw_member(b"link", b'1', "a", b"replacement"),
        ]
        .concat();
        let record = pax_record("size", "11");
        let mut pax_link = raw_member(b"link", b'1', "a", b"replacement");
        pax_link[124..136].copy_from_slice(b"00000000000\0");
        reseal(&mut pax_link);
        let pax = [
            raw_member(b"a", b'0', "", b"original"),
            raw_member(b"PaxHeaders/0", b'x', "", record.as_bytes()),
            pax_link,
        ]
        .concat();
        for (name, body) in [("raw-hardlink.tar", raw), ("pax-hardlink.tar", pax)] {
            let layer = write_archive(dir.path(), name, &body);
            assert!(matches!(
                apply_layer(&layer, &rootfs, &mut Ownership::default()),
                Err(ImageError::Tar(message)) if message == "hardlink member has nonzero data size"
            ));
            assert_eq!(std::fs::read_dir(&rootfs).unwrap().count(), 1);
            assert_eq!(
                std::fs::read(rootfs.join("sentinel")).unwrap(),
                b"unchanged"
            );
        }
    }

    #[test]
    fn symlink_and_directory_data_are_rejected_before_rootfs_mutation() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        std::fs::write(rootfs.join("sentinel"), b"unchanged").unwrap();
        let record = pax_record("size", "11");
        let cases = [
            (
                "symlink",
                b'2',
                b"link".as_slice(),
                "target",
                raw_member(b"target", b'0', "", b"data"),
                Vec::new(),
            ),
            (
                "directory",
                b'5',
                b"dir/".as_slice(),
                "",
                Vec::new(),
                raw_member(b"dir/item", b'0', "", b"data"),
            ),
        ];
        for (kind, flag, name, target, before, after) in cases {
            let raw_entry = raw_member(name, flag, target, b"replacement");
            let mut pax_member = raw_entry.clone();
            pax_member[124..136].copy_from_slice(b"00000000000\0");
            reseal(&mut pax_member);
            let raw = [before.clone(), raw_entry, after.clone()].concat();
            let pax = [
                before,
                raw_member(b"PaxHeaders/0", b'x', "", record.as_bytes()),
                pax_member,
                after,
            ]
            .concat();
            for (variant, body) in [("raw", raw), ("pax", pax)] {
                let layer = write_archive(dir.path(), &format!("{kind}-{variant}.tar"), &body);
                assert!(matches!(
                    apply_layer(&layer, &rootfs, &mut Ownership::default()),
                    Err(ImageError::Tar(message)) if message == format!("{kind} member has nonzero data size")
                ));
                assert_eq!(std::fs::read_dir(&rootfs).unwrap().count(), 1);
                assert_eq!(
                    std::fs::read(rootfs.join("sentinel")).unwrap(),
                    b"unchanged"
                );
            }
        }
    }

    #[test]
    fn regular_member_with_trailing_slash_is_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        std::fs::write(rootfs.join("sentinel"), b"unchanged").unwrap();
        for (name, payload) in [
            ("payload", b"replacement".to_vec()),
            ("hidden", raw_member(b"hidden", b'3', "", b"")),
        ] {
            let layer = write_archive(
                dir.path(),
                &format!("slash-regular-{name}.tar"),
                &raw_member(b"dir/", b'0', "", &payload),
            );
            assert!(matches!(
                apply_layer(&layer, &rootfs, &mut Ownership::default()),
                Err(ImageError::Tar(message)) if message == "non-directory member has a trailing slash"
            ));
            assert_eq!(std::fs::read_dir(&rootfs).unwrap().count(), 1);
            assert_eq!(
                std::fs::read(rootfs.join("sentinel")).unwrap(),
                b"unchanged"
            );
        }
    }

    #[test]
    fn empty_name_override_is_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        std::fs::write(rootfs.join("sentinel"), b"unchanged").unwrap();
        let pax = pax_record("path", "");
        for (name, header) in [
            ("pax", raw_member(b"PaxHeaders/0", b'x', "", pax.as_bytes())),
            ("gnu", raw_member(b"././@LongLink", b'L', "", b"\0")),
        ] {
            let body = [header, raw_member(b"dir/", b'0', "", b"replacement")].concat();
            let layer = write_archive(dir.path(), &format!("empty-{name}.tar"), &body);
            assert!(matches!(
                apply_layer(&layer, &rootfs, &mut Ownership::default()),
                Err(ImageError::Tar(message)) if message == "archive member has an empty name"
            ));
            assert_eq!(std::fs::read_dir(&rootfs).unwrap().count(), 1);
            assert_eq!(
                std::fs::read(rootfs.join("sentinel")).unwrap(),
                b"unchanged"
            );
        }
    }

    #[test]
    fn overridden_trailing_slash_is_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        std::fs::write(rootfs.join("sentinel"), b"unchanged").unwrap();
        let pax = pax_record("path", "dir/");
        for (name, header) in [
            ("pax", raw_member(b"PaxHeaders/0", b'x', "", pax.as_bytes())),
            ("gnu", raw_member(b"././@LongLink", b'L', "", b"dir/\0")),
        ] {
            let body = [header, raw_member(b"safe", b'0', "", b"replacement")].concat();
            let layer = write_archive(dir.path(), &format!("slash-{name}.tar"), &body);
            assert!(matches!(
                apply_layer(&layer, &rootfs, &mut Ownership::default()),
                Err(ImageError::Tar(message)) if message == "non-directory member has a trailing slash"
            ));
            assert_eq!(std::fs::read_dir(&rootfs).unwrap().count(), 1);
            assert_eq!(
                std::fs::read(rootfs.join("sentinel")).unwrap(),
                b"unchanged"
            );
        }
    }

    #[test]
    fn mixed_pax_and_gnu_name_overrides_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        std::fs::write(rootfs.join("sentinel"), b"unchanged").unwrap();
        let gnu = raw_member(b"././@LongLink", b'L', "", b"dir/\0");
        let pax = raw_member(
            b"PaxHeaders/0",
            b'x',
            "",
            pax_record("path", "safe").as_bytes(),
        );
        let hidden = raw_member(b"evil", b'0', "", b"bad");
        for (name, headers) in [
            ("gnu-pax", [gnu.clone(), pax.clone()].concat()),
            ("pax-gnu", [pax.clone(), gnu.clone()].concat()),
        ] {
            let body = [headers, raw_member(b"raw", b'0', "", &hidden)].concat();
            let layer = write_archive(dir.path(), &format!("mixed-name-{name}.tar"), &body);
            assert!(matches!(
                apply_layer(&layer, &rootfs, &mut Ownership::default()),
                Err(ImageError::Tar(message)) if message == "member has conflicting GNU and pax name overrides"
            ));
            assert_eq!(std::fs::read_dir(&rootfs).unwrap().count(), 1);
            assert_eq!(
                std::fs::read(rootfs.join("sentinel")).unwrap(),
                b"unchanged"
            );
        }
    }

    #[test]
    fn mixed_pax_and_gnu_link_overrides_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        std::fs::write(rootfs.join("sentinel"), b"unchanged").unwrap();
        let gnu = raw_member(b"././@LongLink", b'K', "", b"missing\0");
        let pax = raw_member(
            b"PaxHeaders/0",
            b'x',
            "",
            pax_record("linkpath", "source").as_bytes(),
        );
        for (name, headers) in [
            ("gnu-pax", [gnu.clone(), pax.clone()].concat()),
            ("pax-gnu", [pax.clone(), gnu.clone()].concat()),
        ] {
            let body = [
                raw_member(b"source", b'0', "", b"data"),
                headers,
                raw_member(b"link", b'1', "source", b""),
            ]
            .concat();
            let layer = write_archive(dir.path(), &format!("mixed-link-{name}.tar"), &body);
            assert!(matches!(
                apply_layer(&layer, &rootfs, &mut Ownership::default()),
                Err(ImageError::Tar(message)) if message == "member has conflicting GNU and pax link overrides"
            ));
            assert_eq!(std::fs::read_dir(&rootfs).unwrap().count(), 1);
            assert_eq!(
                std::fs::read(rootfs.join("sentinel")).unwrap(),
                b"unchanged"
            );
        }
    }

    #[test]
    fn multiple_pax_headers_for_one_member_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        std::fs::write(rootfs.join("sentinel"), b"unchanged").unwrap();
        let path = raw_member(
            b"PaxHeaders/0",
            b'x',
            "",
            pax_record("path", "safe").as_bytes(),
        );
        let time = raw_member(
            b"PaxHeaders/1",
            b'x',
            "",
            pax_record("mtime", "0").as_bytes(),
        );
        let hidden = raw_member(b"evil", b'0', "", b"bad");
        for (name, headers) in [
            ("path-time", [path.clone(), time.clone()].concat()),
            ("time-path", [time.clone(), path.clone()].concat()),
        ] {
            let body = [headers, raw_member(b"dir/", b'0', "", &hidden)].concat();
            let layer = write_archive(dir.path(), &format!("double-pax-{name}.tar"), &body);
            assert!(matches!(
                apply_layer(&layer, &rootfs, &mut Ownership::default()),
                Err(ImageError::Tar(message)) if message == "member has multiple pax headers"
            ));
            assert_eq!(std::fs::read_dir(&rootfs).unwrap().count(), 1);
            assert_eq!(
                std::fs::read(rootfs.join("sentinel")).unwrap(),
                b"unchanged"
            );
        }
    }

    #[test]
    fn same_path_type_changes_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        let outside = dir.path().join("outside");
        std::fs::create_dir(&rootfs).unwrap();
        std::fs::create_dir(&outside).unwrap();
        std::fs::write(rootfs.join("sentinel"), b"unchanged").unwrap();
        std::fs::write(outside.join("victim"), b"unchanged").unwrap();
        let symlink = raw_member(b"node", b'2', "../outside/victim", b"");
        let regular = raw_member(b"node", b'0', "", b"new");
        for (name, body) in [
            ("symlink-file", [symlink.clone(), regular.clone()].concat()),
            ("file-symlink", [regular.clone(), symlink.clone()].concat()),
        ] {
            let layer = write_archive(dir.path(), &format!("type-change-{name}.tar"), &body);
            assert!(matches!(
                apply_layer(&layer, &rootfs, &mut Ownership::default()),
                Err(ImageError::Tar(message)) if message == "archive changes a member's type at the same path"
            ));
            assert_eq!(std::fs::read_dir(&rootfs).unwrap().count(), 1);
            assert_eq!(
                std::fs::read(rootfs.join("sentinel")).unwrap(),
                b"unchanged"
            );
            assert_eq!(std::fs::read(outside.join("victim")).unwrap(), b"unchanged");
        }
    }

    #[test]
    fn repeated_symlinks_at_one_path_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        std::fs::write(rootfs.join("sentinel"), b"unchanged").unwrap();
        for (name, first, second) in [
            ("ab", "../outside/a", "../outside/b"),
            ("ba", "../outside/b", "../outside/a"),
        ] {
            let body = [
                raw_member(b"node", b'2', first, b""),
                raw_member(b"node", b'2', second, b""),
            ]
            .concat();
            let layer = write_archive(dir.path(), &format!("symlink-repeat-{name}.tar"), &body);
            assert!(matches!(
                apply_layer(&layer, &rootfs, &mut Ownership::default()),
                Err(ImageError::Tar(message)) if message == "archive repeats a symlink at the same path"
            ));
            assert_eq!(std::fs::read_dir(&rootfs).unwrap().count(), 1);
            assert_eq!(
                std::fs::read(rootfs.join("sentinel")).unwrap(),
                b"unchanged"
            );
        }
    }

    #[test]
    fn repeated_regular_members_at_one_path_keep_the_last_content() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        let body = [
            raw_member(b"node", b'0', "", b"first"),
            raw_member(b"node", b'0', "", b"last"),
        ]
        .concat();
        let layer = write_archive(dir.path(), "regular-repeat.tar", &body);
        apply_layer(&layer, &rootfs, &mut Ownership::default()).unwrap();
        assert_eq!(std::fs::read(rootfs.join("node")).unwrap(), b"last");
    }

    #[test]
    fn nonportable_member_types_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        std::fs::write(rootfs.join("sentinel"), b"unchanged").unwrap();
        for (flag, data) in [(b'A', b"x".as_slice()), (b'3', b"".as_slice())] {
            let layer = write_archive(
                dir.path(),
                &format!("type-{}.tar", flag as char),
                &raw_member(b"item", flag, "", data),
            );
            assert!(matches!(
                apply_layer(&layer, &rootfs, &mut Ownership::default()),
                Err(ImageError::Tar(message)) if message == "archive carries an unsupported member type"
            ));
            assert_eq!(std::fs::read_dir(&rootfs).unwrap().count(), 1);
            assert_eq!(
                std::fs::read(rootfs.join("sentinel")).unwrap(),
                b"unchanged"
            );
        }
    }

    #[test]
    fn hardlink_target_checks_pax_and_gnu_longlink_names() {
        let dir = tempfile::tempdir().unwrap();
        let dest = dir.path().join("layout");
        std::fs::create_dir(&dest).unwrap();
        let pax = pax_record("linkpath", "a");
        for (name, header) in [
            (
                "pax-hardlink.tar",
                raw_member(b"PaxHeaders/0", b'x', "", pax.as_bytes()),
            ),
            (
                "gnu-hardlink.tar",
                raw_member(b"././@LongLink", b'K', "", b"a\0"),
            ),
        ] {
            let body = [
                raw_member(b"A", b'0', "", b"data"),
                header,
                raw_member(b"link", b'1', "A", b""),
            ]
            .concat();
            let archive = write_archive(dir.path(), name, &body);
            assert!(matches!(
                extract_checked(&archive, &dest),
                Err(ImageError::UnsafePath(_))
            ));
            assert_eq!(std::fs::read_dir(&dest).unwrap().count(), 0);
        }
    }

    #[test]
    fn symlink_targets_require_portable_header_and_override_bytes() {
        let dir = tempfile::tempdir().unwrap();
        let dest = dir.path().join("layout");
        std::fs::create_dir(&dest).unwrap();
        for (name, header, base) in [
            (
                "pax-empty-base.tar",
                raw_member(
                    b"PaxHeaders/0",
                    b'x',
                    "",
                    pax_record("linkpath", "target").as_bytes(),
                ),
                "",
            ),
            (
                "gnu-empty-base.tar",
                raw_member(b"././@LongLink", b'K', "", b"target\0"),
                "",
            ),
            (
                "pax-empty-override.tar",
                raw_member(
                    b"PaxHeaders/0",
                    b'x',
                    "",
                    pax_record("linkpath", "").as_bytes(),
                ),
                "base",
            ),
            (
                "pax-unicode-override.tar",
                raw_member(
                    b"PaxHeaders/0",
                    b'x',
                    "",
                    pax_record("linkpath", "targét").as_bytes(),
                ),
                "base",
            ),
        ] {
            let archive = write_archive(
                dir.path(),
                name,
                &[header, raw_member(b"link", b'2', base, b"")].concat(),
            );
            assert!(
                matches!(extract_checked(&archive, &dest), Err(ImageError::Tar(_))),
                "{name}"
            );
            assert_eq!(std::fs::read_dir(&dest).unwrap().count(), 0, "{name}");
        }
        let archive = write_archive(
            dir.path(),
            "portable-override.tar",
            &[
                raw_member(
                    b"PaxHeaders/0",
                    b'x',
                    "",
                    pax_record("linkpath", "target").as_bytes(),
                ),
                raw_member(b"link", b'2', "base", b""),
            ]
            .concat(),
        );
        extract_checked(&archive, &dest).unwrap();
        assert_eq!(
            std::fs::read_link(dest.join("link")).unwrap(),
            Path::new("target")
        );
    }

    #[test]
    fn oversized_symlink_target_is_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let dest = dir.path().join("layout");
        std::fs::create_dir(&dest).unwrap();
        let target = "x".repeat(1024);
        for (name, header) in [
            (
                "pax-long-link.tar",
                raw_member(
                    b"PaxHeaders/0",
                    b'x',
                    "",
                    pax_record("linkpath", &target).as_bytes(),
                ),
            ),
            (
                "gnu-long-link.tar",
                raw_member(b"././@LongLink", b'K', "", format!("{target}\0").as_bytes()),
            ),
        ] {
            let archive = write_archive(
                dir.path(),
                name,
                &[header, raw_member(b"link", b'2', "x", b"")].concat(),
            );
            assert!(
                matches!(read_members(&archive), Err(ImageError::Tar(_))),
                "{name}"
            );
            assert!(
                matches!(extract_checked(&archive, &dest), Err(ImageError::Tar(_))),
                "{name}"
            );
            assert_eq!(std::fs::read_dir(&dest).unwrap().count(), 0, "{name}");
        }
    }

    #[test]
    fn overlong_archive_paths_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let dest = dir.path().join("layout");
        std::fs::create_dir(&dest).unwrap();
        let name = vec!["x".repeat(80); 13].join("/");
        let archive = write_archive(
            dir.path(),
            "overlong-path.tar",
            &[
                raw_member(
                    b"PaxHeaders/0",
                    b'x',
                    "",
                    pax_record("path", &name).as_bytes(),
                ),
                raw_member(b"short", b'0', "", b"data"),
            ]
            .concat(),
        );
        assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
        assert!(matches!(
            extract_checked(&archive, &dest),
            Err(ImageError::Tar(_))
        ));
        assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
    }

    #[test]
    fn deep_staging_roots_are_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let dest = dir
            .path()
            .join("a".repeat(80))
            .join("b".repeat(80))
            .join("c".repeat(80));
        std::fs::create_dir_all(&dest).unwrap();
        let archive = write_archive(
            dir.path(),
            "short-path.tar",
            &raw_member(b"file", b'0', "", b"data"),
        );
        assert!(matches!(
            extract_checked(&archive, &dest),
            Err(ImageError::Tar(_))
        ));
        assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
    }

    #[test]
    fn staging_root_limit_uses_resolved_path() {
        let dir = tempfile::tempdir().unwrap();
        let actual = dir.path().join("a".repeat(150)).join("b".repeat(120));
        std::fs::create_dir_all(&actual).unwrap();
        let alias = dir.path().join("alias");
        std::os::unix::fs::symlink(&actual, &alias).unwrap();
        assert!(alias.as_os_str().as_bytes().len() <= MAX_PORTABLE_STAGING_ROOT);
        assert!(
            actual.canonicalize().unwrap().as_os_str().as_bytes().len() > MAX_PORTABLE_STAGING_ROOT
        );
        let archive = write_archive(
            dir.path(),
            "short-via-alias.tar",
            &raw_member(b"file", b'0', "", b"data"),
        );
        assert!(matches!(
            extract_checked(&archive, &alias),
            Err(ImageError::Tar(_))
        ));
        assert_eq!(std::fs::read_dir(actual).unwrap().count(), 0);
    }

    #[test]
    fn staging_root_limit_also_uses_spelled_path() {
        let dir = tempfile::tempdir().unwrap();
        std::fs::create_dir(dir.path().join("x")).unwrap();
        let mut padded = dir.path().to_path_buf();
        for _ in 0..60 {
            padded.push("x");
            padded.push("..");
        }
        assert!(padded.as_os_str().as_bytes().len() > MAX_PORTABLE_STAGING_ROOT);
        assert!(
            padded.canonicalize().unwrap().as_os_str().as_bytes().len()
                <= MAX_PORTABLE_STAGING_ROOT
        );
        let archive = write_archive(
            dir.path(),
            "short-via-padding.tar",
            &raw_member(b"file", b'0', "", b"data"),
        );
        assert!(matches!(
            extract_checked(&archive, &padded),
            Err(ImageError::Tar(_))
        ));
        assert!(!dir.path().join("file").exists());
    }

    #[test]
    fn extraction_ignores_inherited_tar_environment() {
        if std::env::var_os("HARMONY_OCI_TAR_ENV_TEST_CHILD").is_some() {
            let dir = tempfile::tempdir().unwrap();
            let dest = dir.path().join("layout");
            std::fs::create_dir(&dest).unwrap();
            let archive = write_archive(
                dir.path(),
                "nested.tar",
                &[
                    raw_member(b"a/file", b'0', "", b"data"),
                    raw_member(b"a\\b", b'0', "", b"other"),
                ]
                .concat(),
            );
            extract_checked(&archive, &dest).unwrap();
            assert_eq!(std::fs::read(dest.join("a/file")).unwrap(), b"data");
            assert_eq!(std::fs::read(dest.join("a\\b")).unwrap(), b"other");
            assert!(!dest.join("file").exists());
            return;
        }
        let output = Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "image::tests::extraction_ignores_inherited_tar_environment",
            ])
            .env("HARMONY_OCI_TAR_ENV_TEST_CHILD", "1")
            .env("TAR_OPTIONS", "--strip-components=1")
            .env("TAR_READER_OPTIONS", "hdrcharset=SHIFT_JIS")
            .output()
            .unwrap();
        assert!(
            output.status.success(),
            "{}\n{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    #[test]
    fn padded_hardlink_target_is_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let dest = dir.path().join("layout");
        std::fs::create_dir(&dest).unwrap();
        let target = format!("{}A", "./".repeat(600));
        for (name, header) in [
            (
                "pax-padded-hardlink.tar",
                raw_member(
                    b"PaxHeaders/0",
                    b'x',
                    "",
                    pax_record("linkpath", &target).as_bytes(),
                ),
            ),
            (
                "gnu-padded-hardlink.tar",
                raw_member(b"././@LongLink", b'K', "", format!("{target}\0").as_bytes()),
            ),
        ] {
            let archive = write_archive(
                dir.path(),
                name,
                &[
                    raw_member(b"A", b'0', "", b"payload"),
                    header,
                    raw_member(b"link", b'1', "A", b""),
                ]
                .concat(),
            );
            assert!(
                matches!(read_members(&archive), Err(ImageError::Tar(_))),
                "{name}"
            );
            assert!(
                matches!(extract_checked(&archive, &dest), Err(ImageError::Tar(_))),
                "{name}"
            );
            assert_eq!(std::fs::read_dir(&dest).unwrap().count(), 0, "{name}");
        }
    }

    #[test]
    fn hardlink_override_requires_a_nonempty_base_target() {
        let dir = tempfile::tempdir().unwrap();
        let dest = dir.path().join("layout");
        std::fs::create_dir(&dest).unwrap();
        for (name, header) in [
            (
                "pax-empty-hardlink.tar",
                raw_member(
                    b"PaxHeaders/0",
                    b'x',
                    "",
                    pax_record("linkpath", "A").as_bytes(),
                ),
            ),
            (
                "gnu-empty-hardlink.tar",
                raw_member(b"././@LongLink", b'K', "", b"A\0"),
            ),
        ] {
            let archive = write_archive(
                dir.path(),
                name,
                &[
                    raw_member(b"A", b'0', "", b"payload"),
                    header,
                    raw_member(b"link", b'1', "", b""),
                ]
                .concat(),
            );
            assert!(
                matches!(read_members(&archive), Err(ImageError::Tar(_))),
                "{name}"
            );
            assert!(
                matches!(extract_checked(&archive, &dest), Err(ImageError::Tar(_))),
                "{name}"
            );
            assert_eq!(std::fs::read_dir(&dest).unwrap().count(), 0, "{name}");
        }
    }

    #[test]
    fn apply_layer_refuses_a_symlink_stored_with_a_trailing_slash() {
        let dir = tempfile::tempdir().unwrap();
        let (rootfs, victim) = planted(dir.path());
        let layer = raw_tar(
            dir.path(),
            "slash.tar",
            &[("link/", b'2', "../../victim"), ("link/pwn", b'0', "")],
        );
        assert!(matches!(
            apply_layer(&layer, &rootfs, &mut Ownership::default()),
            Err(ImageError::Tar(message)) if message == "non-directory member has a trailing slash"
        ));
        assert!(victim.join("sentinel").exists());
        assert!(!victim.join("pwn").exists());
    }

    #[test]
    fn read_members_reads_names_a_listing_cannot_show() {
        let dir = tempfile::tempdir().unwrap();
        let body = [
            raw_member(b"two\nlines", b'0', "", b""),
            raw_member(b"caf\xc3\xa9", b'0', "", b""),
            raw_member(b"raw\xff", b'0', "", b""),
        ]
        .concat();
        let names: Vec<Vec<u8>> = read_members(&write_archive(dir.path(), "odd.tar", &body))
            .unwrap()
            .into_iter()
            .map(|m| m.name)
            .collect();
        assert_eq!(
            names,
            vec![
                b"two\nlines".to_vec(),
                b"caf\xc3\xa9".to_vec(),
                b"raw\xff".to_vec()
            ]
        );
    }

    #[test]
    fn apply_layer_refuses_a_symlink_child_beside_a_newline_name() {
        let dir = tempfile::tempdir().unwrap();
        let (rootfs, victim) = planted(dir.path());
        let layer = raw_tar(
            dir.path(),
            "newline.tar",
            &[
                ("pad\nlink/", b'5', ""),
                ("link", b'2', "../../victim"),
                ("link/pwn", b'0', ""),
            ],
        );
        assert!(matches!(
            apply_layer(&layer, &rootfs, &mut Ownership::default()),
            Err(ImageError::UnsafePath(_))
        ));
        assert!(victim.join("sentinel").exists());
        assert!(!victim.join("pwn").exists());
    }

    #[test]
    fn read_members_reads_long_names() {
        let dir = tempfile::tempdir().unwrap();
        let long = "d/".repeat(60) + "leaf";
        let pax = pax_record("path", &long);
        let gnu = [long.as_bytes(), b"\0"].concat();
        let body = [
            raw_member(b"././@LongLink", b'L', "", &gnu),
            raw_member(b"truncated", b'0', "", b""),
            raw_member(b"PaxHeaders/0", b'x', "", pax.as_bytes()),
            raw_member(b"truncated", b'0', "", b""),
        ]
        .concat();
        let names: Vec<Vec<u8>> = read_members(&write_archive(dir.path(), "long.tar", &body))
            .unwrap()
            .into_iter()
            .map(|m| m.name)
            .collect();
        assert_eq!(names, vec![long.as_bytes().to_vec(); 2]);

        let host = tar_layer(dir.path(), "long-host", &[(long.as_str(), b"x")]);
        let names: Vec<String> = read_members(&host)
            .unwrap()
            .iter()
            .map(Member::shown)
            .collect();
        assert!(names.contains(&long), "{names:?}");
    }

    #[test]
    fn apply_layer_refuses_a_traversing_long_name() {
        let dir = tempfile::tempdir().unwrap();
        let (rootfs, victim) = planted(dir.path());
        let long = format!("{}../../victim/pwn\0", "a/".repeat(50));
        let body = [
            raw_member(b"././@LongLink", b'L', "", long.as_bytes()),
            raw_member(b"truncated", b'0', "", b""),
        ]
        .concat();
        let layer = write_archive(dir.path(), "longpath.tar", &body);
        assert!(matches!(
            apply_layer(&layer, &rootfs, &mut Ownership::default()),
            Err(ImageError::UnsafePath(_))
        ));
        assert!(victim.join("sentinel").exists());
    }

    #[test]
    fn read_members_refuses_archives_it_cannot_follow() {
        let dir = tempfile::tempdir().unwrap();
        let member = raw_member(b"file", b'0', "", b"");

        let mut corrupt = member.clone();
        corrupt[148..156].copy_from_slice(b"000000\0 ");
        let path = write_archive(dir.path(), "corrupt.tar", &corrupt);
        assert!(matches!(read_members(&path), Err(ImageError::Tar(_))));

        let mut trailing = member.clone();
        trailing.extend_from_slice(&[0u8; 1024]);
        trailing.extend_from_slice(&raw_member(b"after", b'0', "", b""));
        let path = write_archive(dir.path(), "trailing.tar", &trailing);
        assert!(matches!(read_members(&path), Err(ImageError::Tar(_))));

        let path = dir.path().join("unterminated.tar");
        std::fs::write(&path, &member).unwrap();
        assert!(matches!(read_members(&path), Err(ImageError::Tar(_))));

        let path = dir.path().join("truncated.tar");
        std::fs::write(&path, &member[..300]).unwrap();
        assert!(matches!(read_members(&path), Err(ImageError::Tar(_))));

        let mut oversized = member.clone();
        oversized[124..136].copy_from_slice(&[0xff; 12]);
        reseal(&mut oversized);
        let path = write_archive(dir.path(), "oversized.tar", &oversized);
        assert!(matches!(read_members(&path), Err(ImageError::Tar(_))));
    }

    #[test]
    fn apply_layer_refuses_a_traversing_path_from_the_last_pax_record() {
        let dir = tempfile::tempdir().unwrap();
        let (rootfs, victim) = planted(dir.path());
        let records = [
            pax_record("path", "safe"),
            pax_record("path", "../../victim/pwn"),
        ]
        .concat();
        let body = [
            raw_member(b"PaxHeaders/0", b'x', "", records.as_bytes()),
            raw_member(b"safe", b'0', "", b""),
        ]
        .concat();
        let layer = write_archive(dir.path(), "pax-path.tar", &body);
        assert_eq!(
            read_members(&layer)
                .unwrap()
                .iter()
                .map(Member::shown)
                .collect::<Vec<_>>(),
            vec!["../../victim/pwn".to_string()]
        );
        assert!(matches!(
            apply_layer(&layer, &rootfs, &mut Ownership::default()),
            Err(ImageError::UnsafePath(_))
        ));
        assert!(victim.join("sentinel").exists());
    }

    #[test]
    fn apply_layer_reads_the_members_a_pax_size_of_zero_exposes() {
        let dir = tempfile::tempdir().unwrap();
        let (rootfs, victim) = planted(dir.path());
        let mut cover = raw_member(b"cover", b'0', "", b"");
        cover[124..136].copy_from_slice(b"00000002000\0");
        reseal(&mut cover);
        let body = [
            raw_member(
                b"PaxHeaders/0",
                b'x',
                "",
                pax_record("size", "0").as_bytes(),
            ),
            cover,
            raw_member(b"link", b'2', "../../victim", b""),
            raw_member(b"link/pwn", b'0', "", b""),
        ]
        .concat();
        let layer = write_archive(dir.path(), "pax-zero-size.tar", &body);
        assert_eq!(
            read_members(&layer)
                .unwrap()
                .iter()
                .map(Member::shown)
                .collect::<Vec<_>>(),
            vec![
                "cover".to_string(),
                "link".to_string(),
                "link/pwn".to_string()
            ]
        );
        assert!(matches!(
            apply_layer(&layer, &rootfs, &mut Ownership::default()),
            Err(ImageError::UnsafePath(_))
        ));
        assert!(victim.join("sentinel").exists());
        assert!(!victim.join("pwn").exists());
    }

    #[test]
    fn read_members_skips_the_data_a_pax_size_declares() {
        let dir = tempfile::tempdir().unwrap();
        let data = [
            raw_member(b"link", b'2', "../../victim", b""),
            raw_member(b"link/pwn", b'0', "", b""),
        ]
        .concat();
        let mut cover = raw_member(b"cover", b'0', "", &data);
        cover[124..136].copy_from_slice(b"00000000000\0");
        reseal(&mut cover);
        let body = [
            raw_member(
                b"PaxHeaders/0",
                b'x',
                "",
                pax_record("size", "1024").as_bytes(),
            ),
            cover,
        ]
        .concat();
        let layer = write_archive(dir.path(), "pax-size.tar", &body);
        assert_eq!(
            read_members(&layer)
                .unwrap()
                .iter()
                .map(Member::shown)
                .collect::<Vec<_>>(),
            vec!["cover".to_string()]
        );
    }

    #[test]
    fn pax_size_override_refuses_a_base_size_that_overflows_host_tar() {
        let dir = tempfile::tempdir().unwrap();
        for (label, size, admitted) in [
            ("max-minus-one", i64::MAX as u64 - 1, true),
            ("max", i64::MAX as u64, false),
            ("max-plus-one", i64::MAX as u64 + 1, false),
        ] {
            let mut member = raw_member(b"payload", b'0', "", b"data");
            let mut encoded = [0u8; 12];
            encoded[0] = 0x80;
            encoded[4..].copy_from_slice(&size.to_be_bytes());
            member[124..136].copy_from_slice(&encoded);
            reseal(&mut member);
            let body = [
                raw_member(
                    b"PaxHeaders/0",
                    b'x',
                    "",
                    pax_record("size", "4").as_bytes(),
                ),
                member,
            ]
            .concat();
            let archive = write_archive(dir.path(), &format!("{label}.tar"), &body);
            let dest = dir.path().join(label);
            std::fs::create_dir(&dest).unwrap();

            if admitted {
                assert_eq!(read_members(&archive).unwrap().len(), 1);
                extract_checked(&archive, &dest).unwrap();
                assert_eq!(std::fs::read(dest.join("payload")).unwrap(), b"data");
            } else {
                assert!(matches!(read_members(&archive), Err(ImageError::Tar(_))));
                assert!(matches!(
                    extract_checked(&archive, &dest),
                    Err(ImageError::Tar(_))
                ));
                assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
            }
        }
    }

    #[test]
    fn read_members_refuses_unmodeled_header_forms() {
        let dir = tempfile::tempdir().unwrap();
        let member = raw_member(b"file", b'0', "", b"");
        let refused = |name: &str, body: &[u8]| {
            let path = write_archive(dir.path(), name, body);
            assert!(
                matches!(read_members(&path), Err(ImageError::Tar(_))),
                "{name}"
            );
        };

        for (name, record) in [
            ("global-path.tar", pax_record("path", "elsewhere")),
            ("global-comment.tar", pax_record("comment", "anything")),
        ] {
            let mut body = raw_member(b"pax_global_header", b'g', "", record.as_bytes());
            body.extend_from_slice(&member);
            refused(name, &body);
        }

        let mut sparse = raw_member(
            b"PaxHeaders/0",
            b'x',
            "",
            pax_record("GNU.sparse.size", "4096").as_bytes(),
        );
        sparse.extend_from_slice(&member);
        refused("sparse-pax.tar", &sparse);
        refused("sparse-member.tar", &raw_member(b"file", b'S', "", b""));

        refused("multivolume.tar", &raw_member(b"file", b'M', "", b""));

        let mut keyless = raw_member(b"PaxHeaders/0", b'x', "", b"5 bad\n");
        keyless.extend_from_slice(&member);
        refused("keyless-pax.tar", &keyless);

        let mut unreadable = raw_member(
            b"PaxHeaders/0",
            b'x',
            "",
            pax_record("size", "eleven").as_bytes(),
        );
        unreadable.extend_from_slice(&member);
        refused("unreadable-size.tar", &unreadable);
    }

    #[test]
    fn stage_rejects_platform_file_flags_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        std::fs::create_dir(&layout).unwrap();
        std::fs::write(
            layout.join("manifest.json"),
            br#"[{"Config":"config.json","Layers":["layer.tar"]}]"#,
        )
        .unwrap();
        std::fs::write(layout.join("config.json"), br#"{"config":{}}"#).unwrap();
        let body = [
            raw_member(
                b"PaxHeaders/0",
                b'x',
                "",
                pax_record("SCHILY.fflags", "uchg").as_bytes(),
            ),
            raw_member(b"foo", b'0', "", b"payload"),
        ]
        .concat();
        write_archive(&layout, "layer.tar", &body);
        let staging = dir.path().join("stage");

        assert!(matches!(
            stage(layout.to_str().unwrap(), &staging),
            Err(ImageError::Tar(message)) if message == "archive carries platform-specific file flags"
        ));
        assert_eq!(std::fs::read_dir(&staging).unwrap().count(), 0);

        let harmless = [
            raw_member(
                b"PaxHeaders/0",
                b'x',
                "",
                pax_record("mtime", "0").as_bytes(),
            ),
            raw_member(b"foo", b'0', "", b"payload"),
        ]
        .concat();
        write_archive(&layout, "layer.tar", &harmless);
        let staged = stage(layout.to_str().unwrap(), &staging).unwrap();
        assert_eq!(
            std::fs::read(staged.rootfs.join("foo")).unwrap(),
            b"payload"
        );
    }

    #[test]
    fn stage_rejects_nested_appledouble_name_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        std::fs::create_dir(&layout).unwrap();
        std::fs::write(
            layout.join("manifest.json"),
            br#"[{"Config":"config.json","Layers":["layer.tar"]}]"#,
        )
        .unwrap();
        std::fs::write(layout.join("config.json"), br#"{"config":{}}"#).unwrap();
        let mut apple_double = Vec::new();
        apple_double.extend_from_slice(&0x0005_1607u32.to_be_bytes());
        apple_double.extend_from_slice(&0x0002_0000u32.to_be_bytes());
        apple_double.extend_from_slice(b"Mac OS X        ");
        apple_double.extend_from_slice(&2u16.to_be_bytes());
        apple_double.extend_from_slice(&9u32.to_be_bytes());
        apple_double.extend_from_slice(&50u32.to_be_bytes());
        apple_double.extend_from_slice(&32u32.to_be_bytes());
        apple_double.extend_from_slice(&2u32.to_be_bytes());
        apple_double.extend_from_slice(&82u32.to_be_bytes());
        apple_double.extend_from_slice(&8u32.to_be_bytes());
        apple_double.extend_from_slice(&[0; 32]);
        apple_double.extend_from_slice(b"forkdata");
        let body = [
            raw_member(b"dir/sub/._foo", b'0', "", &apple_double),
            raw_member(b"dir/sub/foo", b'0', "", b"payload"),
        ]
        .concat();
        write_archive(&layout, "layer.tar", &body);
        let staging = dir.path().join("stage");

        assert!(matches!(
            stage(layout.to_str().unwrap(), &staging),
            Err(ImageError::Tar(message)) if message == "archive carries an AppleDouble metadata name"
        ));
        assert_eq!(std::fs::read_dir(staging).unwrap().count(), 0);
    }

    #[test]
    fn stage_rejects_platform_acl_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        std::fs::create_dir(&layout).unwrap();
        std::fs::write(
            layout.join("manifest.json"),
            br#"[{"Config":"config.json","Layers":["layer.tar"]}]"#,
        )
        .unwrap();
        std::fs::write(layout.join("config.json"), br#"{"config":{}}"#).unwrap();
        let acl = "group:everyone:d::deny:12,owner@:rwpaARWcCos::allow,group@:raRcs::allow,everyone@:raRcs::allow";
        let body = [
            raw_member(
                b"PaxHeaders/0",
                b'x',
                "",
                pax_record("SCHILY.acl.ace", acl).as_bytes(),
            ),
            raw_member(b"foo", b'0', "", b"payload"),
        ]
        .concat();
        write_archive(&layout, "layer.tar", &body);
        let staging = dir.path().join("stage");

        assert!(matches!(
            stage(layout.to_str().unwrap(), &staging),
            Err(ImageError::Tar(message)) if message == "archive carries platform-specific ACL metadata"
        ));
        assert_eq!(std::fs::read_dir(staging).unwrap().count(), 0);

        for key in ["SCHILY.acl.access", "SCHILY.acl.default"] {
            let body = [
                raw_member(
                    b"PaxHeaders/0",
                    b'x',
                    "",
                    pax_record(key, "u::rwx").as_bytes(),
                ),
                raw_member(b"foo", b'0', "", b"payload"),
            ]
            .concat();
            let layer = write_archive(dir.path(), &format!("{key}.tar"), &body);
            assert!(matches!(
                read_members(&layer),
                Err(ImageError::Tar(message)) if message == "archive carries platform-specific ACL metadata"
            ));
        }
    }

    #[test]
    fn stage_ignores_host_extended_attributes() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        std::fs::create_dir(&layout).unwrap();
        std::fs::write(
            layout.join("manifest.json"),
            br#"[{"Config":"config.json","Layers":["layer.tar"]}]"#,
        )
        .unwrap();
        std::fs::write(layout.join("config.json"), br#"{"config":{}}"#).unwrap();
        let staging = dir.path().join("stage");

        for (key, value) in [
            ("SCHILY.xattr.com.apple.rootless", "x"),
            ("LIBARCHIVE.xattr.com.apple.rootless", "eA=="),
        ] {
            let body = [
                raw_member(b"PaxHeaders/0", b'x', "", pax_record(key, value).as_bytes()),
                raw_member(b"foo", b'0', "", b"payload"),
            ]
            .concat();
            write_archive(&layout, "layer.tar", &body);
            let staged = stage(layout.to_str().unwrap(), &staging).unwrap();
            assert_eq!(
                std::fs::read(staged.rootfs.join("foo")).unwrap(),
                b"payload"
            );
        }
    }

    #[test]
    fn stage_rejects_schily_sparse_size_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        std::fs::create_dir(&layout).unwrap();
        std::fs::write(
            layout.join("manifest.json"),
            br#"[{"Config":"config.json","Layers":["layer.tar"]}]"#,
        )
        .unwrap();
        std::fs::write(layout.join("config.json"), br#"{"config":{}}"#).unwrap();
        let body = [
            raw_member(
                b"PaxHeaders/0",
                b'x',
                "",
                pax_record("SCHILY.realsize", "70").as_bytes(),
            ),
            raw_member(b"foo", b'0', "", b"payload"),
        ]
        .concat();
        write_archive(&layout, "layer.tar", &body);
        let staging = dir.path().join("stage");

        assert!(matches!(
            stage(layout.to_str().unwrap(), &staging),
            Err(ImageError::Tar(message)) if message == "archive uses an unsupported sparse pax record"
        ));
        assert_eq!(std::fs::read_dir(staging).unwrap().count(), 0);
    }

    #[test]
    fn stage_rejects_solaris_sparse_holes_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        std::fs::create_dir(&layout).unwrap();
        std::fs::write(
            layout.join("manifest.json"),
            br#"[{"Config":"config.json","Layers":["layer.tar"]}]"#,
        )
        .unwrap();
        std::fs::write(layout.join("config.json"), br#"{"config":{}}"#).unwrap();
        let body = [
            raw_member(
                b"PaxHeaders/0",
                b'x',
                "",
                pax_record("SUN.holesdata", " 0 3 5 7").as_bytes(),
            ),
            raw_member(b"foo", b'0', "", b"payload"),
        ]
        .concat();
        write_archive(&layout, "layer.tar", &body);
        let staging = dir.path().join("stage");

        assert!(matches!(
            stage(layout.to_str().unwrap(), &staging),
            Err(ImageError::Tar(message)) if message == "archive uses an unsupported sparse pax record"
        ));
        assert_eq!(std::fs::read_dir(staging).unwrap().count(), 0);
    }

    #[test]
    fn read_members_reads_a_binary_size_field() {
        let dir = tempfile::tempdir().unwrap();
        let mut member = raw_member(b"big", b'0', "", b"data");
        let mut size = [0u8; 12];
        size[0] = 0x80;
        size[11] = 4;
        member[124..136].copy_from_slice(&size);
        reseal(&mut member);
        let path = write_archive(dir.path(), "binary-size.tar", &member);
        let names: Vec<String> = read_members(&path)
            .unwrap()
            .iter()
            .map(Member::shown)
            .collect();
        assert_eq!(names, vec!["big".to_string()]);
    }

    #[test]
    fn compressed_layers_are_read_and_extracted() {
        let dir = tempfile::tempdir().unwrap();
        let plain = tar_layer(dir.path(), "layer", &[("etc/passwd", b"root")]);
        let expected: Vec<String> = read_members(&plain)
            .unwrap()
            .iter()
            .map(Member::shown)
            .collect();
        assert!(expected.contains(&"etc/passwd".to_string()));
        for tool in ["gzip", "zstd", "xz", "bzip2"] {
            let compressed = dir.path().join(format!("layer.{tool}"));
            let out = Command::new(tool)
                .arg("-c")
                .arg(&plain)
                .stdout(std::fs::File::create(&compressed).unwrap())
                .status();
            if !out.is_ok_and(|status| status.success()) {
                continue;
            }
            let names: Vec<String> = read_members(&compressed)
                .unwrap()
                .iter()
                .map(Member::shown)
                .collect();
            assert_eq!(names, expected, "{tool}");
            let dest = dir.path().join(format!("extract-{tool}"));
            std::fs::create_dir(&dest).unwrap();
            extract_checked(&compressed, &dest).unwrap();
            assert_eq!(std::fs::read(dest.join("etc/passwd")).unwrap(), b"root");
        }
    }

    #[test]
    fn decompression_ignores_inherited_host_options() {
        if std::env::var_os("HARMONY_OCI_XZ_ENV_TEST_CHILD").is_some() {
            let dir = tempfile::tempdir().unwrap();
            let plain = tar_layer(dir.path(), "layer", &[("file", b"data")]);
            let compressed = dir.path().join("layer.xz");
            let output = Command::new("xz")
                .arg("-c")
                .arg(&plain)
                .env_remove("XZ_DEFAULTS")
                .stdout(std::fs::File::create(&compressed).unwrap())
                .status()
                .unwrap();
            assert!(output.success());
            assert_eq!(read_members(&compressed).unwrap()[0].shown(), "file");
            let dest = dir.path().join("out");
            std::fs::create_dir(&dest).unwrap();
            extract_checked(&compressed, &dest).unwrap();
            assert_eq!(std::fs::read(dest.join("file")).unwrap(), b"data");
            return;
        }
        if Command::new("xz").arg("--version").output().is_err() {
            return;
        }
        let output = Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "image::tests::decompression_ignores_inherited_host_options",
            ])
            .env("HARMONY_OCI_XZ_ENV_TEST_CHILD", "1")
            .env("XZ_DEFAULTS", "--memlimit-decompress=1MiB")
            .output()
            .unwrap();
        assert!(
            output.status.success(),
            "{}\n{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
    }

    #[test]
    fn corrupt_gzip_trailer_is_rejected_before_extraction() {
        let dir = tempfile::tempdir().unwrap();
        let plain = write_archive(
            dir.path(),
            "plain.tar",
            &raw_member(b"payload", b'0', "", b"data"),
        );
        let output = Command::new("gzip").arg("-c").arg(&plain).output().unwrap();
        assert!(output.status.success());
        let mut compressed = output.stdout;
        let trailer = compressed.len() - 8;
        compressed[trailer] ^= 1;
        let archive = dir.path().join("bad-crc.tar.gz");
        std::fs::write(&archive, compressed).unwrap();
        let dest = dir.path().join("dest");
        std::fs::create_dir(&dest).unwrap();

        assert!(matches!(read_members(&archive), Err(ImageError::Io(_))));
        assert!(matches!(
            extract_checked(&archive, &dest),
            Err(ImageError::Io(_))
        ));
        assert_eq!(std::fs::read_dir(dest).unwrap().count(), 0);
    }

    #[test]
    fn gzip_layer_with_trailing_padding_is_rejected_on_every_host() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        std::fs::create_dir(&layout).unwrap();
        std::fs::write(
            layout.join("manifest.json"),
            br#"[{"Config":"config.json","Layers":["layer.tar"]}]"#,
        )
        .unwrap();
        std::fs::write(layout.join("config.json"), br#"{"config":{}}"#).unwrap();
        let plain = write_archive(
            dir.path(),
            "plain.tar",
            &raw_member(b"payload", b'0', "", b"data"),
        );
        let output = Command::new("gzip").arg("-c").arg(&plain).output().unwrap();
        assert!(output.status.success());
        let mut compressed = output.stdout;
        std::fs::write(layout.join("layer.tar"), &compressed).unwrap();
        let admitted = stage(layout.to_str().unwrap(), &dir.path().join("plain-staging")).unwrap();
        assert_eq!(
            std::fs::read(admitted.rootfs.join("payload")).unwrap(),
            b"data"
        );
        compressed.extend_from_slice(&[0; 8]);
        std::fs::write(layout.join("layer.tar"), compressed).unwrap();

        assert!(matches!(
            stage(layout.to_str().unwrap(), &dir.path().join("padded-staging")),
            Err(ImageError::Io(_))
        ));
    }

    #[test]
    fn apply_layer_refuses_a_symlink_and_a_member_under_it_in_one_layer() {
        let dir = tempfile::tempdir().unwrap();
        let (rootfs, victim) = planted(dir.path());
        for (n, members) in [
            vec![("link", b'2', "../../victim"), ("link/pwn", b'0', "")],
            vec![("link", b'2', "/etc"), ("link/pwn", b'0', "")],
            vec![("Link", b'2', "../../victim"), ("link/pwn", b'0', "")],
            vec![("link", b'0', ""), ("link/pwn", b'0', "")],
        ]
        .iter()
        .enumerate()
        {
            let layer = raw_tar(dir.path(), &format!("same{n}.tar"), members);
            let err = apply_layer(&layer, &rootfs, &mut Ownership::default()).unwrap_err();
            assert!(
                matches!(err, ImageError::UnsafePath(_)),
                "{members:?}: {err:?}"
            );
            assert!(!victim.join("pwn").exists(), "{members:?} wrote outside");
            assert!(victim.join("sentinel").is_file(), "{members:?}");
        }
    }

    #[test]
    fn apply_layer_keeps_directories_and_symlinks() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir_all(&rootfs).unwrap();
        let stage = dir.path().join("ok-stage");
        std::fs::create_dir_all(stage.join("bin")).unwrap();
        std::fs::write(stage.join("bin/busybox"), b"elf").unwrap();
        std::os::unix::fs::symlink("busybox", stage.join("bin/sh")).unwrap();
        std::os::unix::fs::symlink("/absolute/target", stage.join("abs")).unwrap();
        let layer = dir.path().join("ok.tar");
        assert!(
            Command::new("tar")
                .env("COPYFILE_DISABLE", "1")
                .arg("-cf")
                .arg(&layer)
                .arg("-C")
                .arg(&stage)
                .args(["bin", "abs"])
                .status()
                .unwrap()
                .success()
        );
        apply_layer(&layer, &rootfs, &mut Ownership::default()).unwrap();
        assert_eq!(std::fs::read(rootfs.join("bin/busybox")).unwrap(), b"elf");
        assert_eq!(
            std::fs::read_link(rootfs.join("bin/sh")).unwrap(),
            Path::new("busybox")
        );
        assert_eq!(
            std::fs::read_link(rootfs.join("abs")).unwrap(),
            Path::new("/absolute/target")
        );
    }

    #[test]
    fn apply_layer_fills_a_read_only_directory() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir_all(&rootfs).unwrap();
        let stage = dir.path().join("ro-stage");
        std::fs::create_dir_all(stage.join("ro")).unwrap();
        std::fs::write(stage.join("ro/x"), b"content").unwrap();
        std::fs::set_permissions(stage.join("ro"), std::fs::Permissions::from_mode(0o555)).unwrap();
        let layer = dir.path().join("ro.tar");
        assert!(
            Command::new("tar")
                .env("COPYFILE_DISABLE", "1")
                .arg("-cf")
                .arg(&layer)
                .arg("-C")
                .arg(&stage)
                .arg("ro")
                .status()
                .unwrap()
                .success()
        );
        apply_layer(&layer, &rootfs, &mut Ownership::default()).unwrap();
        assert_eq!(std::fs::read(rootfs.join("ro/x")).unwrap(), b"content");
        let mode = std::fs::symlink_metadata(rootfs.join("ro"))
            .unwrap()
            .permissions()
            .mode()
            & 0o777;
        assert_eq!(mode, 0o555);
        for path in [stage.join("ro"), rootfs.join("ro")] {
            std::fs::set_permissions(path, std::fs::Permissions::from_mode(0o755)).unwrap();
        }
    }

    #[test]
    fn preparation_reads_unreadable_guest_paths_without_changing_modes() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        std::fs::create_dir(&layout).unwrap();
        std::fs::write(
            layout.join("manifest.json"),
            br#"[{"Config":"config.json","Layers":["layer.tar"]}]"#,
        )
        .unwrap();
        std::fs::write(layout.join("config.json"), br#"{"config":{"User":"svc"}}"#).unwrap();
        let body = [
            raw_member_with_mode(b"secret", b'0', "", b"data", Owner::ROOT, 0),
            raw_member_with_mode(b"sealed/", b'5', "", b"", Owner::ROOT, 0),
            raw_member_with_mode(b"sealed/secret", b'0', "", b"hidden", Owner::ROOT, 0),
            raw_member_with_mode(b"etc/", b'5', "", b"", Owner::ROOT, 0),
            raw_member_with_mode(
                b"etc/passwd",
                b'0',
                "",
                b"svc:x:123:456::/home/svc:/bin/sh\n",
                Owner::ROOT,
                0,
            ),
            raw_member_with_mode(b"etc/group", b'0', "", b"svc:x:456:\n", Owner::ROOT, 0),
            raw_member_with_mode(b"usr/", b'5', "", b"", Owner::ROOT, 0),
        ]
        .concat();
        write_archive(&layout, "layer.tar", &body);
        let stage_dir = dir.path().join("stage");
        std::fs::create_dir(&stage_dir).unwrap();
        let staged = stage(layout.to_str().unwrap(), &stage_dir).unwrap();
        assert_eq!(staged.owners.mode_of(Path::new("secret"), 0o644), 0);
        assert_eq!(staged.owners.mode_of(Path::new("sealed"), 0o755), 0);
        let packed = crate::bundle::build_rootfs_segment(&staged.rootfs, &staged.owners).unwrap();
        for path in ["secret", "sealed"] {
            let staged_path = staged.rootfs.join(path);
            let mode = std::fs::symlink_metadata(staged_path)
                .unwrap()
                .permissions()
                .mode()
                & 0o7777;
            assert_eq!(mode, 0, "{path}");
        }
        std::fs::set_permissions(
            staged.rootfs.join("sealed"),
            std::fs::Permissions::from_mode(0o700),
        )
        .unwrap();
        assert_eq!(
            std::fs::symlink_metadata(staged.rootfs.join("sealed/secret"))
                .unwrap()
                .permissions()
                .mode()
                & 0o7777,
            0
        );
        for path in ["secret", "sealed", "sealed/secret"] {
            let staged_path = staged.rootfs.join(path);
            std::fs::set_permissions(staged_path, std::fs::Permissions::from_mode(0o700)).unwrap();
        }
        assert_eq!(
            packed,
            crate::bundle::build_rootfs_segment(&staged.rootfs, &staged.owners).unwrap()
        );
        let fallback_required = match std::fs::read(staged.rootfs.join("etc/passwd")) {
            Err(error) if error.kind() == std::io::ErrorKind::PermissionDenied => true,
            Ok(_) => false,
            Err(error) => panic!("unexpected account-file read error: {error}"),
        };
        let credentials = staged
            .config
            .resolve_process_credentials(&staged.rootfs)
            .unwrap();
        assert_eq!((credentials.uid, credentials.gid), (123, 456));
        let assert_preparation_modes = || {
            for path in ["etc", "usr"] {
                let mode = std::fs::symlink_metadata(staged.rootfs.join(path))
                    .unwrap()
                    .permissions()
                    .mode()
                    & 0o7777;
                assert_eq!(mode, 0, "{path}");
            }
            std::fs::set_permissions(
                staged.rootfs.join("etc"),
                std::fs::Permissions::from_mode(0o700),
            )
            .unwrap();
            for path in ["etc/passwd", "etc/group"] {
                let mode = std::fs::symlink_metadata(staged.rootfs.join(path))
                    .unwrap()
                    .permissions()
                    .mode()
                    & 0o7777;
                assert_eq!(mode, 0, "{path}");
            }
            std::fs::set_permissions(
                staged.rootfs.join("etc"),
                std::fs::Permissions::from_mode(0o0),
            )
            .unwrap();
        };
        if fallback_required {
            assert_preparation_modes();
        }
        let request = crate::bundle::LaunchRequest::new(vec!["/bin/true".into()]);
        let prepared = crate::bundle::prepare(&staged, &request).unwrap();
        assert_eq!(
            (prepared.execution().uid, prepared.execution().gid),
            (123, 456)
        );
        assert_eq!(prepared.rootfs_segment(), packed);
        assert_preparation_modes();
        for path in ["etc", "usr"] {
            std::fs::set_permissions(
                staged.rootfs.join(path),
                std::fs::Permissions::from_mode(0o700),
            )
            .unwrap();
        }
    }

    #[test]
    fn apply_layer_replaces_earlier_entries() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir_all(&rootfs).unwrap();
        let base = tar_layer(dir.path(), "one", &[("f", b"old"), ("d/x", b"x")]);
        apply_layer(&base, &rootfs, &mut Ownership::default()).unwrap();
        let upper = tar_layer(dir.path(), "two", &[("f", b"new"), ("d/y", b"y")]);
        apply_layer(&upper, &rootfs, &mut Ownership::default()).unwrap();
        assert_eq!(std::fs::read(rootfs.join("f")).unwrap(), b"new");
        assert_eq!(std::fs::read(rootfs.join("d/x")).unwrap(), b"x");
        assert_eq!(std::fs::read(rootfs.join("d/y")).unwrap(), b"y");
    }

    #[test]
    fn apply_layer_honors_whiteouts() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir_all(&rootfs).unwrap();

        let base = tar_layer(
            dir.path(),
            "base",
            &[
                ("keep.txt", b"keep"),
                ("gone.txt", b"gone"),
                ("d/old", b"old"),
            ],
        );
        apply_layer(&base, &rootfs, &mut Ownership::default()).unwrap();
        assert!(rootfs.join("keep.txt").is_file());
        assert!(rootfs.join("d/old").is_file());

        let upper = tar_layer(
            dir.path(),
            "upper",
            &[
                (".wh.gone.txt", b""),
                ("d/.wh..wh..opq", b""),
                ("d/new", b"new"),
            ],
        );
        apply_layer(&upper, &rootfs, &mut Ownership::default()).unwrap();
        assert!(rootfs.join("keep.txt").is_file());
        assert!(!rootfs.join("gone.txt").exists());
        assert!(!rootfs.join("d/old").exists());
        assert_eq!(std::fs::read(rootfs.join("d/new")).unwrap(), b"new");
        assert!(!rootfs.join("d/.wh..wh..opq").exists());
    }

    #[test]
    fn whiteout_removes_child_from_nested_read_only_lower_directory() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        let lower = [
            raw_member_with_mode(b"ro/", b'5', "", b"", Owner::ROOT, 0o555),
            raw_member_with_mode(b"ro/nested/", b'5', "", b"", Owner::ROOT, 0o555),
            raw_member(b"ro/nested/old", b'0', "", b"old"),
            raw_member_with_mode(b"ro/sub/", b'5', "", b"", Owner::ROOT, 0o555),
            raw_member(b"ro/sub/inside", b'0', "", b"inside"),
        ]
        .concat();
        let upper = [
            raw_member(b"ro/nested/.wh.old", b'0', "", b""),
            raw_member(b"ro/.wh.sub", b'0', "", b""),
        ]
        .concat();
        let lower = write_archive(dir.path(), "lower.tar", &lower);
        let upper = write_archive(dir.path(), "upper.tar", &upper);
        let mut owners = Ownership::default();
        apply_layer(&lower, &rootfs, &mut owners).unwrap();
        let result = apply_layer(&upper, &rootfs, &mut owners);
        let ro_mode = std::fs::symlink_metadata(rootfs.join("ro"))
            .unwrap()
            .permissions()
            .mode()
            & 0o7777;
        let nested_mode = std::fs::symlink_metadata(rootfs.join("ro/nested"))
            .unwrap()
            .permissions()
            .mode()
            & 0o7777;
        if rootfs.join("ro/sub").is_dir() {
            std::fs::set_permissions(
                rootfs.join("ro/sub"),
                std::fs::Permissions::from_mode(0o755),
            )
            .unwrap();
        }
        for path in ["ro", "ro/nested"] {
            std::fs::set_permissions(rootfs.join(path), std::fs::Permissions::from_mode(0o755))
                .unwrap();
        }
        result.unwrap();
        assert!(!rootfs.join("ro/nested/old").exists());
        assert!(!rootfs.join("ro/sub").exists());
        assert_eq!(ro_mode, 0o555);
        assert_eq!(nested_mode, 0o555);
        assert_eq!(owners.mode_of(Path::new("ro"), 0), 0o555);
        assert_eq!(owners.mode_of(Path::new("ro/nested"), 0), 0o555);
    }

    #[test]
    fn opaque_whiteout_clears_read_only_lower_directory() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        let lower = [
            raw_member_with_mode(b"ro/", b'5', "", b"", Owner::ROOT, 0o555),
            raw_member_with_mode(b"ro/nested/", b'5', "", b"", Owner::ROOT, 0o555),
            raw_member(b"ro/nested/old", b'0', "", b"old"),
        ]
        .concat();
        let upper = [
            raw_member(b"ro/.wh.missing", b'0', "", b""),
            raw_member(b"ro/.wh..wh..opq", b'0', "", b""),
            raw_member(b"ro/new", b'0', "", b"new"),
        ]
        .concat();
        let lower = write_archive(dir.path(), "lower.tar", &lower);
        let upper = write_archive(dir.path(), "upper.tar", &upper);
        let mut owners = Ownership::default();
        apply_layer(&lower, &rootfs, &mut owners).unwrap();
        let result = apply_layer(&upper, &rootfs, &mut owners);
        let mode = std::fs::symlink_metadata(rootfs.join("ro"))
            .unwrap()
            .permissions()
            .mode()
            & 0o7777;
        if rootfs.join("ro/nested").is_dir() {
            std::fs::set_permissions(
                rootfs.join("ro/nested"),
                std::fs::Permissions::from_mode(0o755),
            )
            .unwrap();
        }
        std::fs::set_permissions(rootfs.join("ro"), std::fs::Permissions::from_mode(0o755))
            .unwrap();
        result.unwrap();
        assert!(!rootfs.join("ro/nested").exists());
        assert_eq!(std::fs::read(rootfs.join("ro/new")).unwrap(), b"new");
        assert_eq!(mode, 0o555);
        assert_eq!(owners.mode_of(Path::new("ro"), 0), 0o555);
    }

    #[test]
    fn upper_file_fills_read_only_implicit_parent_without_changing_its_mode() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        let lower = raw_member_with_mode(b"ro/", b'5', "", b"", Owner::ROOT, 0o555);
        let upper = raw_member(b"ro/new", b'0', "", b"new");
        let lower = write_archive(dir.path(), "lower.tar", &lower);
        let upper = write_archive(dir.path(), "upper.tar", &upper);
        let mut owners = Ownership::default();
        apply_layer(&lower, &rootfs, &mut owners).unwrap();
        let result = apply_layer(&upper, &rootfs, &mut owners);
        let mode = std::fs::symlink_metadata(rootfs.join("ro"))
            .unwrap()
            .permissions()
            .mode()
            & 0o7777;
        std::fs::set_permissions(rootfs.join("ro"), std::fs::Permissions::from_mode(0o755))
            .unwrap();
        result.unwrap();
        assert_eq!(std::fs::read(rootfs.join("ro/new")).unwrap(), b"new");
        assert_eq!(mode, 0o555);
        assert_eq!(owners.mode_of(Path::new("ro"), 0), 0o555);
    }

    const SERVICE: Owner = Owner { uid: 70, gid: 70 };

    #[test]
    fn read_members_reads_the_owner_of_each_member() {
        let dir = tempfile::tempdir().unwrap();
        let body = [
            raw_member_owned(b"data", b'5', "", b"", SERVICE),
            raw_member(b"etc", b'5', "", b""),
            raw_member(
                b"PaxHeaders/0",
                b'x',
                "",
                [pax_record("uid", "70000"), pax_record("gid", "5")]
                    .concat()
                    .as_bytes(),
            ),
            raw_member_owned(b"wide", b'0', "", b"", Owner { uid: 1, gid: 1 }),
        ]
        .concat();
        let members = read_members(&write_archive(dir.path(), "owned.tar", &body)).unwrap();
        let owners: Vec<(String, Owner)> = members
            .iter()
            .map(|member| (member.shown(), member.owner))
            .collect();
        assert_eq!(
            owners,
            [
                ("data".to_string(), SERVICE),
                ("etc".to_string(), Owner::ROOT),
                ("wide".to_string(), Owner { uid: 70000, gid: 5 }),
            ]
        );
    }

    #[test]
    fn read_members_refuses_owners_it_cannot_apply() {
        let dir = tempfile::tempdir().unwrap();
        for (name, record) in [
            ("huge-uid.tar", pax_record("uid", "4294967296")),
            ("text-gid.tar", pax_record("gid", "service")),
        ] {
            let mut body = raw_member(b"PaxHeaders/0", b'x', "", record.as_bytes());
            body.extend_from_slice(&raw_member(b"file", b'0', "", b""));
            let path = write_archive(dir.path(), name, &body);
            assert!(
                matches!(read_members(&path), Err(ImageError::Tar(_))),
                "{name}"
            );
        }
    }

    #[test]
    fn apply_layer_records_what_each_layer_did_to_ownership() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir_all(&rootfs).unwrap();
        let mut owners = Ownership::default();

        let base = [
            raw_member_owned(b"data/", b'5', "", b"", SERVICE),
            raw_member_owned(b"data/conf", b'0', "", b"cfg", SERVICE),
            raw_member_owned(b"data/sub/", b'5', "", b"", SERVICE),
            raw_member_owned(b"data/sub/x", b'0', "", b"x", SERVICE),
            raw_member_owned(b"gone", b'0', "", b"gone", SERVICE),
            raw_member_owned(b"swap/", b'5', "", b"", SERVICE),
            raw_member_owned(b"swap/child", b'0', "", b"child", SERVICE),
            raw_member(b"etc", b'0', "", b"root"),
        ]
        .concat();
        apply_layer(
            &write_archive(dir.path(), "base.tar", &base),
            &rootfs,
            &mut owners,
        )
        .unwrap();
        for path in [
            "data",
            "data/conf",
            "data/sub",
            "data/sub/x",
            "gone",
            "swap",
            "swap/child",
        ] {
            assert_eq!(owners.owner_of(Path::new(path)), SERVICE, "{path}");
        }
        assert_eq!(owners.owner_of(Path::new("etc")), Owner::ROOT);
        assert_eq!(
            owners.owner_of(Path::new("./data/")),
            SERVICE,
            "one entry, however spelled"
        );

        let other = Owner { uid: 71, gid: 71 };
        let upper = [
            raw_member(b".wh.gone", b'0', "", b""),
            raw_member(b"data/.wh..wh..opq", b'0', "", b""),
            raw_member_owned(b"data/new", b'0', "", b"new", other),
            raw_member(b"swap", b'0', "", b"file now"),
            raw_member_owned(b"etc", b'0', "", b"taken", other),
        ]
        .concat();
        apply_layer(
            &write_archive(dir.path(), "upper.tar", &upper),
            &rootfs,
            &mut owners,
        )
        .unwrap();
        assert_eq!(
            owners.owner_of(Path::new("gone")),
            Owner::ROOT,
            "whiteout forgets the entry"
        );
        assert_eq!(
            owners.owner_of(Path::new("data")),
            SERVICE,
            "opaque keeps the directory"
        );
        assert_eq!(
            owners.owner_of(Path::new("data/conf")),
            Owner::ROOT,
            "opaque forgets children"
        );
        assert_eq!(owners.owner_of(Path::new("data/sub/x")), Owner::ROOT);
        assert_eq!(owners.owner_of(Path::new("data/new")), other);
        assert_eq!(
            owners.owner_of(Path::new("swap")),
            Owner::ROOT,
            "the file replacing the directory"
        );
        assert_eq!(
            owners.owner_of(Path::new("swap/child")),
            Owner::ROOT,
            "and the children it took"
        );
        assert_eq!(
            owners.owner_of(Path::new("etc")),
            other,
            "a later layer owns what it replaced"
        );
        assert!(!rootfs.join("gone").exists());
        assert!(!rootfs.join("data/conf").exists());
        assert!(rootfs.join("swap").is_file());
        assert_eq!(std::fs::read(rootfs.join("data/new")).unwrap(), b"new");
    }

    #[test]
    fn apply_layer_keeps_the_modes_the_layer_recorded() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        let expected = [
            ("tmp", b'5', 0o1777),
            ("secret", b'5', 0o700),
            ("secret/key", b'0', 0o600),
            ("shared", b'0', 0o660),
        ];
        let layer: Vec<u8> = expected
            .iter()
            .flat_map(|(name, typeflag, mode)| {
                raw_member_with_mode(name.as_bytes(), *typeflag, "", b"", Owner::ROOT, *mode)
            })
            .collect();
        apply_layer(
            &write_archive(dir.path(), "layer.tar", &layer),
            &rootfs,
            &mut Ownership::default(),
        )
        .unwrap();
        for (name, _, mode) in expected {
            let on_disk = std::fs::metadata(rootfs.join(name))
                .unwrap()
                .permissions()
                .mode()
                & 0o7777;
            assert_eq!(on_disk, mode, "{name}");
        }
    }

    #[test]
    fn implicit_layer_parent_has_a_fixed_mode() {
        let Some(marker) = std::env::var_os("HARMONY_OCI_UMASK_TEST_MARKER") else {
            let marker = tempfile::NamedTempFile::new().unwrap();
            let output = Command::new("sh")
                .arg("-c")
                .arg("umask 077; exec \"$@\"")
                .arg("sh")
                .arg(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "image::tests::implicit_layer_parent_has_a_fixed_mode",
                    "--nocapture",
                ])
                .env("HARMONY_OCI_UMASK_TEST_MARKER", marker.path())
                .output()
                .unwrap();
            assert!(
                output.status.success(),
                "restricted-umask child failed: {} {}",
                String::from_utf8_lossy(&output.stdout),
                String::from_utf8_lossy(&output.stderr)
            );
            assert_eq!(std::fs::read(marker.path()).unwrap(), b"ok");
            return;
        };
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir_all(&rootfs).unwrap();
        let member = raw_member_with_mode(b"implicit/file", b'0', "", b"data", Owner::ROOT, 0o644);
        let layer = write_archive(dir.path(), "implicit.tar", &member);

        apply_layer(&layer, &rootfs, &mut Ownership::default()).unwrap();
        assert_eq!(
            std::fs::symlink_metadata(rootfs.join("implicit"))
                .unwrap()
                .permissions()
                .mode()
                & 0o7777,
            0o755
        );
        assert_eq!(
            std::fs::read(rootfs.join("implicit/file")).unwrap(),
            b"data"
        );
        std::fs::write(marker, b"ok").unwrap();
    }

    #[test]
    fn implicit_upper_parent_preserves_lower_directory_mode() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        let lower = raw_member_with_mode(b"restricted/", b'5', "", b"", SERVICE, 0o700);
        let upper =
            raw_member_with_mode(b"restricted/file", b'0', "", b"payload", Owner::ROOT, 0o644);
        let lower = write_archive(dir.path(), "lower.tar", &lower);
        let upper = write_archive(dir.path(), "upper.tar", &upper);
        let mut owners = Ownership::default();

        apply_layer(&lower, &rootfs, &mut owners).unwrap();
        apply_layer(&upper, &rootfs, &mut owners).unwrap();

        let mode = std::fs::symlink_metadata(rootfs.join("restricted"))
            .unwrap()
            .permissions()
            .mode()
            & 0o7777;
        assert_eq!(mode, 0o700);
        assert_eq!(owners.mode_of(Path::new("restricted"), mode), 0o700);
        assert_eq!(owners.owner_of(Path::new("restricted")), SERVICE);
        assert_eq!(
            std::fs::read(rootfs.join("restricted/file")).unwrap(),
            b"payload"
        );

        let explicit = raw_member_with_mode(b"restricted/", b'5', "", b"", Owner::ROOT, 0o750);
        let explicit = write_archive(dir.path(), "explicit.tar", &explicit);
        apply_layer(&explicit, &rootfs, &mut owners).unwrap();
        let mode = std::fs::symlink_metadata(rootfs.join("restricted"))
            .unwrap()
            .permissions()
            .mode()
            & 0o7777;
        assert_eq!(mode, 0o750);
        assert_eq!(owners.mode_of(Path::new("restricted"), mode), 0o750);
        assert_eq!(owners.owner_of(Path::new("restricted")), Owner::ROOT);
    }

    #[test]
    fn opaque_upper_parent_preserves_lower_directory_metadata() {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs");
        std::fs::create_dir(&rootfs).unwrap();
        let lower = [
            raw_member_with_mode(b"restricted/", b'5', "", b"", SERVICE, 0o700),
            raw_member(b"restricted/old", b'0', "", b"old"),
        ]
        .concat();
        let upper = [
            raw_member(b"restricted/.wh..wh..opq", b'0', "", b""),
            raw_member(b"restricted/.wh..wh..opq", b'0', "", b""),
            raw_member(b"restricted/new", b'0', "", b"new"),
        ]
        .concat();
        let lower = write_archive(dir.path(), "lower.tar", &lower);
        let upper = write_archive(dir.path(), "upper.tar", &upper);
        let mut owners = Ownership::default();

        apply_layer(&lower, &rootfs, &mut owners).unwrap();
        apply_layer(&upper, &rootfs, &mut owners).unwrap();

        let mode = std::fs::symlink_metadata(rootfs.join("restricted"))
            .unwrap()
            .permissions()
            .mode()
            & 0o7777;
        assert_eq!(mode, 0o700);
        assert_eq!(owners.mode_of(Path::new("restricted"), mode), 0o700);
        assert_eq!(owners.owner_of(Path::new("restricted")), SERVICE);
        assert!(!rootfs.join("restricted/old").exists());
        assert_eq!(
            std::fs::read(rootfs.join("restricted/new")).unwrap(),
            b"new"
        );
    }

    fn cpio_entry(bytes: &[u8], at: usize) -> (String, Owner, usize) {
        let field = |i: usize| {
            let text = std::str::from_utf8(&bytes[at + 6 + 8 * i..at + 6 + 8 * (i + 1)]).unwrap();
            u32::from_str_radix(text, 16).unwrap()
        };
        assert_eq!(&bytes[at..at + 6], b"070701");
        let (uid, gid, filesize, namesize) = (field(2), field(3), field(6), field(11));
        let name_at = at + 110;
        let name = std::str::from_utf8(&bytes[name_at..name_at + namesize as usize - 1])
            .unwrap()
            .to_string();
        let data_at = (name_at + namesize as usize).next_multiple_of(4);
        let next = (data_at + filesize as usize).next_multiple_of(4);
        (name, Owner { uid, gid }, next)
    }

    #[test]
    fn staging_carries_layer_ownership_into_the_rootfs_segment() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        let layer = [
            raw_member_owned(b"var/", b'5', "", b"", Owner::ROOT),
            raw_member_owned(b"var/data/", b'5', "", b"", SERVICE),
            raw_member_owned(b"var/data/conf", b'0', "", b"cfg", SERVICE),
            raw_member(b"node", b'0', "", b"#!/bin/sh"),
        ]
        .concat();
        let layer = [layer, vec![0u8; 1024]].concat();
        write_oci_layout(&layout, br#"{"config":{"Cmd":["/node"]}}"#, &[&layer]);

        let stage_dir = dir.path().join("stage");
        std::fs::create_dir_all(&stage_dir).unwrap();
        let staged = stage(layout.to_str().unwrap(), &stage_dir).unwrap();
        assert_eq!(staged.config.cmd, ["/node"]);
        assert_eq!(staged.owners.owner_of(Path::new("var/data/conf")), SERVICE);
        assert_eq!(staged.owners.owner_of(Path::new("var")), Owner::ROOT);
        use std::os::unix::fs::MetadataExt as _;
        let staging_user = std::fs::metadata(&stage_dir).unwrap().uid();
        for path in ["var", "var/data", "var/data/conf", "node"] {
            let on_disk = std::fs::metadata(staged.rootfs.join(path)).unwrap().uid();
            assert_eq!(on_disk, staging_user, "{path}");
        }

        let segment =
            super::super::bundle::build_rootfs_segment(&staged.rootfs, &staged.owners).unwrap();
        let inflated = Command::new("gzip")
            .arg("-dc")
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .spawn()
            .and_then(|mut child| {
                use std::io::Write as _;
                child.stdin.take().unwrap().write_all(&segment)?;
                child.wait_with_output()
            })
            .unwrap();
        assert!(inflated.status.success());
        let cpio = inflated.stdout;
        let mut at = 0;
        let mut owners = BTreeMap::new();
        loop {
            let (name, owner, next) = cpio_entry(&cpio, at);
            if name == "TRAILER!!!" {
                break;
            }
            owners.insert(name, owner);
            at = next;
        }
        assert_eq!(owners["harmony-oci/rootfs/var/data"], SERVICE);
        assert_eq!(owners["harmony-oci/rootfs/var/data/conf"], SERVICE);
        assert_eq!(owners["harmony-oci/rootfs/var"], Owner::ROOT);
        assert_eq!(owners["harmony-oci/rootfs/node"], Owner::ROOT);
        assert_eq!(owners["harmony-oci/rootfs"], Owner::ROOT);
    }

    #[test]
    fn preparation_preserves_special_modes_from_layer_headers() {
        let dir = tempfile::tempdir().unwrap();
        let layout = dir.path().join("layout");
        std::fs::create_dir_all(&layout).unwrap();
        std::fs::write(
            layout.join("manifest.json"),
            br#"[{"Config":"config.json","Layers":["layer.tar","upper.tar"]}]"#,
        )
        .unwrap();
        std::fs::write(layout.join("config.json"), br#"{"config":{}}"#).unwrap();
        let layer = [
            raw_member_with_mode(b"bin/", b'5', "", b"", Owner::ROOT, 0o755),
            raw_member_with_mode(b"bin/tool", b'0', "", b"exec", Owner::ROOT, 0o4755),
            raw_member_with_mode(b"bin/tool-link", b'1', "bin/tool", b"", SERVICE, 0),
            raw_member_with_mode(b"shared/", b'5', "", b"", Owner::ROOT, 0o2775),
            raw_member_with_mode(b"shared/implicit/data", b'0', "", b"x", Owner::ROOT, 0o644),
            raw_member_with_mode(b"overlaid/", b'5', "", b"", Owner::ROOT, 0o2775),
        ]
        .concat();
        write_archive(&layout, "layer.tar", &layer);
        write_archive(
            &layout,
            "upper.tar",
            &raw_member(b"overlaid/child", b'0', "", b"upper"),
        );

        let staged = stage(layout.to_str().unwrap(), &dir.path().join("staging")).unwrap();
        let prepared = super::super::bundle::prepare(
            &staged,
            &super::super::bundle::LaunchRequest::new(Vec::new()),
        )
        .unwrap();
        let inflated = Command::new("gzip")
            .arg("-dc")
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .spawn()
            .and_then(|mut child| {
                use std::io::Write as _;
                child
                    .stdin
                    .take()
                    .unwrap()
                    .write_all(prepared.rootfs_segment())?;
                child.wait_with_output()
            })
            .unwrap();
        assert!(inflated.status.success());
        let mut at = 0;
        let mut metadata = BTreeMap::new();
        loop {
            let mode = u32::from_str_radix(
                std::str::from_utf8(&inflated.stdout[at + 14..at + 22]).unwrap(),
                16,
            )
            .unwrap();
            let (name, owner, next) = cpio_entry(&inflated.stdout, at);
            if name == "TRAILER!!!" {
                break;
            }
            metadata.insert(name, (mode & 0o7777, owner));
            at = next;
        }
        assert_eq!(
            metadata["harmony-oci/rootfs/bin/tool"],
            (0o4755, Owner::ROOT)
        );
        assert_eq!(
            metadata["harmony-oci/rootfs/bin/tool-link"],
            (0o4755, Owner::ROOT)
        );
        assert_eq!(metadata["harmony-oci/rootfs/shared"].0, 0o2775);
        assert_eq!(metadata["harmony-oci/rootfs/shared/implicit"].0, 0o755);
        assert_eq!(metadata["harmony-oci/rootfs/overlaid"].0, 0o2775);
        assert_eq!(
            prepared.identity_hex(),
            "4e07829aa07be1adc04f14bd75da45714a0526350d1470f610398db6b99d614f"
        );
    }
}

#[cfg(test)]
mod acceptance_regressions {
    use super::*;

    #[test]
    fn block_reader_distinguishes_empty_complete_and_truncated_headers() {
        let mut block = [0; TAR_BLOCK];
        assert!(!read_block(&mut &b""[..], &mut block).unwrap());
        assert!(read_block(&mut &[3; TAR_BLOCK][..], &mut block).unwrap());
        assert_eq!(block, [3; TAR_BLOCK]);
        assert!(read_block(&mut &[3; TAR_BLOCK - 1][..], &mut block).is_err());
    }

    #[test]
    fn name_header_limit_accepts_exact_bound_and_rejects_one_more() {
        for size in [0, 1, MAX_HEADER_DATA - 1, MAX_HEADER_DATA] {
            let source = vec![7; (size + padding(size)) as usize];
            assert_eq!(
                header_data(&mut source.as_slice(), size).unwrap(),
                vec![7; size as usize]
            );
        }
        assert!(header_data(&mut &b""[..], MAX_HEADER_DATA + 1).is_err());
    }

    #[test]
    fn gnu_header_does_not_treat_timestamp_field_as_ustar_prefix() {
        let mut block = [0; TAR_BLOCK];
        block[..4].copy_from_slice(b"file");
        block[345..348].copy_from_slice(b"123");
        assert_eq!(ustar_name(&block), b"file");
        block[257..263].copy_from_slice(b"ustar\0");
        assert_eq!(ustar_name(&block), b"123/file");
    }

    #[test]
    fn pax_lengths_are_bounded_and_unrelated_metadata_is_allowed() {
        for record in [b"0 a=b\n".as_slice(), b"99 a=b\n"] {
            assert!(parse_pax(record, &mut Pax::default()).is_err());
        }
        parse_pax(b"11 uid=123\n", &mut Pax::default()).unwrap();
        parse_pax(b"10 uid=12\n", &mut Pax::default()).unwrap();
        assert!(parse_pax(b"22 GNU.sparse.size=1\n", &mut Pax::default()).is_err());
    }

    #[test]
    fn layers_replace_files_with_directories_and_directories_with_files() {
        let root = tempfile::tempdir().unwrap();
        let staged = tempfile::tempdir().unwrap();
        std::fs::write(root.path().join("entry"), b"old").unwrap();
        std::fs::create_dir(staged.path().join("entry")).unwrap();
        std::fs::write(staged.path().join("entry/child"), b"child").unwrap();
        merge_layer(
            staged.path(),
            root.path(),
            Path::new(""),
            &BTreeSet::new(),
            &BTreeMap::new(),
            &mut BTreeMap::new(),
        )
        .unwrap();
        assert_eq!(
            std::fs::read(root.path().join("entry/child")).unwrap(),
            b"child"
        );
        let staged = tempfile::tempdir().unwrap();
        std::fs::write(staged.path().join("entry"), b"replacement").unwrap();
        merge_layer(
            staged.path(),
            root.path(),
            Path::new(""),
            &BTreeSet::new(),
            &BTreeMap::new(),
            &mut BTreeMap::new(),
        )
        .unwrap();
        assert_eq!(
            std::fs::read(root.path().join("entry")).unwrap(),
            b"replacement"
        );
    }

    #[test]
    fn resolution_propagates_symlink_loop_instead_of_treating_it_as_missing() {
        let root = tempfile::tempdir().unwrap();
        let link = root.path().join("loop");
        std::os::unix::fs::symlink("loop", &link).unwrap();
        assert!(resolve_deepest(&link).is_err());
    }

    #[test]
    fn dropping_archive_reader_reaps_its_decompressor() {
        let mut child = Command::new("sh")
            .args(["-c", "exec cat"])
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .spawn()
            .unwrap();
        let input = child.stdin.take().unwrap();
        let reader = child.stdout.take().unwrap();
        let pid = child.id();
        drop(ArchiveReader {
            reader: Box::new(reader),
            child: Some(child),
            feeder: None,
        });
        let exists = Command::new("kill")
            .args(["-0", &pid.to_string()])
            .status()
            .unwrap();
        assert!(!exists.success(), "decompressor was not reaped");
        drop(input);
    }
}

#[cfg(test)]
mod reader_regressions {
    use super::*;
    #[test]
    fn archive_reader_forwards_bytes_count_and_eof() {
        let mut reader = ArchiveReader {
            reader: Box::new(std::io::Cursor::new(b"hello")),
            child: None,
            feeder: None,
        };
        let mut bytes = [0; 8];
        assert_eq!(reader.read(&mut bytes).unwrap(), 5);
        assert_eq!(&bytes[..5], b"hello");
        assert_eq!(reader.read(&mut bytes).unwrap(), 0);
    }
}

#[cfg(test)]
mod trailing_eof_regression {
    use super::*;
    #[test]
    fn trailing_padding_stops_at_first_eof() {
        struct Once(bool);
        impl Read for Once {
            fn read(&mut self, _: &mut [u8]) -> std::io::Result<usize> {
                assert!(!self.0, "reader was polled again after EOF");
                self.0 = true;
                Ok(0)
            }
        }
        require_trailing_zeros(&mut Once(false)).unwrap();
        require_trailing_zeros(&mut &b"\0\0"[..]).unwrap();
        assert!(require_trailing_zeros(&mut &b"\0x"[..]).is_err());
    }
}

#[cfg(test)]
mod layer_mode_tests {
    #[test]
    fn owner_access_is_added_without_removing_existing_permissions() {
        for (mode, expected) in [(0, 0o700), (0o700, 0o700), (0o2555, 0o2755), (0o077, 0o777)] {
            assert_eq!(super::writable_layer_mode(mode), expected);
        }
    }
}

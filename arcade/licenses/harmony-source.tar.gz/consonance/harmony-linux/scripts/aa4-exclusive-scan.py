#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# AA-4(c) level-2: scan every mapped executable user page for
# load/store-EXCLUSIVE instructions. The owned kernel uses a separate mode
# because its runtime page tables do not use the vmlinux PT_LOAD flags.
#
# The LL/SC exclusive family (monitor-based): LDXR/LDXRB/LDXRH/LDAXR.., STXR/STLXR..,
# LDXP/STXP/LDAXP/STLXP. These and LSE CASP share the broad encoding class
# `(insn & 0x3f800000) == 0x08000000`; o1/size distinguish monitor-based pairs from CASP:
# o1=0 is always LL/SC; o1=1 is LL/SC only for word/dword element sizes (size>=2). This deliberately
# EXCLUDES acquire/release non-exclusives LDAR/STLR and LSE CAS/CASP: they carry no reservation
# monitor and are deterministic, so an LSE-only build is clean by construction.
#
# The scan operates on raw ELF bytes and cross-checks objdump wherever it renders
# an instruction. User ELF section labels never remove bytes from the scan.
import bisect
import re
import struct
import subprocess
import sys
from pathlib import Path

EXCL_MASK = 0x3F800000
EXCL_MATCH = 0x08000000
GUEST_PAGE_BYTES = 4096


def is_llsc_exclusive(word: int) -> bool:
    if (word & EXCL_MASK) != EXCL_MATCH:
        return False
    o1 = (word >> 21) & 1
    size = (word >> 30) & 0b11
    return o1 == 0 or size >= 0b10


def self_test_mask() -> None:
    # Real words from the retained AA-4 payload/kernel investigations. CASP shares the broad
    # class prefix with LDXP/STXP, so pinning both sides prevents the exact false-positive that
    # would make an actually LSE-only kernel impossible to publish.
    cases = {
        0x885F7C20: True,   # ldxr w0, [x1]
        0x88027C20: True,   # stxr w2, w0, [x1]
        0x085F7C61: True,   # ldxrb w1, [x3]
        0xC87F7C20: True,   # ldxp x0, xzr, [x1]
        0x48207C82: False,  # casp x0, x1, x2, x3, [x4]
        0x4860FC82: False,  # caspal x0, x1, x2, x3, [x4]
        0xC8DFFC00: False,  # ldar x0, [x0]
    }
    wrong = [
        f"{word:#010x}"
        for word, expected in cases.items()
        if is_llsc_exclusive(word) != expected
    ]
    if wrong:
        raise SystemExit(f"SCANNER MASK SELF-TEST FAILED for words: {', '.join(wrong)}")


REVIEWED_DATA_SECTIONS = {
    ".altinstructions", ".data", ".data..percpu", ".dynamic", ".dynstr",
    ".dynsym", ".eh_frame", ".eh_frame_hdr", ".gnu.hash", ".gnu.version",
    ".gnu.version_d", ".gnu.version_r", ".got", ".got.plt", ".hash",
    ".gopclntab", ".init.data", ".interp", ".itablink",
    ".mmuoff.data.read", ".mmuoff.data.write",
    ".note", ".note.ABI-tag", ".note.gnu.build-id", ".note.gnu.property",
    ".notes", ".rela.dyn", ".rela.plt", ".rodata", ".stapsdt.base",
    ".typelink",
    "__ex_table", "__modver", "__param", "runtime_ptr_dentry_hashtable",
    "runtime_shift_d_hash_shift",
}


def reviewed_data_section(name: str) -> bool:
    return name in REVIEWED_DATA_SECTIONS


def kernel_runtime_exec_ranges(path: str, entry: int):
    names = (
        "_text", "_stext", "_etext", "__start_rodata",
        "__rodata_text_begin", "__rodata_text_end", "__inittext_begin",
        "__inittext_end", "__initdata_begin", "__initdata_end", "_data", "_end",
    )
    try:
        listing = subprocess.run(
            ["nm", "--defined-only", path], capture_output=True, text=True, check=True
        ).stdout
    except (OSError, subprocess.CalledProcessError) as error:
        raise SystemExit(f"SCANNER KERNEL ERROR for {path}: cannot read linker symbols: {error}")
    symbols = {}
    for line in listing.splitlines():
        parts = line.split()
        if len(parts) != 3 or parts[2] not in names:
            continue
        name = parts[2]
        if name in symbols:
            raise SystemExit(f"SCANNER KERNEL ERROR for {path}: duplicate {name}")
        try:
            symbols[name] = int(parts[0], 16)
        except ValueError:
            raise SystemExit(f"SCANNER KERNEL ERROR for {path}: invalid {name}")
    missing = [name for name in names if name not in symbols]
    if missing:
        raise SystemExit(f"SCANNER KERNEL ERROR for {path}: missing {', '.join(missing)}")
    if entry != symbols["_text"]:
        raise SystemExit(f"SCANNER KERNEL ERROR for {path}: unexpected entrypoint")
    ordered = [symbols[name] for name in names]
    if any(value % GUEST_PAGE_BYTES for value in ordered):
        raise SystemExit(f"SCANNER KERNEL ERROR for {path}: unaligned linker boundary")
    if not (
        ordered[0] < ordered[1] < ordered[2] == ordered[3]
        < ordered[4] < ordered[5] < ordered[6]
        < ordered[7] == ordered[8] < ordered[9] == ordered[10]
        < ordered[11]
    ):
        raise SystemExit(f"SCANNER KERNEL ERROR for {path}: unexpected linker layout")
    return ((symbols["_stext"], symbols["_etext"]),
            (symbols["__rodata_text_begin"], symbols["__rodata_text_end"]),
            (symbols["__inittext_begin"], symbols["__inittext_end"]))


def executable_words(path: str, kernel_image_path: str = None, embedded_vdso: bool = False):
    data = Path(path).read_bytes()
    elf_header = "<16sHHIQQQIHHHHHH"
    section_header = "<IIQQQQIIQQ"
    if len(data) < struct.calcsize(elf_header):
        raise SystemExit(f"SCANNER ELF ERROR for {path}: truncated ELF header")

    (
        ident,
        _elf_type,
        machine,
        version,
        _entry,
        program_offset,
        section_offset,
        _flags,
        elf_header_size,
        program_entry_size,
        program_count,
        section_entry_size,
        section_count,
        string_section_index,
    ) = struct.unpack_from(elf_header, data)
    if ident[:4] != b"\x7fELF" or ident[4] != 2 or ident[5] != 1 or ident[6] != 1:
        raise SystemExit(f"SCANNER ELF ERROR for {path}: require ELF64 little-endian")
    if machine != 183 or version != 1 or elf_header_size != struct.calcsize(elf_header):
        raise SystemExit(f"SCANNER ELF ERROR for {path}: require aarch64 ELF version 1")
    if section_count == 0 or string_section_index >= section_count:
        raise SystemExit(f"SCANNER ELF ERROR for {path}: unsupported extended/missing sections")
    if section_entry_size < struct.calcsize(section_header):
        raise SystemExit(f"SCANNER ELF ERROR for {path}: short section-header entries")
    section_table_size = section_count * section_entry_size
    if section_offset > len(data) or section_table_size > len(data) - section_offset:
        raise SystemExit(f"SCANNER ELF ERROR for {path}: section table outside file")

    def read_section(index: int):
        offset = section_offset + index * section_entry_size
        return struct.unpack_from(section_header, data, offset)

    string_section = read_section(string_section_index)
    string_type = string_section[1]
    string_offset = string_section[4]
    string_size = string_section[5]
    if string_type != 3 or string_offset > len(data) or string_size > len(data) - string_offset:
        raise SystemExit(f"SCANNER ELF ERROR for {path}: invalid section-name table")
    names = data[string_offset : string_offset + string_size]

    def section_name(name_offset: int, index: int) -> str:
        if name_offset >= len(names):
            raise SystemExit(f"SCANNER ELF ERROR for {path}: bad name for section {index}")
        end = names.find(b"\0", name_offset)
        if end < 0:
            raise SystemExit(f"SCANNER ELF ERROR for {path}: unterminated section name")
        return names[name_offset:end].decode("ascii", errors="replace")

    program_header = "<IIQQQQQQ"
    if program_count == 0 or program_entry_size < struct.calcsize(program_header):
        raise SystemExit(f"SCANNER ELF ERROR for {path}: missing load segments")
    program_table_size = program_count * program_entry_size
    if program_offset > len(data) or program_table_size > len(data) - program_offset:
        raise SystemExit(f"SCANNER ELF ERROR for {path}: program table outside file")
    load_segments = []
    executable_segments = []
    for index in range(program_count):
        off = program_offset + index * program_entry_size
        p_type, p_flags, p_offset, p_vaddr, _paddr, p_filesz, p_memsz, _align = struct.unpack_from(
            program_header, data, off
        )
        if p_type != 1:
            continue
        if p_offset > len(data) or p_filesz > len(data) - p_offset:
            raise SystemExit(f"SCANNER ELF ERROR for {path}: load segment {index} outside file")
        if p_filesz > p_memsz or p_memsz > (1 << 64) - p_vaddr:
            raise SystemExit(f"SCANNER ELF ERROR for {path}: load segment {index} wraps")
        if p_offset % GUEST_PAGE_BYTES != p_vaddr % GUEST_PAGE_BYTES:
            raise SystemExit(f"SCANNER ELF ERROR for {path}: load segment {index} page mapping disagrees")
        load_segments.append((index, p_flags, p_offset, p_vaddr, p_filesz, p_memsz))
        if p_flags & 0x1:
            if p_vaddr % 4 != 0 or p_filesz % 4 != 0:
                raise SystemExit(f"SCANNER ELF ERROR for {path}: unaligned executable segment {index}")
            executable_segments.append((index, p_flags, p_offset, p_vaddr, p_filesz))
    if not executable_segments:
        raise SystemExit(f"SCANNER ELF ERROR for {path}: no executable load segment")
    ordered_segments = sorted(executable_segments, key=lambda segment: segment[3])
    for previous, current in zip(ordered_segments, ordered_segments[1:]):
        if previous[3] + previous[4] > current[3]:
            raise SystemExit(f"SCANNER ELF ERROR for {path}: overlapping executable segments")

    def page_span(start, size):
        if not size:
            return None
        return (start // GUEST_PAGE_BYTES,
                (start + size + GUEST_PAGE_BYTES - 1) // GUEST_PAGE_BYTES)

    def overlaps(first, second):
        return first is not None and second is not None and first[0] < second[1] and second[0] < first[1]

    load_memsz = {segment[0]: segment[5] for segment in load_segments}
    for ex_index, _flags, ex_offset, ex_vaddr, ex_filesz in executable_segments:
        ex_memsz = load_memsz[ex_index]
        ex_file_pages = page_span(ex_offset, ex_filesz)
        ex_virtual_pages = page_span(ex_vaddr, ex_memsz)
        for other_index, _other_flags, other_offset, other_vaddr, other_filesz, other_memsz in load_segments:
            if other_index == ex_index:
                continue
            if (overlaps(ex_file_pages, page_span(other_offset, other_filesz))
                    or overlaps(ex_virtual_pages, page_span(other_vaddr, other_memsz))):
                raise SystemExit(
                    f"SCANNER ELF ERROR for {path}: executable page alias between loads {ex_index} and {other_index}"
                )

    words = []
    addresses = set()
    data_ranges = []
    allocated_ranges = []
    loaded_names = set()
    text_count = 0
    entry_in_code = _entry == 0
    for index in range(section_count):
        name_offset, section_type, flags, address, offset, size, *_rest = read_section(index)
        if size == 0:
            continue
        name = section_name(name_offset, index)
        if name == ".text":
            text_count += 1
            if flags & 0x6 != 0x6 or section_type == 8:
                raise SystemExit(f"SCANNER ELF ERROR for {path}: non-executable .text section")
        if flags & 0x6 == 0 and section_type != 8:
            continue
        if flags & 0x4 and section_type == 8:
            raise SystemExit(f"SCANNER ELF ERROR for {path}: executable NOBITS section {name}")
        if size > (1 << 64) - address:
            raise SystemExit(f"SCANNER ELF ERROR for {path}: section {name} wraps")
        if section_type == 8:
            continue
        if offset > len(data) or size > len(data) - offset:
            raise SystemExit(f"SCANNER ELF ERROR for {path}: section {name} outside file")
        covering = [
            segment for segment in executable_segments
            if address < segment[3] + segment[4] and segment[3] < address + size
        ]
        if flags & 0x4 and not covering:
            raise SystemExit(f"SCANNER ELF ERROR for {path}: executable section {name} outside executable load segment")
        if not covering:
            continue
        if len(covering) != 1:
            raise SystemExit(f"SCANNER ELF ERROR for {path}: section {name} overlaps load segments")
        _seg_index, _seg_flags, p_offset, p_vaddr, p_filesz = covering[0]
        if (address < p_vaddr or address + size > p_vaddr + p_filesz
                or offset != p_offset + address - p_vaddr):
            raise SystemExit(f"SCANNER ELF ERROR for {path}: section {name} disagrees with segment mapping")
        if name in loaded_names:
            raise SystemExit(f"SCANNER ELF ERROR for {path}: duplicate loaded section {name}")
        loaded_names.add(name)
        allocated_ranges.append((address, address + size, name))
        if flags & 0x4 == 0:
            if not reviewed_data_section(name):
                raise SystemExit(f"SCANNER ELF ERROR for {path}: unreviewed loaded data section {name}")
            if address <= _entry < address + size:
                raise SystemExit(f"SCANNER ELF ERROR for {path}: entrypoint in data section {name}")
            data_ranges.append((address, address + size))
            continue
        if address % 4 != 0 or size % 4 != 0:
            raise SystemExit(f"SCANNER ELF ERROR for {path}: unaligned executable section {name}")
        if address <= _entry < address + size:
            entry_in_code = True
        section = data[offset : offset + size]
        for word_offset in range(0, size, 4):
            word_address = address + word_offset
            if word_address in addresses:
                raise SystemExit(f"SCANNER ELF ERROR for {path}: overlapping executable sections")
            addresses.add(word_address)
            word = int.from_bytes(section[word_offset : word_offset + 4], "little")
            words.append((word_address, word, name))

    if text_count != 1:
        raise SystemExit(f"SCANNER ELF ERROR for {path}: require one executable .text section")
    if not entry_in_code:
        raise SystemExit(f"SCANNER ELF ERROR for {path}: entrypoint outside executable sections")
    allocated_ranges.sort()
    for previous, current in zip(allocated_ranges, allocated_ranges[1:]):
        if previous[1] > current[0]:
            raise SystemExit(f"SCANNER ELF ERROR for {path}: overlapping loaded sections {previous[2]} and {current[2]}")

    # The segment walk covers every byte on a user executable page, including
    # reviewed data sections. Only the owned kernel may exclude data in ranges
    # that its linker-bound page tables actually map non-executable.
    data_ranges.sort()
    _data_starts = [lo for lo, _ in data_ranges]
    kernel_exec_ranges = kernel_runtime_exec_ranges(path, _entry) if kernel_image_path else ()
    for lo, hi in kernel_exec_ranges:
        covering = [
            segment for segment in executable_segments
            if segment[3] <= lo < segment[3] + segment[4]
        ]
        if len(covering) != 1:
            raise SystemExit(
                f"SCANNER KERNEL ERROR for {path}: executable linker range starts outside PF_X load"
            )

    def _in_data_section(addr):
        i = bisect.bisect_right(_data_starts, addr) - 1
        return i >= 0 and data_ranges[i][0] <= addr < data_ranges[i][1]

    for index, _p_flags, p_offset, p_vaddr, p_filesz in executable_segments:
        if not p_filesz:
            continue
        page_offset = p_offset - p_offset % GUEST_PAGE_BYTES
        page_end = ((p_offset + p_filesz + GUEST_PAGE_BYTES - 1)
                    // GUEST_PAGE_BYTES * GUEST_PAGE_BYTES)
        mapped_address = p_vaddr - p_offset % GUEST_PAGE_BYTES
        label = f"<exec-segment {index}>"
        for file_offset in range(page_offset, page_end, 4):
            word_address = mapped_address + file_offset - page_offset
            if word_address in addresses:
                continue
            if (kernel_image_path and _in_data_section(word_address)
                    and not any(lo <= word_address < hi for lo, hi in kernel_exec_ranges)):
                continue
            addresses.add(word_address)
            word = int.from_bytes(data[file_offset : file_offset + 4].ljust(4, b"\0"), "little")
            words.append((word_address, word, label))

    if not words:
        raise SystemExit(f"SCANNER ELF ERROR for {path}: no executable words")
    if kernel_image_path:
        image = Path(kernel_image_path).read_bytes()
        known = {address: word for address, word, _section in words}
        for lo, hi in kernel_exec_ranges:
            if lo < _entry or hi - _entry > len(image):
                raise SystemExit(f"SCANNER KERNEL ERROR for {path}: linker range outside boot Image")
            for address in range(lo, hi, 4):
                word = int.from_bytes(image[address - _entry : address - _entry + 4], "little")
                if address in known:
                    if known[address] != word:
                        raise SystemExit(f"SCANNER KERNEL ERROR for {path}: boot Image differs from vmlinux")
                else:
                    words.append((address, word, "<kernel-image>"))
                    known[address] = word
    if embedded_vdso:
        if kernel_image_path or len(executable_segments) != 1 or executable_segments[0][2:4] != (0, 0):
            raise SystemExit(f"SCANNER ELF ERROR for {path}: unexpected embedded vDSO load layout")
        return [
            (offset, int.from_bytes(data[offset : offset + 4].ljust(4, b"\0"), "little"),
             "<embedded-vdso>")
            for offset in range(0, len(data), 4)
        ]
    words.sort(key=lambda w: w[0])
    return words


def disassembly_cross_check(path: str):
    # Mapping-symbol data in an executable section is intentionally absent from this parse. The
    # independent ELF-byte walk above is authoritative; objdump checks the decoder wherever it
    # actually renders an instruction mnemonic.
    dz = subprocess.run(
        ["objdump", "-d", path], capture_output=True, text=True, check=True
    ).stdout

    decoded = {}
    disagreements = []
    line_re = re.compile(r"^\s*([0-9a-fA-F]+):\s+([0-9a-fA-F]{8})\s+(.*)$")
    for line in dz.splitlines():
        m = line_re.match(line)
        if not m:
            continue
        addr, raw, asm = m.group(1), m.group(2), m.group(3).strip()
        # objdump prints the raw word in target-endian text (already big-endian display of the
        # 32-bit value), so int(raw,16) is the instruction word directly.
        word = int(raw, 16)
        mnem = asm.split()[0].lower() if asm else ""
        if mnem in (".word", ".inst"):
            # Mapping-symbol data that this objdump renders word-wise (binutils 2.42) rather
            # than byte-wise. No mnemonic exists to check; the ELF-byte walk stays the
            # authority that rejects an exclusive hidden as data.
            decoded[int(addr, 16)] = (word, asm)
            continue
        # An exclusive-monitor mnemonic per objdump: starts with ldxr/stxr/ldaxr/stlxr/ldxp/stxp..
        mnem_is_excl = bool(re.match(r"(ld(a)?xr[bh]?|st(l)?xr[bh]?|ld(a)?xp|st(l)?xp)$", mnem))
        if is_llsc_exclusive(word) != mnem_is_excl:
            disagreements.append(addr)
        decoded[int(addr, 16)] = (word, asm)
    if not decoded:
        raise SystemExit(f"SCANNER SELF-CHECK FAILED for {path}: objdump parsed zero instructions")
    if disagreements:
        raise SystemExit(
            f"SCANNER SELF-CHECK FAILED for {path}: decoder disagrees at {disagreements}"
        )
    return decoded


def scan(path: str, kernel_image_path: str = None, embedded_vdso: bool = False):
    words = executable_words(path, kernel_image_path=kernel_image_path,
                             embedded_vdso=embedded_vdso)
    decoded = disassembly_cross_check(path)
    raw_by_address = {address: word for address, word, _section in words}
    raw_mismatches = [
        f"{address:x}"
        for address, (word, _asm) in decoded.items()
        if raw_by_address.get(address) != word
    ]
    if raw_mismatches:
        raise SystemExit(
            f"SCANNER SELF-CHECK FAILED for {path}: ELF/objdump mismatch at {raw_mismatches}"
        )
    hits = []
    for address, word, section in words:
        if is_llsc_exclusive(word):
            decoded_word = decoded.get(address)
            asm = decoded_word[1] if decoded_word else f"<raw executable word in {section}>"
            hits.append((f"{address:x}", f"{word:08x}", asm))
    return hits


def main():
    self_test_mask()
    if len(sys.argv) < 2:
        raise SystemExit("usage: aa4-exclusive-scan.py [--kernel-vmlinux <vmlinux> <Image>|--embedded-vdso <vdso.so>] <aarch64-elf> [<elf> ...]")
    kernel_image = sys.argv[1] == "--kernel-vmlinux"
    embedded_vdso = sys.argv[1] == "--embedded-vdso"
    paths = sys.argv[2:] if kernel_image or embedded_vdso else sys.argv[1:]
    if kernel_image and len(paths) != 2:
        raise SystemExit("usage: aa4-exclusive-scan.py --kernel-vmlinux <vmlinux> <Image>")
    if embedded_vdso and len(paths) != 1:
        raise SystemExit("usage: aa4-exclusive-scan.py --embedded-vdso <vdso.so>")
    kernel_image_path = paths.pop() if kernel_image else None
    any_hits = False
    for path in paths:
        hits = scan(path, kernel_image_path=kernel_image_path, embedded_vdso=embedded_vdso)
        name = path.split("/")[-1]
        if hits:
            any_hits = True
            print(f"[BANNED] {name}: {len(hits)} LL/SC exclusive instruction(s)")
            for addr, raw, asm in hits:
                print(f"    {addr}: {raw}  {asm}")
        else:
            print(f"[CLEAN]  {name}: no LL/SC exclusive instructions (mask self-check passed)")
    # Exit 1 if any scanned image carries an exclusive.
    sys.exit(1 if any_hits else 0)


if __name__ == "__main__":
    main()


#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# AA-5(b) closure scan: the counter-read opcode scan. FEAT_ECV is ABSENT on N1 (AA-0:
# ID_AA64MMFR0_EL1.ECV = 0x0), so the guest's CNTVCT_EL0 cannot be trapped in hardware — raw
# counter access must be closed at the CONTRACT level. One layer of that closure is a build-time
# scan that rejects any image emitting an MRS of a generic-timer counter, so the
# guest reads time ONLY via the exit-count-derived clock page.
#
#   aa5-counter-scan.py <aarch64-elf> [<elf> ...]
#
# MRS Xt, <sysreg> is 0xD53_xxxxx, the counter registers live at op0=3,op1=3,CRn=14,
# CRm=0, distinguished by op2 (0=CNTFRQ 1=CNTPCT 2=CNTVCT 5=CNTPCTSS 6=CNTVCTSS). The raw-opcode
# decode SELF-VALIDATES against objdump's mnemonic on every instruction, so it can neither miss a
# counter read nor invent one. CNTFRQ_EL0 is rejected too: it is constant on one
# machine, but its value differs across the supported HVF and KVM substrates and
# therefore leaks host identity into guest RAM. The owned kernel must obtain the
# fixed guest frequency through its compiled Harmony accessor instead. The
# implementation-defined REVIDR_EL1 and AIDR_EL1 values are rejected for the
# same reason; the owned kernel records neutral values instead. CNTP_TVAL_EL0
# and CNTV_TVAL_EL0 reads expose the live counter through the remaining timer
# interval, even when the guest never programs a timer. Architected timer
# control reads and writes are excluded because an enabled timer follows host
# time and the physical timer control is absent from the snapshot state.
import importlib.util
import re
import subprocess
import sys
from pathlib import Path

OP2 = {0: "CNTFRQ_EL0", 1: "CNTPCT_EL0", 2: "CNTVCT_EL0", 5: "CNTPCTSS_EL0", 6: "CNTVCTSS_EL0"}
HOST_ID_READS = {
    0xD53800C0: "REVIDR_EL1",
    0xD53900E0: "AIDR_EL1",
}
TIMER_PROGRAMS = {
    (2, 0): "CNTP_TVAL_EL0",
    (2, 1): "CNTP_CTL_EL0",
    (2, 2): "CNTP_CVAL_EL0",
    (3, 0): "CNTV_TVAL_EL0",
    (3, 1): "CNTV_CTL_EL0",
    (3, 2): "CNTV_CVAL_EL0",
}


def decode_counter_read(word: int):
    """Return the register name for an MRS that exposes host time or frequency."""
    if word & 0xFFF00000 != 0xD5300000:
        return None
    o0 = (word >> 19) & 0x1  # op0 - 2
    op1 = (word >> 16) & 0x7
    crn = (word >> 12) & 0xF
    crm = (word >> 8) & 0xF
    op2 = (word >> 5) & 0x7
    if o0 != 1 or op1 != 3 or crn != 14:
        return None
    if crm == 0:
        return OP2.get(op2)
    if op2 == 0:
        return {2: "CNTP_TVAL_EL0", 3: "CNTV_TVAL_EL0"}.get(crm)
    if op2 == 1:
        return {2: "CNTP_CTL_EL0", 3: "CNTV_CTL_EL0"}.get(crm)
    return None


def decode_host_identity_read(word: int):
    """Return a non-portable implementation ID read, ignoring the Rt field."""
    return HOST_ID_READS.get(word & ~0x1F)


def decode_timer_program(word: int):
    """Return a live-domain timer target for an MSR, else None."""
    if word & 0xFFF00000 != 0xD5100000:
        return None
    o0 = (word >> 19) & 0x1
    op1 = (word >> 16) & 0x7
    crn = (word >> 12) & 0xF
    crm = (word >> 8) & 0xF
    op2 = (word >> 5) & 0x7
    if o0 != 1 or op1 != 3 or crn != 14:
        return None
    return TIMER_PROGRAMS.get((crm, op2))


def executable_words(path: str, kernel_image_path: str = None, embedded_vdso: bool = False):
    """Use the AA-4 scanner's hardened ELF64 executable-section byte walk."""
    parser_path = Path(__file__).with_name("aa4-exclusive-scan.py")
    spec = importlib.util.spec_from_file_location("harmony_aa4_exec_parser", parser_path)
    if spec is None or spec.loader is None:
        raise SystemExit(f"SCANNER ELF ERROR: cannot load {parser_path}")
    parser = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(parser)
    return parser.executable_words(path, kernel_image_path=kernel_image_path,
                                   embedded_vdso=embedded_vdso)


def scan(path: str, kernel_image_path: str = None, embedded_vdso: bool = False):
    words = executable_words(path, kernel_image_path=kernel_image_path,
                             embedded_vdso=embedded_vdso)
    dz = subprocess.run(["objdump", "-d", path], capture_output=True, text=True, check=True).stdout
    line_re = re.compile(r"^\s*([0-9a-f]+):\s+([0-9a-f]{8})\s+(.*)$")
    decoded = {}
    disagreements = []
    for line in dz.splitlines():
        m = line_re.match(line)
        if not m:
            continue
        addr, raw, asm = m.group(1), m.group(2), m.group(3).strip()
        word = int(raw, 16)
        low = asm.lower()
        if low.startswith((".word", ".inst")):
            # Mapping-symbol data that this objdump renders word-wise (binutils 2.42 prints
            # one 8-hex-digit token; older versions print bytes and never reach here). There
            # is no mnemonic to cross-check; the raw executable-word walk below remains the
            # authority that rejects a counter/timer opcode hidden as data.
            decoded[int(addr, 16)] = (word, asm)
            continue
        counter = decode_counter_read(word)
        identity = decode_host_identity_read(word)
        timer = decode_timer_program(word)
        mnem_counter = low.startswith("mrs") and bool(
            re.search(r"\b(cnt(frq|pct|vct)(ss)?|cnt[vp]_(tval|ctl))_el0\b", low)
        )
        mnem_timer = low.startswith("msr") and bool(
            re.search(r"cnt[vp]_(tval|ctl|cval)_el0", low)
        )
        mnem_identity = low.startswith("mrs") and bool(
            re.search(r"(revidr|aidr)_el1", low)
        )
        if (
            (counter is not None) != mnem_counter
            or (identity is not None) != mnem_identity
            or (timer is not None) != mnem_timer
        ):
            disagreements.append(addr)
        decoded[int(addr, 16)] = (word, asm)

    if not decoded:
        raise SystemExit(f"SCANNER SELF-CHECK FAILED for {path}: objdump parsed zero instructions")
    if disagreements:
        raise SystemExit(
            f"SCANNER SELF-CHECK FAILED for {path}: decoder disagrees at {disagreements}"
        )
    raw_by_address = {address: word for address, word, _section in words}
    mismatches = [
        f"{address:x}"
        for address, (word, _asm) in decoded.items()
        if raw_by_address.get(address) != word
    ]
    if mismatches:
        raise SystemExit(
            f"SCANNER SELF-CHECK FAILED for {path}: ELF/objdump mismatch at {mismatches}"
        )

    reads = []
    timer_programs = []
    for address, word, section in words:
        asm = decoded.get(address, (word, f"<raw executable word in {section}>"))[1]
        host_read = decode_counter_read(word) or decode_host_identity_read(word)
        if host_read:
            reads.append((f"{address:x}", f"{word:08x}", asm, host_read))
        timer = decode_timer_program(word)
        if timer:
            timer_programs.append((f"{address:x}", f"{word:08x}", asm, timer))
    return reads, timer_programs


def main():
    if len(sys.argv) < 2:
        raise SystemExit("usage: aa5-counter-scan.py [--kernel-vmlinux <vmlinux> <Image>|--embedded-vdso <vdso.so>] <aarch64-elf> [<elf> ...]")
    kernel_image = sys.argv[1] == "--kernel-vmlinux"
    embedded_vdso = sys.argv[1] == "--embedded-vdso"
    paths = sys.argv[2:] if kernel_image or embedded_vdso else sys.argv[1:]
    if kernel_image and len(paths) != 2:
        raise SystemExit("usage: aa5-counter-scan.py --kernel-vmlinux <vmlinux> <Image>")
    if embedded_vdso and len(paths) != 1:
        raise SystemExit("usage: aa5-counter-scan.py --embedded-vdso <vdso.so>")
    kernel_image_path = paths.pop() if kernel_image else None
    any_live = False
    for path in paths:
        reads, timer_programs = scan(path, kernel_image_path=kernel_image_path,
                                     embedded_vdso=embedded_vdso)
        name = path.split("/")[-1]
        if reads:
            any_live = True
            print(f"[REJECT] {name}: {len(reads)} host-dependent register read(s) — closure requires the fixed guest contract, not a host register")
            for addr, raw, asm, reg in reads:
                print(f"    {addr}: {raw}  {asm}   [{reg}]")
        else:
            print(f"[CLEAN]  {name}: no raw host-dependent register reads (raw ELF/mask self-check passed)")
        if timer_programs:
            any_live = True
            print(f"[REJECT] {name}: {len(timer_programs)} live-domain timer program(s)")
            for addr, raw, asm, reg in timer_programs:
                print(f"    {addr}: {raw}  {asm}   [{reg}]")
        else:
            print(f"[CLEAN]  {name}: no CNTV/CNTP CTL/CVAL/TVAL programs (raw ELF/mask self-check passed)")
    sys.exit(1 if any_live else 0)


if __name__ == "__main__":
    main()

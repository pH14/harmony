#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
import gzip
import stat
import importlib.util
import os
from pathlib import Path
import struct
import tempfile
import unittest
from unittest.mock import patch

SPEC = importlib.util.spec_from_file_location("admission", Path(__file__).with_name("x86-xstate-admission.py"))
a = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(a)


def fixture(code=b"\xc3", flags=5, needed=None, soname=None):
    payload = bytearray(code)
    count = 1
    if needed or soname:
        count = 2
        payload.extend(bytes(0x100 - len(payload)))
        strings = b"\0" + (needed or soname).encode() + b"\0"
        payload.extend(strings)
        payload.extend(bytes(0x200 - len(payload)))
        payload.extend(b"".join(struct.pack("<qQ", *v) for v in [(1 if needed else 14, 1), (5, 0x400100), (10, len(strings)), (0, 0)]))
    header = struct.pack("<16sHHIQQQIHHHHHH", b"\x7fELF\x02\x01\x01" + bytes(9), 2, 62, 1, 0x400000, 64, 0, 0, 64, 56, count, 0, 0, 0)
    header += struct.pack("<IIQQQQQQ", 1, flags, 0x1000, 0x400000, 0, len(payload), len(payload), 0x1000)
    if needed or soname:
        header += struct.pack("<IIQQQQQQ", 2, 4, 0x1200, 0x400200, 0, 64, 64, 8)
    return header + bytes(0x1000 - len(header)) + payload


def many_symbol_fixture(count):
    code = bytes.fromhex("0f1f4000c3909090") * count
    data = bytearray(fixture(code))
    data.extend(bytes((-len(data)) % 4096))
    shoff = len(data)
    symbol_offset = shoff + 4 * 64
    symbols = b"".join(struct.pack("<IBBHQQ", 0, 2, 0, 1, 0x400000 + 8 * i, 8) for i in range(count))
    sections = [bytes(64),
                struct.pack("<IIQQQQIIQQ", 0, 1, 6, 0x400000, 0x1000, len(code), 0, 0, 1, 0),
                struct.pack("<IIQQQQIIQQ", 0, 2, 0, 0, symbol_offset, len(symbols), 3, 0, 8, 24),
                struct.pack("<IIQQQQIIQQ", 0, 3, 0, 0, symbol_offset + len(symbols), 1, 0, 0, 1, 0)]
    data.extend(b"".join(sections) + symbols + b"\0")
    struct.pack_into("<Q", data, 40, shoff)
    struct.pack_into("<HHH", data, 58, 64, 4, 0)
    return bytes(data)


def resolver_trampoline(save=b"\x0f\xae\x64\x24\x40", entry_jump=b""):
    spills = "48890424 48894c2408 4889542410 4889742418 48897c2420 4c89442428 4c894c2430"
    reloads = "4c8b4c2430 4c8b442428 488b7c2420 488b742418 488b542410 488b4c2408 488b0424"
    head = bytes.fromhex("f30f1efa 53 4889e3 4883e4c0 482b2500000000 " + spills + " b8ee000800 31d2")
    head += b"".join(b"\x48\x89\x94\x24" + struct.pack("<I", 0x240 + 8 * i) for i in range(8))
    head += save + bytes.fromhex("488b7310 488b7b08")
    tail = bytes.fromhex("4989c3 b8ee000800 31d2 0fae6c2440 " + reloads + " 4889dc 488b1c24 4883c418 41ffe3")
    call = b"\xe8" + struct.pack("<i", len(tail))
    code = head + call + tail + b"\xc3"
    if entry_jump:
        jump = entry_jump + b"\xe9"
        code = jump + struct.pack("<i", len(head) - len(save) - 8) + code
    return code


def newc(entries):
    output = bytearray()
    for index, (name, mode, content, rdev) in enumerate(entries + [("TRAILER!!!", 0, b"", (0, 0))]):
        name = name.encode() + b"\0"
        fields = [index + 1, mode, 0, 0, 1, 0, len(content), 0, 0, *rdev, len(name), 0]
        output.extend(b"070701" + b"".join(f"{v:08x}".encode() for v in fields))
        output.extend(name)
        output.extend(bytes((-len(output)) % 4))
        output.extend(content)
        output.extend(bytes((-len(output)) % 4))
    return bytes(output)


class ExecutableCoverageTests(unittest.TestCase):
    def inspect(self, data):
        record = a.elf(bytes(data))
        record.update(sites=a.disassemble(bytes(data), record["segments"], os.environ.get("OBJDUMP", "objdump")),
                      writable_executable_segments=[])
        report = {"artifacts": {"/fixture": record}}
        return report, a.verify(report)

    def assert_rejected(self, data, mnemonic):
        report, accepted = self.inspect(data)
        self.assertFalse(accepted, report)
        self.assertIn(mnemonic, [site["mnemonic"] for site in report["artifacts"]["/fixture"]["sites"]])

    def test_direct_transfer_into_an_immediate_restarts_decoding(self):
        self.assert_rejected(fixture(bytes.fromhex("eb01 b8 0fae27 c3 c3")), "xsave")

    def test_elf_entry_into_an_immediate_restarts_decoding(self):
        data = bytearray(fixture(bytes.fromhex("b8 0fae27 c3 c3")))
        struct.pack_into("<Q", data, 24, 0x400001)
        self.assert_rejected(data, "xsave")

    def test_executable_page_tail_and_head_are_scanned(self):
        self.assert_rejected(fixture() + bytes.fromhex("0fae27 c3"), "xsave")
        data = bytearray(fixture(bytes.fromhex("0fae27 c3")))
        struct.pack_into("<QQ", data, 72, 0x1003, 0x400003)
        struct.pack_into("<QQ", data, 96, 1, 1)
        self.assert_rejected(data, "xsave")

    def test_instruction_split_across_adjacent_executable_mappings(self):
        data = bytearray(fixture(bytes(4095) + b"\x0f"))
        data.extend(bytes.fromhex("ae27 c3"))
        struct.pack_into("<H", data, 56, 2)
        struct.pack_into("<IIQQQQQQ", data, 120, 1, 5, 0x2000, 0x401000, 0, 3, 3, 0x1000)
        self.assert_rejected(data, "xsave")

    def test_legacy_save_is_not_a_restore_or_loader_exemption(self):
        for opcode in (bytes.fromhex("0fae07"), bytes.fromhex("480fae07")):
            report, accepted = self.inspect(fixture(opcode + b"\xc3"))
            self.assertFalse(accepted, report)
            self.assertTrue(report["artifacts"]["/fixture"]["sites"][0]["mnemonic"] in a.SAVE)
        self.assert_rejected(fixture(resolver_trampoline(bytes.fromhex("0fae442440"))), "fxsave")

    def test_native_math_is_admitted_and_inventoried_with_exact_arithmetic_control(self):
        for raw, name in [("0f53c0", "rcpps"), ("0f52c0", "rsqrtps"),
                          ("f30f53c0", "rcpss"), ("f30f52c0", "rsqrtss"),
                          ("d9fe", "fsin"), ("d9ff", "fcos"), ("d9f9", "fyl2xp1"), ("c5f853c0", "vrcpps"),
                          ("62f27d484cc0", "vrcp14ps"),
                          ("62f67d484cc0", "vrcpph"), ("62f67d084dc0", "vrcpsh"),
                          ("62f67d484ec0", "vrsqrtph"), ("62f67d084fc0", "vrsqrtsh"),
                          ("c7f800000000", "xbegin"), ("66c7f80000", "xbegin"),
                          ("f28700", "xacquire"), ("f2f0830001", "xacquire"),
                          ("f2f00fb108", "xacquire"), ("c6f801", "xabort")]:
            report, accepted = self.inspect(fixture(bytes.fromhex(raw) + b"\xc3"))
            self.assertTrue(accepted, report)
            self.assertIn(name, [site["mnemonic"] for site in report["artifacts"]["/fixture"]["sites"]])
            if name in {"vrcpph", "vrcpsh", "vrsqrtph", "vrsqrtsh"}:
                report, accepted = self.inspect(fixture(bytes.fromhex("eb01b8" + raw) + b"\xc3"))
                self.assertTrue(accepted, report)
        report, accepted = self.inspect(fixture(bytes.fromhex("eb01 b8 0f53c0 c3 c3")))
        self.assertTrue(accepted, report)
        report, accepted = self.inspect(fixture(bytes.fromhex("0f51c0 c3")))
        self.assertTrue(accepted, report)

    def test_native_math_does_not_exempt_state_save_or_selector_checks(self):
        self.assert_rejected(fixture(bytes.fromhex("d9f9 0f52c0 0fae27 c3")), "xsave")
        self.assert_rejected(fixture(bytes.fromhex("d9f9 0f52c0 0f01d0 c3")), "xgetbv")

    def test_uml_rejects_transaction_entry_but_vm_disposition_is_unchanged(self):
        for raw, name in [("c7f800000000", "xbegin"), ("66c7f80000", "xbegin"),
                          ("f2f0830001", "xacquire"), ("f28700", "xacquire"),
                          ("f2f00fc708", "xacquire"), ("f3f2f0830001", "xacquire"),
                          ("f22e3ef0830001", "xacquire"), ("f26465f0830001", "xacquire")]:
            with self.subTest(raw=raw):
                report, accepted = self.inspect(fixture(bytes.fromhex(raw) + b"\xc3"))
                self.assertTrue(accepted, report)
                self.assertIn(name, [site["mnemonic"] for site in report["artifacts"]["/fixture"]["sites"]])
                self.assertFalse(a.verify(report, "uml"), report)
                self.assertIn("native transaction entry", report["errors"][0])
                self.assertEqual(report["execution_mode"], "uml")

    def test_uml_allows_standalone_controls_and_nontransactional_repeat_prefixes(self):
        for raw in ("0f01d5", "c6f801", "0f01d6", "f20f01e8", "f20f01e9",
                    "f3f0830001", "f3c70000000000", "f2f3f0830001",
                    "f3a4", "f2a6", "f390", "f30f10c0", "f20f10c0", "f3c3",
                    "f287c0", "f2f0480fc708"):
            with self.subTest(raw=raw):
                report, accepted = self.inspect(fixture(bytes.fromhex(raw) + b"\xc3"))
                self.assertTrue(accepted, report)
                self.assertTrue(a.verify(report, "uml"), report)
                self.assertFalse(any(site["mnemonic"] in a.TRANSACTION_ENTRY
                                     for site in report["artifacts"]["/fixture"]["sites"]))

    def test_direct_transfer_cannot_hide_transaction_entry_in_an_operand(self):
        for raw in ("c7f800000000", "f28700"):
            report, _ = self.inspect(fixture(bytes.fromhex("eb01b8" + raw) + b"\xc3"))
            self.assertFalse(a.verify(report, "uml"), report)

    def test_unknown_execution_mode_does_not_return_admitted(self):
        report, _ = self.inspect(fixture())
        self.assertFalse(a.verify(report, "unknown"))

    def test_overlapping_predecessors_cannot_fake_selector_dominance(self):
        code = bytes.fromhex("7401 8031c9 0f01d0 c3")
        report, accepted = self.inspect(fixture(code))
        sites = report["artifacts"]["/fixture"]["sites"]
        self.assertFalse(accepted, report)
        selector = next(site for site in sites if site["mnemonic"] == "xgetbv")
        self.assertFalse(selector["straightline_ecx_zero"])
        self.assertEqual(selector["selector_proof_instructions"], [])
        control, accepted = self.inspect(fixture(bytes.fromhex("31c9 0f01d0 c3")))
        self.assertTrue(accepted, control)

    def test_elf_entry_cannot_bypass_selector_initialization(self):
        data = bytearray(fixture(bytes.fromhex("31c9 0f01d0 c3")))
        struct.pack_into("<Q", data, 24, 0x400002)
        self.assert_rejected(data, "xgetbv")

    def test_overlapping_entry_cannot_receive_a_loader_trampoline_exemption(self):
        code = bytes.fromhex("7401 b8") + resolver_trampoline()
        self.assert_rejected(fixture(code), "xsave")

    def test_unambiguous_loader_trampoline_keeps_its_exemption(self):
        report, accepted = self.inspect(fixture(resolver_trampoline()))
        self.assertTrue(accepted, report)
        save = next(site for site in report["artifacts"]["/fixture"]["sites"] if site["mnemonic"] == "xsave")
        self.assertEqual(save["loader_trampoline"], "eager-resolver")

    def test_boundary_filter_preserves_special_instructions_hidden_inside_an_immediate(self):
        for raw, name in [("0fae27", "xsave"), ("0fc727", "xsavec"),
                          ("480fae07", "fxsave64"), ("0fae2f", "xrstor"),
                          ("0f01d0", "xgetbv"), ("d9fe", "fsin"),
                          ("0f53c0", "rcpps"), ("c5f853c0", "vrcpps"),
                          ("62f67d484cc0", "vrcpph"), ("62f67d084dc0", "vrcpsh"),
                          ("62f67d484ec0", "vrsqrtph"), ("62f67d084fc0", "vrsqrtsh"),
                          ("c7f800000000", "xbegin"), ("66c7f80000", "xbegin"),
                          ("f28700", "xacquire"), ("f2f0830001", "xacquire"),
                          ("f2f00fb108", "xacquire"), ("c6f801", "xabort")]:
            with self.subTest(mnemonic=name):
                data = bytearray(many_symbol_fixture(1))
                code = b"\xb8" + bytes.fromhex(raw) + b"\xc3"
                data[0x1000:0x1008] = code.ljust(8, b"\x90")
                symbol = struct.unpack_from("<Q", data, 40)[0] + 4 * 64
                struct.pack_into("<Q", data, symbol + 8, 0x400002)
                record = a.elf(data)
                sites = a.disassemble(data, record["segments"], os.environ.get("OBJDUMP", "objdump"))
                self.assertTrue(any(site["address"] == 0x400001 and site["mnemonic"] == name for site in sites), sites)

    def test_many_function_symbols_reuse_decodes_instead_of_spawning_per_boundary(self):
        data = many_symbol_fixture(2048)
        with patch.object(a.subprocess, "run", wraps=a.subprocess.run) as run:
            report, accepted = self.inspect(data)
        self.assertTrue(accepted, report)
        self.assertLessEqual(run.call_count, 3)
        self.assertEqual(report["artifacts"]["/fixture"]["sites"], [])

    def test_executable_page_alias_is_refused(self):
        data = bytearray(fixture())
        struct.pack_into("<H", data, 56, 2)
        struct.pack_into("<IIQQQQQQ", data, 120, 1, 4, 0x1000, 0x400100, 0, 1, 1, 0x1000)
        with self.assertRaisesRegex(a.Rejected, "memory-page alias"):
            self.inspect(data)


class AdmissionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.root = self.base / "root"
        self.root.mkdir()
        self.binary = self.root / "unexecutable"
        self.binary.write_bytes(fixture())
        self.binary.chmod(0o644)

    def scan(self):
        return a.inventory(self.root, os.environ.get("OBJDUMP", "objdump"))

    def admitted(self, report):
        return a.verify(report)

    def test_nonexecutable_elf_is_inventoried_and_admitted(self):
        report, _ = self.scan()
        self.assertIn("/unexecutable", report["artifacts"])
        self.assertFalse(report["admitted"])
        self.assertTrue(self.admitted(report))

    def test_save_instructions_outside_a_loader_trampoline_rejected(self):
        for opcode in (b"\x0f\xae\x27", b"\x0f\xae\x37", b"\x0f\xc7\x27", b"\x0f\xc7\x2f", b"\x48\x0f\xae\x27"):
            with self.subTest(opcode=opcode.hex()):
                self.binary.write_bytes(fixture(opcode + b"\xc3"))
                report, _ = self.scan()
                self.assertTrue(any(s["mnemonic"] in a.SAVE for s in report["artifacts"]["/unexecutable"]["sites"]))
                self.assertFalse(self.admitted(report))

    def test_lazy_binding_resolver_trampoline_admitted(self):
        for save in (b"\x0f\xae\x64\x24\x40", b"\x0f\xc7\x64\x24\x40"):
            with self.subTest(save=save.hex()):
                self.binary.write_bytes(fixture(resolver_trampoline(save)))
                report, _ = self.scan()
                sites = [s for s in report["artifacts"]["/unexecutable"]["sites"] if s["mnemonic"] in a.SAVE]
                self.assertEqual([s["loader_trampoline"] for s in sites], ["eager-resolver"])
                self.assertTrue(self.admitted(report))

    def test_resolver_trampoline_with_other_save_operand_or_entry_branch_rejected(self):
        for code in (resolver_trampoline(b"\x0f\xae\x64\x24\x48"), resolver_trampoline(entry_jump=b"\x90"), resolver_trampoline(entry_jump=b"\xf2")):
            with self.subTest(code=code[:8].hex()):
                self.binary.write_bytes(fixture(code))
                report, _ = self.scan()
                self.assertFalse(self.admitted(report))

    def test_xgetbv_selector_and_incoming_branch(self):
        for code, accepted in [(b"\x31\xc9\x0f\x01\xd0\xc3", True), (b"\xb9\x01\0\0\0\x0f\x01\xd0\xc3", False), (b"\xeb\x02\x31\xc9\x0f\x01\xd0\xc3", False)]:
            with self.subTest(code=code.hex()):
                self.binary.write_bytes(fixture(code))
                report, _ = self.scan()
                self.assertEqual(self.admitted(report), accepted)

    def test_tlsdesc_relocation_tables(self):
        for address_tag, size_tag, stride in ((7, 8, 24), (17, 18, 16), (23, 2, 24)):
            for relocation, expected in ((8, False), (34, True), (35, True), (36, True)):
                with self.subTest(table=address_tag, relocation=relocation):
                    data = bytearray(fixture(soname="fixture.so"))
                    entries = [(address_tag, 0x400100), (size_tag, stride)]
                    if address_tag == 23:
                        entries.append((20, 7))
                    entries.append((0, 0))
                    table = b"".join(struct.pack("<qQ", *entry) for entry in entries)
                    data[0x1200:0x1240] = table + bytes(64 - len(table))
                    struct.pack_into("<QQ", data, 0x1100, 0, (1 << 32) | relocation)
                    self.assertEqual(a.elf(bytes(data))["tlsdesc"], expected)
                    struct.pack_into("<Q", data, 0x1218, stride - 1)
                    with self.assertRaisesRegex(a.Rejected, "relocation table size"):
                        a.elf(bytes(data))

    def test_missing_dependency(self):
        self.binary.write_bytes(fixture(needed="libfixture.so"))
        with self.assertRaisesRegex(a.Rejected, "missing ELF dependency"):
            self.scan()

    def test_dependency_symlink_and_full_inventory(self):
        self.binary.write_bytes(fixture(needed="libfixture.so"))
        (self.root / "lib").mkdir()
        (self.root / "hidden").mkdir()
        (self.root / "hidden/library").write_bytes(fixture())
        (self.root / "lib/libfixture.so").symlink_to("/hidden/library")
        report, data = self.scan()
        dep = report["artifacts"]["/unexecutable"]["dependencies"][0]
        self.assertEqual(dep["resolved"], "/hidden/library")
        self.assertEqual(dep["symlinks"], [{"path": "/lib/libfixture.so", "target": "/hidden/library"}])
        self.assertIn("/hidden/library", report["artifacts"])

    def test_writable_executable_rejected(self):
        self.binary.write_bytes(fixture(flags=7))
        report, _ = self.scan()
        self.assertFalse(self.admitted(report))
        self.assertIn("writable executable", report["errors"][0])

    def test_executable_stack_rejected(self):
        for flags, rejected in ((6, False), (7, True)):
            with self.subTest(flags=flags):
                data = bytearray(fixture())
                struct.pack_into("<H", data, 56, 2)
                struct.pack_into("<IIQQQQQQ", data, 120, 0x6474E551, flags, 0, 0, 0, 0, 0, 16)
                record = a.elf(bytes(data))
                self.assertEqual(record["executable_stack"], rejected)
                record.update(sha256=a.digest(data), sites=[], writable_executable_segments=[])
                report = {"rootfs_sha256": "fixture", "artifacts": {"/fixture": record}}
                self.assertEqual(self.admitted(report), not rejected)
                if rejected:
                    self.assertIn("executable ELF stack", report["errors"][0])

    def test_uid_gid_bound(self):
        report, _ = self.scan()
        entry = next(f for f in report["files"] if f["path"] == "/unexecutable")
        self.assertEqual(entry["uid"], self.binary.stat().st_uid)
        self.assertEqual(entry["gid"], self.binary.stat().st_gid)
        self.assertIn("xattrs", entry)

    @unittest.skipUnless(os.geteuid() == 0, "ownership mutation requires root")
    def test_ownership_changes_the_tree_digest(self):
        report, _ = self.scan()
        os.chown(self.binary, self.binary.stat().st_uid, self.binary.stat().st_gid + 1)
        changed, _ = self.scan()
        self.assertNotEqual(report["rootfs_sha256"], changed["rootfs_sha256"])

    def test_xattr_changes_the_tree_digest(self):
        report, _ = self.scan()
        try:
            os.setxattr(self.binary, "user.admission-test", b"changed")
        except OSError as error:
            self.skipTest(f"test filesystem lacks user xattrs: {error}")
        changed, _ = self.scan()
        self.assertNotEqual(report["rootfs_sha256"], changed["rootfs_sha256"])

    def test_unreadable_xattrs_rejected(self):
        with patch.object(os, "listxattr", side_effect=PermissionError("denied")):
            with self.assertRaisesRegex(a.Rejected, "extended attributes"):
                self.scan()

    def test_dynamic_interpreter_rejected(self):
        data = bytearray(fixture())
        interpreter = b"/lib/ld-musl-x86_64.so.1\0"
        struct.pack_into("<H", data, 56, 2)
        struct.pack_into("<IIQQQQQQ", data, 120, 3, 4, len(data), 0, 0, len(interpreter), len(interpreter), 1)
        data.extend(interpreter)
        self.binary.write_bytes(data)
        with self.assertRaisesRegex(a.Rejected, "unsupported dynamic interpreter"):
            self.scan()

    def dynamic_tree(self):
        data = bytearray(fixture(needed="libfixture.so"))
        interpreter = a.GLIBC_INTERPRETER.encode() + b"\0"
        struct.pack_into("<H", data, 56, 3)
        struct.pack_into("<IIQQQQQQ", data, 176, 3, 4, len(data), 0, 0, len(interpreter), len(interpreter), 1)
        data.extend(interpreter)
        self.binary.write_bytes(data)
        (self.root / "lib64").mkdir()
        (self.root / "lib64/ld-linux-x86-64.so.2").write_bytes(fixture(soname="ld-linux-x86-64.so.2"))
        (self.root / "lib").mkdir()
        (self.root / "lib/libfixture.so").write_bytes(fixture())

    def test_dynamic_closure_requires_the_canonical_glibc_loader(self):
        self.dynamic_tree()
        report, _ = self.scan()
        self.assertTrue(self.admitted(report))
        report["artifacts"][a.GLIBC_INTERPRETER]["soname"] = "ld-other.so"
        self.assertFalse(self.admitted(report))
        self.assertIn("canonical glibc loader", report["errors"][0])

    def test_missing_transitive_dependency(self):
        self.dynamic_tree()
        (self.root / "lib/libfixture.so").write_bytes(fixture(needed="libmissing.so"))
        with self.assertRaisesRegex(a.Rejected, "missing ELF dependency"):
            self.scan()

    def test_loader_cache_rejected(self):
        self.dynamic_tree()
        (self.root / "etc").mkdir()
        (self.root / "etc/ld.so.cache").write_bytes(b"cache")
        with self.assertRaisesRegex(a.Rejected, "loader cache"):
            self.scan()

    def test_ambiguous_library_rejected(self):
        self.dynamic_tree()
        (self.root / "usr/lib").mkdir(parents=True)
        (self.root / "usr/lib/libfixture.so").write_bytes(fixture(b"\x90\xc3"))
        with self.assertRaisesRegex(a.Rejected, "ambiguous differing"):
            self.scan()

    def test_differing_duplicate_sonames_rejected(self):
        self.binary.write_bytes(fixture(soname="libsame.so"))
        (self.root / "elsewhere").write_bytes(fixture(b"\x90\xc3", soname="libsame.so"))
        with self.assertRaisesRegex(a.Rejected, "differing ELF SONAME"):
            self.scan()

    def test_no_needed_dynamic_paths_rejected(self):
        for tag in (15, 29):
            data = bytearray(fixture(soname="/lib"))
            struct.pack_into("<q", data, 0x1200, tag)
            self.binary.write_bytes(data)
            with self.assertRaisesRegex(a.Rejected, "RPATH/RUNPATH"):
                self.scan()
        self.binary.write_bytes(fixture(soname="libfixture.so"))
        (self.root / "etc").mkdir()
        (self.root / "etc/ld.so.cache").symlink_to("/does-not-exist")
        with self.assertRaisesRegex(a.Rejected, "loader cache"):
            self.scan()

    def test_straightline_xgetbv_proof(self):
        cases = [
            (b"\x31\xc9\xb8\x01\0\0\0\x09\xd0\x0f\x01\xd0\xc3", True),
            (b"\x31\xc9\xb9\x01\0\0\0\x0f\x01\xd0\xc3", False),
            (b"\x31\xc9\xb1\x01\x0f\x01\xd0\xc3", False),
            (b"\x31\xc9\xeb\x00\x0f\x01\xd0\xc3", False),
            (b"\x31\xc9\xe8\0\0\0\0\x0f\x01\xd0\xc3", False),
            (b"\xeb\x02\x31\xc9\xb8\x01\0\0\0\x0f\x01\xd0\xc3", False),
        ]
        for code, accepted in cases:
            with self.subTest(code=code.hex()):
                self.binary.write_bytes(fixture(code))
                report, _ = self.scan()
                self.assertEqual(self.admitted(report), accepted)

    def test_musl_configuration_rejected(self):
        self.binary.write_bytes(fixture(needed="libfixture.so"))
        (self.root / "etc").mkdir()
        (self.root / "etc/ld-musl-x86_64.path").write_text("/custom")
        with self.assertRaisesRegex(a.Rejected, "musl loader configuration"):
            self.scan()

    def test_elf_parser_rejects_truncation(self):
        with self.assertRaises(a.Rejected):
            a.elf(fixture()[:-1])
        self.assertEqual(a.elf(fixture())["segments"][0]["flags"], 5)

    def test_guest_symlink_cannot_escape(self):
        (self.root / "escape").symlink_to("../../outside")
        with self.assertRaisesRegex(a.Rejected, "escapes root"):
            a.resolve(self.root, "/escape")

    def test_read_failure_not_silently_skipped(self):
        original = Path.open
        def denied(path, *args, **kwargs):
            if path.resolve() == self.binary.resolve():
                raise PermissionError("fixture unreadable")
            return original(path, *args, **kwargs)
        with patch.object(Path, "open", denied):
            with self.assertRaises(PermissionError):
                self.scan()

    def initramfs(self, device_minor=3):
        return newc([("bin", stat.S_IFDIR | 0o755, b"", (0, 0)),
                     ("bin/app", stat.S_IFREG | 0o4755, fixture(), (0, 0)),
                     ("bin/sh", stat.S_IFLNK | 0o777, b"/bin/app", (0, 0)),
                     ("dev", stat.S_IFDIR | 0o755, b"", (0, 0)),
                     ("dev/null", stat.S_IFCHR | 0o666, b"", (1, device_minor))])

    def test_initramfs_devices_metadata_and_archive_binding(self):
        archive = self.base / "initramfs.gz"
        archive.write_bytes(gzip.compress(self.initramfs(), mtime=0))
        report, data = a.inventory_initramfs(archive)
        files = {f["path"]: f for f in report["files"]}
        self.assertEqual(files["/dev/null"]["rdev"], [1, 3])
        self.assertEqual(files["/bin/app"]["mode"], 0o4755)
        self.assertEqual(files["/bin/sh"]["target"], "/bin/app")
        self.assertTrue(self.admitted(report))
        archive.write_bytes(gzip.compress(self.initramfs(5), mtime=0))
        changed, _ = a.inventory_initramfs(archive)
        self.assertNotEqual(changed["rootfs_sha256"], report["rootfs_sha256"])
        self.assertNotEqual(changed["archive_sha256"], report["archive_sha256"])

    def test_newc_duplicates_truncation_and_traversal(self):
        with self.assertRaisesRegex(a.Rejected, "duplicate"):
            a.parse_newc(newc([("a", stat.S_IFREG | 0o644, b"", (0, 0)), ("./a", stat.S_IFREG | 0o644, b"", (0, 0))]))
        for name in ("../escape", "/absolute", "a/../../escape"):
            with self.assertRaises(a.Rejected):
                a.parse_newc(newc([(name, stat.S_IFREG | 0o644, b"", (0, 0))]))
        for truncated in (self.initramfs()[:20], self.initramfs()[:-1]):
            with self.assertRaises(a.Rejected):
                a.parse_newc(truncated)
        with self.assertRaisesRegex(a.Rejected, "concatenated"):
            a.parse_newc(self.initramfs() + self.initramfs())

    def test_newc_symlink_parent_is_not_extracted(self):
        archive = self.base / "unsafe.cpio"
        archive.write_bytes(newc([("outside", stat.S_IFLNK | 0o777, b"/tmp", (0, 0)),
                                 ("outside/payload", stat.S_IFREG | 0o644, fixture(), (0, 0))]))
        with self.assertRaisesRegex(a.Rejected, "not a directory"):
            a.inventory_initramfs(archive)

    def test_text_relocations_rejected(self):
        for tag, value in ((22, 0), (30, 4)):
            with self.subTest(tag=tag):
                data = bytearray(fixture(soname="libfixture.so"))
                struct.pack_into("<qQ", data, 0x1200, tag, value)
                self.binary.write_bytes(data)
                report, _ = self.scan()
                self.assertTrue(report["artifacts"]["/unexecutable"]["text_relocations"])
                self.assertFalse(self.admitted(report))
                self.assertIn("text relocations", report["errors"][0])

    def test_tlsdesc_relocations_rejected(self):
        report, _ = self.scan()
        self.assertTrue(self.admitted(report))
        report["artifacts"]["/unexecutable"]["tlsdesc"] = True
        self.assertFalse(self.admitted(report))
        self.assertIn("TLSdesc relocation", report["errors"][0])

    def test_newc_kernel_symlink_terminator(self):
        records = a.parse_newc(newc([("link", stat.S_IFLNK | 0o777, b"/bin/app\0", (0, 0))]))
        item, _ = records[0]
        self.assertEqual(item["target"], "/bin/app")
        self.assertEqual(item["sha256"], a.digest(b"/bin/app\0"))
        with self.assertRaisesRegex(a.Rejected, "symlink target"):
            a.parse_newc(newc([("link", stat.S_IFLNK | 0o777, b"/bin/app\0extra", (0, 0))]))

    def test_malformed_report_rejected(self):
        self.assertFalse(self.admitted({"artifacts": {"/fixture": {}}}))


if __name__ == "__main__":
    unittest.main()

// SPDX-License-Identifier: AGPL-3.0-or-later
// Clean-room implementation of the public libvoidstar ABI used by Antithesis SDKs.
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <signal.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#ifdef __linux__
#include <sys/syscall.h>
#endif

#ifndef HARMONY_OPEN
#define HARMONY_OPEN(path, flags) open((path), (flags))
#endif
#ifndef HARMONY_CLOSE
#define HARMONY_CLOSE(fd) close((fd))
#endif
#ifndef HARMONY_READ
#define HARMONY_READ(fd, buf, len) read((fd), (buf), (len))
#endif
#ifndef HARMONY_WRITE
#define HARMONY_WRITE(fd, buf, len) write((fd), (buf), (len))
#endif
#ifndef HARMONY_IOCTL
#include <sys/ioctl.h>
#define HARMONY_IOCTL(fd, command, arg) ioctl((fd), (command), (arg))
#endif
static pthread_mutex_t harmony_device_lock = PTHREAD_MUTEX_INITIALIZER;

enum {
    HARMONY_CMD_ENTROPY = 0,
    HARMONY_COVERAGE_REQUEST_SIZE = 16,
    HARMONY_COVERAGE_RESPONSE_SIZE = 12
};

/* Matches struct harmony_ioc_coverage in the guest kernel's uapi/linux/harmony.h. */
struct harmony_ioc_coverage {
    unsigned char request[HARMONY_COVERAGE_REQUEST_SIZE];
    unsigned char response[HARMONY_COVERAGE_RESPONSE_SIZE];
    uint32_t reserved;
};

_Static_assert(sizeof(struct harmony_ioc_coverage) == 32,
               "coverage ioctl layout");

#define HARMONY_IOC_COVERAGE 0xC0204803UL

struct harmony_coverage_state {
    uint32_t thread;
    uint32_t ready;
    uint32_t selected;
    uint64_t counter;
    uint64_t threshold;
};

static _Thread_local struct harmony_coverage_state harmony_coverage = {
    0, 1, 0, 0, 1
};
static _Thread_local volatile sig_atomic_t harmony_device_held;
static int harmony_coverage_fd = -1;
static uint64_t harmony_next_edge;
static const uint64_t harmony_lease_generation = 1;

static int device_lock(void)
{
    harmony_device_held = 1;
    if (pthread_mutex_lock(&harmony_device_lock) != 0) {
        harmony_device_held = 0;
        return -1;
    }
    return 0;
}

static void device_unlock(void)
{
    (void)pthread_mutex_unlock(&harmony_device_lock);
    harmony_device_held = 0;
}

static void harmony_before_fork(void)
{
    (void)device_lock();
}

static void harmony_after_fork(void)
{
    device_unlock();
}

static void harmony_child_after_fork(void)
{
    harmony_coverage = (struct harmony_coverage_state){0, 1, 0, 0, 1};
    harmony_after_fork();
}

__attribute__((constructor)) static void harmony_initialize(void)
{
    (void)pthread_atfork(harmony_before_fork, harmony_after_fork,
                         harmony_child_after_fork);
}

static uint32_t harmony_thread_id(void)
{
#ifdef __linux__
    return (uint32_t)syscall(SYS_gettid);
#else
    uint64_t thread = 0;
    (void)pthread_threadid_np(NULL, &thread);
    return (uint32_t)thread;
#endif
}

/* The R-L3 transport ruling fixes the device path; it is not configurable. */
static const char harmony_device_path[] = "/dev/harmony";

static int write_all(int fd, const unsigned char *data, size_t size)
{
    size_t written = 0;

    while (written < size) {
        ssize_t result = HARMONY_WRITE(fd, data + written, size - written);
        if (result < 0 && errno == EINTR)
            continue;
        if (result <= 0)
            return -1;
        written += (size_t)result;
    }
    return 0;
}

static int read_all(int fd, unsigned char *data, size_t size)
{
    size_t consumed = 0;

    while (consumed < size) {
        ssize_t result = HARMONY_READ(fd, data + consumed, size - consumed);
        if (result < 0 && errno == EINTR)
            continue;
        if (result <= 0)
            return -1;
        consumed += (size_t)result;
    }
    return 0;
}

void fuzz_json_data(const char *data, size_t size)
{
    int fd;
    int result;

    if ((data == NULL && size != 0) || size > (size_t)SSIZE_MAX)
        abort();
    if (device_lock() != 0)
        abort();
    fd = HARMONY_OPEN(harmony_device_path, O_WRONLY | O_CLOEXEC);
    if (fd < 0) {
        device_unlock();
        abort();
    }
    result = write_all(fd, (const unsigned char *)data, size);
    (void)HARMONY_CLOSE(fd);
    device_unlock();
    if (result != 0)
        abort();
}

uint64_t fuzz_get_random(void)
{
    static const unsigned char request = HARMONY_CMD_ENTROPY;
    unsigned char bytes[8];
    uint64_t value = 0;
    int fd;
    size_t index;

    if (device_lock() != 0)
        abort();
    fd = HARMONY_OPEN(harmony_device_path, O_RDWR | O_CLOEXEC);
    if (fd < 0) {
        device_unlock();
        abort();
    }
    if (write_all(fd, &request, sizeof(request)) != 0 ||
        read_all(fd, bytes, sizeof(bytes)) != 0) {
        (void)HARMONY_CLOSE(fd);
        device_unlock();
        abort();
    }
    (void)HARMONY_CLOSE(fd);
    for (index = 0; index < sizeof(bytes); index++)
        value |= (uint64_t)bytes[index] << (index * CHAR_BIT);
    device_unlock();
    return value;
}

void fuzz_flush(void)
{
}

static void put_u32(unsigned char *out, uint32_t value)
{
    size_t index;

    for (index = 0; index < 4; index++)
        out[index] = (unsigned char)(value >> (index * CHAR_BIT));
}

static void put_u64(unsigned char *out, uint64_t value)
{
    size_t index;

    for (index = 0; index < 8; index++)
        out[index] = (unsigned char)(value >> (index * CHAR_BIT));
}

static uint32_t get_u32(const unsigned char *in)
{
    uint32_t value = 0;
    size_t index;

    for (index = 0; index < 4; index++)
        value |= (uint32_t)in[index] << (index * CHAR_BIT);
    return value;
}

static uint64_t get_u64(const unsigned char *in)
{
    uint64_t value = 0;
    size_t index;

    for (index = 0; index < 8; index++)
        value |= (uint64_t)in[index] << (index * CHAR_BIT);
    return value;
}

__attribute__((weak)) void harmony_instrumentation_event(uint64_t site)
{
    (void)site;
}

/*
 * Give an instrumented logical thread a stable identity and runnable-set
 * width. The first prescribed threshold is one basic block. Reconfiguration
 * resets only this calling thread's TLS counter.
 */
int harmony_coverage_configure(uint32_t thread, uint32_t ready)
{
    if (ready == 0)
        return -1;
    harmony_coverage.thread = thread;
    harmony_coverage.ready = ready;
    harmony_coverage.selected = 0;
    harmony_coverage.counter = 0;
    harmony_coverage.threshold = 1;
    return 0;
}

uint32_t harmony_coverage_selected(void)
{
    return harmony_coverage.selected;
}

static int coverage_ioctl(struct harmony_ioc_coverage *coverage)
{
    int result;

    do
        result = HARMONY_IOCTL(harmony_coverage_fd, HARMONY_IOC_COVERAGE, coverage);
    while (result < 0 && errno == EINTR);
    return result;
}

static int coverage_open(void)
{
    harmony_coverage_fd = HARMONY_OPEN(harmony_device_path, O_RDWR | O_CLOEXEC);
    if (harmony_coverage_fd >= 0)
        return 0;
    return errno == ENOENT ? 1 : -1;
}

static int coverage_exchange(uint64_t observed)
{
    struct harmony_ioc_coverage coverage = {{0}, {0}, 0};
    uint64_t next;
    uint32_t selected;
    int status = 0;

    put_u32(coverage.request, harmony_coverage.thread);
    put_u64(coverage.request + 4, observed);
    put_u32(coverage.request + 12, harmony_coverage.ready);
    if (pthread_mutex_lock(&harmony_device_lock) != 0)
        return -1;
    if (harmony_coverage_fd < 0)
        status = coverage_open();
    if (status == 0 && coverage_ioctl(&coverage) != 0) {
        status = -1;
        if (errno == EBADF || errno == ENOTTY) {
            status = coverage_open();
            if (status == 0 && coverage_ioctl(&coverage) != 0)
                status = -1;
        }
    }
    (void)pthread_mutex_unlock(&harmony_device_lock);
    if (status != 0)
        return status;
    next = get_u64(coverage.response);
    selected = get_u32(coverage.response + 8);
    if (next <= observed || selected >= harmony_coverage.ready)
        return -1;
    harmony_coverage.threshold = next;
    harmony_coverage.selected = selected;
    return 0;
}

uint64_t init_coverage_module(size_t edges, const char *symbols)
{
    uint64_t offset;
    (void)symbols;
    if (device_lock() != 0)
        return 0;
    offset = harmony_next_edge;
    if ((uint64_t)edges >= UINT64_MAX - offset)
        abort();
    harmony_next_edge += (uint64_t)edges + 1;
    device_unlock();
    return offset;
}

static void coverage_count(uint64_t hits)
{
    if (hits > UINT64_MAX - harmony_coverage.counter)
        harmony_coverage.counter = UINT64_MAX;
    else
        harmony_coverage.counter += hits;
    if (!harmony_device_held &&
        harmony_coverage.counter >= harmony_coverage.threshold) {
        int result;
        harmony_device_held = 1;
        result = coverage_exchange(harmony_coverage.threshold);
        harmony_device_held = 0;
        if (result < 0)
            abort();
        if (result > 0)
            harmony_coverage.threshold = UINT64_MAX;
    }
}

bool notify_coverage(size_t edge)
{
    if (harmony_coverage.thread == 0)
        harmony_coverage.thread = harmony_thread_id();
    harmony_instrumentation_event(edge);
    coverage_count(1);
    return true;
}

uint64_t harmony_coverage_add(uint64_t hits)
{
    if (harmony_coverage.thread == 0)
        harmony_coverage.thread = harmony_thread_id();
    coverage_count(hits);
    if (harmony_coverage.counter >= harmony_coverage.threshold)
        return 1;
    return harmony_coverage.threshold - harmony_coverage.counter;
}

uint64_t notify_coverage_v2(size_t edge, uint64_t hits)
{
    (void)hits;
    (void)notify_coverage(edge);
    return harmony_lease_generation << 40;
}

const uint64_t *coverage_lease_generation_addr(void)
{
    return &harmony_lease_generation;
}

uint64_t instrumentation_request_abi_version(uint64_t requested)
{
    return requested < 2 ? requested : 2;
}

void __sanitizer_cov_trace_pc_guard_init(uint32_t *start, uint32_t *stop)
{
    while (start != NULL && stop != NULL && start < stop) {
        if (*start == 0)
            *start = 1;
        start++;
    }
}

void __sanitizer_cov_trace_pc_guard_internal(uint32_t *guard, uint64_t site)
{
    if (guard != NULL && *guard != 0)
        notify_coverage(site);
}

void __sanitizer_cov_trace_pc_guard(uint32_t *guard)
{
    if (guard != NULL && *guard != 0)
        (void)notify_coverage((size_t)__builtin_return_address(0));
}

void __sanitizer_cov_trace_pc(void)
{
    (void)notify_coverage((size_t)__builtin_return_address(0));
}

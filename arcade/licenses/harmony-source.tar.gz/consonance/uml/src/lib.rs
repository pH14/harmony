// SPDX-License-Identifier: AGPL-3.0-or-later

mod bridge;
mod console;
mod launch;
#[cfg(target_os = "linux")]
mod memory;
mod process;
mod profile;
mod recording;
#[cfg(target_os = "linux")]
mod session;

pub use bridge::{Bridge, Event, event_hash};
pub use console::ConsoleTail;
pub use launch::{Exit, ExitReason, Guest, Launch, LaunchError};
#[cfg(target_os = "linux")]
pub use memory::{Checkpoints, MemoryError};
pub use process::group_members;
pub use profile::{
    Artifact, HostAuxv, HostIdentity, Profile, ProfileError, VerifiedProfile, VirtualTimeCosts,
};
pub use recording::{Recording, ReplayRefused};
#[cfg(target_os = "linux")]
pub use session::{Capture, Checkpoint, Session, SessionError, Stop};
